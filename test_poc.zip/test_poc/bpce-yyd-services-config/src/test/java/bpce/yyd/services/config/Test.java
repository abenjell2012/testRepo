package bpce.yyd.services.config;

import org.junit.Assert;

public class Test {

	@org.junit.Test
	public void testbidon() {
		// Arrange
		int val1 = 10;
		int val2 = 22;
		// Act
		int somme = val1 + val2;
		// Assert
		Assert.assertEquals(32, somme);
	}
}

#!/bin/sh
reponse=0
while read ligne
do
#result=`echo "$ligne" | awk -F "=" '{print $2}' | sed "s/\s\+//g"`
result=`echo $ligne | grep "/" | grep "=" | sed -e '/^#.*$/d' | sed -e '/^.*\/$/!d'`
if [ "$result" == "$ligne" ] && [ "$ligne" != "" ] && [ ! -d "`echo $ligne | awk -F "=" '{print $2}'`" ];then
   res=`echo $ligne | awk -F "=" '{print $2}'`
   echo "Creation du repertoire $res"
   mkdir -p "$res"
   reponse+=1
fi

#if [ `echo $ligne | grep "/$"` ] && [ ! -d "$result" ];then
#echo "Creation du repertoire $result"
#mkdir -p "$result"
done < /appli/ndod/config/config.properties

if [ $reponse == 0 ];then
   echo "l'arborescence est a jour ..."
fi

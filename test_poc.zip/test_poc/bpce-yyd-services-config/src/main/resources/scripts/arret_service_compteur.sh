#!/bin/sh
#sce=( "/appli/ndod/services/bpce-yyd-service-traitement-evenements*.jar" )
sce=( "/appli/ndod/services/bpce-yyd-service-calcul-compteur-lnk.jar" )
cnt=`ps -eaflc --sort stime | grep $sce |grep -v grep | wc -l`
if [ $cnt = 0 ]
then 
  echo "Warning: The service is already stoped!"
else
  pid=`ps -ef --sort stime | grep $sce | grep -v grep | awk '{print $2}'`
  kill $pid
  sleep 1
  if ! ps -p $pid > /dev/null ;
   then
    echo "INFO: The service is stoped successfully"
  else
    echo "ERROR: The service could not be stoped"
  fi
fi
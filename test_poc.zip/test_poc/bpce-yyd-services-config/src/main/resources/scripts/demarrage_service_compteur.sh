#!/bin/sh
declare -a sce=( "/appli/ndod/services/bpce-yyd-service-calcul-compteur-lnk.jar" )   
# get length of an array
arraylength=${#sce[@]}
# use for loop to read all values and indexes
for (( i=1; i<${arraylength}+1; i++ ));
do
y=${sce[$i-1]}
cnt=`ps -eaflc --sort stime | grep $y |grep -v grep | wc -l`
if [ $cnt = 0 ]
then
echo "INFO: Starting the service..."

nohup java -jar $sce --spring.config.location=file:/appli/ndod/config/service-calcul-compteur.yml -Dlogging.config=file:/appli/ndod/config/logback-compteur.xml $1 &>/dev/null &
spcnt=`ps -eaflc --sort stime | grep $y |grep -v grep | wc -l`
if [ $spcnt = 0 ]
   then
   echo "ERROR: Service couldn't be started correctly ..."
   exit 1 
 elif [ $spcnt != 0 ]
   then
   echo "INFO: Service is started successfully, enjoy it."
   continue
fi
elif [ $cnt != 0 ] 
then
  echo "Warning: It seems that the service is already running, it must be stoped before continue."
fi
done

import com.michelin.cio.hudson.plugins.rolestrategy.RoleBasedAuthorizationStrategy
import com.synopsys.arc.jenkins.plugins.rolestrategy.RoleType
import hudson.tasks.Mailer
import hudson.FilePath

def call(Map map) {
	def recipients = getAllUserEmailByRole('user-bpce-sa-' + getFolderName()).join(", ")
	//def recipients = "Nicolas.AUTIE@bpce.fr;Yves.LING@bpce.fr;Wassim.JAAFAR_EXT@bpce.fr"
	def parametersMap = [dockerName : 'bpcesa/build-java:jdk8-mvn3.5.3-1', goalBuild : 'clean package -Dmaven.test.failure.ignore=true',goalDeploy : 'deploy -Dmaven.test.skip']

    if(map) {
		parametersMap << map
	}
	pipeline {
		triggers {
			bitbucketPush()
		}
		options {
			//on garde que 5 build success dans jenkins
			buildDiscarder(logRotator(numToKeepStr: '5', daysToKeepStr:'5'))
		}
		agent {
			docker {
				//execution du job sur les noeuds dont le tag jenkins est swarm
				label 'swarm'
				//recuperation de l'image docker pour maven
				image parametersMap.dockerName
				registryUrl 'http://picnex000.dom101.mapres:8082'
				registryCredentialsId 'dockerRegistryCredentials'

			}
		}
		stages {
			//recuperation des sources de Bitbucket
			stage('scm') {
			steps {
				checkout([$class: 'GitSCM', branches: scm.branches, doGenerateSubmoduleConfigurations: false, extensions: [], submoduleCfg: [], userRemoteConfigs: scm.userRemoteConfigs])
				}
			}
			//compilation du code source + test unitaire
			stage('build') {
				steps {
                   configFileProvider([configFile(fileId: '72323f9c-589b-4ec4-b068-b20fdd0fa71f', variable: 'MAVEN_SETTINGS')]){
                     sh 'mvn -s "$MAVEN_SETTINGS" org.apache.maven.plugins:maven-help-plugin:2.2:active-profiles'
                     sh 'mvn -s "$MAVEN_SETTINGS" -B ' + parametersMap.goalBuild
                   }
				
				}
			}
			stage('sonar') {
				steps {
					withSonarQubeEnv('SONAR') {
						  configFileProvider([configFile(fileId: '72323f9c-589b-4ec4-b068-b20fdd0fa71f', variable: 'MAVEN_SETTINGS')]){
                      sh 'mvn -s "$MAVEN_SETTINGS" test -Dmaven.test.failure.ignore=true sonar:sonar'
                          }
					}
				}
			}
			//insertion de l'artefact dans nexus
			stage('nexus') {
				steps {
				  configFileProvider([configFile(fileId: '72323f9c-589b-4ec4-b068-b20fdd0fa71f', variable: 'MAVEN_SETTINGS')]){
                  sh 'mvn -s "$MAVEN_SETTINGS" -B ' + parametersMap.goalDeploy
                  }
				}
			}
		}
		
           stage('Publish') {  
              steps {
                 xldPublishPackage serverCredentials: 'XLD_BPCEIT_PROD', darPath: parametersMap.DarName+'-'+parametersMap.packageVersion+'.dar'
              }
            }
			
		}
		post {
			always {
				//insertion des resultats des tests unitaires dans Jenkins
			   // junit "**/target/surefire-reports/*.xml"
				//suppression du container maven
				sh 'docker ps -q -f status=exited | xargs --no-run-if-empty docker rm'
				sh 'docker images -q -f dangling=true | xargs --no-run-if-empty docker rmi'
				sh 'docker volume ls -qf dangling=true | xargs -r docker volume rm'

				script {
					if (currentBuild.result == null || currentBuild.result == 'SUCCESS') {
					  if (currentBuild.previousBuild != null && currentBuild.previousBuild.result != 'SUCCESS') {
						emailext (
							to: recipients,
							mimeType: 'text/html',
							compressLog: true,
							attachLog: true,
							subject: "BACK TO NORMAL : Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]'",
							body: """<p>BACK TO NORMAL: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]':</p>
						<p>Check console output at &QUOT;<a href='${env.BUILD_URL}'>${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>&QUOT;</p>"""
						)
						}
					}
				}
			}
			success { echo 'I succeeeded!' }
			unstable { echo 'I am unstable :/' }
		
			changed { echo 'Things were different before...' }
		}
	}
}

def getFolderName() {
	return "${JOB_NAME}".tokenize("/")[0]
}

def getAllUserEmailByRole(String role) {
     def emails = []
     def authStrategy = Jenkins.instance.getAuthorizationStrategy()
     if(authStrategy instanceof RoleBasedAuthorizationStrategy){
          grantedRoles = authStrategy.getGrantedRoles(RoleType.Project).findAll {it.key.name == role}
          grantedRoles.each { grantedRole ->
                grantedRole.getValue().each { sid ->
                emails.add(Jenkins.instance.getUser(sid).getProperty(Mailer.UserProperty.class).getAddress())
                }      
          }
     }
     return emails
}

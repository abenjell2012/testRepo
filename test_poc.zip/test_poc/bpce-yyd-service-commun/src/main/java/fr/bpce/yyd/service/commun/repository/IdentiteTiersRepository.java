package fr.bpce.yyd.service.commun.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.service.commun.beans.InfoTiers;

@Repository
public interface IdentiteTiersRepository extends CrudRepository<IdentiteTiers, Long> {

	@Query(value = "select i from IdentiteTiers i where i.tiers.id = :idTiers order by i.dateDebut desc")
	List<IdentiteTiers> rechercheIdentitesActivesADate(@Param("idTiers") Long idTiers);

	@Query(value = "select i from IdentiteTiers i where i.tiers.id in (:idTiersL) and i.dateFin is null order by i.dateDebut desc")
	List<IdentiteTiers> rechercheIdentitesActivesADateByIdTiersList(@Param("idTiersL") List<Long> idTiersL);

	@Query(value = "select t.id as idTiers, t.id_rft as idFederal, i.code_Bq as codeBanque, i.id_Local as idLocal from tiers t "
			+ "inner join identite_tiers i on i.tiers_id = t.id "
			+ "where i.date_fin is null and t.id in (:idTiersList) order by i.date_debut desc", nativeQuery = true)
	List<InfoTiers> rechercheIdentitesActives(@Param("idTiersList") List<Long> idTiersList);

	@Query(value = "select i from IdentiteTiers i where i.tiers.id in (:idsTiers) order by i.dateDebut desc")
	List<IdentiteTiers> rechercheIdentitesWithListTiersActivesADate(@Param("idsTiers") List<Long> idsTiers);

	@Query(value = "select t from Tiers t where id = :idTiers")
	Tiers chercheTiersParId(@Param("idTiers") Long idTiers);

	@Query(value = "select t from Tiers t where t.id in (:idTiersL) ")
	List<Tiers> rechercheTiersList(@Param("idTiersL") List<Long> idTiersL);
}
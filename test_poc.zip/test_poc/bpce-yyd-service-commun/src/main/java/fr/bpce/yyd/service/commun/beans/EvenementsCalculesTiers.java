package fr.bpce.yyd.service.commun.beans;

import java.util.ArrayList;
import java.util.List;

import fr.bpce.yyd.commun.model.ArriereSignificatif;
import fr.bpce.yyd.commun.model.EvenementCalcule;
import fr.bpce.yyd.commun.model.ImpayeSurForbearance;
import fr.bpce.yyd.commun.model.PeriodeProbatoire;

/**
 * Objet permettant de voir les Evenements Calcules d'un tiers selon leur type.
 *
 * @author zgud
 *
 */
public class EvenementsCalculesTiers {

	private final List<EvenementCalcule> evenementsCalcules;

	private ArriereSignificatif arriereSignigicatif = null;

	private PeriodeProbatoire periodeProbatoire = null;

	private List<ImpayeSurForbearance> impayesSurForbearance = new ArrayList<>();

	public EvenementsCalculesTiers(List<EvenementCalcule> evenementsCalcules) {
		this.evenementsCalcules = evenementsCalcules;
		repartitEvenements();
	}

	private final void repartitEvenements() {
		for (EvenementCalcule ec : evenementsCalcules) {
			if (ec instanceof ArriereSignificatif) {
				// A un instant donné, il ne peut y avoir qu'un seul arriéré significatif.
				arriereSignigicatif = (ArriereSignificatif) ec;
			} else if (ec instanceof PeriodeProbatoire) {
				// A un instant donné, il ne peut y avoir qu'une seule période probatoire.
				periodeProbatoire = (PeriodeProbatoire) ec;
			} else if (ec instanceof ImpayeSurForbearance) {
				impayesSurForbearance.add((ImpayeSurForbearance) ec);
			}
		}
	}

	public List<EvenementCalcule> getEvenementsCalcules() {
		return evenementsCalcules;
	}

	public ArriereSignificatif getArriereSignigicatif() {
		return arriereSignigicatif;
	}

	public PeriodeProbatoire getPeriodeProbatoire() {
		return periodeProbatoire;
	}

	public List<ImpayeSurForbearance> getImpayesSurForbearance() {
		return impayesSurForbearance;
	}

	public void setPeriodeProbatoire(PeriodeProbatoire periodeProbatoire) {
		this.periodeProbatoire = periodeProbatoire;
	}

	public void setArriereSignigicatif(ArriereSignificatif arriereSignigicatif) {
		this.arriereSignigicatif = arriereSignigicatif;
	}

	public void setImpayesSurForbearance(List<ImpayeSurForbearance> impayesSurForbearance) {
		this.impayesSurForbearance = impayesSurForbearance;
	}

}

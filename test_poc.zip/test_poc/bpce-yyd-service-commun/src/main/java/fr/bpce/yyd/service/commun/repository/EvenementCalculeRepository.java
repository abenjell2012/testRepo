package fr.bpce.yyd.service.commun.repository;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import fr.bpce.yyd.commun.model.ComplementArriere;
import fr.bpce.yyd.commun.model.EvenementCalcule;

@Repository
public interface EvenementCalculeRepository extends CrudRepository<EvenementCalcule, Long> {

	@Query(value = "select c from EvenementCalcule c where c.tiers.id = :idTiers and c.dateDebut <= :dateCalcul and (c.dateFin is null or c.dateFin > :dateCalcul) order by c.dateDebut asc")
	List<EvenementCalcule> rechercheEvenementsCalculesActifsADate(@Param("idTiers") Long idTiers,
			@Param("dateCalcul") LocalDate date);

	@Query(value = "select c from EvenementCalcule c where c.tiers.id = :idTiers and ((c.dateDebut between :dateDeb and :dateFin) or (c.dateFin between :dateDeb and :dateFin)) order by c.dateDebut asc")
	List<EvenementCalcule> rechercheEvenementsCalculesEntreDeuxDates(@Param("idTiers") Long idTiers,
			@Param("dateDeb") LocalDate dateDeb, @Param("dateFin") LocalDate dateFin);

	@Query(value = "select c from EvenementCalcule c where c.tiers.id = :idTiers and c.dateFin is null")
	List<EvenementCalcule> rechercheEvenementCalculTiers(@Param("idTiers") Long idTiers);

	@Query(value = "select date_fin from (select date_fin from evenement_calcule e where e.tiers_id = :idTiers and e.code = 'AS' order by e.id desc) where rownum = 1", nativeQuery = true)
	Timestamp rechercheDateDernierArriereSignificatif(@Param("idTiers") Long idTiers);

	@Query(value = "select date_debut from (select date_debut from evenement_calcule e where e.tiers_id = :idTiers and e.code = 'AS' order by e.id desc) where rownum = 1", nativeQuery = true)
	Timestamp rechercheDateDebutArriereSignificatif(@Param("idTiers") Long idTiers);

	@Query(value = "select c from EvenementCalcule c where c.tiers.id in (:idsTiers) and c.dateDebut <= :dateCalcul and (c.dateFin is null or c.dateFin > :dateCalcul) order by c.dateDebut asc")
	List<EvenementCalcule> rechercheEvenementsCalculesWithListTiersActifsADate(@Param("idsTiers") List<Long> idsTiers,
			@Param("dateCalcul") LocalDate date);

	@Query(value = "select c from ComplementArriere c where c.idTiers in (:idsTiers)")
	List<ComplementArriere> rechercheComplementArriereTiers(@Param("idsTiers") List<Long> idsTiers);

}
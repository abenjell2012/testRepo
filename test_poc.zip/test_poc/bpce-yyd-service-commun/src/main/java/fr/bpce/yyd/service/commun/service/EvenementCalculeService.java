package fr.bpce.yyd.service.commun.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import fr.bpce.yyd.commun.enums.EvenementArriereSignificatif;
import fr.bpce.yyd.commun.messages.dto.LotIdTiersDTO;
import fr.bpce.yyd.commun.model.ArriereSignificatif;
import fr.bpce.yyd.commun.model.ComplementArriere;
import fr.bpce.yyd.commun.model.ElementsDeCalcul;
import fr.bpce.yyd.commun.model.Evenement;
import fr.bpce.yyd.commun.model.ImpayeSurForbearance;
import fr.bpce.yyd.commun.model.PeriodeProbatoire;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.service.commun.beans.EvenementsCalculesTiers;

/**
 * Interface de services autour des événements calculés.
 *
 * @author zgud
 *
 */
public interface EvenementCalculeService {

	/**
	 * Recherche de l'éventuel arriéré significatif du tiers à date donnée.
	 *
	 * @param idTiers
	 * @param dateCalcul
	 * @return
	 */
	ArriereSignificatif rechercheArriereSignificatifADate(Long idTiers, LocalDate dateCalcul);

	/**
	 * Retourne un ArriereSignificatif complet et correctement instancié, associé au
	 * tiers paramètre et débutant en date de 'enDateDu', associé au calcul passé.
	 *
	 * @param tiers
	 * @param enDateDu
	 * @param calcul
	 * @return
	 */
	ArriereSignificatif creeArriereSignificatif(Tiers tiers, LocalDate enDateDu, LocalDate dateCalcul,
			ElementsDeCalcul calcul, boolean chgtTiersId);

	/**
	 * Clot l'ArriereSignificatif 'aClore' en date de 'enDateDu', en l'associant au
	 * calcul passé.
	 *
	 * @param asAClore
	 * @param enDateDu
	 * @param calcul
	 */
	void closArriereSignificatif(ArriereSignificatif asAClore, LocalDate enDateDu, ElementsDeCalcul calcul,
			LocalDate dateCalcul);

	/**
	 * Retourne les événements calculés actifs d'un tiers à date, présentés au sein
	 * d'un EvenementsCalculesTiers qui les répartit par type.
	 *
	 * @param idTiers
	 * @param date
	 * @return
	 */
	EvenementsCalculesTiers rechercheEvenementsCalculesActifsADate(Long idTiers, LocalDate date);

	/**
	 * Caractérise sous forme d'EvenementArriereSignificatif l'ArriereSignificatif
	 * paramètre à date 'date' pour le tiers identifié.
	 *
	 * @param idTiers
	 * @param as
	 * @param date
	 * @return
	 */
	EvenementArriereSignificatif categoriseArriereSignificatif(Long idTiers, ArriereSignificatif as,
			LocalDate dateEtat);

	/**
	 * Construit une map donnant la date de chacun des événements AR0 à AR3 pour un
	 * ArriereSignificatif donné. La map est théorique, en fonction de la date de
	 * début de l'événement, et ne reflète pas ce qui s'est effectivement passé pour
	 * lui. L'idTiers sert à retrouver son segment.
	 *
	 * @param idTiers
	 * @param as       arriéré significatif pour lequel on demande un calendrier
	 * @param dateEtat date pour laquelle ce calendrier est demandé
	 * @return
	 */
	Map<EvenementArriereSignificatif, LocalDate> calculeCalendrierArriereSignificatif(Long idTiers,
			ArriereSignificatif as, LocalDate dateEtat);

	/**
	 * Création d'une période probatoire avec audit.
	 *
	 * @param tiers
	 * @param enDateDu
	 * @return
	 */
	PeriodeProbatoire creePeriodeProbatoire(Tiers tiers, LocalDate enDateDu, LocalDate dateCalcul);

	/**
	 * Clôture d'une période probatoire avec audit.
	 *
	 * @param pp
	 * @param enDateDu
	 */
	void closPeriodeProbatoire(PeriodeProbatoire pp, LocalDate enDateDu, LocalDate dateCalcul);

	/**
	 * Création d'un impayé sur forbearance.
	 *
	 * @param tiers
	 * @param enDateDu
	 * @param as
	 * @param forbearance
	 * @param impaye
	 * @return
	 */
	ImpayeSurForbearance creeImpayeSurForbearance(Tiers tiers, LocalDate enDateDu, ArriereSignificatif as,
			Evenement forbearance, Evenement impaye);

	/**
	 * Recherche liste des arriérés significatifs du tiers compris entre deux dates.
	 *
	 * @param idTiers
	 * @param dateDebut
	 * @param dateFin
	 * @return
	 */
	List<ArriereSignificatif> rechercheArriereSignificatifEntreDeuxDate(Long idTiers, LocalDate dateDebut,
			LocalDate dateFin);

	/**
	 * cloture liste des evenementCalcul du tiers.
	 *
	 * @param idTiers
	 * @param dateCalcul
	 * @return void
	 */
	void clotureEvenementCalcul(Long idTiers, LocalDate dateCalcul);

	/**
	 * Reourne le dernier AS du tiers passé en paramètre
	 *
	 * @param idTiers
	 */
	LocalDate rechercheDateFinDernierArriereSignificatif(Long idTiers);

	/**
	 * Reourne la date de début AS du tiers passé en paramètre
	 *
	 * @param idTiers
	 */
	LocalDate rechercheDateDebutArriereSignificatif(Long idTiers);

	Map<Long, EvenementsCalculesTiers> rechercheEvenementsCalculesActifsADate(LotIdTiersDTO data);

	Map<Long, ComplementArriere> rechercheComplementArriere(LotIdTiersDTO data);

}

package fr.bpce.yyd.service.commun.service.impl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fr.bpce.yyd.commun.constantes.Constant;
import fr.bpce.yyd.commun.model.reference.RefImpactEvtMdc;
import fr.bpce.yyd.service.commun.repository.EvenementImpactRepository;
import fr.bpce.yyd.service.commun.service.EvenementImpactService;

@Service
public class EvenementImpactServiceImpl implements EvenementImpactService {
	private static final Logger LOG = LoggerFactory.getLogger(EvenementImpactServiceImpl.class);

	@Autowired
	private EvenementImpactRepository evenementImpactRepository;

	private List<RefImpactEvtMdc> listRefImpact = new ArrayList<>();

	public EvenementImpactServiceImpl() {
		super();
	}

	public List<RefImpactEvtMdc> chargeRefImpactEvtMdc() {
		if (listRefImpact.isEmpty()) {
			if (LOG.isDebugEnabled()) {
				LOG.debug("Chargement du référentiel REF_IMPACT_EVT_MDC");
			}
			listRefImpact = evenementImpactRepository.findAll();
		}
		return listRefImpact;
	}

	@Override
	public RefImpactEvtMdc findImpactEvenement(String codEvt, String catSegment, LocalDate dateDemande) {
		List<RefImpactEvtMdc> refImpactList = chargeRefImpactEvtMdc();
		// filter par rapport à la date de demande
		List<RefImpactEvtMdc> refImpactListADAte = refImpactList.stream()
				.filter(ref -> (ref.getDateDebut().compareTo(dateDemande) <= 0
						&& (ref.getDateFin() == null || ref.getDateFin().compareTo(dateDemande) > 0)))
				.collect(Collectors.toList());
		// filrer par rapport à codeEvt et catSegment
		RefImpactEvtMdc refImpactEvtMdc = refImpactListADAte.stream()
				.filter(ref -> ref.getCodEvt().equals(codEvt) && ref.getCategorieSegment().equals(catSegment))
				.findFirst().orElse(null);
		// filter par catSegment = TOUS_AUTRES si le résultat est nulle
		if (refImpactEvtMdc == null) {
			refImpactEvtMdc = refImpactListADAte.stream().filter(
					ref -> ref.getCodEvt().equals(codEvt) && ref.getCategorieSegment().equals(Constant.TOUS_AUTRES))
					.findFirst().orElse(null);
		}

		return refImpactEvtMdc;
	}

	public void setEvenementImpactRepository(EvenementImpactRepository evenementImpactRepository) {
		this.evenementImpactRepository = evenementImpactRepository;
	}

}

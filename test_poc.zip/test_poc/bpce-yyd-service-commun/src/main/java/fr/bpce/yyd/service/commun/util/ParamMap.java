package fr.bpce.yyd.service.commun.util;

import java.util.HashMap;

import fr.bpce.yyd.commun.enums.CodeParamMdc;

public class ParamMap extends HashMap<String, String> {

	private static final long serialVersionUID = 3381391750263915099L;

	/**
	 * Stocke la valeur 'value' associée à une clé composite.
	 *
	 * @param value
	 * @param codeParam
	 * @param keyParts
	 */
	public void putValueFor(String value, CodeParamMdc codeParam, String... keyParts) {
		put(buildKey(codeParam, keyParts), value);
	}

	/**
	 * Retourne la valeur associée à cette clé composite.
	 *
	 * @param codeParam
	 * @param keyParts
	 * @return
	 */
	public String get(CodeParamMdc codeParam, String... keyParts) {
		return super.get(buildKey(codeParam, keyParts));
	}

	/**
	 * Assemblage/concaténation des éléments de la clé composite en une seule
	 * chaîne.
	 *
	 * @param codeParam
	 * @param keyParts
	 * @return
	 */
	protected String buildKey(CodeParamMdc codeParam, String... keyParts) {
		StringBuilder ret = new StringBuilder(codeParam.name());
		for (String keyPart : keyParts) {
			ret.append('.').append(keyPart.trim());
		}
		return ret.toString();
	}
}

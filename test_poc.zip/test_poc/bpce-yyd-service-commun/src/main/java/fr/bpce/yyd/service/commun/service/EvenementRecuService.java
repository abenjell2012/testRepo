package fr.bpce.yyd.service.commun.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import fr.bpce.yyd.commun.messages.dto.LotIdTiersDTO;
import fr.bpce.yyd.commun.model.ComplementEvenement;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.service.commun.beans.EvenementsATraiter;

public interface EvenementRecuService {

	/**
	 * Retourne la liste des ComplementEvenement actifs à date, pour un tiers. Leurs
	 * Evenement sont déjà chargés en join ainsi que l'identité initiale.
	 *
	 * L'objet EvenementsATraiter en permet un accès par type : arriérés (IMX, DAX),
	 * Evenement defaut, F.
	 *
	 * @param idTiers
	 * @param dateCalcul
	 * @return
	 */
	EvenementsATraiter rechercheEvenementsATraiterADate(Long idTiers, LocalDate dateCalcul);

	List<ComplementEvenement> rechercheForbearenceClotureEntreDeuxDate(Long idTiers, LocalDate dateDeb,
			LocalDate dateFin);

	Map<Long, EvenementsATraiter> rechercheEvenementsATraiterADate(LotIdTiersDTO data,
			Map<Long, List<IdentiteTiers>> identities);

	List<ComplementEvenement> rechercheEvenementsActifsADate(LotIdTiersDTO data);
}

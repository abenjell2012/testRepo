package fr.bpce.yyd.service.commun.service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/**
 * Classe proposant une interface vers l'accès aux paramètres de l'application
 * NDoD.
 *
 * @author zgud
 *
 */
public interface ParametresNDoD {

	int getNbJoursPPStandard(String segment, LocalDate aDate);

	int getNbJoursPPForbearance(String segment, LocalDate aDate);

	int getNbJoursASVersDefaut(String segment, LocalDate aDate);

	int getNbJoursASRazDecomptePP(String segment, LocalDate aDate);

	int getSeuilAbsolu(String codeBanque, String segment, LocalDate aDate);

	public BigDecimal getSeuilRelatif(String segment, LocalDate aDate);

	int getNbJoursPourIFSurCtrtForbearance(String segment, LocalDate aDate);

	List<String> getCodBqAgregationNationale(LocalDate aDate);

	public LocalDate getDateCalculCourante();

	void updateDateCalculCourante(LocalDate valeurParam);

	int getProfondeurHistoEvts(LocalDate aDate);
}

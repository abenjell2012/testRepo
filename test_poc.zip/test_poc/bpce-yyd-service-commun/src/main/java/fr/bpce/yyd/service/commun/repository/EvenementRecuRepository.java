package fr.bpce.yyd.service.commun.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import fr.bpce.yyd.commun.model.ComplementEvenement;
import fr.bpce.yyd.commun.model.Evenement;

@Repository
public interface EvenementRecuRepository extends CrudRepository<Evenement, Long> {

	@Query(value = "select c,e from ComplementEvenement c inner join Evenement e on e.id = c.evenement inner join IdentiteTiers i on i.id = e.identiteInitiale inner join IdentiteTiers i2 on i.idLocal = i2.idLocal and i.codeBanque = i2.codeBanque and i2.dateFin is null where c.identiteInitiale = i.id and i2.tiers.id = :idTiers  and ((c.miseAJour = 1 and c.statutEvt = 'ACT' and c.datePhoto <= :dateCalcul) or ((c.miseAJour = 0 or c.statutEvt != 'ACT') and c.dateMaj <= :dateCalcul)) and (c.dateFin is null or c.dateFin > :dateCalcul)")
	List<Object[]> rechercheEvenementsActifsADate(@Param("idTiers") Long idTiers, @Param("dateCalcul") LocalDate date);

	@Query(value = "select c from ComplementEvenement c inner join Evenement e on e.id = c.evenement inner join IdentiteTiers i on i.id = e.identiteInitiale inner join IdentiteTiers i2 on i.idLocal = i2.idLocal and i.codeBanque = i2.codeBanque and i2.dateFin is null where c.identiteInitiale = i.id and i2.tiers.id = :idTiers and e.code = 'F' and c.dateFin = (select max(ce.dateFin) from ComplementEvenement ce inner join Evenement ev on ce.evenement = ev.id inner join IdentiteTiers i3 on i3.id = ev.identiteInitiale inner join IdentiteTiers i4 on i3.idLocal = i4.idLocal and i3.codeBanque = i4.codeBanque where ce.identiteInitiale = i3.id  and i4.tiers.id = :idTiers  and ev.code = 'F'  and ce.dateFin between :dateDeb and :dateFin)")
	List<ComplementEvenement> rechercheForbearenceClotureEntreDeuxDate(@Param("idTiers") Long idTiers,
			@Param("dateDeb") LocalDate dateDeb, @Param("dateFin") LocalDate dateFin);

	@Query(value = "select c, e from ComplementEvenement c inner join Evenement e on e.id = c.evenement inner join IdentiteTiers i on i.id = e.identiteInitiale inner join IdentiteTiers i2 on i.idLocal = i2.idLocal and i.codeBanque = i2.codeBanque and i2.dateFin is null where c.identiteInitiale = i.id and i2.tiers.id in (:idsTiers)  and ((c.miseAJour = 1 and c.statutEvt = 'ACT' and c.datePhoto <= :dateCalcul) or ((c.miseAJour = 0 or c.statutEvt != 'ACT') and c.dateMaj <= :dateCalcul)) and (c.dateFin is null or c.dateFin > :dateCalcul)")
	List<Object[]> rechercheEvenementsActifsWithListTiersADate(@Param("idsTiers") List<Long> idsTiers,
			@Param("dateCalcul") LocalDate date);

}
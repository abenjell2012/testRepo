package fr.bpce.yyd.service.commun.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import fr.bpce.yyd.commun.model.ParMdcBqSeg;


@Repository
public interface ParMdcBqSegRepository extends CrudRepository<ParMdcBqSeg, Long> {

	@Query(value = "select par from ParMdcBqSeg par where par.dateDebut <= :dateCalcul and (par.dateFin is null or par.dateFin > :dateCalcul)")
	List<ParMdcBqSeg> findAllParamMdcBqSegADate(@Param("dateCalcul") LocalDate dateCalcul);

}
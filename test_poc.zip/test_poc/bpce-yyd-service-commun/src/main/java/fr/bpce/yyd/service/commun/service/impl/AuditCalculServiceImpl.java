package fr.bpce.yyd.service.commun.service.impl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fr.bpce.yyd.commun.enums.StatutAuditEvenement;
import fr.bpce.yyd.commun.model.AuditCalcul;
import fr.bpce.yyd.commun.model.EvenementCalcule;
import fr.bpce.yyd.service.commun.repository.AuditCalculRepository;
import fr.bpce.yyd.service.commun.service.AuditCalculService;

@Service
public class AuditCalculServiceImpl implements AuditCalculService {

	@Autowired
	private AuditCalculRepository auditCalculRepository;

	/**
	 * {@inheritDoc}
	 */
	@Override
	public AuditCalcul creeAuditCalcul(EvenementCalcule evtCalc, String code, StatutAuditEvenement statut,
			LocalDate dateEffet, LocalDate datePhoto) {
		AuditCalcul audit = new AuditCalcul();
		audit.setCode(code);
		audit.setStatut(statut);
		audit.setEvenementCalcule(evtCalc);
		audit.setDateEffet(dateEffet);
		audit.setDateGeneration(LocalDateTime.now());
		audit.setDatePhoto(datePhoto);
		return auditCalculRepository.save(audit);
	}

	/*
	 * Setters
	 */
	public void setAuditCalculRepository(AuditCalculRepository auditCalculRepository) {
		this.auditCalculRepository = auditCalculRepository;
	}

	@Override
	public AuditCalcul recupererAuditPeriodeProbatoire(Long idEvenementCalcule, Long idTiers, LocalDate dateCalcul) {
		return auditCalculRepository
				.rechercheAuditCalculePPActifOuSuspenduADate(idEvenementCalcule, idTiers, dateCalcul).get(0);
	}

	@Override
	public void clotureAuditCalcul(Long idTiers, LocalDate dateCalcul) {

		List<AuditCalcul> auditCalculs = auditCalculRepository.rechercheAuditCalculAClotuer(idTiers);
		auditCalculs.forEach(auditCalcul -> creeAuditCalcul(auditCalcul.getEvenementCalcule(), auditCalcul.getCode(),
				StatutAuditEvenement.CLO, dateCalcul, dateCalcul));

	}
}
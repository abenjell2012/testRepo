package fr.bpce.yyd.service.commun.config.kafka;

import org.apache.kafka.common.header.Headers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.support.serializer.JsonDeserializer;

import fr.bpce.yyd.commun.messages.dto.LotIdTiersDTO;

public class LotIdTiersDtoDeserializer extends JsonDeserializer<LotIdTiersDTO> {

	private static final Logger LOGGER = LoggerFactory.getLogger(LotIdTiersDtoDeserializer.class);

	@Override
	public LotIdTiersDTO deserialize(String topic, Headers headers, byte[] data) {

		try {

			return super.deserialize(topic, headers, data);

		} catch (Exception ex) {
			LOGGER.error("Erreur lors de la déserialisation des données: {} , cause: {}", ex.getMessage(),
					ex.getCause().getMessage());
			return new LotIdTiersDTO();
		}

	}

}

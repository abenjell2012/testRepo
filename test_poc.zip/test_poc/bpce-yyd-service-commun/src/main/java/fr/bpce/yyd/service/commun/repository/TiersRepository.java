package fr.bpce.yyd.service.commun.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.service.commun.beans.InfoTiers;

@Repository
public interface TiersRepository extends JpaRepository<Tiers, Long> {

	@Query(value = "select i.tiers from IdentiteTiers i where i.codeBanque = :codeBanque and i.idLocal = :idTiersLocal and i.dateFin is null")
	Tiers chercheTiersParCodeBanqueEtIdLocal(@Param("codeBanque") String codeBanque,
			@Param("idTiersLocal") String idTiersLocal);

	@Query(value = "select t from Tiers t where idFederal = :idFederal")
	Tiers chercheTiersParIdFederal(@Param("idFederal") String idFederal);

	@Query(value = "select t.* from tiers t inner join ( select i2.tiers_id, sum(c.montant_Arriere) as montant_Arriere from  Complement_Evenement c inner join Evenement e on e.id = c.evenement_id inner join Identite_Tiers i on i.id = e.identite_Initiale_id inner join Identite_Tiers i2 on i.id_Local = i2.id_Local and i.code_Bq = i2.code_Bq and i2.date_Fin is null where c.identite_Initiale_id = i.id  and c.evenement_id = e.id and c.statut_evenement = 'ACT' and c.arriere_Tech = 0 and c.arriere_Litige = 0 and e.code in ('IMX','DAX') and ((c.mise_A_Jour = 1 and c.date_Photo <= :dateCalcul) or (c.mise_A_Jour = 0 and c.date_Maj <= :dateCalcul)) and (c.date_Fin is null or c.date_Fin > :dateCalcul) group by i2.tiers_id ) mnt_t on mnt_t.tiers_id = t.id inner join ( select i.tiers_id, max(r.cod_Typ_Not) as cat_seg from identite_Tiers i inner join ref_mcdn_seg s on s.cod_Seg_Cli = i.code_Segment inner join Ref_Cli_Ss_Class r on r.cod_Ss_Class_Cli = s.cod_Ss_Class_Cli where i.date_Debut <= :dateCalcul and (i.date_Fin is null or i.date_Fin > :dateCalcul) group by i.tiers_id) seg_t on seg_t.tiers_id = t.id where (seg_t.cat_seg in ('PROF','PART','NSEG') and mnt_t.montant_Arriere >= (select valeur_param from par_mdc_bq_seg where code_param = 'SEUIL_EUR_RETAIL')) or (seg_t.cat_seg not in ('PROF','PART','NSEG') and mnt_t.montant_Arriere >= (select valeur_param from par_mdc_bq_seg where code_param = 'SEUIL_EUR_HORS_RETAIL'))", nativeQuery = true)
	List<Tiers> listAllTiersWithEvt(@Param("dateCalcul") LocalDate dateCalcul);

	@Query(value = "select t.id as idTiers, t.id_rft as idFederal, i3.code_Bq as codeBanque, i3.id_Local as idLocal from tiers t inner join ( select i2.tiers_id, sum(c.montant_Arriere) as montant_Arriere from  Complement_Evenement c inner join Evenement e on e.id = c.evenement_id inner join Identite_Tiers i on i.id = e.identite_Initiale_id inner join Identite_Tiers i2 on i.id_Local = i2.id_Local and i.code_Bq = i2.code_Bq and i2.date_Fin is null where c.identite_Initiale_id = i.id  and c.evenement_id = e.id and c.statut_evenement = 'ACT' and c.arriere_Tech = 0 and c.arriere_Litige = 0 and e.code in ('IMX','DAX') and ((c.mise_A_Jour = 1 and c.date_Photo <= :dateCalcul) or (c.mise_A_Jour = 0 and c.date_Maj <= :dateCalcul)) and (c.date_Fin is null or c.date_Fin > :dateCalcul) group by i2.tiers_id ) mnt_t on mnt_t.tiers_id = t.id inner join ( select i.tiers_id, max(r.cod_Typ_Not) as cat_seg from identite_Tiers i inner join ref_mcdn_seg s on s.cod_Seg_Cli = i.code_Segment inner join Ref_Cli_Ss_Class r on r.cod_Ss_Class_Cli = s.cod_Ss_Class_Cli where i.date_Debut <= :dateCalcul and (i.date_Fin is null or i.date_Fin > :dateCalcul) group by i.tiers_id) seg_t on seg_t.tiers_id = t.id inner join identite_tiers i3 on i3.tiers_id = t.id and i3.date_fin is null where (seg_t.cat_seg in ('PROF','PART','NSEG') and mnt_t.montant_Arriere >= (select valeur_param from par_mdc_bq_seg where code_param = 'SEUIL_EUR_RETAIL')) or (seg_t.cat_seg not in ('PROF','PART','NSEG') and mnt_t.montant_Arriere >= (select valeur_param from par_mdc_bq_seg where code_param = 'SEUIL_EUR_HORS_RETAIL'))", nativeQuery = true)
	List<InfoTiers> listAllTiersWithEvt2(@Param("dateCalcul") LocalDate dateCalcul);
}
package fr.bpce.yyd.service.commun.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import fr.bpce.yyd.commun.enums.CodeParamMdc;
import fr.bpce.yyd.commun.model.ParMdcSeg;

@Repository
public interface ParMdcSegRepository extends CrudRepository<ParMdcSeg, Long> {

	@Query(value = "select par from ParMdcSeg par where par.dateDebut <= :dateCalcul and (par.dateFin is null or par.dateFin > :dateCalcul)")
	List<ParMdcSeg> findAllParamMdcSegADate(@Param("dateCalcul") LocalDate dateCalcul);

	@Query(value = "select par from ParMdcSeg par where par.codeParam = :codeParam")
	ParMdcSeg rechercherParamMdcADate(@Param("codeParam") CodeParamMdc codeParam);

	@Modifying
	@Query("update ParMdcSeg p set p.valeurParam = :valeurParam where p.codeParam = :codeParam")
	int setValeurParamByCodeParam(@Param("valeurParam") String valeurParam, @Param("codeParam") CodeParamMdc codeParam);
}
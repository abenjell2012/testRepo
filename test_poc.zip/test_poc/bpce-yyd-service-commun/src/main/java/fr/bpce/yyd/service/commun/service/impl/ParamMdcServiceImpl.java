package fr.bpce.yyd.service.commun.service.impl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fr.bpce.yyd.commun.constantes.Constant;
import fr.bpce.yyd.commun.enums.CodeParamMdc;
import fr.bpce.yyd.commun.model.ParMdcBqSeg;
import fr.bpce.yyd.commun.model.ParMdcSeg;
import fr.bpce.yyd.service.commun.repository.ParMdcBqSegRepository;
import fr.bpce.yyd.service.commun.repository.ParMdcSegRepository;
import fr.bpce.yyd.service.commun.service.ParamMdcService;
import fr.bpce.yyd.service.commun.util.ParamMap;

/**
 *
 * @author zgud
 *
 */
@Service
public class ParamMdcServiceImpl implements ParamMdcService {

	/*
	 * Les paramètres sont lus et mis en cache. Leur durée de vie en cache est
	 * définie par CACHE_LIVE_MINUTES.
	 */
	public static final int CACHE_LIVE_MINUTES = 15;

	@FunctionalInterface
	public static interface ParamRefresher {
		ParamMap refreshParamMap();
	}

	public static class ParamCacheEntry {
		private final LocalDateTime timestamp;
		private final ParamMap paramMap;

		ParamCacheEntry(LocalDateTime timestamp, ParamMap paramMap) {
			this.timestamp = timestamp;
			this.paramMap = paramMap;
		}

		public LocalDateTime getTimestamp() {
			return timestamp;
		}

		public ParamMap getParamMap() {
			return paramMap;
		}
	}

	public enum CacheType {
		PARAM_SEG, PARAM_BQ_SEG
	}

	private final Map<CacheType, ParamCacheEntry> mapCache = new EnumMap<>(CacheType.class);

	@Autowired
	private ParMdcSegRepository parMdcSegRepository;

	@Autowired
	private ParMdcBqSegRepository parMdcBqSegRepository;

	/**
	 * {@inheritDoc}
	 */
	@Override
	public ParamMap getParamsMdcSegMapADate(LocalDate dateCalcul) {
		return getMap(CacheType.PARAM_SEG, () -> {
			ParamMap paramsMap = new ParamMap();
			List<ParMdcSeg> paramsList = parMdcSegRepository.findAllParamMdcSegADate(dateCalcul);
			for (ParMdcSeg parMdcSeg : paramsList) {
				paramsMap.putValueFor(parMdcSeg.getValeurParam(), parMdcSeg.getCodeParam(), parMdcSeg.getCodeSegment());
			}

			return paramsMap;
		});
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public ParamMap getParamsMdcBqSegMapADate(final LocalDate dateCalcul) {
		return getMap(CacheType.PARAM_BQ_SEG, () -> {
			ParamMap paramsMap = new ParamMap();
			List<ParMdcBqSeg> paramsList = parMdcBqSegRepository.findAllParamMdcBqSegADate(dateCalcul);
			for (ParMdcBqSeg parMdcBqSeg : paramsList) {
				paramsMap.putValueFor(parMdcBqSeg.getValeurParam(), parMdcBqSeg.getCodeParam(), parMdcBqSeg.getCodeBq(),
						parMdcBqSeg.getCodeSegment());
			}
			return paramsMap;
		});
	}

	protected ParamMap getMap(CacheType type, ParamRefresher refresher) {
		ParamCacheEntry cacheEntry = mapCache.get(type);
		if (cacheEntry == null
				|| ChronoUnit.MINUTES.between(cacheEntry.timestamp, LocalDateTime.now()) > CACHE_LIVE_MINUTES) {
			cacheEntry = new ParamCacheEntry(LocalDateTime.now(), refresher.refreshParamMap());
			mapCache.put(type, cacheEntry);
		}
		return cacheEntry.getParamMap();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String getParamMdcSegValueADate(CodeParamMdc codeParam, String segment, LocalDate dateCalcul) {
		ParamMap paramsMap = getParamsMdcSegMapADate(dateCalcul);
		String ret = paramsMap.get(codeParam, segment);
		if (ret == null) {
			ret = paramsMap.get(codeParam, Constant.ANY);
		}
		return ret;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String getParamMdcBqSegValueADate(CodeParamMdc codeParam, String codeBanque, String segment,
			LocalDate dateCalcul) {
		ParamMap paramsMap = getParamsMdcBqSegMapADate(dateCalcul);
		String ret = paramsMap.get(codeParam, codeBanque, segment);
		if (ret == null) {
			ret = paramsMap.get(codeParam, codeBanque, Constant.ANY);
		}
		if (ret == null) {
			ret = paramsMap.get(codeParam, Constant.ANY, segment);
		}
		if (ret == null) {
			ret = paramsMap.get(codeParam, Constant.ANY, Constant.ANY);
		}
		return ret;
	}

	@Override
	public ParMdcSeg initParamMdc(ParMdcSeg param) {
		return parMdcSegRepository.save(param);
	}

	@Override
	public ParMdcSeg getParamMdcADate(CodeParamMdc codeParam) {
			return parMdcSegRepository.rechercherParamMdcADate(codeParam);
	}

	@Override
	public void updateParamMdc(String valeurParam, CodeParamMdc codeParam) {
			parMdcSegRepository.setValeurParamByCodeParam(valeurParam, codeParam);
	}

	public void setParMdcSegRepository(ParMdcSegRepository parMdcSegRepository) {
		this.parMdcSegRepository = parMdcSegRepository;
	}

	public void setParMdcBqSegRepository(ParMdcBqSegRepository parMdcBqSegRepository) {
		this.parMdcBqSegRepository = parMdcBqSegRepository;
	}

	Map<CacheType, ParamCacheEntry> getMapCache() {
		return mapCache;
	}
}

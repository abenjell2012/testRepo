package fr.bpce.yyd.service.commun.service.impl;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fr.bpce.yyd.commun.constantes.Constant;
import fr.bpce.yyd.commun.enums.CategorieSegment;
import fr.bpce.yyd.commun.enums.CodeParamMdc;
import fr.bpce.yyd.commun.model.ParMdcSeg;
import fr.bpce.yyd.commun.service.RefCliSegService;
import fr.bpce.yyd.service.commun.service.ParamMdcService;
import fr.bpce.yyd.service.commun.service.ParametresNDoD;

/**
 * Classe proposant une interface vers l'accès aux paramètres de l'application
 * NDoD.
 *
 * @author zgud
 *
 */
@Service
public class ParametresNDoDImpl implements ParametresNDoD {

	@Autowired
	private ParamMdcService paramService;

	@Autowired
	private RefCliSegService refCliSegService;

	@Override
	public List<String> getCodBqAgregationNationale(LocalDate aDate) {
		String val = paramService.getParamMdcSegValueADate(CodeParamMdc.CODE_BQ_AGREG_REGIONALE, Constant.ANY, aDate);
		List<String> codBqList = new ArrayList<>();
		if (StringUtils.isNotEmpty(val)) {
			codBqList = Arrays.asList(val.split(Constant.SEP_VIRGULE));
		}
		return codBqList;
	}

	@Override
	public int getNbJoursPPStandard(String segment, LocalDate aDate) {
		String val = paramService.getParamMdcSegValueADate(CodeParamMdc.DUREE_PP_SANS_FORB, segment, aDate);
		return val != null ? Integer.parseInt(val) : 90;
	}

	@Override
	public int getNbJoursPPForbearance(String segment, LocalDate aDate) {
		String val = paramService.getParamMdcSegValueADate(CodeParamMdc.DUREE_PP_AVEC_FORB, segment, aDate);
		return val != null ? Integer.parseInt(val) : 365;
	}

	@Override
	public int getNbJoursPourIFSurCtrtForbearance(String segment, LocalDate aDate) {
		String val = paramService.getParamMdcSegValueADate(CodeParamMdc.DUREE_IMPAYE_FORB, segment, aDate);
		return val != null ? Integer.parseInt(val) : 30;
	}

	@Override
	public int getNbJoursASVersDefaut(String segment, LocalDate aDate) {
		String val = paramService.getParamMdcSegValueADate(CodeParamMdc.NB_JOURS_DECL_AR3, segment, aDate);
		return val != null ? Integer.parseInt(val) : 90;
	}

	@Override
	public int getNbJoursASRazDecomptePP(String segment, LocalDate aDate) {
		String val = paramService.getParamMdcSegValueADate(CodeParamMdc.DELAI_RAZ_PP, segment, aDate);
		return val != null ? Integer.parseInt(val) : 30;
	}

	@Override
	public BigDecimal getSeuilRelatif(String segment, LocalDate aDate) {
		String val = paramService.getParamMdcSegValueADate(CodeParamMdc.SEUIL_SIGNIFICATIVITE, segment, aDate);
		if (val != null) {
			Double seuilRelatif = Double.valueOf(val) / Double.valueOf(100d);
			return new BigDecimal(seuilRelatif.toString());
		} else {
			return new BigDecimal("0.01");
		}
	}

	@Override
	public int getSeuilAbsolu(String codeBanque, String segment, LocalDate aDate) {
		String catSegment = refCliSegService.getCategorieSegment(segment);
		if (CategorieSegment.PART.name().equals(catSegment) || CategorieSegment.PROF.name().equals(catSegment)
				|| CategorieSegment.NSEG.name().equals(catSegment)) {
			String val = paramService.getParamMdcBqSegValueADate(CodeParamMdc.SEUIL_EUR_RETAIL, codeBanque, segment,
					aDate);
			return val != null ? Integer.parseInt(val) : 100;
		} else {
			String val = paramService.getParamMdcBqSegValueADate(CodeParamMdc.SEUIL_EUR_HORS_RETAIL, codeBanque,
					segment, aDate);
			return val != null ? Integer.parseInt(val) : 500;
		}
	}

	@Override
	public LocalDate getDateCalculCourante() {
		ParMdcSeg paramDateCalcul = paramService.getParamMdcADate(CodeParamMdc.DATE_CALCUL_COURANTE);
		if (paramDateCalcul != null) {
			return LocalDate.parse(paramDateCalcul.getValeurParam(), DateTimeFormatter.BASIC_ISO_DATE);
		}
		return null;
	}

	@Override
	public int getProfondeurHistoEvts(LocalDate aDate) {
		String val = paramService.getParamMdcSegValueADate(CodeParamMdc.PROF_HISTO_EVTS_IHM, Constant.ANY, aDate);
		return val != null ? Integer.parseInt(val) : 95;
	}

	@Override
	public void updateDateCalculCourante(LocalDate valeurParam) {
		String dateStr = valeurParam.format(Constant.YYYYMMDD_FORMATTER);
		paramService.updateParamMdc(dateStr, CodeParamMdc.DATE_CALCUL_COURANTE);
	}

	/*
	 * Setter
	 */
	public void setParamService(ParamMdcService paramService) {
		this.paramService = paramService;
	}

	public void setRefCliSegService(RefCliSegService refCliSegService) {
		this.refCliSegService = refCliSegService;
	}
}

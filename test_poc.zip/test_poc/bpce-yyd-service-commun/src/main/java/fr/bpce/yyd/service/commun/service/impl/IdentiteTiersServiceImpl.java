package fr.bpce.yyd.service.commun.service.impl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fr.bpce.yyd.commun.messages.dto.LotIdTiersDTO;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.service.commun.contexte.ContexteCalculTiers;
import fr.bpce.yyd.service.commun.repository.IdentiteTiersRepository;
import fr.bpce.yyd.service.commun.service.IdentiteTiersService;

@Service
public class IdentiteTiersServiceImpl implements IdentiteTiersService {

	@Autowired
	private IdentiteTiersRepository identTiersRepository;

	@Override
	public String donneSegmentDuTiers(Long idTiers, LocalDate date) {
		String segment;
		List<IdentiteTiers> identitesCourantes = rechercheIdentitesActivesADate(idTiers, date);
		if (identitesCourantes.isEmpty()) {
			segment = "NSEG"; // Quoi faire ?
		} else {
			segment = identitesCourantes.get(0).getCodeSegment();
		}

		return segment;
	}

	@Override
	public String donneCodeBanqueDuTiersRetail(Long idTiers, LocalDate date) {
		String codeBanque;
		List<IdentiteTiers> identitesCourantes = rechercheIdentitesActivesADate(idTiers, date);
		codeBanque = identitesCourantes.get(0).getCodeBanque();

		return codeBanque;
	}

	@Override
	public List<IdentiteTiers> rechercheAllIdentites(Long idTiers, LocalDate dateCalcul) {
		return ContexteCalculTiers.getIdentiteTiers(idTiers);
	}

	@Override
	public List<IdentiteTiers> rechercheIdentitesActivesADate(Long idTiers, LocalDate dateCalcul) {
		List<IdentiteTiers> identitesCourantes = rechercheAllIdentites(idTiers, dateCalcul);
		return identitesCourantes.stream().filter(s -> s.getDateFin() == null).collect(Collectors.toList());
	}

	@Override
	public Map<Long, List<IdentiteTiers>> rechercheIdentitesActivesADate(LotIdTiersDTO data) {
		Map<Long, List<IdentiteTiers>> ret = new HashMap<>();
		List<IdentiteTiers> idents = identTiersRepository
				.rechercheIdentitesWithListTiersActivesADate(data.getIdsTiers());
		for (IdentiteTiers ident : idents) {
			List<IdentiteTiers> idts = ret.get(ident.getTiers().getId());
			if (idts == null) {
				idts = new ArrayList<>();
			}
			idts.add(ident);
			ret.put(ident.getTiers().getId(), idts);
		}

		return ret;
	}

	@Override
	public Tiers rechercheTiersById(Long tiersId) {
		return identTiersRepository.chercheTiersParId(tiersId);
	}

	public void setIdentTiersRepository(IdentiteTiersRepository identTiersRepository) {
		this.identTiersRepository = identTiersRepository;
	}

	@Override
	public Map<Long, Tiers> rechercheAllTiers(List<Long> idsTiers) {
		Map<Long, Tiers> retMap = new HashMap<>();
		List<Tiers> tiersList = identTiersRepository.rechercheTiersList(idsTiers);
		for (Tiers tiers : tiersList) {
			retMap.put(tiers.getId(), tiers);
		}
		return retMap;
	}

}

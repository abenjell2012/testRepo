package fr.bpce.yyd.service.commun.contexte;

public class ContexteException extends RuntimeException {

	private static final long serialVersionUID = -8457461193925552109L;

	public ContexteException(String message) {
		super(message);
	}
}

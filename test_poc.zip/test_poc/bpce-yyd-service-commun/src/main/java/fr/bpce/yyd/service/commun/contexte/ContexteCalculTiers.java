package fr.bpce.yyd.service.commun.contexte;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import fr.bpce.yyd.commun.model.EvenementCalcule;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.StatutHistorise;
import fr.bpce.yyd.service.commun.beans.EvenementsATraiter;
import fr.bpce.yyd.service.commun.beans.EvenementsCalculesTiers;

public class ContexteCalculTiers {

	private static ThreadLocal<ContexteCalculTiers> contexteLocal = new ThreadLocal<>();

	private Map<Long, EvenementsATraiter> evenementsATraiter;
	private Map<Long, List<StatutHistorise>> statutsCourants;
	private Map<Long, List<IdentiteTiers>> identiteTiers;
	private Map<Long, EvenementsCalculesTiers> evtCalculesTiers;

	public static ContexteCalculTiers init(Map<Long, EvenementsATraiter> evenementsATraiter,
			Map<Long, List<StatutHistorise>> statutsCourants, Map<Long, List<IdentiteTiers>> identiteTiers,
			Map<Long, EvenementsCalculesTiers> evtCalculesTiers) {
		ContexteCalculTiers contexte = contexteLocal.get();
		if (contexte == null) {
			contexte = new ContexteCalculTiers();
			contexte.evenementsATraiter = evenementsATraiter;
			contexte.statutsCourants = statutsCourants;
			contexte.identiteTiers = identiteTiers;
			contexte.evtCalculesTiers = evtCalculesTiers;
			contexteLocal.set(contexte);
		}
		return contexte;
	}

	public static ContexteCalculTiers get() {
		return contexteLocal.get();
	}

	public static void clear() {
		contexteLocal.remove();
	}

	public static void setEvenementsATraiter(Map<Long, EvenementsATraiter> evenementsATraiter) {
		ContexteCalculTiers contexte = get();
		if (contexte != null) {
			contexte.evenementsATraiter = evenementsATraiter;
		}
	}

	public static void setStatutsCourants(Map<Long, List<StatutHistorise>> statutsCourants) {
		ContexteCalculTiers contexte = get();
		if (contexte != null) {
			contexte.statutsCourants = statutsCourants;
		}
	}

	public static void setIdentiteTiers(Map<Long, List<IdentiteTiers>> identiteTiers) {
		ContexteCalculTiers contexte = get();
		if (contexte != null) {
			contexte.identiteTiers = identiteTiers;
		}
	}

	public static void setEvtCalculesTiers(Map<Long, EvenementsCalculesTiers> evtCalculesTiers) {
		ContexteCalculTiers contexte = get();
		if (contexte != null) {
			contexte.evtCalculesTiers = evtCalculesTiers;
		}
	}

	public static EvenementsATraiter getEvenementsATraiter(Long idTiers) {
		ContexteCalculTiers contexte = get();
		if (contexte != null && contexte.evenementsATraiter != null
				&& contexte.evenementsATraiter.get(idTiers) != null) {
			return contexte.evenementsATraiter.get(idTiers);
		}
		return new EvenementsATraiter();
	}

	public static List<StatutHistorise> getStatutsCourants(Long idTiers) {
		ContexteCalculTiers contexte = get();
		if (contexte != null && contexte.statutsCourants != null && contexte.statutsCourants.get(idTiers) != null) {
			return contexte.statutsCourants.get(idTiers);
		}
		return new ArrayList<>();
	}

	public static void addStatutsCourants(Long idTiers, StatutHistorise statut) {
		ContexteCalculTiers contexte = get();
		List<StatutHistorise> status = contexte.statutsCourants.get(idTiers);
		if (status == null) {
			status = new ArrayList<>();
		}
		status.add(statut);
		contexte.statutsCourants.put(idTiers, status);
	}

	public static List<IdentiteTiers> getIdentiteTiers(Long idTiers) {
		ContexteCalculTiers contexte = get();
		if (contexte != null && contexte.identiteTiers != null && contexte.identiteTiers.get(idTiers) != null) {
			return contexte.identiteTiers.get(idTiers);
		}
		return new ArrayList<>();
	}

	public static EvenementsCalculesTiers getEvtCalculesTiers(Long idTiers) {
		ContexteCalculTiers contexte = get();
		if (contexte != null && contexte.evtCalculesTiers != null && contexte.evtCalculesTiers.get(idTiers) != null) {
			return contexte.evtCalculesTiers.get(idTiers);
		}
		List<EvenementCalcule> evts = new ArrayList<>();
		return new EvenementsCalculesTiers(evts);
	}

	public static void setEvtCalculesTiers(Long idTiers, EvenementsCalculesTiers evtsCalcule) {
		ContexteCalculTiers contexte = get();
		contexte.evtCalculesTiers.put(idTiers, evtsCalcule);
	}
}

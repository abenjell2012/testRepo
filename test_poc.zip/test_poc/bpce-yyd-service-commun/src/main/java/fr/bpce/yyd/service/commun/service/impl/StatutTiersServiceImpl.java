package fr.bpce.yyd.service.commun.service.impl;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fr.bpce.yyd.commun.enums.StatutTiers;
import fr.bpce.yyd.commun.model.StatutHistorise;
import fr.bpce.yyd.service.commun.repository.StatutTiersRepository;
import fr.bpce.yyd.service.commun.service.StatutTiersService;

@Service
public class StatutTiersServiceImpl implements StatutTiersService {

	@Autowired
	private StatutTiersRepository statutTiersRepository;

	/**
	 * {@inheritDoc}
	 */
	@Override
	public StatutTiers getStatutADate(Long idTiers, LocalDate date) {
		List<StatutHistorise> statutsCourants = statutTiersRepository.getStatutADate(idTiers, date);
		if (statutsCourants.isEmpty()) {
			return StatutTiers.SAIN;
		}
		return statutsCourants.get(0).getStatut();
	}

	/*
	 * Setters
	 */
	public void setStatutTiersRepository(StatutTiersRepository statutTiersRepository) {
		this.statutTiersRepository = statutTiersRepository;
	}
}

package fr.bpce.yyd.service.commun.beans;

public interface InfoTiers {

	Long getIdTiers();

	String getIdFederal();

	String getCodeBanque();

	String getIdLocal();

}

package fr.bpce.yyd.service.commun.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import fr.bpce.yyd.commun.model.StatutHistorise;

@Repository
public interface StatutTiersRepository extends JpaRepository<StatutHistorise, Long> {

	@Query("select status from StatutHistorise status where status.tiers.id = :idTiers and status.dateDebut <= :dateCalcul and (status.dateFin is null or status.dateFin > :dateCalcul)")
	List<StatutHistorise> getStatutADate(@Param("idTiers") Long idTiers, @Param("dateCalcul") LocalDate date);

	@Query("select status from StatutHistorise status where status.tiers.id = :idTiers and status.dateFin is null")
	List<StatutHistorise> findStatusTiersActive(@Param("idTiers") Long idTiers);

	@Query(nativeQuery = true, value = "select s.* from Statut_tiers s where s.tiers_id = :idTiers and s.motif ='PP' and s.date_Debut > :dateCalcul and s.date_Fin is null")
	StatutHistorise findStatusTiersPPActive(@Param("idTiers") Long idTiers, @Param("dateCalcul") LocalDate date);

	@Query("select status from StatutHistorise status where status.tiers.id in (:idsTiers)")
	List<StatutHistorise> getStatutWithListTiersADate(@Param("idsTiers") List<Long> idsTiers);

	List<StatutHistorise> findAllByOrderByIdAsc();
}
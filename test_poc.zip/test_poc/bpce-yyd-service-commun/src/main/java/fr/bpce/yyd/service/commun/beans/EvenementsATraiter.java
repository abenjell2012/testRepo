package fr.bpce.yyd.service.commun.beans;

import java.util.ArrayList;
import java.util.List;

import fr.bpce.yyd.commun.enums.StatutEvenement;
import fr.bpce.yyd.commun.model.ComplementEvenement;

/**
 * Remarque : En passant par les méthodes addXxxx(), les listes sont maintenues
 * toujours classées.
 *
 * @author zgud
 *
 */
public class EvenementsATraiter {

	private List<ComplementEvenement> tousEvenements = new ArrayList<>();
	private List<ComplementEvenement> arrieres = new ArrayList<>();
	private List<ComplementEvenement> evenementsDefaut = new ArrayList<>();
	private List<ComplementEvenement> forbearances = new ArrayList<>();

	public List<ComplementEvenement> getTousEvenements() {
		return tousEvenements;
	}

	public List<ComplementEvenement> getTousEvenementsActifs() {
		return getTousEvenements(StatutEvenement.ACT);
	}

	public List<ComplementEvenement> getTousEvenements(StatutEvenement statut) {
		return filtreSurStatut(tousEvenements, statut);
	}

	public List<ComplementEvenement> getArrieres() {
		return arrieres;
	}

	public List<ComplementEvenement> getArrieresActifs() {
		return getArrieres(StatutEvenement.ACT);
	}

	public List<ComplementEvenement> getArrieres(StatutEvenement statut) {
		return filtreSurStatut(arrieres, statut);
	}

	public EvenementsATraiter addArriere(ComplementEvenement complEvtArr) {
		addSorted(complEvtArr, arrieres);
		addSorted(complEvtArr, tousEvenements);
		return this;
	}

	public List<ComplementEvenement> getEvenementsDefaut() {
		return evenementsDefaut;
	}

	public List<ComplementEvenement> getEvenementsDefautActifs() {
		return getEvenementsDefaut(StatutEvenement.ACT);
	}

	public List<ComplementEvenement> getEvenementsDefaut(StatutEvenement statut) {
		return filtreSurStatut(evenementsDefaut, statut);
	}

	public EvenementsATraiter addEvenementDefaut(ComplementEvenement complEvtDefaut) {
		addSorted(complEvtDefaut, evenementsDefaut);
		addSorted(complEvtDefaut, tousEvenements);
		return this;
	}

	public List<ComplementEvenement> getForbearances() {
		return forbearances;
	}

	public List<ComplementEvenement> getForbearancesActifs() {
		List<ComplementEvenement> ret = new ArrayList<>();
		for (ComplementEvenement ce : forbearances) {
			if (StatutEvenement.ACT == ce.getStatutEvt()) {
				ret.add(ce);
			}
		}
		return ret;
	}

	public List<ComplementEvenement> getForbearances(StatutEvenement statut) {
		return filtreSurStatut(forbearances, statut);
	}

	public EvenementsATraiter addForbearance(ComplementEvenement complEvtForbearance) {
		addSorted(complEvtForbearance, forbearances);
		addSorted(complEvtForbearance, tousEvenements);
		return this;
	}

	protected List<ComplementEvenement> filtreSurStatut(List<ComplementEvenement> listeCE, StatutEvenement statut) {
		List<ComplementEvenement> ret = new ArrayList<>();
		for (ComplementEvenement ce : listeCE) {
			if (!Boolean.TRUE.equals(ce.isArriereTech()) && !Boolean.TRUE.equals(ce.isArriereLitige())
					&& statut == ce.getStatutEvt()) {
				ret.add(ce);
			}
		}
		return ret;
	}

	public int nbArrieresTechOuLitige(StatutEvenement statut) {
		int ret = 0;
		for (ComplementEvenement ce : arrieres) {
			if ((ce.isArriereTech() || ce.isArriereLitige()) && statut == ce.getStatutEvt()) {
				ret++;
			}
		}
		return ret;

	}

	/**
	 * Ajout d'un élément à une liste triée, en respectant le tri.
	 *
	 * @param elem
	 * @param liste
	 */
	protected void addSorted(ComplementEvenement elem, List<ComplementEvenement> liste) {
		for (int i = 0; i < liste.size(); i++) {
			if (elem.compareTo(liste.get(i)) < 0) {
				liste.add(i, elem);
				return;
			}
		}
		// Ajout en queue
		liste.add(elem);
	}
}

package fr.bpce.yyd.service.commun.service;

import java.time.LocalDate;

import fr.bpce.yyd.commun.model.reference.RefImpactEvtMdc;

public interface EvenementImpactService {

	RefImpactEvtMdc findImpactEvenement(String codEvt, String catSegment, LocalDate dateDemande);

}

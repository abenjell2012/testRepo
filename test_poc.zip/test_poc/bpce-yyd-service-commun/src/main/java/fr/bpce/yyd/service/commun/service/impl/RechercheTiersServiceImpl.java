package fr.bpce.yyd.service.commun.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.service.commun.repository.TiersRepository;
import fr.bpce.yyd.service.commun.service.RechercheTiersService;

@Service
public class RechercheTiersServiceImpl implements RechercheTiersService {

	@Autowired
	private TiersRepository tiersRepository;

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Tiers getTiers(Long idTiers) {
		Optional<Tiers> optTiers = tiersRepository.findById(idTiers);
		if (optTiers.isPresent()) {
			return optTiers.get();
		}
		return null;
	}

	public void setTiersRepository(TiersRepository tiersRepository) {
		this.tiersRepository = tiersRepository;
	}

}

package fr.bpce.yyd.service.commun.service.impl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fr.bpce.yyd.commun.enums.CodeEvenement;
import fr.bpce.yyd.commun.messages.dto.LotIdTiersDTO;
import fr.bpce.yyd.commun.model.ComplementEvenement;
import fr.bpce.yyd.commun.model.Evenement;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.reference.RefImpactEvtMdc;
import fr.bpce.yyd.commun.service.RefCliSegService;
import fr.bpce.yyd.service.commun.beans.EvenementsATraiter;
import fr.bpce.yyd.service.commun.contexte.ContexteCalculTiers;
import fr.bpce.yyd.service.commun.repository.EvenementRecuRepository;
import fr.bpce.yyd.service.commun.service.EvenementImpactService;
import fr.bpce.yyd.service.commun.service.EvenementRecuService;

@Service
public class EvenementRecuServiceImpl implements EvenementRecuService {

	public static final String EVENEMENT_DEFAUT = "D";
	public static final String EVENEMENT_FORBEARANCE = "F";

	@Autowired
	private EvenementRecuRepository evtRecuRepository;

	@Autowired
	private EvenementImpactService impactService;

	@Autowired
	private RefCliSegService cliSegService;

	/**
	 * {@inheritDoc}
	 */
	@Override
	public EvenementsATraiter rechercheEvenementsATraiterADate(Long idTiers, LocalDate dateCalcul) {
		return ContexteCalculTiers.getEvenementsATraiter(idTiers);
	}

	@Override
	public Map<Long, EvenementsATraiter> rechercheEvenementsATraiterADate(LotIdTiersDTO data,
			Map<Long, List<IdentiteTiers>> identities) {
		Map<Long, EvenementsATraiter> ret = new HashMap<>();
		List<ComplementEvenement> cmpltEvnts = rechercheEvenementsActifsADate(data);
		Collections.sort(cmpltEvnts);

		for (ComplementEvenement cmpltEvt : cmpltEvnts) {
			IdentiteTiers identiteInitiale = cmpltEvt.getIdentiteInitiale();
			IdentiteTiers ident = recupererIdentiteActive(identiteInitiale);

			EvenementsATraiter evtATrt = ret.get(ident.getTiers().getId());
			if (evtATrt == null) {
				evtATrt = new EvenementsATraiter();
			}
			Evenement evt = cmpltEvt.getEvenement();
			String code = evt.getCode();
			if (CodeEvenement.IMX.name().equals(code) || CodeEvenement.DAX.name().equals(code)) {
				evtATrt.addArriere(cmpltEvt);
			} else {
				String segment = ident.getCodeSegment();
				String catSeg = cliSegService.getCategorieSegment(segment);

				RefImpactEvtMdc refImpact = impactService.findImpactEvenement(code, catSeg, cmpltEvt.getDateDebut());
				String impact = refImpact != null ? refImpact.getImpact() : null;

				if (EVENEMENT_DEFAUT.equals(impact)) {
					evtATrt.addEvenementDefaut(cmpltEvt);
				} else if (EVENEMENT_FORBEARANCE.equals(code)) {
					evtATrt.addForbearance(cmpltEvt);
				}
			}
			ret.put(ident.getTiers().getId(), evtATrt);
		}
		return ret;

	}

	@Override
	public List<ComplementEvenement> rechercheEvenementsActifsADate(LotIdTiersDTO data) {
		List<ComplementEvenement> result = new ArrayList<>();
		List<Object[]> cmpltEvnts = evtRecuRepository.rechercheEvenementsActifsWithListTiersADate(data.getIdsTiers(),
				data.getDateCalcul());
		for (Object[] pair : cmpltEvnts) {
			((ComplementEvenement) pair[0]).setEvenement((Evenement) pair[1]);
			result.add((ComplementEvenement) pair[0]);
		}
		return result;
	}

	private IdentiteTiers recupererIdentiteActive(IdentiteTiers identiteInitiale) {
		IdentiteTiers identCourante = identiteInitiale;
		while (identCourante.getSuivante() != null) {
			identCourante = identCourante.getSuivante();
		}
		return identCourante;
	}

	/*
	 * Getters et setters
	 */
	public void setEvtRecuRepository(EvenementRecuRepository evtRecuRepository) {
		this.evtRecuRepository = evtRecuRepository;
	}

	@Override
	public List<ComplementEvenement> rechercheForbearenceClotureEntreDeuxDate(Long idTiers, LocalDate dateDeb,
			LocalDate dateFin) {
		return evtRecuRepository.rechercheForbearenceClotureEntreDeuxDate(idTiers, dateDeb, dateFin);
	}

	public void setImpactService(EvenementImpactService impactService) {
		this.impactService = impactService;
	}

	public void setCliSegService(RefCliSegService cliSegService) {
		this.cliSegService = cliSegService;
	}

}

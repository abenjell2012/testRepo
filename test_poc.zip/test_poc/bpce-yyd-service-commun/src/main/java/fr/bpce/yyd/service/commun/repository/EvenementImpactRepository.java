package fr.bpce.yyd.service.commun.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import fr.bpce.yyd.commun.model.reference.RefImpactEvtMdc;

@Repository
public interface EvenementImpactRepository extends CrudRepository<RefImpactEvtMdc, Long> {

	@Query(value = "select r from RefImpactEvtMdc r where r.dateDebut <= :dateCalcul and (r.dateFin is null or r.dateFin > :dateCalcul)")
	List<RefImpactEvtMdc> findAllRefImpactEvtMdcADate(@Param("dateCalcul") LocalDate dateCalcul);

	@Override
	List<RefImpactEvtMdc> findAll();

}
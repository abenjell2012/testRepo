package fr.bpce.yyd.service.commun.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import fr.bpce.yyd.commun.messages.dto.LotIdTiersDTO;
import fr.bpce.yyd.commun.model.ComplementEvenement;
import fr.bpce.yyd.commun.model.MotifStatutTiers;
import fr.bpce.yyd.commun.model.PeriodeProbatoire;
import fr.bpce.yyd.commun.model.StatutHistorise;
import fr.bpce.yyd.commun.model.Tiers;

public interface DefautService {

	/**
	 * A appeler quand un événement de défaut a été identifié. Gère la mise en
	 * défaut.
	 *
	 * @param tiers
	 * @param dateEntree
	 * @param motif
	 */
	void entreeEnDefaut(Tiers tiers, LocalDate dateEntree, MotifStatutTiers motif, LocalDate dateCalcul);

	/**
	 *
	 * @param idTiers
	 * @param evtDefaut
	 */
	void annulerDefautEventClos(Tiers tiers, ComplementEvenement evtDefaut, LocalDate dateCalcul);

	/**
	 * A appeler suite à la clôture d'un événement pouvant provoquer le défaut. Cet
	 * événement est passé en paramètre sous forme de motifDefaut. Gère l'éventuelle
	 * période probatoire qui démarre si aucun autre événement de défaut n'existe ou
	 * le retour direct en sain si annulation=true.
	 *
	 * @param idTiers
	 * @param dateSortie
	 * @param motifDefaut
	 * @param annulation
	 */
	PeriodeProbatoire sortieDUnEvenementDeDefaut(Long idTiers, LocalDate dateSortie, MotifStatutTiers motifDefaut,
			boolean annulation, LocalDate dateCalcul);

	/**
	 * A appeler quand un PP est cluturé / Evenement defaut annule / ARX cloturé
	 * pour flag tech ou litige. Gère le retour en sain.
	 *
	 * @param tiers
	 * @param dateSortie
	 * @param motif
	 */
	void sortieDeDefaut(Tiers tiers, LocalDate dateSortie, MotifStatutTiers motif);

	/**
	 * A appeler quand traitementTiers est terminé et que aucun statut n'est
	 * renseigné sain.
	 *
	 * @param idTiers
	 * @param dateCreation
	 */
	void initStatutTiersASain(Long idTiers, LocalDate dateCreationTiers);

	/**
	 * Retourne le statut de défaut du tiers correspondant au motif en paramètre, si
	 * ce statut existe à date.
	 *
	 * @param idTiers
	 * @param date
	 * @param motif
	 * @return
	 */
	StatutHistorise trouveStatutDefautByMotif(Long idTiers, LocalDate date, MotifStatutTiers motif);

	/**
	 * Retourne la liste des statuts à date pour le tiers donné.
	 *
	 * Remarque : le résultat est mis en cache. Cette méthode n'est pas faite pour
	 * être appelée avec des paramètres différents dans le traitement d'un tiers
	 * donné.
	 *
	 * @param idTiers
	 * @param date
	 * @return
	 */
	List<StatutHistorise> getStatutsADate(Long idTiers, LocalDate date);

	Map<Long, List<StatutHistorise>> getStatutsADate(LotIdTiersDTO data);

	List<StatutHistorise> getStatutsSain(Long idTiers);

	List<StatutHistorise> getAllStatuts(Long idTiers);

	List<StatutHistorise> getStatutsActif(Long idTiers, LocalDate date);

	StatutHistorise trouveStatutDefautCloNotAnnulePlusRecent(Long idTiers);

	StatutHistorise trouveStatutSainEntreDeuxDates(Long idTiers, StatutHistorise statut, LocalDate date2);

	StatutHistorise trouveStatutDefautAnnulePlusRecent(Long idTiers);

}

package fr.bpce.yyd.service.commun.service.impl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fr.bpce.yyd.commun.constantes.Constant;
import fr.bpce.yyd.commun.enums.StatutTiers;
import fr.bpce.yyd.commun.messages.dto.LotIdTiersDTO;
import fr.bpce.yyd.commun.model.ComplementEvenement;
import fr.bpce.yyd.commun.model.MotifStatutTiers;
import fr.bpce.yyd.commun.model.PeriodeProbatoire;
import fr.bpce.yyd.commun.model.StatutHistorise;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.commun.model.reference.RefImpactEvtMdc;
import fr.bpce.yyd.commun.service.RefCliSegService;
import fr.bpce.yyd.service.commun.beans.EvenementsCalculesTiers;
import fr.bpce.yyd.service.commun.contexte.ContexteCalculTiers;
import fr.bpce.yyd.service.commun.repository.StatutTiersRepository;
import fr.bpce.yyd.service.commun.service.DefautService;
import fr.bpce.yyd.service.commun.service.EvenementCalculeService;
import fr.bpce.yyd.service.commun.service.EvenementImpactService;
import fr.bpce.yyd.service.commun.service.IdentiteTiersService;
import fr.bpce.yyd.service.commun.service.RechercheTiersService;

@Service
public class DefautServiceImpl implements DefautService {

	private static final String MSG_PAS_DE_RETOUR_SAIN = "Pas de retour en SAIN le tiers {} car il a d'autres evenements de defaut clos qui subsistent, le tiers reste en PP";

	private static final Logger LOG = LoggerFactory.getLogger(DefautServiceImpl.class);

	public static final String CREATION_LIGNE_PP = "Création d'une ligne de defaut PP";
	public static final String CREATION_LIGNE_SAIN = "Retour à SAIN sans période probatoire";
	private static final String MSG_STATUT_DEFAUT_PP_INTROUVABLE = "On n'a pas trouvé le statut de defaut PP dans STATUT_TIERS correspondant au motif de l'evenement de defaut annulé {} pour le tiers {}";
	private static final String MSG_BESOIN_RECALCUL_PP = "Besoin de recalculer la date de début de la PP pour le tiers {}, date de début actuelle {}, nouvelle date de début {}";

	@Autowired
	private StatutTiersRepository statutTiersRepository;

	@Autowired
	private RechercheTiersService rechercheTiersService;

	@Autowired
	private EvenementCalculeService evtCalculeService;

	@Autowired
	private EvenementImpactService impactService;

	@Autowired
	private IdentiteTiersService identiteTiersService;

	@Autowired
	private RefCliSegService refCliSegService;

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void entreeEnDefaut(Tiers tiers, LocalDate dateEntree, MotifStatutTiers motif, LocalDate dateCalcul) {
		List<StatutHistorise> statutsCourants = getStatutsADate(tiers.getId(), dateCalcul);
		List<StatutHistorise> statutsSain = getStatutsSain(tiers.getId());

		EvenementsCalculesTiers evtsCalc = evtCalculeService.rechercheEvenementsCalculesActifsADate(tiers.getId(),
				dateCalcul);
		if (evtsCalc.getPeriodeProbatoire() != null) {
			if (evtsCalc.getPeriodeProbatoire().getDateDebut().isAfter(dateEntree)) {
				evtCalculeService.closPeriodeProbatoire(evtsCalc.getPeriodeProbatoire(),
						evtsCalc.getPeriodeProbatoire().getDateDebut(), dateCalcul);
			} else {
				evtCalculeService.closPeriodeProbatoire(evtsCalc.getPeriodeProbatoire(), dateEntree, dateCalcul);
			}
		}

		for (StatutHistorise statutCourant : statutsCourants) {
			if (StatutTiers.DEFAUT.equals(statutCourant.getStatut())
					&& Constant.EVENEMENT_PP.equals(statutCourant.getMotif().getMotif())) {
				if (statutCourant.getDateDebut().isAfter(dateEntree)) {
					statutCourant.setDateFin(statutCourant.getDateDebut());
				} else {
					statutCourant.setDateFin(dateEntree);
				}
			}
		}

		for (StatutHistorise statutSain : statutsSain) {
			if (dateEntree.equals(statutSain.getDateDebut()) || dateEntree.isBefore(statutSain.getDateDebut())) {
				if (statutSain.getDateFin() == null) {
					statutSain.setDateFin(statutSain.getDateDebut());
				}
				statutSain.setAnnule(true);
			} else {
				if (statutSain.getDateFin() != null && dateEntree.isBefore(statutSain.getDateFin())) {
					statutSain.setAnnule(true);
					StatutHistorise newStatut = new StatutHistorise(tiers, StatutTiers.SAIN, null,
							statutSain.getDateDebut(), false, null);
					newStatut.setDateFin(dateEntree);
					saveNewStatut(newStatut);
				} else if (statutSain.getDateFin() == null) {
					statutSain.setDateFin(dateEntree);
				}
			}
		}

		String segment = identiteTiersService.donneSegmentDuTiers(tiers.getId(), dateCalcul);
		String catSeg = refCliSegService.getCategorieSegment(segment);

		RefImpactEvtMdc refImpact = impactService.findImpactEvenement(motif.getMotif(), catSeg, dateEntree);
		String gravite = refImpact != null ? refImpact.getGraviteImpact() : null;

		// inserer le nouveau statut defaut
		StatutHistorise newStatut = new StatutHistorise(tiers, StatutTiers.DEFAUT, gravite, dateEntree, false, motif);
		saveNewStatut(newStatut);
		if (LOG.isDebugEnabled()) {
			LOG.debug("Création d'un nouveau statut du tiers {} en défaut", tiers.getId());
		}

		// calculer le palier de defaut (gravite)
		// lancement du traitement alertes contagion
	}

	@Override
	public void annulerDefautEventClos(Tiers tiers, ComplementEvenement evtDefaut, LocalDate dateCalcul) {
		// choix MOA dans les cas d'annulation on prend la date de calcul courante
		LocalDate dateSortie = dateCalcul;

		if (LOG.isDebugEnabled()) {
			LOG.debug("Le motif de defaut du tiers {} : {}", tiers.getId(), new MotifStatutTiers(evtDefaut));
		}

		List<StatutHistorise> allStatutsCourants = ContexteCalculTiers.getStatutsCourants(tiers.getId());

		// annulation de la ligne en DEFAUT sur motif de l'UTP dans STATUT_TIERS si il
		// n'a pas déjà été annulé
		// l'evt de type ANN n'a pas forcement de date de fin et donc si l'annulation a
		// déjà été appliqué
		// il ne faut pas la déclencher encore une fois le traitement d'annulation
		final StatutHistorise statutDefautByMotif = trouveStatutDefautByMotif(allStatutsCourants,
				new MotifStatutTiers(evtDefaut));

		// Prevent NullPointerException et l'evenement de defaut n'a pas déjà été annulé
		if (statutDefautByMotif != null && !statutDefautByMotif.getAnnule()) {
			statutDefautByMotif.setAnnule(true);

			EvenementsCalculesTiers evtsCalc = evtCalculeService.rechercheEvenementsCalculesActifsADate(tiers.getId(),
					dateSortie);
			final PeriodeProbatoire ppCalcule = evtsCalc.getPeriodeProbatoire();

			if (ppCalcule != null) {
				// le tiers es en PP

				// on recherche la ligne dans la table statut tiers qui correspond à la PP du
				// tiers
				List<StatutHistorise> statutsCourants = getStatutsActif(tiers.getId(), dateSortie);

				StatutHistorise statutDefautMotifPP = trouveStatutDefautByMotif(statutsCourants,
						new MotifStatutTiers(ppCalcule));

				if (statutDefautMotifPP != null) {

					if (isLeSeulStatutDefaut(tiers.getId(), dateSortie)) {

						// cloture de la PP (sur annulation) et sortie du DEFAUT avec retour en SAIN
						evtCalculeService.closPeriodeProbatoire(ppCalcule, dateSortie, dateCalcul);
						this.sortieDeDefaut(ppCalcule.getTiers(), dateSortie, null);
						statutDefautMotifPP.setAnnule(true);

					} else {
						afficheLogDebug(MSG_PAS_DE_RETOUR_SAIN, tiers.getId());
						// le tiers a d'autres evenements de défaut
						// on vérifier si la date de début de PP soit etre raffraichi
						// cloture de la PP (sur annulation) et sortie du DEFAUT avec retour en SAIN
						StatutHistorise statutDefautCloNotAnnulePlusRecent = trouveStatutDefautCloNotAnnulePlusRecent(
								tiers.getId());

						// la date de début de PP ne corespond à la date du dernier défaut clot
						// il faut remettre à jour la date de début de PP
						// pour se faire, on clot la PP existante et on en crée une nouvelle

						if (!statutDefautCloNotAnnulePlusRecent.getDateFin().isEqual(ppCalcule.getDateDebut())) {
							afficheLogDebug(MSG_BESOIN_RECALCUL_PP, ppCalcule.getDateDebut(),
									statutDefautCloNotAnnulePlusRecent.getDateFin());
							// annulation de la PP dans AUDIT_CALCUL et EVENEMENT_CALCULE
							evtCalculeService.closPeriodeProbatoire(ppCalcule, dateSortie, dateCalcul);

							// maj dans STATUT_TIERS
							statutDefautMotifPP.setDateFin(dateSortie);
							statutDefautMotifPP.setAnnule(true);

							// création de la nouvelle PP sur la bonne date de début
							gestionDefautSurCloture(tiers, tiers.getId(), statutDefautCloNotAnnulePlusRecent,
									dateCalcul);

						}
					}
				} else {
					afficheLogDebug(MSG_STATUT_DEFAUT_PP_INTROUVABLE, evtDefaut.getEvenement().getCode(),
							tiers.getId());
				}
			}
		}

	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public PeriodeProbatoire sortieDUnEvenementDeDefaut(Long idTiers, LocalDate dateDebutEvenement,
			MotifStatutTiers motifDefaut, boolean annulation, LocalDate dateCalcul) {

		afficheLogDebug("Le motif de defaut du tiers {} : {}", idTiers, motifDefaut);
		PeriodeProbatoire pp = null;
		List<StatutHistorise> statutsCourants = getStatutsActif(idTiers, dateDebutEvenement);
		StatutHistorise statutDefaut = trouveStatutDefautByMotif(statutsCourants, motifDefaut);

		// statut de défaut trouvé sur le motif de l'évenement défaut (CLO ou ANN) en
		// entrée de la fonction
		if (statutDefaut != null) {
			afficheLogDebug("Statut de defaut {} trouvé", motifDefaut);
			// sort de l'evenement de defaut on met à jour les infos
			statutDefaut.setDateFin(dateDebutEvenement);
			statutDefaut.setAnnule(annulation);

			if (statutsCourants.size() == 1) {
				// le tiers n'a plus qu'1 seul statut de défaut
				Tiers tiers = rechercheTiersService.getTiers(idTiers);

				if (annulation) {
					// annulation

					// choix MOA, dans le cadre de l'annulation on prend la date de calcul courante
					// et pas la date de l'evt
					dateDebutEvenement = dateCalcul;
					pp = gestionDefautSurAnnulation(tiers, idTiers, dateDebutEvenement, dateCalcul);

				} else {
					// clorure
					pp = gestionDefautSurCloture(tiers, idTiers, statutDefaut, dateCalcul);
				}
			} else {
				afficheLogDebug("Pas d'initialisation d'une période probatoire pour le tiers {}. "
						+ "D'autres evenements de defaut subsistent pour tiers", idTiers);
			}

		} else {
			LOG.info(
					"On n'a pas trouvé le statut de defaut dans STATUT_TIERS correspondant au motif de l'evenement de defaut pour la sortie de defaut {} pour le tiers {}",
					motifDefaut.getMotif(), idTiers);
		}

		return pp;
	}

	private PeriodeProbatoire gestionDefautSurAnnulation(Tiers tiers, Long idTiers, LocalDate dateDebutEvenement,
			LocalDate dateCalcul) {

		StatutHistorise newStatut = null;
		PeriodeProbatoire pp = null;

		if (isLeSeulStatutDefaut(idTiers, dateDebutEvenement)) {

			// le tiers n'a que ce statut défaut qui est annulé => retour en sain
			afficheLogDebug(CREATION_LIGNE_SAIN);
			LocalDate dateDebut = trouveDateDebutSurAnnulations(idTiers, dateDebutEvenement);
			newStatut = new StatutHistorise(tiers, StatutTiers.SAIN, null, dateDebut, false, null);
		} else {
			// le tiers a d'autre Statut Defaut Clot => Création PP a partir de cette date
			afficheLogDebug(CREATION_LIGNE_PP);
			StatutHistorise statutDefautCloPlusRecent = trouveStatutDefautCloNotAnnulePlusRecent(idTiers);
			LocalDate dateDebutPP = statutDefautCloPlusRecent.getDateFin();
			pp = evtCalculeService.creePeriodeProbatoire(tiers, dateDebutPP, dateCalcul);
			newStatut = new StatutHistorise(tiers, StatutTiers.DEFAUT, statutDefautCloPlusRecent.getGravite(),
					dateDebutPP, false, new MotifStatutTiers(pp));
		}

		// inserer le nouveau statut defaut avec ou sans motif PP
		saveNewStatut(newStatut);

		return pp;

	}

	private PeriodeProbatoire gestionDefautSurCloture(Tiers tiers, Long idTiers, StatutHistorise statutDefaut,
			LocalDate dateCalcul) {

		// cas de la cloture
		afficheLogDebug(CREATION_LIGNE_PP);
		StatutHistorise statutDefautClo = trouveDateDebutSurCloture(idTiers, statutDefaut);

		PeriodeProbatoire pp = evtCalculeService.creePeriodeProbatoire(tiers, statutDefautClo.getDateFin(), dateCalcul);
		StatutHistorise newStatut = new StatutHistorise(tiers, StatutTiers.DEFAUT, statutDefautClo.getGravite(),
				statutDefautClo.getDateFin(), false, new MotifStatutTiers(pp));

		// inserer le nouveau statut defaut avec ou sans motif PP
		saveNewStatut(newStatut);

		return pp;

	}

	private boolean isLeSeulStatutDefaut(Long idTiers, LocalDate dateSortie) {
		StatutHistorise statutDefautCloNotAnnulePlusRecent = trouveStatutDefautCloNotAnnulePlusRecent(idTiers);
		StatutHistorise statutSainDepuisDerniereCloture = trouveStatutSainEntreDeuxDates(idTiers,
				statutDefautCloNotAnnulePlusRecent, dateSortie);

		boolean result = false;
		if (statutDefautCloNotAnnulePlusRecent == null || statutSainDepuisDerniereCloture != null) {
			result = true;
		}
		return result;
	}

	// fonction pour récuper la date de début de l'evenement SAIN, si y'a eu
	// plusieurs annulatio non prend le moins recent
	private LocalDate trouveDateDebutSurAnnulations(Long idTiers, LocalDate dateDebutEvenement) {
		StatutHistorise statutDefautAnnulePlusRecent = trouveStatutDefautAnnulePlusRecent(idTiers);

		// Si y'a eu un autre défaut annulé avant on retourne la date la plus ancienne
		if (statutDefautAnnulePlusRecent != null
				&& dateDebutEvenement.isBefore(statutDefautAnnulePlusRecent.getDateFin())) {
			return statutDefautAnnulePlusRecent.getDateFin();
		} else {
			return dateDebutEvenement;
		}
	}

	// fonction pour récuper le statut CLO origine creation PP
	private StatutHistorise trouveDateDebutSurCloture(Long idTiers, StatutHistorise statutCourant) {
		StatutHistorise statutDefautCloNotAnnulePlusRecent = trouveStatutDefautCloNotAnnulePlusRecent(idTiers);

		if (statutDefautCloNotAnnulePlusRecent == null
				|| statutCourant.getDateFin().isAfter(statutDefautCloNotAnnulePlusRecent.getDateFin())) {
			return statutCourant;
		} else {
			return statutDefautCloNotAnnulePlusRecent;
		}

	}

	private void afficheLogDebug(String message, Object... parametres) {
		if (LOG.isDebugEnabled()) {
			LOG.debug(message, parametres);
		}
	}

	@Override
	public void sortieDeDefaut(Tiers tiers, LocalDate dateSortie, MotifStatutTiers motif) {
		List<StatutHistorise> statutsCourants = getStatutsADate(tiers.getId(), dateSortie);
		// cloturer ligne defaut avec le motif PP
		StatutHistorise statutPP = recupererStatutTiersByMotif(statutsCourants, Constant.EVENEMENT_PP);
		if (statutPP != null && StatutTiers.DEFAUT == statutPP.getStatut()) {
			statutPP.setDateFin(dateSortie);
		}

		// inserer le nouveau statut sain
		StatutHistorise newStatut = new StatutHistorise(tiers, StatutTiers.SAIN, null, dateSortie, false, motif);
		saveNewStatut(newStatut);
		if (LOG.isDebugEnabled()) {
			LOG.debug("Mise à jour du statut du tiers {} en sain", tiers.getId());
		}

	}

	@Override
	public void initStatutTiersASain(Long idTiers, LocalDate dateCreationTiers) {
		// inserer le nouveau statut sain
		StatutHistorise newStatut = new StatutHistorise(rechercheTiersService.getTiers(idTiers), StatutTiers.SAIN, null,
				dateCreationTiers, false, null);
		saveNewStatut(newStatut);
		if (LOG.isDebugEnabled()) {
			LOG.debug("Création du nouveau statut SAIN pour le tiers {}", idTiers);
		}
	}

	private StatutHistorise recupererStatutTiersByMotif(List<StatutHistorise> listStatuts, String motif) {
		List<StatutHistorise> list = listStatuts.stream()
				.filter(x -> (x.getMotif() != null && motif.equals(x.getMotif().getMotif())))
				.collect(Collectors.toList());
		if (list.size() == 1) {
			return list.get(0);
		}
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public StatutHistorise trouveStatutDefautByMotif(Long idTiers, LocalDate date, MotifStatutTiers motif) {
		return trouveStatutDefautByMotif(getStatutsADate(idTiers, date), motif);
	}

	protected StatutHistorise trouveStatutDefautByMotif(List<StatutHistorise> statuts, MotifStatutTiers motif) {
		for (StatutHistorise statutTiers : statuts) {
			if (motif.equals(statutTiers.getMotif())) {
				return statutTiers;
			}
		}
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public StatutHistorise trouveStatutDefautCloNotAnnulePlusRecent(Long idTiers) {
		StatutHistorise ret = null;
		List<StatutHistorise> statutsCourants = ContexteCalculTiers.getStatutsCourants(idTiers);
		List<StatutHistorise> statutClo = statutsCourants
				.stream().filter(s -> StatutTiers.DEFAUT.equals(s.getStatut()) && s.getDateFin() != null
						&& !s.getAnnule() && !Constant.EVENEMENT_PP.equals(s.getMotif().getMotif()))
				.collect(Collectors.toList());

		for (StatutHistorise statutTiers : statutClo) {
			if (ret == null || statutTiers.getDateFin().isAfter(ret.getDateFin())) {
				ret = statutTiers;
			}
		}
		return ret;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public StatutHistorise trouveStatutDefautAnnulePlusRecent(Long idTiers) {
		StatutHistorise ret = null;
		List<StatutHistorise> statutsCourants = ContexteCalculTiers.getStatutsCourants(idTiers);
		List<StatutHistorise> statutClo = statutsCourants.stream()
				.filter(s -> StatutTiers.DEFAUT.equals(s.getStatut()) && s.getDateFin() != null && s.getAnnule())
				.collect(Collectors.toList());

		for (StatutHistorise statutTiers : statutClo) {
			if (ret == null || statutTiers.getDateFin().isAfter(ret.getDateFin())) {
				ret = statutTiers;
			}
		}
		return ret;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public StatutHistorise trouveStatutSainEntreDeuxDates(Long idTiers, StatutHistorise statut, LocalDate date2) {
		StatutHistorise ret = null;
		if (statut != null) {
			List<StatutHistorise> statutsCourants = ContexteCalculTiers.getStatutsCourants(idTiers);
			List<StatutHistorise> statutClo = statutsCourants.stream()
					.filter(s -> StatutTiers.SAIN.equals(s.getStatut()) && s.getDateFin().isAfter(statut.getDateFin())
							&& s.getDateFin().isBefore(date2) && !s.getAnnule())
					.collect(Collectors.toList());

			for (StatutHistorise statutTiers : statutClo) {
				if (ret == null || statutTiers.getDateFin().isAfter(ret.getDateFin())) {
					ret = statutTiers;
				}
			}
		}
		return ret;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<StatutHistorise> getStatutsADate(Long idTiers, LocalDate date) {
		List<StatutHistorise> statutsCourants = ContexteCalculTiers.getStatutsCourants(idTiers);
		return statutsCourants.stream().filter(s -> (date.isAfter(s.getDateDebut()) || date.isEqual(s.getDateDebut()))
				&& (s.getDateFin() == null || date.isBefore(s.getDateFin()))).collect(Collectors.toList());
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<StatutHistorise> getStatutsActif(Long idTiers, LocalDate date) {
		List<StatutHistorise> statutsCourants = ContexteCalculTiers.getStatutsCourants(idTiers);
		return statutsCourants.stream().filter(s -> s.getDateFin() == null).collect(Collectors.toList());
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<StatutHistorise> getStatutsSain(Long idTiers) {
		List<StatutHistorise> statutsCourants = ContexteCalculTiers.getStatutsCourants(idTiers);
		return statutsCourants.stream().filter(s -> StatutTiers.SAIN.equals(s.getStatut()))
				.collect(Collectors.toList());
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<StatutHistorise> getAllStatuts(Long idTiers) {
		return ContexteCalculTiers.getStatutsCourants(idTiers);
	}

	@Override
	public Map<Long, List<StatutHistorise>> getStatutsADate(LotIdTiersDTO data) {
		Map<Long, List<StatutHistorise>> ret = new HashMap<>();
		List<StatutHistorise> statutsCourants = statutTiersRepository.getStatutWithListTiersADate(data.getIdsTiers());
		for (StatutHistorise statu : statutsCourants) {
			List<StatutHistorise> st = ret.get(statu.getTiers().getId());
			if (st == null) {
				st = new ArrayList<>();
			}
			st.add(statu);
			ret.put(statu.getTiers().getId(), st);
		}

		return ret;
	}

	/**
	 * Persistence du statut avec mise à jour du cache du tiers.
	 *
	 * @param newStatut
	 */
	private void saveNewStatut(StatutHistorise newStatut) {
		StatutHistorise statutSauve = statutTiersRepository.save(newStatut);
		ContexteCalculTiers.addStatutsCourants(newStatut.getTiers().getId(), statutSauve);
	}

	/*
	 * Setters
	 */
	public void setStatutTiersRepository(StatutTiersRepository statutTiersRepository) {
		this.statutTiersRepository = statutTiersRepository;
	}

	public void setRechercheTiersService(RechercheTiersService rechercheTiersService) {
		this.rechercheTiersService = rechercheTiersService;
	}

	public void setEvtCalculeService(EvenementCalculeService evtCalculeService) {
		this.evtCalculeService = evtCalculeService;
	}

	public void setImpactService(EvenementImpactService impactService) {
		this.impactService = impactService;
	}

	public void setIdentiteTiersService(IdentiteTiersService identiteTiersService) {
		this.identiteTiersService = identiteTiersService;
	}

	public void setRefCliSegService(RefCliSegService refCliSegService) {
		this.refCliSegService = refCliSegService;
	}
}

package fr.bpce.yyd.service.commun.service;

import java.time.LocalDate;

import org.springframework.stereotype.Service;

import fr.bpce.yyd.commun.enums.StatutAuditEvenement;
import fr.bpce.yyd.commun.model.AuditCalcul;
import fr.bpce.yyd.commun.model.EvenementCalcule;

@Service
public interface AuditCalculService {

	/**
	 * Crée une ligne d'AuditCalcul attachée à l'EvenementCalcule ectCalc.
	 *
	 * @param evtCalc
	 * @param code
	 * @param statut
	 * @param dateEffet
	 * @return
	 */
	AuditCalcul creeAuditCalcul(EvenementCalcule evtCalc, String code, StatutAuditEvenement statut, LocalDate dateEffet,
			LocalDate dateCalcul);

	AuditCalcul recupererAuditPeriodeProbatoire(Long idEvenementCalcule, Long idTiers, LocalDate dateCalcul);

	void clotureAuditCalcul(Long idTiers, LocalDate dateCalcul);
}

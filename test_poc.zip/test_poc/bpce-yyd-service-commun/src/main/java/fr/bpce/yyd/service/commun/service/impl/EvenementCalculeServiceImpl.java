package fr.bpce.yyd.service.commun.service.impl;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fr.bpce.yyd.commun.enums.CodeEvenement;
import fr.bpce.yyd.commun.enums.EvenementArriereSignificatif;
import fr.bpce.yyd.commun.enums.StatutAuditEvenement;
import fr.bpce.yyd.commun.messages.dto.LotIdTiersDTO;
import fr.bpce.yyd.commun.model.ArriereSignificatif;
import fr.bpce.yyd.commun.model.ComplementArriere;
import fr.bpce.yyd.commun.model.ComplementImpaye;
import fr.bpce.yyd.commun.model.ElementsDeCalcul;
import fr.bpce.yyd.commun.model.Evenement;
import fr.bpce.yyd.commun.model.EvenementCalcule;
import fr.bpce.yyd.commun.model.ImpayeSurForbearance;
import fr.bpce.yyd.commun.model.PeriodeProbatoire;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.service.commun.beans.EvenementsCalculesTiers;
import fr.bpce.yyd.service.commun.contexte.ContexteCalculTiers;
import fr.bpce.yyd.service.commun.repository.EvenementCalculeRepository;
import fr.bpce.yyd.service.commun.service.AuditCalculService;
import fr.bpce.yyd.service.commun.service.EvenementCalculeService;
import fr.bpce.yyd.service.commun.service.IdentiteTiersService;
import fr.bpce.yyd.service.commun.service.ParametresNDoD;

@Service
public class EvenementCalculeServiceImpl implements EvenementCalculeService {

	@Autowired
	private EvenementCalculeRepository evtCalculeRepository;

	@Autowired
	private IdentiteTiersService identiteTiersService;

	@Autowired
	private AuditCalculService auditCalculService;

	@Autowired
	private ParametresNDoD paramsNDoD;

	private static final int DUREE_MAX_ARX = 15;

	/**
	 * {@inheritDoc}
	 */
	@Override
	public ArriereSignificatif rechercheArriereSignificatifADate(Long idTiers, LocalDate dateCalcul) {
		EvenementsCalculesTiers evtsCalcTiers = rechercheEvenementsCalculesActifsADate(idTiers, dateCalcul);
		return evtsCalcTiers.getArriereSignigicatif();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public ArriereSignificatif creeArriereSignificatif(Tiers tiers, LocalDate enDateDu, LocalDate dateCalcul,
			ElementsDeCalcul calcul, boolean chgtTiersId) {
		ArriereSignificatif as = new ArriereSignificatif();
		LocalDate dateDebutAs = enDateDu;
		long nbJours = ChronoUnit.DAYS.between(enDateDu, dateCalcul);
		if (nbJours >= DUREE_MAX_ARX && !chgtTiersId) {
			dateDebutAs = dateCalcul.minusDays(DUREE_MAX_ARX);
		}
		as.setDateDebut(dateDebutAs);
		as.setTiers(tiers);
		as.setComplement(new ComplementArriere());
		as.getComplement().setEntree(calcul);
		calcul.setTiers(tiers);
		if (calcul.getDateCalcul() == null) {
			calcul.setDateCalcul(dateDebutAs);
		}

		evtCalculeRepository.save(as);
		EvenementsCalculesTiers evtCalc = ContexteCalculTiers.getEvtCalculesTiers(tiers.getId());
		evtCalc.setArriereSignigicatif(as);
		ContexteCalculTiers.setEvtCalculesTiers(tiers.getId(), evtCalc);
		return as;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void closArriereSignificatif(ArriereSignificatif asAClore, LocalDate enDateDu, ElementsDeCalcul calcul,
			LocalDate dateCalcul) {
		if (asAClore.getDateFin() == null) {
			asAClore.setDateFin(enDateDu);
			asAClore.getComplement().setSortie(calcul);

			if (asAClore.getComplement().getDernierEvenementEnvoye() != null) {
				auditCalculService.creeAuditCalcul(asAClore,
						asAClore.getComplement().getDernierEvenementEnvoye().name(), StatutAuditEvenement.CLO, enDateDu,
						dateCalcul);
			}

			EvenementsCalculesTiers evtCalc = ContexteCalculTiers.getEvtCalculesTiers(asAClore.getTiers().getId());
			evtCalc.setArriereSignigicatif(asAClore);
			ContexteCalculTiers.setEvtCalculesTiers(asAClore.getTiers().getId(), evtCalc);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public EvenementsCalculesTiers rechercheEvenementsCalculesActifsADate(Long idTiers, LocalDate date) {
		EvenementsCalculesTiers evtCalc = ContexteCalculTiers.getEvtCalculesTiers(idTiers);

		if (evtCalc.getArriereSignigicatif() != null && evtCalc.getArriereSignigicatif().getDateFin() != null
				&& date.isAfter(evtCalc.getArriereSignigicatif().getDateFin())) {
			evtCalc.setArriereSignigicatif(null);
		}

		if (evtCalc.getPeriodeProbatoire() != null && evtCalc.getPeriodeProbatoire().getDateFin() != null
				&& (date.isAfter(evtCalc.getPeriodeProbatoire().getDateFin())
						|| date.equals(evtCalc.getPeriodeProbatoire().getDateFin()))) {
			evtCalc.setPeriodeProbatoire(null);
		}

		evtCalc.setImpayesSurForbearance(evtCalc.getImpayesSurForbearance().stream()
				.filter(s -> s.getDateFin() == null || date.isBefore(s.getDateFin())).collect(Collectors.toList()));

		return evtCalc;
	}

	@Override
	public Map<Long, EvenementsCalculesTiers> rechercheEvenementsCalculesActifsADate(LotIdTiersDTO data) {
		Map<Long, EvenementsCalculesTiers> ret = new HashMap<>();
		Map<Long, List<EvenementCalcule>> res = new HashMap<>();

		List<EvenementCalcule> evtCalc = evtCalculeRepository
				.rechercheEvenementsCalculesWithListTiersActifsADate(data.getIdsTiers(), data.getDateCalcul());

		for (EvenementCalcule evt : evtCalc) {
			List<EvenementCalcule> calcs = res.get(evt.getTiers().getId());
			if (calcs == null) {
				calcs = new ArrayList<>();
			}
			calcs.add(evt);
			res.put(evt.getTiers().getId(), calcs);
		}

		for (List<EvenementCalcule> listEvt : res.values()) {
			ret.put(listEvt.get(0).getTiers().getId(), new EvenementsCalculesTiers(listEvt));
		}

		return ret;
	}

	@Override
	public Map<Long, ComplementArriere> rechercheComplementArriere(LotIdTiersDTO data) {
		Map<Long, ComplementArriere> ret = new HashMap<>();

		List<ComplementArriere> evtCalc = evtCalculeRepository.rechercheComplementArriereTiers(data.getIdsTiers());

		for (ComplementArriere evt : evtCalc) {
			ret.put(evt.getArriere().getId(), evt);
		}

		return ret;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public EvenementArriereSignificatif categoriseArriereSignificatif(Long idTiers, ArriereSignificatif as,
			LocalDate dateEtat) {
		String segment = identiteTiersService.donneSegmentDuTiers(idTiers, dateEtat);
		long nbJours = ChronoUnit.DAYS.between(as.getDateDebut(), dateEtat);
		if (nbJours >= paramsNDoD.getNbJoursASVersDefaut(segment, dateEtat)) {
			return EvenementArriereSignificatif.AR3;
		} else if (nbJours >= 60) {
			return EvenementArriereSignificatif.AR2;
		} else if (nbJours >= 30) {
			return EvenementArriereSignificatif.AR1;
		} else {
			return EvenementArriereSignificatif.AR0;
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Map<EvenementArriereSignificatif, LocalDate> calculeCalendrierArriereSignificatif(Long idTiers,
			ArriereSignificatif as, LocalDate dateEtat) {
		String segment = identiteTiersService.donneSegmentDuTiers(idTiers, dateEtat);
		Map<EvenementArriereSignificatif, LocalDate> ret = new EnumMap<>(EvenementArriereSignificatif.class);
		ret.put(EvenementArriereSignificatif.AR0, as.getDateDebut());
		ret.put(EvenementArriereSignificatif.AR1, as.getDateDebut().plusDays(30));
		ret.put(EvenementArriereSignificatif.AR2, as.getDateDebut().plusDays(60));
		ret.put(EvenementArriereSignificatif.AR3,
				as.getDateDebut().plusDays(paramsNDoD.getNbJoursASVersDefaut(segment, dateEtat)));
		return ret;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public PeriodeProbatoire creePeriodeProbatoire(Tiers tiers, LocalDate enDateDu, LocalDate dateCalcul) {
		PeriodeProbatoire pp = new PeriodeProbatoire();
		pp.setDateDebut(enDateDu);
		pp.setTiers(tiers);

		evtCalculeRepository.save(pp);
		EvenementsCalculesTiers evtCalc = ContexteCalculTiers.getEvtCalculesTiers(tiers.getId());
		evtCalc.setPeriodeProbatoire(pp);
		ContexteCalculTiers.setEvtCalculesTiers(tiers.getId(), evtCalc);

		// calcul du statut de de la periode probatoire a sa creation
		ArriereSignificatif as = evtCalc.getArriereSignigicatif();
		StatutAuditEvenement statutPP = as == null || as.getDateFin() != null ? StatutAuditEvenement.ACT : StatutAuditEvenement.SUS;

		auditCalculService.creeAuditCalcul(pp, CodeEvenement.PP.name(), statutPP, enDateDu, dateCalcul);
		return pp;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void closPeriodeProbatoire(PeriodeProbatoire pp, LocalDate enDateDu, LocalDate dateCalcul) {
		if (pp != null && (pp.getDateFin() == null || pp.getDateFin().isAfter(enDateDu))) {
			pp.setDateFin(enDateDu);
			auditCalculService.creeAuditCalcul(pp, CodeEvenement.PP.name(), StatutAuditEvenement.CLO, enDateDu,
					dateCalcul);
			evtCalculeRepository.save(pp);

			EvenementsCalculesTiers evtCalc = ContexteCalculTiers.getEvtCalculesTiers(pp.getTiers().getId());
			evtCalc.setPeriodeProbatoire(pp);
			ContexteCalculTiers.setEvtCalculesTiers(pp.getTiers().getId(), evtCalc);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public ImpayeSurForbearance creeImpayeSurForbearance(Tiers tiers, LocalDate enDateDu, ArriereSignificatif as,
			Evenement forbearance, Evenement impaye) {
		ComplementImpaye complement = new ComplementImpaye();
		complement.setArriere(as);
		complement.setEvenementForbearance(forbearance);
		complement.setEvenementImpaye(impaye);
		ImpayeSurForbearance isf = new ImpayeSurForbearance();
		isf.setDateDebut(enDateDu);
		isf.setTiers(tiers);
		isf.setComplement(complement);

		evtCalculeRepository.save(isf);
		EvenementsCalculesTiers evtCalc = ContexteCalculTiers.getEvtCalculesTiers(tiers.getId());
		evtCalc.getImpayesSurForbearance().add(isf);
		ContexteCalculTiers.setEvtCalculesTiers(tiers.getId(), evtCalc);

		return isf;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<ArriereSignificatif> rechercheArriereSignificatifEntreDeuxDate(Long idTiers, LocalDate dateDebut,
			LocalDate dateFin) {
		List<EvenementCalcule> evtsCalcTiers = evtCalculeRepository.rechercheEvenementsCalculesEntreDeuxDates(idTiers,
				dateDebut, dateFin);
		List<ArriereSignificatif> list = new ArrayList<>();
		for (EvenementCalcule evtCalc : evtsCalcTiers) {
			if (evtCalc instanceof ArriereSignificatif) {
				list.add((ArriereSignificatif) evtCalc);
			}
		}
		return list;
	}

	@Override
	public void clotureEvenementCalcul(Long idTiers, LocalDate dateCalcul) {

		List<EvenementCalcule> evenementCalculs = evtCalculeRepository.rechercheEvenementCalculTiers(idTiers);
		evenementCalculs.forEach(evenementCalcul -> evenementCalcul.setDateFin(dateCalcul));
		evtCalculeRepository.saveAll(evenementCalculs);
	}

	/*
	 * Setters
	 */
	public void setEvtCalculeRepository(EvenementCalculeRepository evtCalculeRepository) {
		this.evtCalculeRepository = evtCalculeRepository;
	}

	public void setIdentiteTiersService(IdentiteTiersService identiteTiersService) {
		this.identiteTiersService = identiteTiersService;
	}

	public void setAuditCalculService(AuditCalculService auditCalculService) {
		this.auditCalculService = auditCalculService;
	}

	public void setParamsNDoD(ParametresNDoD paramsNDoD) {
		this.paramsNDoD = paramsNDoD;
	}

	@Override
	public LocalDate rechercheDateFinDernierArriereSignificatif(Long idTiers) {
		Timestamp timeStamp = evtCalculeRepository.rechercheDateDernierArriereSignificatif(idTiers);

		return (timeStamp == null) ? null : timeStamp.toLocalDateTime().toLocalDate();
	}

	@Override
	public LocalDate rechercheDateDebutArriereSignificatif(Long idTiers) {
		Timestamp timeStamp = evtCalculeRepository.rechercheDateDebutArriereSignificatif(idTiers);

		return (timeStamp == null) ? null : timeStamp.toLocalDateTime().toLocalDate();
	}

}

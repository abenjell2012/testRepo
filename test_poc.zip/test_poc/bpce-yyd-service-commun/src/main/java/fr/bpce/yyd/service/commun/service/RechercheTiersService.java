package fr.bpce.yyd.service.commun.service;

import fr.bpce.yyd.commun.model.Tiers;

public interface RechercheTiersService {

	/**
	 * Retourne le Tiers identifié par idTiers ou null si aucun tiers n'a cet
	 * identifiant.
	 *
	 * @param idTiers
	 * @return
	 */
	Tiers getTiers(Long idTiers);
}

package fr.bpce.yyd.service.commun.config.kafka;

import org.springframework.kafka.support.serializer.JsonSerializer;

import fr.bpce.yyd.commun.messages.dto.LotIdTiersDTO;

public class LotIdTiersDtoSerializer extends JsonSerializer<LotIdTiersDTO> {
}

package fr.bpce.yyd.service.commun.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import fr.bpce.yyd.commun.messages.dto.LotIdTiersDTO;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.Tiers;

public interface IdentiteTiersService {

	/**
	 * Retourne le (code) segment du tiers à date. Le code segment est celui de la
	 * première identité active du tiers à cette date remontée par la BD.
	 *
	 * Si il n'y en a pas, la méthode retourne "NSEG".
	 *
	 * @param idTiers
	 * @param date
	 * @return
	 */
	String donneSegmentDuTiers(Long idTiers, LocalDate date);

	/**
	 * Méthode qui récupère les identités actives d'un tiers à date
	 *
	 * @param idTiers
	 * @param dateCalcul
	 * @return
	 */
	List<IdentiteTiers> rechercheIdentitesActivesADate(Long idTiers, LocalDate dateCalcul);

	Map<Long, List<IdentiteTiers>> rechercheIdentitesActivesADate(LotIdTiersDTO data);

	List<IdentiteTiers> rechercheAllIdentites(Long idTiers, LocalDate dateCalcul);

	String donneCodeBanqueDuTiersRetail(Long idTiers, LocalDate date);

	Tiers rechercheTiersById(Long tiersId);

	Map<Long, Tiers> rechercheAllTiers(List<Long> idsTiers);
}
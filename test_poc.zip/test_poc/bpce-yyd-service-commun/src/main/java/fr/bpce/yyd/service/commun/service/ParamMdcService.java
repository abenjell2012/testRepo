package fr.bpce.yyd.service.commun.service;

import java.time.LocalDate;

import fr.bpce.yyd.commun.enums.CodeParamMdc;
import fr.bpce.yyd.commun.model.ParMdcSeg;
import fr.bpce.yyd.service.commun.util.ParamMap;

public interface ParamMdcService {

	public ParamMap getParamsMdcSegMapADate(LocalDate dateCalcul);

	public ParamMap getParamsMdcBqSegMapADate(LocalDate dateCalcul);

	public String getParamMdcSegValueADate(CodeParamMdc param, String segment, LocalDate dateCalcul);

	public String getParamMdcBqSegValueADate(CodeParamMdc param, String codeBanque, String segment,
			LocalDate dateCalcul);

	public ParMdcSeg getParamMdcADate(CodeParamMdc codeParam);

	public void updateParamMdc(String valeurParam, CodeParamMdc codeParam);

	public ParMdcSeg initParamMdc(ParMdcSeg param);
}

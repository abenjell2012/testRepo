package fr.bpce.yyd.service.commun.service;

import java.time.LocalDate;

import fr.bpce.yyd.commun.enums.StatutTiers;

public interface StatutTiersService {

	/**
	 * Méthode haut niveau donnant le statut d'un tiers à date sans en détailler les
	 * motifs.
	 *
	 * @param idTiers
	 * @param date
	 * @return
	 */
	StatutTiers getStatutADate(Long idTiers, LocalDate date);
}

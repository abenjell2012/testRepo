package fr.bpce.yyd.service.commun.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import fr.bpce.yyd.commun.model.AuditCalcul;

@Repository
public interface AuditCalculRepository extends CrudRepository<AuditCalcul, Long> {

	@Query(value = "select c from AuditCalcul c where c.idTiers = :idTiers and c.evenementCalcule.id = :idEvenementCalcule and c.code = 'PP' "
			+ "and c.dateEffet = (select max(a.dateEffet) from AuditCalcul a where a.idTiers = :idTiers and a.evenementCalcule.id = :idEvenementCalcule and a.code = 'PP' and a.dateEffet <= :date) order by c.id desc")
	List<AuditCalcul> rechercheAuditCalculePPActifOuSuspenduADate(@Param("idEvenementCalcule") Long idEvenementCalcule,
			@Param("idTiers") Long idTiers, @Param("date") LocalDate date);

	@Query(value = "select a from AuditCalcul a " + "where a.statut = 'ACT' and a.idTiers = :idTiers "
			+ "and 0 = (select count(*) from AuditCalcul a2 where  a.code = a2.code and a.idTiers = a2.idTiers and a2.statut = 'CLO')")
	List<AuditCalcul> rechercheAuditCalculAClotuer(@Param("idTiers") Long idTiers);
}
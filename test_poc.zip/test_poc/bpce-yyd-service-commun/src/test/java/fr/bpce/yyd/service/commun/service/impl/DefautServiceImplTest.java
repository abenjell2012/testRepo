package fr.bpce.yyd.service.commun.service.impl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import fr.bpce.yyd.commun.constantes.Constant;
import fr.bpce.yyd.commun.enums.StatutEvenement;
import fr.bpce.yyd.commun.enums.StatutTiers;
import fr.bpce.yyd.commun.model.ComplementEvenement;
import fr.bpce.yyd.commun.model.Evenement;
import fr.bpce.yyd.commun.model.ImpayeSurForbearance;
import fr.bpce.yyd.commun.model.MotifStatutTiers;
import fr.bpce.yyd.commun.model.PeriodeProbatoire;
import fr.bpce.yyd.commun.model.StatutHistorise;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.service.commun.contexte.ContexteCalculTiers;
import fr.bpce.yyd.service.commun.repository.StatutTiersRepository;
import fr.bpce.yyd.service.commun.service.EvenementCalculeService;
import fr.bpce.yyd.service.commun.service.RechercheTiersService;

@RunWith(PowerMockRunner.class)
@PrepareForTest(ContexteCalculTiers.class)
public class DefautServiceImplTest {

	PeriodeProbatoire periodeProbatoireCree;
	StatutHistorise nouveauStatut;

	@Before
	public void initValeursRetournees() {
		ContexteCalculTiers.clear();
		periodeProbatoireCree = null;
		nouveauStatut = null;
	}

	@Test
	public void creationPeriodeProbatoire() {
		// Arrange
		DefautServiceImpl defautService = new DefautServiceImpl();

		// Un seul statut de défaut : un impayé sur forbearance
		ImpayeSurForbearance evtDef = new ImpayeSurForbearance();
		evtDef.setId(1L);
		List<StatutHistorise> statuts = new ArrayList<>();
		StatutHistorise statutDefaut = new StatutHistorise();
		statutDefaut.setDateDeb(LocalDate.now().minusDays(20));
		statutDefaut.setStatut(StatutTiers.DEFAUT);
		statutDefaut.setMotif(new MotifStatutTiers(evtDef));
		statuts.add(statutDefaut);

		PowerMockito.mockStatic(ContexteCalculTiers.class);
		PowerMockito.when(ContexteCalculTiers.getStatutsCourants(Mockito.any())).thenReturn(statuts);

		StatutTiersRepository statutTiersRepository = Mockito.mock(StatutTiersRepository.class);
		Mockito.when(statutTiersRepository.getStatutADate(Mockito.any(), Mockito.any())).thenReturn(statuts);

		defautService.setStatutTiersRepository(statutTiersRepository);

		initServicesCommuns(defautService, statutTiersRepository);

		LocalDate dateSortie = LocalDate.now().minusDays(2);

		// Act : on sort de l'impayé
		defautService.sortieDUnEvenementDeDefaut(0L, dateSortie, new MotifStatutTiers(evtDef), false, dateSortie);

		// Assert
		Assert.assertNotNull(periodeProbatoireCree);
		Assert.assertEquals(dateSortie, periodeProbatoireCree.getDateDebut());
		Assert.assertNotNull(nouveauStatut);
		Assert.assertEquals(Constant.EVENEMENT_PP, nouveauStatut.getMotif().getMotif());
		Assert.assertEquals(dateSortie, nouveauStatut.getDateDebut());
	}

	@Test
	public void sortieDefautSansPeriodeProbatoire() {
		// Arrange
		DefautServiceImpl defautService = new DefautServiceImpl();

		// Un seul statut de défaut : un Evenement Defaut
		Evenement evt = new Evenement();
		evt.setId(1L);
		evt.setCode("PCO");
		ComplementEvenement complEvt = new ComplementEvenement();
		complEvt.setEvenement(evt);
		evt.addComplement(complEvt);

		List<StatutHistorise> statuts = new ArrayList<>();
		StatutHistorise statutDefaut = new StatutHistorise();
		statutDefaut.setDateDeb(LocalDate.now().minusDays(20));
		statutDefaut.setStatut(StatutTiers.DEFAUT);
		statutDefaut.setMotif(new MotifStatutTiers(complEvt));
		statuts.add(statutDefaut);

		StatutTiersRepository statutTiersRepository = Mockito.mock(StatutTiersRepository.class);
		Mockito.when(statutTiersRepository.getStatutADate(Mockito.any(), Mockito.any())).thenReturn(statuts);

		PowerMockito.mockStatic(ContexteCalculTiers.class);
		PowerMockito.when(ContexteCalculTiers.getStatutsCourants(Mockito.any())).thenReturn(statuts);

		defautService.setStatutTiersRepository(statutTiersRepository);

		initServicesCommuns(defautService, statutTiersRepository);

		LocalDate dateSortie = LocalDate.now().minusDays(2);

		// Act : on sort de l'Evenement Defaut qui est annulé
		ComplementEvenement complEvtAnn = new ComplementEvenement();
		complEvtAnn.setStatutEvt(StatutEvenement.ANN);
		evt.addComplement(complEvtAnn);
		defautService.sortieDUnEvenementDeDefaut(0L, dateSortie, new MotifStatutTiers(complEvtAnn), true, dateSortie);

		// Assert
		Assert.assertNull(periodeProbatoireCree);
		Assert.assertNotNull(nouveauStatut);
		Assert.assertEquals(StatutTiers.SAIN, nouveauStatut.getStatut());
		Assert.assertNull(nouveauStatut.getMotif());
		Assert.assertEquals(dateSortie, nouveauStatut.getDateDebut());
	}

	@Test
	public void cloDefaut1PuisCloDefaut2DateAnteriure() {
		// Arrange
		DefautServiceImpl defautService = new DefautServiceImpl();

		// premier statut de défaut : un Evenement Defaut
		Evenement evt1 = new Evenement();
		evt1.setId(1L);
		evt1.setCode("PCO");
		ComplementEvenement complEvt1 = new ComplementEvenement();
		complEvt1.setEvenement(evt1);
		evt1.addComplement(complEvt1);

		// premier statut de défaut : un Evenement Defaut
		Evenement evt2 = new Evenement();
		evt2.setId(1L);
		evt2.setCode("IB");
		ComplementEvenement complEvt2 = new ComplementEvenement();
		complEvt2.setEvenement(evt2);
		evt2.addComplement(complEvt2);

		List<StatutHistorise> statuts = new ArrayList<>();
		StatutHistorise statutDefaut1 = new StatutHistorise();
		statutDefaut1.setDateDeb(LocalDate.now().minusDays(20));
		statutDefaut1.setStatut(StatutTiers.DEFAUT);
		statutDefaut1.setMotif(new MotifStatutTiers(complEvt1));
		statuts.add(statutDefaut1);

		StatutHistorise statutDefaut2 = new StatutHistorise();
		statutDefaut2.setDateDeb(LocalDate.now().minusDays(15));
		statutDefaut2.setStatut(StatutTiers.DEFAUT);
		statutDefaut2.setMotif(new MotifStatutTiers(complEvt2));
		statuts.add(statutDefaut2);

		StatutTiersRepository statutTiersRepository = Mockito.mock(StatutTiersRepository.class);
		Mockito.when(statutTiersRepository.getStatutADate(Mockito.any(), Mockito.any())).thenReturn(statuts);

		PowerMockito.mockStatic(ContexteCalculTiers.class);
		PowerMockito.when(ContexteCalculTiers.getStatutsCourants(Mockito.any())).thenReturn(statuts);

		defautService.setStatutTiersRepository(statutTiersRepository);

		initServicesCommuns(defautService, statutTiersRepository);

		// Act1 : on sort de l'Evenement Defaut PCO qui est clo
		LocalDate dateSortie1 = LocalDate.now().minusDays(2);
		ComplementEvenement complEvtClo1 = new ComplementEvenement();
		complEvtClo1.setStatutEvt(StatutEvenement.CLO);
		evt1.addComplement(complEvtClo1);
		defautService.sortieDUnEvenementDeDefaut(0L, dateSortie1, new MotifStatutTiers(complEvtClo1), false,
				dateSortie1);

		// Act2 : on sort de l'Evenement Defaut IB qui est clo
		LocalDate dateSortie2 = LocalDate.now().minusDays(4);
		ComplementEvenement complEvtClo2 = new ComplementEvenement();
		complEvtClo2.setStatutEvt(StatutEvenement.CLO);
		evt2.addComplement(complEvtClo2);
		defautService.sortieDUnEvenementDeDefaut(0L, dateSortie2, new MotifStatutTiers(complEvtClo2), false,
				dateSortie2);

		// Assert
		Assert.assertNotNull(periodeProbatoireCree);
		Assert.assertEquals(dateSortie1, periodeProbatoireCree.getDateDebut());
		Assert.assertNotNull(nouveauStatut);
		Assert.assertEquals(Constant.EVENEMENT_PP, nouveauStatut.getMotif().getMotif());
		Assert.assertEquals(dateSortie1, nouveauStatut.getDateDebut());
	}

	@Test
	public void cloDefaut1PuisAnnDefaut2DateAnteriure() {
		// Arrange
		DefautServiceImpl defautService = new DefautServiceImpl();

		// premier statut de défaut : un Evenement Defaut
		Evenement evt1 = new Evenement();
		evt1.setId(1L);
		evt1.setCode("PCO");
		ComplementEvenement complEvt1 = new ComplementEvenement();
		complEvt1.setEvenement(evt1);
		evt1.addComplement(complEvt1);

		// premier statut de défaut : un Evenement Defaut
		Evenement evt2 = new Evenement();
		evt2.setId(1L);
		evt2.setCode("IB");
		ComplementEvenement complEvt2 = new ComplementEvenement();
		complEvt2.setEvenement(evt2);
		evt2.addComplement(complEvt2);

		List<StatutHistorise> statuts = new ArrayList<>();
		StatutHistorise statutDefaut1 = new StatutHistorise();
		statutDefaut1.setDateDeb(LocalDate.now().minusDays(20));
		statutDefaut1.setStatut(StatutTiers.DEFAUT);
		statutDefaut1.setMotif(new MotifStatutTiers(complEvt1));
		statuts.add(statutDefaut1);

		StatutHistorise statutDefaut2 = new StatutHistorise();
		statutDefaut2.setDateDeb(LocalDate.now().minusDays(15));
		statutDefaut2.setStatut(StatutTiers.DEFAUT);
		statutDefaut2.setMotif(new MotifStatutTiers(complEvt2));
		statuts.add(statutDefaut2);

		StatutTiersRepository statutTiersRepository = Mockito.mock(StatutTiersRepository.class);
		Mockito.when(statutTiersRepository.getStatutADate(Mockito.any(), Mockito.any())).thenReturn(statuts);

		PowerMockito.mockStatic(ContexteCalculTiers.class);
		PowerMockito.when(ContexteCalculTiers.getStatutsCourants(Mockito.any())).thenReturn(statuts);

		defautService.setStatutTiersRepository(statutTiersRepository);

		initServicesCommuns(defautService, statutTiersRepository);

		// Act1 : on sort de l'Evenement Defaut PCO qui est clo
		LocalDate dateSortie1 = LocalDate.now().minusDays(2);
		ComplementEvenement complEvtClo1 = new ComplementEvenement();
		complEvtClo1.setStatutEvt(StatutEvenement.CLO);
		evt1.addComplement(complEvtClo1);
		defautService.sortieDUnEvenementDeDefaut(0L, dateSortie1, new MotifStatutTiers(complEvtClo1), false,
				dateSortie1);

		// Act2 : on sort de l'Evenement Defaut IB qui est annul
		LocalDate dateSortie2 = LocalDate.now().minusDays(4);
		ComplementEvenement complEvtAnn2 = new ComplementEvenement();
		complEvtAnn2.setStatutEvt(StatutEvenement.ANN);
		evt2.addComplement(complEvtAnn2);
		defautService.sortieDUnEvenementDeDefaut(0L, dateSortie2, new MotifStatutTiers(complEvtAnn2), true,
				dateSortie2);

		// Assert
		Assert.assertNotNull(periodeProbatoireCree);
		Assert.assertEquals(dateSortie1, periodeProbatoireCree.getDateDebut());
		Assert.assertNotNull(nouveauStatut);
		Assert.assertEquals(Constant.EVENEMENT_PP, nouveauStatut.getMotif().getMotif());
		Assert.assertEquals(dateSortie1, nouveauStatut.getDateDebut());
	}

	@Test
	public void cloDefaut1PuisCloDefaut2DatePosterieure() {
		// Arrange
		DefautServiceImpl defautService = new DefautServiceImpl();

		// premier statut de défaut : un Evenement Defaut
		Evenement evt1 = new Evenement();
		evt1.setId(1L);
		evt1.setCode("PCO");
		ComplementEvenement complEvt1 = new ComplementEvenement();
		complEvt1.setEvenement(evt1);
		evt1.addComplement(complEvt1);

		// premier statut de défaut : un Evenement Defaut
		Evenement evt2 = new Evenement();
		evt2.setId(1L);
		evt2.setCode("IB");
		ComplementEvenement complEvt2 = new ComplementEvenement();
		complEvt2.setEvenement(evt2);
		evt2.addComplement(complEvt2);

		List<StatutHistorise> statuts = new ArrayList<>();
		StatutHistorise statutDefaut1 = new StatutHistorise();
		statutDefaut1.setDateDeb(LocalDate.now().minusDays(20));
		statutDefaut1.setStatut(StatutTiers.DEFAUT);
		statutDefaut1.setMotif(new MotifStatutTiers(complEvt1));
		statuts.add(statutDefaut1);

		StatutHistorise statutDefaut2 = new StatutHistorise();
		statutDefaut2.setDateDeb(LocalDate.now().minusDays(15));
		statutDefaut2.setStatut(StatutTiers.DEFAUT);
		statutDefaut2.setMotif(new MotifStatutTiers(complEvt2));
		statuts.add(statutDefaut2);

		StatutTiersRepository statutTiersRepository = Mockito.mock(StatutTiersRepository.class);
		Mockito.when(statutTiersRepository.getStatutADate(Mockito.any(), Mockito.any())).thenReturn(statuts);

		PowerMockito.mockStatic(ContexteCalculTiers.class);
		PowerMockito.when(ContexteCalculTiers.getStatutsCourants(Mockito.any())).thenReturn(statuts);

		defautService.setStatutTiersRepository(statutTiersRepository);

		initServicesCommuns(defautService, statutTiersRepository);

		// Act1 : on sort de l'Evenement Defaut PCO qui est clo
		LocalDate dateSortie1 = LocalDate.now().minusDays(2);
		ComplementEvenement complEvtClo1 = new ComplementEvenement();
		complEvtClo1.setStatutEvt(StatutEvenement.CLO);
		evt1.addComplement(complEvtClo1);
		defautService.sortieDUnEvenementDeDefaut(0L, dateSortie1, new MotifStatutTiers(complEvtClo1), false,
				dateSortie1);

		// Act2 : on sort de l'Evenement Defaut IB qui est clo
		LocalDate dateSortie2 = LocalDate.now();
		ComplementEvenement complEvtClo2 = new ComplementEvenement();
		complEvtClo2.setStatutEvt(StatutEvenement.CLO);
		evt2.addComplement(complEvtClo2);
		defautService.sortieDUnEvenementDeDefaut(0L, dateSortie2, new MotifStatutTiers(complEvtClo2), false,
				dateSortie2);

		// Assert
		Assert.assertNotNull(periodeProbatoireCree);
		Assert.assertEquals(dateSortie2, periodeProbatoireCree.getDateDebut());
		Assert.assertNotNull(nouveauStatut);
		Assert.assertEquals(Constant.EVENEMENT_PP, nouveauStatut.getMotif().getMotif());
		Assert.assertEquals(dateSortie2, nouveauStatut.getDateDebut());
	}

	@Test
	public void cloDefaut1PuisAnnDefaut2DatePosterieure() {
		// Arrange
		DefautServiceImpl defautService = new DefautServiceImpl();

		// premier statut de défaut : un Evenement Defaut
		Evenement evt1 = new Evenement();
		evt1.setId(1L);
		evt1.setCode("PCO");
		ComplementEvenement complEvt1 = new ComplementEvenement();
		complEvt1.setEvenement(evt1);
		evt1.addComplement(complEvt1);

		// premier statut de défaut : un Evenement Defaut
		Evenement evt2 = new Evenement();
		evt2.setId(1L);
		evt2.setCode("IB");
		ComplementEvenement complEvt2 = new ComplementEvenement();
		complEvt2.setEvenement(evt2);
		evt2.addComplement(complEvt2);

		List<StatutHistorise> statuts = new ArrayList<>();
		StatutHistorise statutDefaut1 = new StatutHistorise();
		statutDefaut1.setDateDeb(LocalDate.now().minusDays(20));
		statutDefaut1.setStatut(StatutTiers.DEFAUT);
		statutDefaut1.setMotif(new MotifStatutTiers(complEvt1));
		statuts.add(statutDefaut1);

		StatutHistorise statutDefaut2 = new StatutHistorise();
		statutDefaut2.setDateDeb(LocalDate.now().minusDays(15));
		statutDefaut2.setStatut(StatutTiers.DEFAUT);
		statutDefaut2.setMotif(new MotifStatutTiers(complEvt2));
		statuts.add(statutDefaut2);

		StatutTiersRepository statutTiersRepository = Mockito.mock(StatutTiersRepository.class);
		Mockito.when(statutTiersRepository.getStatutADate(Mockito.any(), Mockito.any())).thenReturn(statuts);

		PowerMockito.mockStatic(ContexteCalculTiers.class);
		PowerMockito.when(ContexteCalculTiers.getStatutsCourants(Mockito.any())).thenReturn(statuts);

		defautService.setStatutTiersRepository(statutTiersRepository);

		initServicesCommuns(defautService, statutTiersRepository);

		// Act1 : on sort de l'Evenement Defaut PCO qui est clo
		LocalDate dateSortie1 = LocalDate.now().minusDays(2);
		ComplementEvenement complEvtClo1 = new ComplementEvenement();
		complEvtClo1.setStatutEvt(StatutEvenement.CLO);
		evt1.addComplement(complEvtClo1);
		defautService.sortieDUnEvenementDeDefaut(0L, dateSortie1, new MotifStatutTiers(complEvtClo1), false,
				dateSortie1);

		// Act2 : on sort de l'Evenement Defaut IB qui est annul
		LocalDate dateSortie2 = LocalDate.now();
		ComplementEvenement complEvtAnn2 = new ComplementEvenement();
		complEvtAnn2.setStatutEvt(StatutEvenement.ANN);
		evt2.addComplement(complEvtAnn2);
		defautService.sortieDUnEvenementDeDefaut(0L, dateSortie2, new MotifStatutTiers(complEvtAnn2), true,
				dateSortie2);

		// Assert
		Assert.assertNotNull(periodeProbatoireCree);
		Assert.assertEquals(dateSortie1, periodeProbatoireCree.getDateDebut());
		Assert.assertNotNull(nouveauStatut);
		Assert.assertEquals(Constant.EVENEMENT_PP, nouveauStatut.getMotif().getMotif());
		Assert.assertEquals(dateSortie1, nouveauStatut.getDateDebut());
	}

	@Test
	public void annDefaut1PuisCloDefaut2DateAnteriure() {
		// Arrange
		DefautServiceImpl defautService = new DefautServiceImpl();

		// premier statut de défaut : un Evenement Defaut
		Evenement evt1 = new Evenement();
		evt1.setId(1L);
		evt1.setCode("PCO");
		ComplementEvenement complEvt1 = new ComplementEvenement();
		complEvt1.setEvenement(evt1);
		evt1.addComplement(complEvt1);

		// premier statut de défaut : un Evenement Defaut
		Evenement evt2 = new Evenement();
		evt2.setId(1L);
		evt2.setCode("IB");
		ComplementEvenement complEvt2 = new ComplementEvenement();
		complEvt2.setEvenement(evt2);
		evt2.addComplement(complEvt2);

		List<StatutHistorise> statuts = new ArrayList<>();
		StatutHistorise statutDefaut1 = new StatutHistorise();
		statutDefaut1.setDateDeb(LocalDate.now().minusDays(20));
		statutDefaut1.setStatut(StatutTiers.DEFAUT);
		statutDefaut1.setMotif(new MotifStatutTiers(complEvt1));
		statuts.add(statutDefaut1);

		StatutHistorise statutDefaut2 = new StatutHistorise();
		statutDefaut2.setDateDeb(LocalDate.now().minusDays(15));
		statutDefaut2.setStatut(StatutTiers.DEFAUT);
		statutDefaut2.setMotif(new MotifStatutTiers(complEvt2));
		statuts.add(statutDefaut2);

		StatutTiersRepository statutTiersRepository = Mockito.mock(StatutTiersRepository.class);
		Mockito.when(statutTiersRepository.getStatutADate(Mockito.any(), Mockito.any())).thenReturn(statuts);

		PowerMockito.mockStatic(ContexteCalculTiers.class);
		PowerMockito.when(ContexteCalculTiers.getStatutsCourants(Mockito.any())).thenReturn(statuts);

		defautService.setStatutTiersRepository(statutTiersRepository);

		initServicesCommuns(defautService, statutTiersRepository);

		// Act1 : on sort de l'Evenement Defaut PCO qui est clo
		LocalDate dateSortie1 = LocalDate.now().minusDays(2);
		ComplementEvenement complEvtAnn1 = new ComplementEvenement();
		complEvtAnn1.setStatutEvt(StatutEvenement.ANN);
		evt1.addComplement(complEvtAnn1);
		defautService.sortieDUnEvenementDeDefaut(0L, dateSortie1, new MotifStatutTiers(complEvtAnn1), true,
				dateSortie1);

		// Act2 : on sort de l'Evenement Defaut IB qui est clo
		LocalDate dateSortie2 = LocalDate.now().minusDays(4);
		ComplementEvenement complEvtClo2 = new ComplementEvenement();
		complEvtClo2.setStatutEvt(StatutEvenement.CLO);
		evt2.addComplement(complEvtClo2);
		defautService.sortieDUnEvenementDeDefaut(0L, dateSortie2, new MotifStatutTiers(complEvtClo2), false,
				dateSortie2);

		// Assert
		Assert.assertNotNull(periodeProbatoireCree);
		Assert.assertEquals(dateSortie2, periodeProbatoireCree.getDateDebut());
		Assert.assertNotNull(nouveauStatut);
		Assert.assertEquals(Constant.EVENEMENT_PP, nouveauStatut.getMotif().getMotif());
		Assert.assertEquals(dateSortie2, nouveauStatut.getDateDebut());
	}

	@Test
	public void annDefaut1PuisAnnDefaut2DateAnteriure() {
		// Arrange
		DefautServiceImpl defautService = new DefautServiceImpl();

		// premier statut de défaut : un Evenement Defaut
		Evenement evt1 = new Evenement();
		evt1.setId(1L);
		evt1.setCode("PCO");
		ComplementEvenement complEvt1 = new ComplementEvenement();
		complEvt1.setEvenement(evt1);
		evt1.addComplement(complEvt1);

		// premier statut de défaut : un Evenement Defaut
		Evenement evt2 = new Evenement();
		evt2.setId(1L);
		evt2.setCode("IB");
		ComplementEvenement complEvt2 = new ComplementEvenement();
		complEvt2.setEvenement(evt2);
		evt2.addComplement(complEvt2);

		List<StatutHistorise> statuts = new ArrayList<>();
		StatutHistorise statutDefaut1 = new StatutHistorise();
		statutDefaut1.setDateDeb(LocalDate.now().minusDays(20));
		statutDefaut1.setStatut(StatutTiers.DEFAUT);
		statutDefaut1.setMotif(new MotifStatutTiers(complEvt1));
		statuts.add(statutDefaut1);

		StatutHistorise statutDefaut2 = new StatutHistorise();
		statutDefaut2.setDateDeb(LocalDate.now().minusDays(15));
		statutDefaut2.setStatut(StatutTiers.DEFAUT);
		statutDefaut2.setMotif(new MotifStatutTiers(complEvt2));
		statuts.add(statutDefaut2);

		StatutTiersRepository statutTiersRepository = Mockito.mock(StatutTiersRepository.class);
		Mockito.when(statutTiersRepository.getStatutADate(Mockito.any(), Mockito.any())).thenReturn(statuts);

		PowerMockito.mockStatic(ContexteCalculTiers.class);
		PowerMockito.when(ContexteCalculTiers.getStatutsCourants(Mockito.any())).thenReturn(statuts);

		defautService.setStatutTiersRepository(statutTiersRepository);

		initServicesCommuns(defautService, statutTiersRepository);

		// Act1 : on sort de l'Evenement Defaut PCO qui est clo
		LocalDate dateSortie1 = LocalDate.now().minusDays(2);
		ComplementEvenement complEvtAnn1 = new ComplementEvenement();
		complEvtAnn1.setStatutEvt(StatutEvenement.ANN);
		evt1.addComplement(complEvtAnn1);
		defautService.sortieDUnEvenementDeDefaut(0L, dateSortie1, new MotifStatutTiers(complEvtAnn1), true,
				dateSortie1);

		// Act2 : on sort de l'Evenement Defaut IB qui est annul
		LocalDate dateSortie2 = LocalDate.now().minusDays(4);
		ComplementEvenement complEvtAnn2 = new ComplementEvenement();
		complEvtAnn2.setStatutEvt(StatutEvenement.ANN);
		evt2.addComplement(complEvtAnn2);
		defautService.sortieDUnEvenementDeDefaut(0L, dateSortie2, new MotifStatutTiers(complEvtAnn2), true,
				dateSortie2);

		// Assert
		Assert.assertNull(periodeProbatoireCree);
		Assert.assertNotNull(nouveauStatut);
		Assert.assertEquals(StatutTiers.SAIN, nouveauStatut.getStatut());
		Assert.assertNull(nouveauStatut.getMotif());
		Assert.assertEquals(dateSortie1, nouveauStatut.getDateDebut());
	}

	@Test
	public void annDefaut1PuisCloDefaut2DatePosterieure() {
		// Arrange
		DefautServiceImpl defautService = new DefautServiceImpl();

		// premier statut de défaut : un Evenement Defaut
		Evenement evt1 = new Evenement();
		evt1.setId(1L);
		evt1.setCode("PCO");
		ComplementEvenement complEvt1 = new ComplementEvenement();
		complEvt1.setEvenement(evt1);
		evt1.addComplement(complEvt1);

		// premier statut de défaut : un Evenement Defaut
		Evenement evt2 = new Evenement();
		evt2.setId(1L);
		evt2.setCode("IB");
		ComplementEvenement complEvt2 = new ComplementEvenement();
		complEvt2.setEvenement(evt2);
		evt2.addComplement(complEvt2);

		List<StatutHistorise> statuts = new ArrayList<>();
		StatutHistorise statutDefaut1 = new StatutHistorise();
		statutDefaut1.setDateDeb(LocalDate.now().minusDays(20));
		statutDefaut1.setStatut(StatutTiers.DEFAUT);
		statutDefaut1.setMotif(new MotifStatutTiers(complEvt1));
		statuts.add(statutDefaut1);

		StatutHistorise statutDefaut2 = new StatutHistorise();
		statutDefaut2.setDateDeb(LocalDate.now().minusDays(15));
		statutDefaut2.setStatut(StatutTiers.DEFAUT);
		statutDefaut2.setMotif(new MotifStatutTiers(complEvt2));
		statuts.add(statutDefaut2);

		StatutTiersRepository statutTiersRepository = Mockito.mock(StatutTiersRepository.class);
		Mockito.when(statutTiersRepository.getStatutADate(Mockito.any(), Mockito.any())).thenReturn(statuts);

		PowerMockito.mockStatic(ContexteCalculTiers.class);
		PowerMockito.when(ContexteCalculTiers.getStatutsCourants(Mockito.any())).thenReturn(statuts);

		defautService.setStatutTiersRepository(statutTiersRepository);

		initServicesCommuns(defautService, statutTiersRepository);

		// Act1 : on sort de l'Evenement Defaut PCO qui est clo
		LocalDate dateSortie1 = LocalDate.now().minusDays(2);
		ComplementEvenement complEvtAnn1 = new ComplementEvenement();
		complEvtAnn1.setStatutEvt(StatutEvenement.ANN);
		evt1.addComplement(complEvtAnn1);
		defautService.sortieDUnEvenementDeDefaut(0L, dateSortie1, new MotifStatutTiers(complEvtAnn1), true,
				dateSortie1);

		// Act2 : on sort de l'Evenement Defaut IB qui est clo
		LocalDate dateSortie2 = LocalDate.now();
		ComplementEvenement complEvtClo2 = new ComplementEvenement();
		complEvtClo2.setStatutEvt(StatutEvenement.CLO);
		evt2.addComplement(complEvtClo2);
		defautService.sortieDUnEvenementDeDefaut(0L, dateSortie2, new MotifStatutTiers(complEvtClo2), false,
				dateSortie2);

		// Assert
		Assert.assertNotNull(periodeProbatoireCree);
		Assert.assertEquals(dateSortie2, periodeProbatoireCree.getDateDebut());
		Assert.assertNotNull(nouveauStatut);
		Assert.assertEquals(Constant.EVENEMENT_PP, nouveauStatut.getMotif().getMotif());
		Assert.assertEquals(dateSortie2, nouveauStatut.getDateDebut());
	}

	@Test
	public void annDefaut1PuisAnnDefaut2DatePosterieure() {
		// Arrange
		DefautServiceImpl defautService = new DefautServiceImpl();

		// premier statut de défaut : un Evenement Defaut
		Evenement evt1 = new Evenement();
		evt1.setId(1L);
		evt1.setCode("PCO");
		ComplementEvenement complEvt1 = new ComplementEvenement();
		complEvt1.setEvenement(evt1);
		evt1.addComplement(complEvt1);

		// premier statut de défaut : un Evenement Defaut
		Evenement evt2 = new Evenement();
		evt2.setId(1L);
		evt2.setCode("IB");
		ComplementEvenement complEvt2 = new ComplementEvenement();
		complEvt2.setEvenement(evt2);
		evt2.addComplement(complEvt2);

		List<StatutHistorise> statuts = new ArrayList<>();
		StatutHistorise statutDefaut1 = new StatutHistorise();
		statutDefaut1.setDateDeb(LocalDate.now().minusDays(20));
		statutDefaut1.setStatut(StatutTiers.DEFAUT);
		statutDefaut1.setMotif(new MotifStatutTiers(complEvt1));
		statuts.add(statutDefaut1);

		StatutHistorise statutDefaut2 = new StatutHistorise();
		statutDefaut2.setDateDeb(LocalDate.now().minusDays(15));
		statutDefaut2.setStatut(StatutTiers.DEFAUT);
		statutDefaut2.setMotif(new MotifStatutTiers(complEvt2));
		statuts.add(statutDefaut2);

		StatutTiersRepository statutTiersRepository = Mockito.mock(StatutTiersRepository.class);
		Mockito.when(statutTiersRepository.getStatutADate(Mockito.any(), Mockito.any())).thenReturn(statuts);

		PowerMockito.mockStatic(ContexteCalculTiers.class);
		PowerMockito.when(ContexteCalculTiers.getStatutsCourants(Mockito.any())).thenReturn(statuts);

		defautService.setStatutTiersRepository(statutTiersRepository);

		initServicesCommuns(defautService, statutTiersRepository);

		// Act1 : on sort de l'Evenement Defaut PCO qui est clo
		LocalDate dateSortie1 = LocalDate.now().minusDays(2);
		ComplementEvenement complEvtAnn1 = new ComplementEvenement();
		complEvtAnn1.setStatutEvt(StatutEvenement.ANN);
		evt1.addComplement(complEvtAnn1);
		defautService.sortieDUnEvenementDeDefaut(0L, dateSortie1, new MotifStatutTiers(complEvtAnn1), true,
				dateSortie1);

		// Act2 : on sort de l'Evenement Defaut IB qui est annul
		LocalDate dateSortie2 = LocalDate.now();
		ComplementEvenement complEvtAnn2 = new ComplementEvenement();
		complEvtAnn2.setStatutEvt(StatutEvenement.ANN);
		evt2.addComplement(complEvtAnn2);
		defautService.sortieDUnEvenementDeDefaut(0L, dateSortie2, new MotifStatutTiers(complEvtAnn2), true,
				dateSortie2);

		// Assert
		Assert.assertNull(periodeProbatoireCree);
		Assert.assertNotNull(nouveauStatut);
		Assert.assertEquals(StatutTiers.SAIN, nouveauStatut.getStatut());
		Assert.assertNull(nouveauStatut.getMotif());
		Assert.assertEquals(dateSortie2, nouveauStatut.getDateDebut());
	}

	@Test
	public void defautCloPuisSainPuisDefautAnn() {
		// Arrange
		DefautServiceImpl defautService = new DefautServiceImpl();

		// premier statut de défaut : un Evenement Defaut
		Evenement evt1 = new Evenement();
		evt1.setId(1L);
		evt1.setCode("PCO");
		ComplementEvenement complEvt1 = new ComplementEvenement();
		complEvt1.setEvenement(evt1);
		evt1.addComplement(complEvt1);

		// premier statut de défaut : un Evenement Defaut
		Evenement evt2 = new Evenement();
		evt2.setId(1L);
		evt2.setCode("IB");
		ComplementEvenement complEvt2 = new ComplementEvenement();
		complEvt2.setEvenement(evt2);
		evt2.addComplement(complEvt2);

		List<StatutHistorise> statuts = new ArrayList<>();
		StatutHistorise statutDefaut1 = new StatutHistorise();
		statutDefaut1.setDateDeb(LocalDate.now().minusDays(20));
		statutDefaut1.setDateFin(LocalDate.now().minusDays(10));
		statutDefaut1.setStatut(StatutTiers.DEFAUT);
		statutDefaut1.setMotif(new MotifStatutTiers(complEvt1));
		statuts.add(statutDefaut1);

		StatutHistorise statutSain = new StatutHistorise();
		statutSain.setDateDeb(LocalDate.now().minusDays(10));
		statutSain.setDateFin(LocalDate.now());
		statutSain.setStatut(StatutTiers.SAIN);
		statuts.add(statutSain);

		StatutHistorise statutDefaut2 = new StatutHistorise();
		statutDefaut2.setDateDeb(LocalDate.now());
		statutDefaut2.setStatut(StatutTiers.DEFAUT);
		statutDefaut2.setMotif(new MotifStatutTiers(complEvt2));
		statuts.add(statutDefaut2);

		StatutTiersRepository statutTiersRepository = Mockito.mock(StatutTiersRepository.class);
		Mockito.when(statutTiersRepository.getStatutADate(Mockito.any(), Mockito.any())).thenReturn(statuts);

		PowerMockito.mockStatic(ContexteCalculTiers.class);
		PowerMockito.when(ContexteCalculTiers.getStatutsCourants(Mockito.any())).thenReturn(statuts);

		defautService.setStatutTiersRepository(statutTiersRepository);

		initServicesCommuns(defautService, statutTiersRepository);

		// Act1 : on sort de l'Evenement Defaut PCO qui est clo
		LocalDate dateSortie = LocalDate.now().plusDays(10);
		ComplementEvenement complEvtAnn = new ComplementEvenement();
		complEvtAnn.setStatutEvt(StatutEvenement.ANN);
		evt2.addComplement(complEvtAnn);
		defautService.sortieDUnEvenementDeDefaut(0L, dateSortie, new MotifStatutTiers(complEvtAnn), true, dateSortie);

		// Assert
		Assert.assertNull(periodeProbatoireCree);
		Assert.assertNotNull(nouveauStatut);
		Assert.assertEquals(StatutTiers.SAIN, nouveauStatut.getStatut());
		Assert.assertNull(nouveauStatut.getMotif());
		Assert.assertEquals(dateSortie, nouveauStatut.getDateDebut());
	}

	@Test
	public void sainPuisDefaut1CloPuisDefaut2Ann() {
		// Arrange
		DefautServiceImpl defautService = new DefautServiceImpl();

		// premier statut de défaut : un Evenement Defaut
		Evenement evt1 = new Evenement();
		evt1.setId(1L);
		evt1.setCode("PCO");
		ComplementEvenement complEvt1 = new ComplementEvenement();
		complEvt1.setEvenement(evt1);
		evt1.addComplement(complEvt1);

		// premier statut de défaut : un Evenement Defaut
		Evenement evt2 = new Evenement();
		evt2.setId(1L);
		evt2.setCode("IB");
		ComplementEvenement complEvt2 = new ComplementEvenement();
		complEvt2.setEvenement(evt2);
		evt2.addComplement(complEvt2);

		List<StatutHistorise> statuts = new ArrayList<>();
		StatutHistorise statutSain = new StatutHistorise();
		statutSain.setDateDeb(LocalDate.now().minusDays(30));
		statutSain.setDateFin(LocalDate.now().minusDays(20));
		statutSain.setStatut(StatutTiers.SAIN);
		statuts.add(statutSain);

		StatutHistorise statutDefaut1 = new StatutHistorise();
		statutDefaut1.setDateDeb(LocalDate.now().minusDays(20));
		statutDefaut1.setDateFin(LocalDate.now().minusDays(10));
		statutDefaut1.setStatut(StatutTiers.DEFAUT);
		statutDefaut1.setMotif(new MotifStatutTiers(complEvt1));
		statuts.add(statutDefaut1);

		StatutHistorise statutDefaut2 = new StatutHistorise();
		statutDefaut2.setDateDeb(LocalDate.now().minusDays(15));
		statutDefaut2.setStatut(StatutTiers.DEFAUT);
		statutDefaut2.setMotif(new MotifStatutTiers(complEvt2));
		statuts.add(statutDefaut2);

		StatutTiersRepository statutTiersRepository = Mockito.mock(StatutTiersRepository.class);
		Mockito.when(statutTiersRepository.getStatutADate(Mockito.any(), Mockito.any())).thenReturn(statuts);

		PowerMockito.mockStatic(ContexteCalculTiers.class);
		PowerMockito.when(ContexteCalculTiers.getStatutsCourants(Mockito.any())).thenReturn(statuts);

		defautService.setStatutTiersRepository(statutTiersRepository);

		initServicesCommuns(defautService, statutTiersRepository);

		// Act1 : on sort de l'Evenement Defaut PCO qui est clo
		LocalDate dateSortie = LocalDate.now();
		ComplementEvenement complEvtAnn = new ComplementEvenement();
		complEvtAnn.setStatutEvt(StatutEvenement.ANN);
		evt2.addComplement(complEvtAnn);
		defautService.sortieDUnEvenementDeDefaut(0L, dateSortie, new MotifStatutTiers(complEvtAnn), true, dateSortie);

		// Assert
		Assert.assertNotNull(periodeProbatoireCree);
		Assert.assertEquals(LocalDate.now().minusDays(10), periodeProbatoireCree.getDateDebut());
		Assert.assertNotNull(nouveauStatut);
		Assert.assertEquals(Constant.EVENEMENT_PP, nouveauStatut.getMotif().getMotif());
		Assert.assertEquals(LocalDate.now().minusDays(10), nouveauStatut.getDateDebut());
	}

	private void initServicesCommuns(DefautServiceImpl defautService, StatutTiersRepository statutTiersRepository) {
		// Retourne un Tiers quand on en demande un
		RechercheTiersService rechTiersService = Mockito.mock(RechercheTiersService.class);
		Mockito.when(rechTiersService.getTiers(Mockito.any())).thenReturn(new Tiers());
		defautService.setRechercheTiersService(rechTiersService);

		EvenementCalculeService ecService = Mockito.mock(EvenementCalculeService.class);
		defautService.setEvtCalculeService(ecService);
		// Création de la période probatoire si appelé. Ca renseigne
		// "periodeProbatoireCree"
		Mockito.when(ecService.creePeriodeProbatoire(Mockito.any(), Mockito.any(), Mockito.any()))
				.then(new Answer<PeriodeProbatoire>() {

					@Override
					public PeriodeProbatoire answer(InvocationOnMock invocation) throws Throwable {
						periodeProbatoireCree = new PeriodeProbatoire();
						periodeProbatoireCree.setDateDebut(invocation.getArgument(1));
						return periodeProbatoireCree;
					}
				});

		// Persistence d'un nouveau statut pour le tiers. Renseigne "nouveauStatut".
		Mockito.when(statutTiersRepository.save(Mockito.any())).then(new Answer<StatutHistorise>() {

			@Override
			public StatutHistorise answer(InvocationOnMock invocation) throws Throwable {
				nouveauStatut = invocation.getArgument(0);
				return nouveauStatut;
			}
		});
	}

}

package fr.bpce.yyd.service.commun.service.impl.scenarios;

import java.sql.SQLException;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

//lancement de la console H2
@SpringBootApplication
public class H2WebConfiguration {
	@Bean(initMethod = "start", destroyMethod = "stop")
	// @Bean(destroyMethod = "stop")
	public org.h2.tools.Server h2WebConsonleServer() throws SQLException {
		return org.h2.tools.Server.createWebServer("-web", "-webAllowOthers", "-webDaemon", "-webPort", "8082");
	}
}

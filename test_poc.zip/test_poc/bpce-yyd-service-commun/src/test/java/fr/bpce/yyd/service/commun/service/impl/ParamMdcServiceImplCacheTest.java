package fr.bpce.yyd.service.commun.service.impl;

import java.time.LocalDateTime;

import org.junit.Assert;
import org.junit.Test;

import fr.bpce.yyd.service.commun.service.impl.ParamMdcServiceImpl.CacheType;
import fr.bpce.yyd.service.commun.service.impl.ParamMdcServiceImpl.ParamCacheEntry;
import fr.bpce.yyd.service.commun.service.impl.ParamMdcServiceImpl.ParamRefresher;
import fr.bpce.yyd.service.commun.util.ParamMap;

public class ParamMdcServiceImplCacheTest {

	private static ParamMap REPO_NOT_CALLED = new ParamMap();
	private static ParamMap REPO_CALLED = new ParamMap();

	private static ParamRefresher REFRESHER = new ParamRefresher() {
		@Override
		public ParamMap refreshParamMap() {
			return REPO_CALLED;
		}

	};

	private ParamMdcServiceImpl srv = new ParamMdcServiceImpl();

	@Test
	public void cacheVide() {
		// Arrange
		srv.getMapCache().clear();

		// Act
		ParamMap map = srv.getMap(CacheType.PARAM_BQ_SEG, REFRESHER);

		// Assert
		Assert.assertTrue(REPO_CALLED == map);
	}

	@Test
	public void cacheRecent() {
		// Arrange
		srv.getMapCache().clear();
		ParamCacheEntry cacheEntry = new ParamCacheEntry(
				LocalDateTime.now().minusMinutes(ParamMdcServiceImpl.CACHE_LIVE_MINUTES - 1), REPO_NOT_CALLED);
		srv.getMapCache().put(CacheType.PARAM_BQ_SEG, cacheEntry);

		// Act
		ParamMap map = srv.getMap(CacheType.PARAM_BQ_SEG, REFRESHER);

		// Assert
		Assert.assertTrue(REPO_NOT_CALLED == map);
	}

	@Test
	public void cacheAncien() {
		// Arrange
		srv.getMapCache().clear();
		ParamCacheEntry cacheEntry = new ParamCacheEntry(
				LocalDateTime.now().minusMinutes(ParamMdcServiceImpl.CACHE_LIVE_MINUTES + 1), REPO_NOT_CALLED);
		srv.getMapCache().put(CacheType.PARAM_BQ_SEG, cacheEntry);

		// Act
		ParamMap map = srv.getMap(CacheType.PARAM_BQ_SEG, REFRESHER);

		// Assert
		Assert.assertTrue(REPO_CALLED == map);
	}
}

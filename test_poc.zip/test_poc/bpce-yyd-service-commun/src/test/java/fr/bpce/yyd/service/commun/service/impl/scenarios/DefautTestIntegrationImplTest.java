package fr.bpce.yyd.service.commun.service.impl.scenarios;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.test.context.junit4.SpringRunner;

import fr.bpce.yyd.commun.constantes.Constant;
import fr.bpce.yyd.commun.enums.StatutAuditEvenement;
import fr.bpce.yyd.commun.enums.StatutEvenement;
import fr.bpce.yyd.commun.enums.StatutTiers;
import fr.bpce.yyd.commun.messages.dto.LotIdTiersDTO;
import fr.bpce.yyd.commun.model.AuditCalcul;
import fr.bpce.yyd.commun.model.AuditFichiers;
import fr.bpce.yyd.commun.model.ComplementEvenement;
import fr.bpce.yyd.commun.model.Evenement;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.MotifStatutTiers;
import fr.bpce.yyd.commun.model.StatutHistorise;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.commun.model.reference.RefImpactEvtMdc;
import fr.bpce.yyd.service.commun.beans.EvenementsATraiter;
import fr.bpce.yyd.service.commun.beans.EvenementsCalculesTiers;
import fr.bpce.yyd.service.commun.contexte.ContexteCalculTiers;
import fr.bpce.yyd.service.commun.service.AuditCalculService;
import fr.bpce.yyd.service.commun.service.IdentiteTiersService;
import fr.bpce.yyd.service.commun.service.impl.DefautServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.EvenementCalculeServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.EvenementRecuServiceImpl;

@RunWith(SpringRunner.class)
@ComponentScan(basePackages = { "fr.bpce.yyd.service.commun", "fr.bpce.yyd.service.traitement.evenements",
		"fr.bpce.yyd.commun" })

@EntityScan(basePackages = { "fr.bpce.yyd.service.traitement.evenements.entities",
		"fr.bpce.yyd.service.traitement.evenements.domain", "fr.bpce.yyd.commun.model",
		"fr.bpce.yyd.service.commun.model" })
@EnableJpaRepositories(basePackages = { "fr.bpce.yyd.service.commun.repository",
		"fr.bpce.yyd.service.traitement.evenements.repositories", "fr.bpce.yyd.commun.repository" })
@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
public class DefautTestIntegrationImplTest {

	// a ajouter pour debug sur H2 localhost:8082
	// entityManager.getEntityManager().getTransaction().commit();

	@Autowired
	private TestEntityManager entityManager;
	@Autowired
	private IdentiteTiersService identiteTiersService;
	@Autowired
	private EvenementRecuServiceImpl evtRecuService;
	@Autowired
	private EvenementCalculeServiceImpl evtCalculeService;
	@Autowired
	private DefautServiceImpl defautService;
	@Autowired
	private AuditCalculService auditCalculService;

	@Before
	public void initTableParametrage() {
		initParam();
	}

	@Test
	public void TestCasrincipalJira109() {

		// Le défaut du client n'est lié qu'à l'UTP concerné (CAS PRIORITAIRE)
		// Cas de test :
		// RAD ACT le 15/10, entrée en défaut le 15/10
		// RAD CLO le 28/10,
		// PP ACT le 28/10
		// RAD ANN le 10/12
		// Dans cet exemple il faut à la réception du RAD ANN :
		// Intégrer la mise à jour au niveau de l'évènement RAD
		// Flagger le statut tiers RAD correspondant à annulé (1)
		// Clôturer l'évènement PP
		// Flagger le statut tiers PP correspondant à annulé (1)
		// Passer le tiers en statut SAIN à date de clôture de PP (le 10/12)

		// *******************************
		// *** ARRANGE 1 : RAD ACT *******
		// *******************************

		// 1. crée un tiers
		Tiers tiers = createTiers();

		// 1. créer une identite
		LocalDate date_15_10_2020 = LocalDate.of(2020, 10, 15);
		IdentiteTiers identite = createIdentiteTiers("idLoc1", "00001", "3200", date_15_10_2020, date_15_10_2020,
				tiers);

		// creation de l'evenement
		Evenement evt = createEevenement("RAD", date_15_10_2020, identite);

		// 2.collect evt RAD au 15/10/2020
		ComplementEvenement complEvt1 = createEvenementLocal("RAD", StatutEvenement.ACT, evt, date_15_10_2020, null,
				identite);

		// *** Act 1 => suite au RAD mis en DEFAUT du tiers dans la table STATUT TIERS
		// et pas de creation d'evenment dans AUDIT_CALCUL

		// 3.le tiers est mis en défaut au 15/10
		majContexte(tiers, date_15_10_2020);
		defautService.entreeEnDefaut(tiers, date_15_10_2020, new MotifStatutTiers(complEvt1), date_15_10_2020);

		// Asserts
		List<StatutHistorise> allStatutsCourants = ContexteCalculTiers.getStatutsCourants(tiers.getId());
		EvenementsCalculesTiers evtsCalc = evtCalculeService.rechercheEvenementsCalculesActifsADate(tiers.getId(),
				date_15_10_2020);

		Assert.assertEquals(1, allStatutsCourants.size());

		for (StatutHistorise statutCourant : allStatutsCourants) {
			Assert.assertEquals(date_15_10_2020, statutCourant.getDateDebut());
			Assert.assertEquals(null, statutCourant.getDateFin());
			Assert.assertEquals("RX", statutCourant.getGravite());
			Assert.assertEquals("DEFAUT", statutCourant.getStatut().toString());
			Assert.assertEquals("RAD", statutCourant.getMotif().getMotif());
			Assert.assertEquals(false, statutCourant.getAnnule());
		}

		Assert.assertEquals(0, evtsCalc.getEvenementsCalcules().size());

		// *******************************
		// *** ARRANGE 2 : RAD CLO *******
		// *******************************

		// 4. Cloture du RAD au 28/10
		LocalDate date_28_10_2020 = LocalDate.of(2020, 10, 28);
		ComplementEvenement complEvt2 = createEvenementLocal("RAD", StatutEvenement.CLO, evt, date_28_10_2020, null,
				identite);
		complEvt1.setDateFin(date_28_10_2020); // maj dateFn du complEvt1
		entityManager.persist(complEvt1);

		// *** Act 2 => suite au RAD CLO, le tiers passe en DEFAUT PP (statut tiers et
		// audit calcul)

		majContexte(tiers, date_28_10_2020);
		defautService.sortieDUnEvenementDeDefaut(tiers.getId(), date_28_10_2020, new MotifStatutTiers(complEvt2), false,
				date_28_10_2020);

		allStatutsCourants = ContexteCalculTiers.getStatutsCourants(tiers.getId());
		evtsCalc = evtCalculeService.rechercheEvenementsCalculesActifsADate(tiers.getId(), date_28_10_2020);
		AuditCalcul auditcalcul = auditCalculService.recupererAuditPeriodeProbatoire(
				evtsCalc.getPeriodeProbatoire().getId(), tiers.getId(), date_28_10_2020);

		Assert.assertEquals(2, allStatutsCourants.size());

		for (StatutHistorise statutCourant : allStatutsCourants) {

			// test que l'evenement DEFAUT RAD est bien cloture en date 28_10_2020
			if (statutCourant.getMotif().getMotif().equals("RAD")) {
				Assert.assertEquals(date_15_10_2020, statutCourant.getDateDebut());
				Assert.assertEquals(date_28_10_2020, statutCourant.getDateFin());
			}

			// test qu'on a bien créé un DEFAUT PP en date du 28/10
			if (statutCourant.getMotif().getMotif().equals("PP")) {
				Assert.assertEquals(date_28_10_2020, statutCourant.getDateDebut());
				Assert.assertEquals(null, statutCourant.getDateFin());
				Assert.assertEquals("RX", statutCourant.getGravite());
				Assert.assertEquals("DEFAUT", statutCourant.getStatut().toString());
				Assert.assertEquals("PP", statutCourant.getMotif().getMotif());
				Assert.assertEquals(false, statutCourant.getAnnule());
			}
		}

		Assert.assertNotNull(evtsCalc.getPeriodeProbatoire());

		// test la ligne PP créé dans AUDIT_CALCUL
		Assert.assertNotNull(auditcalcul);
		Assert.assertEquals(StatutAuditEvenement.ACT, auditcalcul.getStatut());
		Assert.assertEquals(date_28_10_2020, auditcalcul.getDateEffet());
		Assert.assertEquals("PP", auditcalcul.getCode());

		// *******************************
		// *** ARRANGE 3 : RAD ANN *******
		// *******************************

		// 5.Annulation de défaut RAD au 10/12 => Retour en SAIN au 10/12
		LocalDate date_10_12_2020 = LocalDate.of(2020, 12, 10);
		ComplementEvenement complEvt3 = createEvenementLocal("RAD", StatutEvenement.ANN, evt, date_10_12_2020, null,
				identite);
		complEvt2.setDateFin(date_10_12_2020); // maj dateFn du complEvt2
		entityManager.persist(complEvt2);

		// *** Act 3 => suite à l'annulation du RAD, le tiers passe en SAIN avec
		// annulation de la PP

		majContexte(tiers, date_10_12_2020);
		defautService.annulerDefautEventClos(tiers, complEvt3, date_10_12_2020);

		allStatutsCourants = ContexteCalculTiers.getStatutsCourants(tiers.getId());
		evtsCalc = evtCalculeService.rechercheEvenementsCalculesActifsADate(tiers.getId(), date_10_12_2020);

		// Asserts

		// test qu'on est sorti de la PP
		Assert.assertNull(evtsCalc.getPeriodeProbatoire());

		// on a 3 statut DEFAUT-RAD ; DEFAUT-PP; SAIN

		Assert.assertEquals(3, allStatutsCourants.size());

		for (StatutHistorise statutCourant : allStatutsCourants) {
			// test que l'evenement DEFAUT RAD est bien annulé
			if (statutCourant.getMotif() != null && statutCourant.getMotif().getMotif().equals("RAD")) {
				Assert.assertEquals(date_15_10_2020, statutCourant.getDateDebut());
				Assert.assertEquals(date_28_10_2020, statutCourant.getDateFin());
				Assert.assertTrue(statutCourant.getAnnule());
			}

			// test qu'on a bien créé un DEFAUT PP cloturé en date du 10/12
			if (statutCourant.getMotif() != null && statutCourant.getMotif().getMotif().equals("PP")) {
				Assert.assertEquals(date_28_10_2020, statutCourant.getDateDebut());
				Assert.assertEquals(date_10_12_2020, statutCourant.getDateFin());
				Assert.assertEquals("RX", statutCourant.getGravite());
				Assert.assertEquals("DEFAUT", statutCourant.getStatut().toString());
				Assert.assertEquals("PP", statutCourant.getMotif().getMotif());
				Assert.assertEquals(true, statutCourant.getAnnule());
			}

			// test qu'on a bien créé un staut SAIN actif (sans date de fin)
			if (statutCourant.getMotif() == null && statutCourant.getStatut().toString().equals("SAIN")) {
				Assert.assertEquals(date_10_12_2020, statutCourant.getDateDebut());
				Assert.assertEquals(null, statutCourant.getDateFin());
				Assert.assertEquals(null, statutCourant.getGravite());
				Assert.assertEquals("SAIN", statutCourant.getStatut().toString());
				Assert.assertEquals(null, statutCourant.getMotif());
				Assert.assertEquals(false, statutCourant.getAnnule());
			}
		}
	}

	@Test
	public void TestRADactPuisANN() {

		// Cas de test :
		// RAD ACT le 15/10, entrée en défaut le 15/10
		// RAD ANN le 28/10,
		// Dans cet exemple il faut à la réception du RAD ANN :
		// Intégrer la mise à jour au niveau de l'évènement RAD
		// Flagger le statut tiers RAD correspondant à annulé (1)
		// Passer le tiers en statut SAIN à date de clôture de PP (le 10/12)

		// *******************************
		// *** ARRANGE 1 : RAD ACT *******
		// *******************************

		// 1. crée un tiers
		Tiers tiers = createTiers();

		// 2. créer une identite
		LocalDate date_15_10_2020 = LocalDate.of(2020, 10, 15);
		IdentiteTiers identite = createIdentiteTiers("idLoc1", "00001", "3200", date_15_10_2020, date_15_10_2020,
				tiers);

		// creation de l'evenement
		Evenement evt = createEevenement("RAD", date_15_10_2020, identite);

		// 3.collect evt RAD au 15/10/2020
		ComplementEvenement complEvt1 = createEvenementLocal("RAD", StatutEvenement.ACT, evt, date_15_10_2020, null,
				identite);

		// *** Act 1 => suite au RAD mis en DEFAUT du tiers dans la table STATUT TIERS
		// et pas de creation d'evenment dans AUDIT_CALCUL

		// 4.le tiers est mis en défaut au 15/10
		majContexte(tiers, date_15_10_2020);
		defautService.entreeEnDefaut(tiers, date_15_10_2020, new MotifStatutTiers(complEvt1), date_15_10_2020);

		// *******************************
		// *** ARRANGE 2 : RAD ANN *******
		// *******************************

		// 5.Annulation de défaut RAD au 28/10 => Retour en SAIN au 28/10
		LocalDate date_28_10_2020 = LocalDate.of(2020, 10, 28);
		ComplementEvenement complEvt2 = createEvenementLocal("RAD", StatutEvenement.ANN, evt, date_28_10_2020, null,
				identite);
		complEvt2.setDateFin(date_28_10_2020); // maj dateFn du complEvt2
		entityManager.persist(complEvt2);

		// *** Act 1 => suite au RAD mis en DEFAUT du tiers dans la table STATUT TIERS
		// et pas de creation d'evenment dans AUDIT_CALCUL
		LocalDate date_10_11_2020 = LocalDate.of(2020, 11, 10); // le traitement a lieu de 10/11
		majContexte(tiers, date_10_11_2020);
		defautService.sortieDUnEvenementDeDefaut(tiers.getId(), date_28_10_2020, new MotifStatutTiers(complEvt2), true,
				date_10_11_2020);

		List<StatutHistorise> allStatutsCourants = ContexteCalculTiers.getStatutsCourants(tiers.getId());
		EvenementsCalculesTiers evtsCalc = evtCalculeService.rechercheEvenementsCalculesActifsADate(tiers.getId(),
				date_10_11_2020);

		// Asserts

		// le tiers retourne SAIN pas de PP
		Assert.assertNull(evtsCalc.getPeriodeProbatoire());

		// le tiers à deux lignes satuts
		// 1- DEFAUT RX RAD cloruté
		// 2 -SAIN

		Assert.assertEquals(2, allStatutsCourants.size());

		for (StatutHistorise statutCourant : allStatutsCourants) {
			// test que l'evenement DEFAUT RAD est bien cloturé et annulé
			if (statutCourant.getMotif() != null && statutCourant.getMotif().getMotif().equals("RAD")) {
				Assert.assertEquals(date_15_10_2020, statutCourant.getDateDebut());
				Assert.assertEquals(date_28_10_2020, statutCourant.getDateFin());
				Assert.assertTrue(statutCourant.getAnnule());
			}

			// test qu'on a bien créé un staut SAIN actif (sans date de fin)
			if (statutCourant.getMotif() == null && statutCourant.getStatut().toString().equals("SAIN")) {
				Assert.assertEquals(date_10_11_2020, statutCourant.getDateDebut());
				Assert.assertEquals(null, statutCourant.getDateFin());
				Assert.assertEquals(null, statutCourant.getGravite());
				Assert.assertEquals("SAIN", statutCourant.getStatut().toString());
				Assert.assertEquals(null, statutCourant.getMotif());
				Assert.assertEquals(false, statutCourant.getAnnule());
			}
		}
	}

	@Test
	public void TestPlusieursDefautUTPAnnulationQueDe1Seul() {

		// Cas de test :
		// RAD ACT le 15/10, entrée en défaut le 15/10
		// DM ACT le 20/10 nouvelle cause de DEFAUT sur motif DM
		// RAD CLO le 28/10
		// DM CLO le 30/10
		// PP ACT le 30/10
		// RAD ANN le 10/12
		// Pour ce cas il faut Intégrer la mise à jour au niveau de l'évènement RAD
		// Flagger le statut tiers RAD correspondant à annulé (1)
		// Flagger le statut tiers PP correspondant à annulé (1)
		// IMPORTANT : on ne clorure pas l'evenement PP car il reste le Defaut DM CLO
		// (non ANN)
		// DM ANN le 20/12, on annule le DM puis le tiers passe en SAIN à la date du
		// 20/12

		// *******************************
		// *** ARRANGE 1 : RAD ACT *******
		// *******************************

		// 1. crée un tiers
		Tiers tiers = createTiers();

		// 2. créer une identite
		LocalDate date_15_10_2020 = LocalDate.of(2020, 10, 15);
		IdentiteTiers identite = createIdentiteTiers("idLoc1", "00001", "3200", date_15_10_2020, date_15_10_2020,
				tiers);

		// 2. creation de l'evenement RAD le 15/10
		Evenement evtRAD = createEevenement("RAD", date_15_10_2020, identite);

		// 4 .collect complement evt RAD au 15/10/2020
		ComplementEvenement complEvtRAD = createEvenementLocal("RAD", StatutEvenement.ACT, evtRAD, date_15_10_2020,
				null, identite);

		// 5. creation de l'evenement DM le 20/10
		LocalDate date_20_10_2020 = LocalDate.of(2020, 10, 20);
		Evenement evtDM = createEevenement("DM", date_20_10_2020, identite);

		// 6 .collect complement evt DM au 20/10/2020
		ComplementEvenement complEvtDM = createEvenementLocal("DM", StatutEvenement.ACT, evtDM, date_20_10_2020, null,
				identite);

		// *** Act 1 => suite au RAD et DM mis en DEFAUT du tiers dans la table STATUT
		// TIERS
		// et pas de creation d'evenment dans AUDIT_CALCUL

		// le tiers est mis en défaut au 15/10
		majContexte(tiers, date_15_10_2020);
		defautService.entreeEnDefaut(tiers, date_15_10_2020, new MotifStatutTiers(complEvtRAD), date_15_10_2020);

		majContexte(tiers, date_20_10_2020);
		defautService.entreeEnDefaut(tiers, date_20_10_2020, new MotifStatutTiers(complEvtDM), date_20_10_2020);

		// Asserts
		List<StatutHistorise> allStatutsCourants = ContexteCalculTiers.getStatutsCourants(tiers.getId());
		EvenementsCalculesTiers evtsCalc = evtCalculeService.rechercheEvenementsCalculesActifsADate(tiers.getId(),
				date_15_10_2020);

		Assert.assertEquals(2, allStatutsCourants.size());

		for (StatutHistorise statutCourant : allStatutsCourants) {

			// test que l'evenement DEFAUT RAD commence le 15/10
			if (statutCourant.getMotif() != null && statutCourant.getMotif().getMotif().equals("RAD")) {
				Assert.assertEquals(date_15_10_2020, statutCourant.getDateDebut());
				Assert.assertNull(statutCourant.getDateFin());
				Assert.assertTrue(!statutCourant.getAnnule());
				Assert.assertEquals("RX", statutCourant.getGravite()); // donner par initParam()

			}

			// test que l'evenement DEFAUT DM commence le 20/10
			if (statutCourant.getMotif() != null && statutCourant.getMotif().getMotif().equals("DM")) {
				Assert.assertEquals(date_20_10_2020, statutCourant.getDateDebut());
				Assert.assertNull(statutCourant.getDateFin());
				Assert.assertTrue(!statutCourant.getAnnule());
				Assert.assertEquals("DX", statutCourant.getGravite()); // donner par initParam
			}

		}

		Assert.assertEquals(0, evtsCalc.getEvenementsCalcules().size());

		// *****************************************
		// *** ARRANGE 2 : RAD CLO et DM CLO *******
		// *****************************************

		// 7. Cloture du RAD au 28/10
		LocalDate date_28_10_2020 = LocalDate.of(2020, 10, 28);
		createEvenementLocal("RAD", StatutEvenement.CLO, evtRAD, date_28_10_2020, null, identite);
		complEvtRAD.setDateFin(date_28_10_2020); // maj dateFn du complEvtRAD
		entityManager.persist(complEvtRAD);

		// 8. Cloture du DM au 30/10
		LocalDate date_30_10_2020 = LocalDate.of(2020, 10, 30);
		createEvenementLocal("DM", StatutEvenement.CLO, evtDM, date_30_10_2020, null, identite);
		complEvtDM.setDateFin(date_30_10_2020); // maj dateFn du complEvtDM
		entityManager.persist(complEvtDM);

		// *** Act 2 => suite au RAD CLO, le tiers a encore un evt defaut DM.
		// suite au DM CLO le tiers passe en PP à la date de cloture du DM

		majContexte(tiers, date_28_10_2020);
		defautService.sortieDUnEvenementDeDefaut(tiers.getId(), date_28_10_2020, new MotifStatutTiers(complEvtRAD),
				false, date_28_10_2020);

		majContexte(tiers, date_30_10_2020);
		defautService.sortieDUnEvenementDeDefaut(tiers.getId(), date_30_10_2020, new MotifStatutTiers(complEvtDM),
				false, date_30_10_2020);

		allStatutsCourants = ContexteCalculTiers.getStatutsCourants(tiers.getId());
		evtsCalc = evtCalculeService.rechercheEvenementsCalculesActifsADate(tiers.getId(), date_30_10_2020);
		AuditCalcul auditcalcul = auditCalculService.recupererAuditPeriodeProbatoire(
				evtsCalc.getPeriodeProbatoire().getId(), tiers.getId(), date_30_10_2020);

		// Asserts
		Assert.assertEquals(3, allStatutsCourants.size());

		for (StatutHistorise statutCourant : allStatutsCourants) {

			// test que l'evenement DEFAUT RAD commence le 15/10 et se cloture le 28/10
			if (statutCourant.getMotif() != null && statutCourant.getMotif().getMotif().equals("RAD")) {
				Assert.assertEquals(date_15_10_2020, statutCourant.getDateDebut());
				Assert.assertEquals(date_28_10_2020, statutCourant.getDateFin());
				Assert.assertTrue(!statutCourant.getAnnule());
				Assert.assertEquals("RX", statutCourant.getGravite()); // donner par initParam()

			}

			// test que l'evenement DEFAUT DM commence le 20/10 et se clorure le 30/10
			if (statutCourant.getMotif() != null && statutCourant.getMotif().getMotif().equals("DM")) {
				Assert.assertEquals(date_20_10_2020, statutCourant.getDateDebut());
				Assert.assertEquals(date_30_10_2020, statutCourant.getDateFin());
				Assert.assertTrue(!statutCourant.getAnnule());
				Assert.assertEquals("DX", statutCourant.getGravite()); // donner par initParam
			}

			// test qu'on a bien créé un DEFAUT PP cloturé qui a commencé en date du 30/10
			if (statutCourant.getMotif() != null && statutCourant.getMotif().getMotif().equals("PP")) {
				Assert.assertEquals(date_30_10_2020, statutCourant.getDateDebut());
				Assert.assertNull(statutCourant.getDateFin());
				Assert.assertEquals("DX", statutCourant.getGravite());
				Assert.assertEquals("DEFAUT", statutCourant.getStatut().toString());
				Assert.assertEquals("PP", statutCourant.getMotif().getMotif());
				Assert.assertTrue(!statutCourant.getAnnule());
			}
		}

		// test la ligne PP créé dans AUDIT_CALCUL
		Assert.assertNotNull(auditcalcul);
		Assert.assertEquals(StatutAuditEvenement.ACT, auditcalcul.getStatut());
		Assert.assertEquals(date_30_10_2020, auditcalcul.getDateEffet());
		Assert.assertEquals("PP", auditcalcul.getCode());

		// *****************************************
		// *** ARRANGE 3 : RAD ANN le 10/12 *******
		// *****************************************

		// 9.Annulation de défaut RAD au 10/12
		LocalDate date_10_12_2020 = LocalDate.of(2020, 12, 10);
		ComplementEvenement complEvtRADAnn = createEvenementLocal("RAD", StatutEvenement.ANN, evtRAD, date_10_12_2020,
				null, identite);
		complEvtRAD.setDateFin(date_10_12_2020); // maj dateFn du complEvt2
		entityManager.persist(complEvtRAD);

		// *** Act 3 => suite à l'annulation du RAD
		LocalDate date_15_12_2020 = LocalDate.of(2020, 12, 15); // le calcul a lieu le 15/12/2020
		majContexte(tiers, date_15_12_2020);
		defautService.annulerDefautEventClos(tiers, complEvtRADAnn, date_15_12_2020);

		allStatutsCourants = ContexteCalculTiers.getStatutsCourants(tiers.getId());
		evtsCalc = evtCalculeService.rechercheEvenementsCalculesActifsADate(tiers.getId(), date_15_12_2020);

		// Asserts
		Assert.assertEquals(3, allStatutsCourants.size());

		for (StatutHistorise statutCourant : allStatutsCourants) {

			// test que l'evenement DEFAUT RAD est annulé
			if (statutCourant.getMotif() != null && statutCourant.getMotif().getMotif().equals("RAD")) {
				Assert.assertTrue(statutCourant.getAnnule());

				// inchangé
				Assert.assertEquals(date_28_10_2020, statutCourant.getDateFin());
				Assert.assertEquals(date_15_10_2020, statutCourant.getDateDebut());
				Assert.assertEquals("RX", statutCourant.getGravite()); // donner par initParam()
			}

			// test que l'evenement DEFAUT DM pas de changement
			if (statutCourant.getMotif() != null && statutCourant.getMotif().getMotif().equals("DM")) {
				Assert.assertEquals(date_20_10_2020, statutCourant.getDateDebut());
				Assert.assertEquals(date_30_10_2020, statutCourant.getDateFin());
				Assert.assertTrue(!statutCourant.getAnnule());
				Assert.assertEquals("DX", statutCourant.getGravite()); // donner par initParam
			}

			// test que nous sommes toujouts DEFAUT PP, pas de changement
			if (statutCourant.getMotif() != null && statutCourant.getMotif().getMotif().equals("PP")) {
				Assert.assertEquals(date_30_10_2020, statutCourant.getDateDebut());
				Assert.assertNull(statutCourant.getDateFin());
				Assert.assertEquals("DX", statutCourant.getGravite());
				Assert.assertEquals("DEFAUT", statutCourant.getStatut().toString());
				Assert.assertEquals("PP", statutCourant.getMotif().getMotif());
				Assert.assertTrue(!statutCourant.getAnnule());
			}
		}

		// *****************************************
		// *** ARRANGE 4 : DM ANN le 20/12 ******* RETOIR EN SAIN
		// *****************************************

		// 10.Annulation de défaut dm au 20/12
		LocalDate date_20_12_2020 = LocalDate.of(2020, 12, 20);
		ComplementEvenement complEvtDMAnn = createEvenementLocal("DM", StatutEvenement.ANN, evtDM, date_20_12_2020,
				null, identite);
		complEvtDM.setDateFin(date_20_12_2020); // maj dateFn du complEvt2
		entityManager.persist(complEvtDM);

		// *** Act 4 => suite à l'annulation du DM
		LocalDate date_01_01_2021 = LocalDate.of(2021, 1, 1); // le calcul a lieu le 01/01/2021
		majContexte(tiers, date_01_01_2021);
		defautService.annulerDefautEventClos(tiers, complEvtDMAnn, date_01_01_2021);

		allStatutsCourants = ContexteCalculTiers.getStatutsCourants(tiers.getId());
		evtsCalc = evtCalculeService.rechercheEvenementsCalculesActifsADate(tiers.getId(), date_01_01_2021);

		// Asserts
		Assert.assertEquals(4, allStatutsCourants.size());

		for (StatutHistorise statutCourant : allStatutsCourants) {

			// test que l'evenement DEFAUT RAD ne change pas
			if (statutCourant.getMotif() != null && statutCourant.getMotif().getMotif().equals("RAD")) {
				Assert.assertEquals(date_15_10_2020, statutCourant.getDateDebut());
				Assert.assertEquals(date_28_10_2020, statutCourant.getDateFin());
				Assert.assertTrue(statutCourant.getAnnule());
				Assert.assertEquals("RX", statutCourant.getGravite()); // donner par initParam()
			}

			// test que l'evenement DEFAUT DM passe à annuler
			if (statutCourant.getMotif() != null && statutCourant.getMotif().getMotif().equals("DM")) {
				Assert.assertTrue(statutCourant.getAnnule());

				// Les autres champs restent inchangés
				Assert.assertEquals(date_20_10_2020, statutCourant.getDateDebut());
				Assert.assertEquals(date_30_10_2020, statutCourant.getDateFin());
				Assert.assertEquals("DX", statutCourant.getGravite()); // donner par initParam
			}

			// test que le DEFAUT PP est cloturé et annulé à la date du traitement
			// 01/01/2021
			if (statutCourant.getMotif() != null && statutCourant.getMotif().getMotif().equals("PP")) {
				Assert.assertEquals(date_01_01_2021, statutCourant.getDateFin());
				Assert.assertTrue(statutCourant.getAnnule());

				// les autres champs inchangés
				Assert.assertEquals(date_30_10_2020, statutCourant.getDateDebut());
				Assert.assertEquals("DX", statutCourant.getGravite());
				Assert.assertEquals("DEFAUT", statutCourant.getStatut().toString());
				Assert.assertEquals("PP", statutCourant.getMotif().getMotif());

			}

			// test qu'on a bien créé un staut SAIN actif (sans date de fin), qui débute à
			// la date du traitement 01/01/2021
			if (statutCourant.getMotif() == null && statutCourant.getStatut().toString().equals("SAIN")) {
				Assert.assertEquals(date_01_01_2021, statutCourant.getDateDebut());
				Assert.assertEquals(null, statutCourant.getDateFin());
				Assert.assertEquals(null, statutCourant.getGravite());
				Assert.assertEquals("SAIN", statutCourant.getStatut().toString());
				Assert.assertEquals(null, statutCourant.getMotif());
				Assert.assertEquals(false, statutCourant.getAnnule());
			}

		}

	}

	@Test
	public void TestPlusieursDefautUTPAnnulationrRecalculPPl() {

		// DM ACT le 08/10, entrée en défaut le 08/10
		// RAD ACT le 15/10,
		// DM CLO le 16/10,
		// RAD CLO le 28/10,
		// PP ACT le 28/10,
		// RAD ANN le 10/12
		// Dans cet exemple 1 il faut à la réception du RAD ANN :
		// Intégrer la mise à jour au niveau de l'évènement RAD
		// Flagger le statut tiers RAD correspondant à annulé (1)
		// Comme il existe d'autres évènements liés au défaut non annulés :
		// Recalculer la PP par rapport au DM CLO (le dernier UTP lié à la période de
		// défaut)

		// Attention, si DM CLO il y a plus de 3 / 12 mois (en fonction de la présence
		// de F) : clôturer la PP
		// Passer le tiers en statut SAIN à date de clôture de PP (le 10/12)
		// Restituer le statut sain en synthèse tiers avec les warnings qui vont bien
		// ATTENTION : changement de palier de défaut si l'autre UTP donne un palier de
		// défaut différent.
		// Si PP recalculée et toujours en cours => restituer une synthèse tiers mise à
		// jour en conséquence (voir si déclencheur ?)

		// *******************************
		// *** ARRANGE 1 : DM ACT *******
		// *******************************

		// 1. crée un tiers
		Tiers tiers = createTiers();

		// 2. créer une identite
		LocalDate date_08_10_2020 = LocalDate.of(2020, 10, 8);
		IdentiteTiers identite = createIdentiteTiers("idLoc1", "00001", "3200", date_08_10_2020, date_08_10_2020,
				tiers);

		// 2. creation de l'evenement DM le 08/10
		Evenement evtDM = createEevenement("DM", date_08_10_2020, identite);

		// 4 .collect complement evt DM au 08/10/2020
		ComplementEvenement complEvtDM = createEvenementLocal("DM", StatutEvenement.ACT, evtDM, date_08_10_2020, null,
				identite);

		// 5. creation de l'evenement RAD le 15/10
		LocalDate date_15_10_2020 = LocalDate.of(2020, 10, 15);
		Evenement evtRAD = createEevenement("RAD", date_15_10_2020, identite);

		// 6 .collect complement evt DM au 20/10/2020
		ComplementEvenement complEvtRAD = createEvenementLocal("RAD", StatutEvenement.ACT, evtRAD, date_15_10_2020,
				null, identite);

		// *** Act 1 => suite au RAD et DM mis en DEFAUT du tiers dans la table STATUT
		// TIERS
		// et pas de creation d'evenment dans AUDIT_CALCUL

		// le tiers est mis en défaut au 15/10
		majContexte(tiers, date_08_10_2020);
		defautService.entreeEnDefaut(tiers, date_08_10_2020, new MotifStatutTiers(complEvtDM), date_08_10_2020);

		majContexte(tiers, date_15_10_2020);
		defautService.entreeEnDefaut(tiers, date_15_10_2020, new MotifStatutTiers(complEvtRAD), date_15_10_2020);

		// Asserts
		List<StatutHistorise> allStatutsCourants = ContexteCalculTiers.getStatutsCourants(tiers.getId());
		EvenementsCalculesTiers evtsCalc = evtCalculeService.rechercheEvenementsCalculesActifsADate(tiers.getId(),
				date_15_10_2020);

		Assert.assertEquals(2, allStatutsCourants.size());

		for (StatutHistorise statutCourant : allStatutsCourants) {

			// test que l'evenement DEFAUT DM commence le 08/10
			if (statutCourant.getMotif() != null && statutCourant.getMotif().getMotif().equals("DM")) {
				Assert.assertEquals(date_08_10_2020, statutCourant.getDateDebut());
			}

			// test que l'evenement DEFAUT RAD commence le 15/10
			if (statutCourant.getMotif() != null && statutCourant.getMotif().getMotif().equals("RAD")) {
				Assert.assertEquals(date_15_10_2020, statutCourant.getDateDebut());
			}

		}

		// test pas de PP
		Assert.assertEquals(0, evtsCalc.getEvenementsCalcules().size());

		// ***********************************************************
		// *** ARRANGE 2 : DM CLO (16/10) puis RAD CLO (28/10) *******
		// ***********************************************************

		// 7. Cloture du DM au 16/10
		LocalDate date_16_10_2020 = LocalDate.of(2020, 10, 16);
		ComplementEvenement complEvtDMClos = createEvenementLocal("DM", StatutEvenement.CLO, evtDM, date_16_10_2020,
				null, identite);
		complEvtDM.setDateFin(date_16_10_2020); // maj dateFn du complEvtDM
		entityManager.persist(complEvtDM);

		// 8. Cloture du RAD au 28/10
		LocalDate date_28_10_2020 = LocalDate.of(2020, 10, 28);
		ComplementEvenement complEvtRADClos = createEvenementLocal("RAD", StatutEvenement.CLO, evtRAD, date_28_10_2020,
				null, identite);
		complEvtRAD.setDateFin(date_28_10_2020); // maj dateFn du complEvtRAD
		entityManager.persist(complEvtRAD);

		// *** Act 2 => suite au DM CLO, le tiers a encore un evt defaut RAD.
		// suite au RAD CLO le tiers passe en PP à la date de cloture du RAD

		majContexte(tiers, date_16_10_2020);
		defautService.sortieDUnEvenementDeDefaut(tiers.getId(), date_16_10_2020, new MotifStatutTiers(complEvtDM),
				false, date_16_10_2020);

		LocalDate date_29_10_2020 = LocalDate.of(2020, 10, 29); // le traitement a lieu le 29/10
		majContexte(tiers, date_29_10_2020);
		defautService.sortieDUnEvenementDeDefaut(tiers.getId(), date_28_10_2020, new MotifStatutTiers(complEvtRAD),
				false, date_29_10_2020);

		allStatutsCourants = ContexteCalculTiers.getStatutsCourants(tiers.getId());
		evtsCalc = evtCalculeService.rechercheEvenementsCalculesActifsADate(tiers.getId(), date_28_10_2020);
		AuditCalcul auditcalcul = auditCalculService.recupererAuditPeriodeProbatoire(
				evtsCalc.getPeriodeProbatoire().getId(), tiers.getId(), date_28_10_2020);

		// Asserts
		Assert.assertEquals(3, allStatutsCourants.size());

		for (StatutHistorise statutCourant : allStatutsCourants) {

			// test que l'evenement DEFAUT DM commence le 08/10 et se cloture le 16/10
			if (statutCourant.getMotif() != null && statutCourant.getMotif().getMotif().equals("DM")) {
				Assert.assertEquals(date_08_10_2020, statutCourant.getDateDebut());
				Assert.assertEquals(date_16_10_2020, statutCourant.getDateFin());
				Assert.assertTrue(!statutCourant.getAnnule());
			}

			// test que l'evenement DEFAUT RAD commence le 15/10 et se clorure le 28/10
			if (statutCourant.getMotif() != null && statutCourant.getMotif().getMotif().equals("RAD")) {
				Assert.assertEquals(date_15_10_2020, statutCourant.getDateDebut());
				Assert.assertEquals(date_28_10_2020, statutCourant.getDateFin());
				Assert.assertTrue(!statutCourant.getAnnule());
			}

			// test qu'on a bien créé un DEFAUT PP cloturé qui a commencé en date du 28/10
			if (statutCourant.getMotif() != null && statutCourant.getMotif().getMotif().equals("PP")) {
				Assert.assertEquals(date_28_10_2020, statutCourant.getDateDebut());
				Assert.assertNull(statutCourant.getDateFin());
				Assert.assertEquals("DEFAUT", statutCourant.getStatut().toString());
				Assert.assertEquals("PP", statutCourant.getMotif().getMotif());
				Assert.assertTrue(!statutCourant.getAnnule());
			}
		}

		// test la ligne PP créé dans AUDIT_CALCUL
		Assert.assertNotNull(auditcalcul);
		Assert.assertEquals(StatutAuditEvenement.ACT, auditcalcul.getStatut());
		Assert.assertEquals(date_28_10_2020, auditcalcul.getDateEffet());
		Assert.assertEquals("PP", auditcalcul.getCode());

		// *************************************
		// *** ARRANGE 3 : RAD ANN (10/12) ****
		// *************************************

		// 9.Annulation de défaut RAD au 10/12
		// Comme il existe d'autres évènements liés au défaut non annulés :
		// Recalculer la PP par rapport au DM CLO (le dernier UTP lié à la période de
		// défaut)
		// La PP du 28/10 doit etre annulé et on doit créer une PP qui démarre le 16/10

		LocalDate date_10_12_2020 = LocalDate.of(2020, 12, 10);
		ComplementEvenement complEvtRADAnn = createEvenementLocal("RAD", StatutEvenement.ANN, evtRAD, date_10_12_2020,
				null, identite);
		complEvtRADClos.setDateFin(date_10_12_2020); // maj dateFn du complEvtRAD
		entityManager.persist(complEvtRAD);

		// *** Act 3 => suite à l'annulation du RAD, clot la PP du 28/10 et on crée une
		// PP au 16/10

		LocalDate date_01_01_2021 = LocalDate.of(2021, 01, 01); // le traitement a lieu le 01/01/2021
		majContexte(tiers, date_01_01_2021);
		defautService.annulerDefautEventClos(tiers, complEvtRADAnn, date_01_01_2021);

		allStatutsCourants = ContexteCalculTiers.getStatutsCourants(tiers.getId());
		evtsCalc = evtCalculeService.rechercheEvenementsCalculesActifsADate(tiers.getId(), date_01_01_2021);
		auditcalcul = auditCalculService.recupererAuditPeriodeProbatoire(evtsCalc.getPeriodeProbatoire().getId(),
				tiers.getId(), date_01_01_2021);

		// Asserts
		Assert.assertEquals(4, allStatutsCourants.size());

		// test que la date d'effet de AUDIT_CALCUL est au 16/10
		Assert.assertEquals(date_16_10_2020, auditcalcul.getDateEffet());

		// test que EVENEMENT_CALCULE a pour date_debut le 16/10
		Assert.assertEquals(date_16_10_2020, evtsCalc.getPeriodeProbatoire().getDateDebut());

		for (StatutHistorise statutCourant : allStatutsCourants) {

			// test que l'evenement DEFAUT DM reste inchangé
			if (statutCourant.getMotif() != null && statutCourant.getMotif().getMotif().equals("DM")) {
				Assert.assertEquals(date_08_10_2020, statutCourant.getDateDebut());
				Assert.assertEquals(date_16_10_2020, statutCourant.getDateFin());
				Assert.assertTrue(!statutCourant.getAnnule());
			}

			// test que l'evenement DEFAUT RAD passe a annulé (pas de changement de DATE)
			if (statutCourant.getMotif() != null && statutCourant.getMotif().getMotif().equals("RAD")) {
				Assert.assertEquals(date_15_10_2020, statutCourant.getDateDebut());
				Assert.assertEquals(date_28_10_2020, statutCourant.getDateFin());
				Assert.assertTrue(statutCourant.getAnnule());
			}

			// test que l'on cloture le DEFAUT PP à la date du traitement le 01/01/2021 et
			// passe à annuler
			if (statutCourant.getMotif() != null && statutCourant.getMotif().getMotif().equals("PP")
					&& statutCourant.getDateDebut().equals(date_28_10_2020)) {
				Assert.assertEquals(date_28_10_2020, statutCourant.getDateDebut());
				Assert.assertEquals(date_01_01_2021, statutCourant.getDateFin()); // date_01_01_2021
				Assert.assertEquals("RX", statutCourant.getGravite());
				Assert.assertTrue(statutCourant.getAnnule());
			}

			// test que l'on créé un DEFAUT PP à la date de calcul courante (soit le
			// 10/12/2010) (réévaluation sur le défaut DM clot)
			if (statutCourant.getMotif() != null && statutCourant.getMotif().getMotif().equals("PP")
					&& statutCourant.getDateFin() == null) {
				Assert.assertEquals(date_16_10_2020, statutCourant.getDateDebut());
				Assert.assertNull(statutCourant.getDateFin());
				Assert.assertEquals("DX", statutCourant.getGravite());
				Assert.assertTrue(!statutCourant.getAnnule());
			}
		}
	}

	@Test
	public void TestJira351CasOnTourne2foisLeCalculViaBatchCalculTiers() {

		// DM ACT Le 01/02/2019
		// DM ANN le 03/02/2019
		// RAD ACT le 01/02/2021
		// RAD CLO le 02/02/2021

		// 1. crée un tiers
		Tiers tiers = createTiers();

		// 2. créer une identite
		LocalDate date_01_02_2019 = LocalDate.of(2019, 02, 1);
		IdentiteTiers identite = createIdentiteTiers("JIRA_109_178_T1_USE_CASE_2", "16188", "3120", date_01_02_2019,
				null, tiers);

		// 2. creation de l'evenement DM le 08/10
		Evenement evtDM = createEevenement("DM", date_01_02_2019, identite);

		// 4 .collect complement evt DM au 08/10/2020
		ComplementEvenement complEvtDM = createEvenementLocal("DM", StatutEvenement.ACT, evtDM, date_01_02_2019, null,
				identite);

		// programme lancé le 09/02/2021
		LocalDate date_09_02_2021 = LocalDate.of(2021, 02, 9);
		majContexte(tiers, date_09_02_2021);
		defautService.entreeEnDefaut(tiers, date_01_02_2019, new MotifStatutTiers(complEvtDM), date_09_02_2021);

		// 05. collecte DM ANN le 03/02/19
		LocalDate date_03_02_2019 = LocalDate.of(2019, 02, 3);
		ComplementEvenement complEvtDMAnn = createEvenementLocal("DM", StatutEvenement.ANN, evtDM, date_03_02_2019,
				null, identite);
		complEvtDM.setDateFin(date_03_02_2019); // maj dateFn du complEvtDM
		entityManager.persist(complEvtDM);

		// programme lancé le 12/02/2021
		LocalDate date_13_02_2021 = LocalDate.of(2021, 02, 13);
		majContexte(tiers, date_13_02_2021);
		defautService.sortieDUnEvenementDeDefaut(tiers.getId(), date_13_02_2021, new MotifStatutTiers(complEvtDMAnn),
				true, date_13_02_2021);

		// 6. creation de l'evenement DM le 01/02/21
		LocalDate date_01_02_2021 = LocalDate.of(2021, 02, 1);
		Evenement evtRAD = createEevenement("RAD", date_01_02_2021, identite);

		// 7 .collect complement evt RAD le 01/02/21
		ComplementEvenement complEvtRAD = createEvenementLocal("RAD", StatutEvenement.ACT, evtRAD, date_01_02_2021,
				null, identite);

		// programme lancé le 14/02/2021
		LocalDate date_14_02_2021 = LocalDate.of(2021, 02, 14);
		majContexte(tiers, date_14_02_2021);
		defautService.entreeEnDefaut(tiers, date_01_02_2021, new MotifStatutTiers(complEvtRAD), date_14_02_2021);

		// 08. collecte RAD clo le 02/02/21 date_maj
		LocalDate date_02_02_2021 = LocalDate.of(2021, 2, 2);
		ComplementEvenement complEvtRADClo = createEvenementLocal("DM", StatutEvenement.CLO, evtRAD, date_02_02_2021,
				null, identite);
		complEvtRAD.setDateFin(date_02_02_2021); // maj dateFn
		entityManager.persist(complEvtRAD);

		// programme lancé le 15/02/2021
		LocalDate date_15_02_2021 = LocalDate.of(2021, 02, 15);
		majContexte(tiers, date_15_02_2021);
		defautService.sortieDUnEvenementDeDefaut(tiers.getId(), date_02_02_2021, new MotifStatutTiers(complEvtRADClo),
				false, date_15_02_2021);

		// ********************************************************************
		// lance un calcul tiers on réévalue le tiers - BATCH CALCUL TIERS
		// ********************************************************************
		LocalDate date_18_02_2021 = LocalDate.of(2021, 02, 18);
		majContexte(tiers, date_18_02_2021);
		defautService.annulerDefautEventClos(tiers, complEvtDMAnn, date_18_02_2021);

		// 09. collecte annulation RAD le 03/02/2021
		LocalDate date_03_02_2021 = LocalDate.of(2021, 02, 03);
		ComplementEvenement complEvtRADAnn = createEvenementLocal("RAD", StatutEvenement.ANN, evtRAD, date_03_02_2021,
				null, identite);
		complEvtRADClo.setDateFin(date_03_02_2021); // maj dateFn du complEvtRAD
		entityManager.persist(complEvtRADClo);

		// programme lancé le 18/02/2021
		// LocalDate date_18_02_2021 = LocalDate.of(2021, 02, 18);
		majContexte(tiers, date_18_02_2021);
		defautService.annulerDefautEventClos(tiers, complEvtRADAnn, date_18_02_2021);

		// Asserts
		List<StatutHistorise> allStatutsCourants = ContexteCalculTiers.getStatutsCourants(tiers.getId());

		assertEquals(5, allStatutsCourants.size());

		StatutHistorise statutDmDx = allStatutsCourants.get(0); // ligne defaut DX pour le DM
		StatutHistorise statutSainPostAnnDm = allStatutsCourants.get(1); // ligne Sain suite à l'annulation du DM
		StatutHistorise statutRadRx = allStatutsCourants.get(2); // ligne defaut RX pour le RAD
		StatutHistorise statutPP = allStatutsCourants.get(3); // ligne defaut PP suite à la cloture du RAD
		StatutHistorise statutSainPostAnnRad = allStatutsCourants.get(4); // ligne Sain suite à l'annulation du RAD

		assertEquals(true, statutDmDx.getAnnule());
		assertEquals("DM", statutDmDx.getMotif().getMotif());
		assertEquals(date_01_02_2019, statutDmDx.getDateDebut());
		assertEquals(date_13_02_2021, statutDmDx.getDateFin());

		assertEquals(true, statutSainPostAnnDm.getAnnule());
		assertNull(statutSainPostAnnDm.getMotif());
		assertEquals(date_13_02_2021, statutSainPostAnnDm.getDateDebut());
		assertEquals(date_13_02_2021, statutSainPostAnnDm.getDateFin());

		assertEquals(true, statutRadRx.getAnnule());
		assertEquals("RAD", statutRadRx.getMotif().getMotif());
		assertEquals(date_01_02_2021, statutRadRx.getDateDebut());
		assertEquals(date_02_02_2021, statutRadRx.getDateFin());

		assertEquals(true, statutPP.getAnnule());
		assertEquals("PP", statutPP.getMotif().getMotif());
		assertEquals(date_02_02_2021, statutPP.getDateDebut());
		assertEquals(date_18_02_2021, statutPP.getDateFin());

		assertEquals(false, statutSainPostAnnRad.getAnnule());
		assertNull(statutSainPostAnnRad.getMotif());
		assertEquals(date_18_02_2021, statutSainPostAnnRad.getDateDebut());
		assertNull(statutSainPostAnnRad.getDateFin());

	}

	// Fonctions pour créer les objets

	private Evenement createEevenement(String code, LocalDate dateDeb, IdentiteTiers identite) {

		Evenement evt = new Evenement();
		evt.setCode(code);
		evt.setDateDebut(dateDeb);
		evt.setIdentiteInitiale(identite);
		evt = entityManager.persist(evt);

		return evt;
	}

	private IdentiteTiers createIdentiteTiers(String idLocal, String codeBanque, String codeSegement,
			LocalDate dateDebut, LocalDate dateFin, Tiers tiers) {

		IdentiteTiers ident = new IdentiteTiers();
		ident.setIdLocal(idLocal);
		ident.setCodeBanque(codeBanque);
		ident.setCodeSegment(codeSegement);
		ident.setDateDebut(dateDebut);
		ident.setTiers(tiers);
		tiers.addIdentite(ident);
		ident = entityManager.persist(ident);
		return ident;
	}

	public Tiers createTiers() {
		Tiers tiers = new Tiers();
		tiers = entityManager.persist(tiers);
		return tiers;
	}

	public ComplementEvenement createEvenementLocal(String code, StatutEvenement statut, Evenement evt,
			LocalDate dateMaj, LocalDate dateFin, IdentiteTiers identite) {

		ComplementEvenement complEvt = new ComplementEvenement();
		complEvt.setEvenement(evt);
		complEvt.setDatePhoto(dateMaj);
		complEvt.setDateMaj(dateMaj);
		complEvt.setStatutEvt(statut);
		complEvt.setIdentiteInitiale(identite);
		complEvt.setAuditFichier(entityManager.persist(new AuditFichiers()));
		complEvt = entityManager.persist(complEvt);

		return complEvt;

	}

	public StatutHistorise createStatutTiers(StatutTiers satut, MotifStatutTiers motif, String gravite,
			LocalDate dateDeb, LocalDate dateFin, Tiers tiers) {
		StatutHistorise statutDefaut = new StatutHistorise();
		statutDefaut.setDateDeb(dateDeb);
		statutDefaut.setDateFin(dateFin);
		statutDefaut.setStatut(satut);
		statutDefaut.setMotif(motif);
		statutDefaut.setGravite(gravite);
		statutDefaut.setTiers(tiers);
		statutDefaut = entityManager.persist(statutDefaut);

		return statutDefaut;

	}

	public void majContexte(Tiers tiers, LocalDate dateCalcul)

	{
		LotIdTiersDTO lotIds = new LotIdTiersDTO();
		lotIds.setGuid(java.util.UUID.randomUUID().getMostSignificantBits());
		Long idTiers = Long.valueOf(tiers.getId());
		lotIds.addIdTiers(idTiers);
		lotIds.setDateCalcul(dateCalcul);

		Map<Long, List<IdentiteTiers>> identiteTiers = identiteTiersService.rechercheIdentitesActivesADate(lotIds);
		Map<Long, EvenementsATraiter> evenementsATraiter = evtRecuService.rechercheEvenementsATraiterADate(lotIds,
				identiteTiers);
		Map<Long, List<StatutHistorise>> statutsCourants = defautService.getStatutsADate(lotIds);
		Map<Long, EvenementsCalculesTiers> evtCalculesTiers = evtCalculeService
				.rechercheEvenementsCalculesActifsADate(lotIds);

		ContexteCalculTiers.init(evenementsATraiter, statutsCourants, identiteTiers, evtCalculesTiers);
	}

	public void initParam() {
		LocalDate date_01_01_2019 = LocalDate.of(2019, 01, 01);
		// REF IMPACT EVT MDC
		RefImpactEvtMdc refImpactRAD = new RefImpactEvtMdc();
		refImpactRAD.setCodEvt("RAD");
		refImpactRAD.setCategorieSegment(Constant.TOUS_AUTRES);
		refImpactRAD.setImpact("D");
		refImpactRAD.setGraviteImpact("RX");
		refImpactRAD.setDateDebut(date_01_01_2019);
		entityManager.persist(refImpactRAD);

		RefImpactEvtMdc refImpactDM = new RefImpactEvtMdc();
		refImpactDM.setCodEvt("DM");
		refImpactDM.setCategorieSegment(Constant.TOUS_AUTRES);
		refImpactDM.setImpact("D");
		refImpactDM.setGraviteImpact("DX");
		refImpactDM.setDateDebut(date_01_01_2019);
		entityManager.persist(refImpactDM);

	}

}
package fr.bpce.yyd.service.commun.service.impl;

import static org.mockito.Mockito.doAnswer;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import fr.bpce.yyd.commun.enums.StatutAuditEvenement;
import fr.bpce.yyd.commun.enums.StatutEvenement;
import fr.bpce.yyd.commun.enums.StatutTiers;
import fr.bpce.yyd.commun.model.AuditCalcul;
import fr.bpce.yyd.commun.model.ComplementEvenement;
import fr.bpce.yyd.commun.model.Evenement;
import fr.bpce.yyd.commun.model.EvenementCalcule;
import fr.bpce.yyd.commun.model.MotifStatutTiers;
import fr.bpce.yyd.commun.model.PeriodeProbatoire;
import fr.bpce.yyd.commun.model.StatutHistorise;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.service.commun.beans.EvenementsCalculesTiers;
import fr.bpce.yyd.service.commun.contexte.ContexteCalculTiers;
import fr.bpce.yyd.service.commun.repository.StatutTiersRepository;
import fr.bpce.yyd.service.commun.service.EvenementCalculeService;

@RunWith(PowerMockRunner.class)
@PrepareForTest(ContexteCalculTiers.class)

//********************************************************************************************************
//USE CASE JIRA 109 - confluence TEMPO : https://confluence.f.bbg/display/NDODSA/Annulation+UTP+clos
//********************************************************************************************************
public class AnnulationUTPImplTest {

	private PeriodeProbatoire periodeProbatoireCree;
	private StatutHistorise nouveauStatut;

	@Before
	public void initTest() throws SQLException {
		ContexteCalculTiers.clear();
	}

	@Test
	public void cloDefaut1PuisAnnDefaut1DatePosterieure() {

		// Arrange
		DefautServiceImpl defautService = new DefautServiceImpl();

		Tiers tiers = new Tiers(0L);

		// 1. RAD ACT - Création d'un de défaut RAD au 15/10
		LocalDate date20201015 = LocalDate.of(2020, 10, 15);
		Evenement evt1 = new Evenement();
		evt1.setId(1L);
		evt1.setCode("RAD");
		evt1.setDateDebut(date20201015);

		ComplementEvenement complEvt1 = new ComplementEvenement();
		complEvt1.setEvenement(evt1);
		complEvt1.setDatePhoto(date20201015);
		complEvt1.setDateMaj(date20201015);
		complEvt1.setStatutEvt(StatutEvenement.ACT);

		// 2. RAD CLO - Cloture de l'evenemnt de défaut RAD au 28/10
		LocalDate date20201028 = LocalDate.of(2020, 10, 28);
		ComplementEvenement complEvt2 = new ComplementEvenement();
		complEvt2.setEvenement(evt1);
		complEvt2.setDateMaj(date20201028);
		complEvt2.setStatutEvt(StatutEvenement.CLO);
		complEvt1.setDateFin(date20201028);

		evt1.addComplement(complEvt1);
		complEvt1.setEvenement(evt1);
		evt1.addComplement(complEvt2);
		complEvt2.setEvenement(evt1);

		// 3 => creation STATUT DEFAUT associé au RAD du 15/10
		List<StatutHistorise> statuts = new ArrayList<>();
		StatutHistorise statutDefaut1 = new StatutHistorise();
		statutDefaut1.setDateDeb(date20201015);
		statutDefaut1.setDateFin(date20201028);
		statutDefaut1.setStatut(StatutTiers.DEFAUT);
		statutDefaut1.setMotif(new MotifStatutTiers(complEvt1));
		statutDefaut1.setGravite("RX");
		statuts.add(statutDefaut1);

		// 4. => creation STATUT DEFAUT PP suite a la cloture du RAD au 28/10
		StatutHistorise statutDefaut2 = new StatutHistorise();
		statutDefaut2.setDateDeb(date20201028);
		statutDefaut2.setStatut(StatutTiers.DEFAUT);

		PeriodeProbatoire pp = new PeriodeProbatoire();
		pp.setDateDebut(date20201028);
		pp.setTiers(tiers);
		tiers.addEvenementCalcule(pp);
		statutDefaut2.setMotif(new MotifStatutTiers(pp));
		statutDefaut2.setGravite("RX");
		statuts.add(statutDefaut2);

		// 5. creation de l'AUDIT CALCUL pour la création PP au 28/12
		AuditCalcul auditCalcul = new AuditCalcul();
		auditCalcul.setEvenementCalcule(pp);
		auditCalcul.setDateEffet(date20201028);
		auditCalcul.setStatut(StatutAuditEvenement.ACT);
		auditCalcul.setCode("PP");

		// 5.Annulation de défaut RAD au 10/12 => Retour en SAIN au 10/12
		LocalDate date20201210 = LocalDate.of(2020, 12, 10);
		ComplementEvenement complEvt3 = new ComplementEvenement();
		complEvt3.setEvenement(evt1);
		complEvt3.setDateMaj(date20201210);
		complEvt3.setStatutEvt(StatutEvenement.ANN);
		complEvt3.setEvenement(evt1);
		evt1.addComplement(complEvt3);
		complEvt3.setEvenement(evt1);

		// 5. les mocks

		// retourne StatutHistorise
		StatutTiersRepository statutTiersRepository = Mockito.mock(StatutTiersRepository.class);
		Mockito.when(statutTiersRepository.getStatutADate(Mockito.any(), Mockito.any())).thenReturn(statuts);
		defautService.setStatutTiersRepository(statutTiersRepository);

		// retourne StatutHistorise
		PowerMockito.mockStatic(ContexteCalculTiers.class);
		PowerMockito.when(ContexteCalculTiers.getStatutsCourants(Mockito.any())).thenReturn(statuts);

		// return EvenementsCalculesTiers a l'appel de
		// rechercheEvenementsCalculesActifsADate
		EvenementCalculeService ecService = Mockito.mock(EvenementCalculeService.class);
		defautService.setEvtCalculeService(ecService);

		Mockito.when(ecService.rechercheEvenementsCalculesActifsADate(tiers.getId(), date20201210))
				.then(new Answer<EvenementsCalculesTiers>() {

					@Override
					public EvenementsCalculesTiers answer(InvocationOnMock invocation) throws Throwable {

						PeriodeProbatoire pp = new PeriodeProbatoire();
						pp.setDateDebut(date20201028);
						pp.setTiers(tiers);

						List<EvenementCalcule> calcs = new ArrayList<>();
						calcs.add(pp);
						EvenementsCalculesTiers evenementsCalculesTiers = new EvenementsCalculesTiers(calcs);
						evenementsCalculesTiers.setPeriodeProbatoire(pp);

						return evenementsCalculesTiers;
					}
				});

		// return le StatutHistorise (retour en SAIN)
		Mockito.when(statutTiersRepository.save(Mockito.any())).then(new Answer<StatutHistorise>() {
			@Override
			public StatutHistorise answer(InvocationOnMock invocation) throws Throwable {
				nouveauStatut = invocation.getArgument(0);
				return nouveauStatut;
			}
		});

		// mock sur la période probatoire
		doAnswer((i) -> {
			periodeProbatoireCree = i.getArgument(0);
			periodeProbatoireCree.setDateFin(i.getArgument(1));
			return null;
		}).when(ecService).closPeriodeProbatoire(Mockito.any(), Mockito.any(), Mockito.any());

		// ACT
		defautService.annulerDefautEventClos(tiers, complEvt3, date20201210);

		// TEST
		Assert.assertNotNull(nouveauStatut);
		Assert.assertEquals(StatutTiers.SAIN, nouveauStatut.getStatut()); // Tiers retour en SAIN

		Assert.assertNotNull(periodeProbatoireCree);
		Assert.assertNotNull(periodeProbatoireCree.getDateFin()); // PP CLOT

	}

}

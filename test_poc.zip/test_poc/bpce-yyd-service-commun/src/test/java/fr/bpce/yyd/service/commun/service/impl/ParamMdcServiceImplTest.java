package fr.bpce.yyd.service.commun.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import fr.bpce.yyd.commun.constantes.Constant;
import fr.bpce.yyd.commun.enums.CodeParamMdc;
import fr.bpce.yyd.commun.model.ParMdcBqSeg;
import fr.bpce.yyd.commun.model.ParMdcSeg;
import fr.bpce.yyd.service.commun.repository.ParMdcBqSegRepository;
import fr.bpce.yyd.service.commun.repository.ParMdcSegRepository;

public class ParamMdcServiceImplTest {

	ParamMdcServiceImpl srv;

	static CodeParamMdc PARAM_TEST = CodeParamMdc.DELAI_RAZ_PP; // Peu importe

	static String BANQUE_TEST = "17515";
	static String SEGMENT_TEST = "3200";
	static String BANQUE_HORS_TEST = "00000";
	static String SEGMENT_HORS_TEST = "0000";
	static BigDecimal VAL_BQ_SEG_EXACT = new BigDecimal(20);
	static BigDecimal VAL_BQ_SEG_BQ_DEF = new BigDecimal(15);
	static BigDecimal VAL_BQ_SEG_SEG_DEF = new BigDecimal(10);
	static BigDecimal VAL_BQ_SEG_GENERIQUE = new BigDecimal(5);

	static BigDecimal VAL_SEG_EXACT = new BigDecimal(40);
	static BigDecimal VAL_SEG_GENERIQUE = new BigDecimal(35);

	@Before
	public void init() {
		ParMdcSegRepository parMdcSegRepository = Mockito.mock(ParMdcSegRepository.class);
		List<ParMdcSeg> paramMdcSeg = new ArrayList<>();
		paramMdcSeg.add(newParMdcSeg(SEGMENT_TEST, VAL_SEG_EXACT));
		paramMdcSeg.add(newParMdcSeg(Constant.ANY, VAL_SEG_GENERIQUE));
		Mockito.when(parMdcSegRepository.findAllParamMdcSegADate(Mockito.any())).thenReturn(paramMdcSeg);

		ParMdcBqSegRepository parMdcBqSegRepository = Mockito.mock(ParMdcBqSegRepository.class);
		List<ParMdcBqSeg> paramMdcBqSeg = new ArrayList<>();
		paramMdcBqSeg.add(newParMdcBqSeg(BANQUE_TEST, SEGMENT_TEST, VAL_BQ_SEG_EXACT));
		paramMdcBqSeg.add(newParMdcBqSeg(BANQUE_TEST, Constant.ANY, VAL_BQ_SEG_BQ_DEF));
		paramMdcBqSeg.add(newParMdcBqSeg(Constant.ANY, SEGMENT_TEST, VAL_BQ_SEG_SEG_DEF));
		paramMdcBqSeg.add(newParMdcBqSeg(Constant.ANY, Constant.ANY, VAL_BQ_SEG_GENERIQUE));
		Mockito.when(parMdcBqSegRepository.findAllParamMdcBqSegADate(Mockito.any())).thenReturn(paramMdcBqSeg);

		srv = new ParamMdcServiceImpl();
		srv.setParMdcBqSegRepository(parMdcBqSegRepository);
		srv.setParMdcSegRepository(parMdcSegRepository);
	}

	private ParMdcSeg newParMdcSeg(String codeSegment, BigDecimal valeur) {
		ParMdcSeg ret = new ParMdcSeg();
		ret.setCodeParam(PARAM_TEST);
		ret.setCodeSegment(codeSegment);
		ret.setValeurParam(valeur.toString());
		return ret;
	}

	private ParMdcBqSeg newParMdcBqSeg(String codeBanque, String codeSegment, BigDecimal valeur) {
		ParMdcBqSeg ret = new ParMdcBqSeg();
		ret.setCodeParam(PARAM_TEST);
		ret.setCodeBq(codeBanque);
		ret.setCodeSegment(codeSegment);
		ret.setValeurParam(valeur.toString());
		return ret;
	}

	@Test
	public void parametreMdcSegExact() {
		// Act
		String ret = srv.getParamMdcSegValueADate(PARAM_TEST, SEGMENT_TEST, null);

		// Assert
		Assert.assertEquals(VAL_SEG_EXACT.toString(), ret);
	}

	@Test
	public void parametreMdcSegGenerique() {
		// Act
		String ret = srv.getParamMdcSegValueADate(PARAM_TEST, SEGMENT_HORS_TEST, null);

		// Assert
		Assert.assertEquals(VAL_SEG_GENERIQUE.toString(), ret);
	}

	@Test
	public void parametreMdcBqSegBanqueDef() {
		// Act
		String ret = srv.getParamMdcBqSegValueADate(PARAM_TEST, BANQUE_TEST, SEGMENT_HORS_TEST, null);

		// Assert
		Assert.assertEquals(VAL_BQ_SEG_BQ_DEF.toString(), ret);
	}

	@Test
	public void parametreMdcBqSegSegmentDef() {
		// Act
		String ret = srv.getParamMdcBqSegValueADate(PARAM_TEST, BANQUE_HORS_TEST, SEGMENT_TEST, null);

		// Assert
		Assert.assertEquals(VAL_BQ_SEG_SEG_DEF.toString(), ret);
	}

	@Test
	public void parametreMdcBqSegExact() {
		// Act
		String ret = srv.getParamMdcBqSegValueADate(PARAM_TEST, BANQUE_TEST, SEGMENT_TEST, null);

		// Assert
		Assert.assertEquals(VAL_BQ_SEG_EXACT.toString(), ret);
	}

	@Test
	public void parametreMdcBqSegGenerique() {
		// Act
		String ret = srv.getParamMdcBqSegValueADate(PARAM_TEST, BANQUE_HORS_TEST, SEGMENT_HORS_TEST, null);

		// Assert
		Assert.assertEquals(VAL_BQ_SEG_GENERIQUE.toString(), ret);
	}
}

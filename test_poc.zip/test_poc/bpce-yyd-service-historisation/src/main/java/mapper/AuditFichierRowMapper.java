package mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fr.bpce.yyd.service.histo.beans.AuditFichierDto;

public class AuditFichierRowMapper implements RowMapper<AuditFichierDto> {

	@Override
	public AuditFichierDto mapRow(ResultSet rs, int rowNum) throws SQLException {
		AuditFichierDto dto = new AuditFichierDto();
		dto.setId(rs.getLong("ID"));
		dto.setCodBq(rs.getString("CODE_BQ"));
		dto.setCodAudit(rs.getString("CODE_AUDIT"));
		dto.setDateAudit(rs.getDate("DATE_AUDIT"));
		dto.setLibCodAudit(rs.getString("LIBELLE_AUDIT"));
		dto.setNbLignes(rs.getInt("NB_LIGNES"));
		dto.setNbLignesRejet(rs.getInt("NB_LIGNES_REJET"));
		dto.setNomFichier(rs.getString("NOM_FICHIER"));
		dto.setJobExecutionId(rs.getLong("JOB_EXECUTION_ID"));
		dto.setDatePhoto(rs.getDate("DATE_PHOTO"));
		return dto;
	}

}

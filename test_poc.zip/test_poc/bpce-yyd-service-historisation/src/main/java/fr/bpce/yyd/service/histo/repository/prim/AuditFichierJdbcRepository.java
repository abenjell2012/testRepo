/*
 * package fr.bpce.yyd.service.histo.repository.prim;
 * 
 * import java.sql.Date; import java.sql.PreparedStatement; import
 * java.sql.SQLException; import java.util.Arrays; import java.util.List;
 * 
 * import org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.beans.factory.annotation.Qualifier; import
 * org.springframework.jdbc.core.BatchPreparedStatementSetter; import
 * org.springframework.jdbc.core.JdbcTemplate; import
 * org.springframework.stereotype.Repository;
 * 
 * import fr.bpce.yyd.service.histo.beans.AuditFichierDto; import
 * mapper.AuditFichierRowMapper;
 * 
 * @Repository public class AuditFichierJdbcRepository {
 * 
 * @Autowired
 * 
 * @Qualifier("jdbcPrim") JdbcTemplate jdbcTemplatePrim;
 * 
 * @Autowired
 * 
 * @Qualifier("jdbcHisto") JdbcTemplate jdbcTemplateHisto;
 * 
 * public List<AuditFichierDto> getAuditFichier(Date datePhoto) {
 * 
 * List<AuditFichierDto> dtos =
 * jdbcTemplatePrim.query("SELECT * FROM AUDIT_FICHIERS WHERE DATE_AUDIT >= ?",
 * new Object[] { datePhoto }, new AuditFichierRowMapper());
 * 
 * for (AuditFichierDto auditFichierDto : dtos) { System.out.println("dtos " +
 * dtos); }
 * 
 * return dtos;
 * 
 * }
 * 
 * public int insertAuditFichier(List<AuditFichierDto> dtos) {
 * 
 * int[] nbInserts = jdbcTemplateHisto.batchUpdate(
 * "INSERT INTO AUDIT_FICHIERS (CODE_AUDIT,CODE_BQ,DATE_AUDIT,LIBELLE_AUDIT,NB_LIGNES,NB_LIGNES_REJET,NOM_FICHIER,JOB_EXECUTION_ID,DATE_PHOTO) "
 * + "values (?,?,?,?,?,?,?,?,?)", new BatchPreparedStatementSetter() {
 * 
 * @Override public void setValues(PreparedStatement ps, int i) throws
 * SQLException { // ps.setLong(1, dtos.get(i).getId()); ps.setString(1,
 * dtos.get(i).getCodAudit()); ps.setString(2, dtos.get(i).getCodBq());
 * ps.setDate(3, dtos.get(i).getDateAudit()); ps.setString(4,
 * dtos.get(i).getLibCodAudit()); ps.setInt(5, dtos.get(i).getNbLignes());
 * ps.setInt(6, dtos.get(i).getNbLignesRejet()); ps.setString(7,
 * dtos.get(i).getNomFichier()); ps.setLong(8, dtos.get(i).getJobExecutionId());
 * ps.setDate(9, dtos.get(i).getDatePhoto()); }
 * 
 * @Override public int getBatchSize() { return dtos.size(); } });
 * 
 * return Arrays.stream(nbInserts).sum();
 * 
 * }
 * 
 * }
 */
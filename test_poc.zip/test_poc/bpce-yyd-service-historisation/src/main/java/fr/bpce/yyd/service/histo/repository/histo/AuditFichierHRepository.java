package fr.bpce.yyd.service.histo.repository.histo;

import org.springframework.data.jpa.repository.JpaRepository;

import fr.bpce.yyd.commun.model.AuditFichiers;

public interface AuditFichierHRepository extends JpaRepository<AuditFichiers, Integer> {

}

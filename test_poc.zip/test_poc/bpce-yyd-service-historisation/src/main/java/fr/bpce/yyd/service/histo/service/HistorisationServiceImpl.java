//package fr.bpce.yyd.service.histo.service;
//
//import java.sql.Date;
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;
//
//import fr.bpce.yyd.commun.model.AuditFichiers;
//import fr.bpce.yyd.service.histo.repository.histo.AuditFichierHRepository;
//import fr.bpce.yyd.service.histo.repository.prim.AuditFichierJdbcRepository;
//import fr.bpce.yyd.service.histo.repository.prim.AuditFichierRepository;
//
//@Service
//public class HistorisationServiceImpl {
//
//	@Autowired
//	private AuditFichierJdbcRepository auditFicRepo;
//
//	@Autowired
//	private AuditFichierRepository auditFicJpaRepo;
//
//	@Autowired
//	private AuditFichierHRepository auditFicHJpaRepo;
//
//	@Transactional(transactionManager = "chainedDsTransactionManager")
//	public int copyFromDsPrimToHisto(Date datePhoto) {
//		return auditFicRepo.insertAuditFichier(auditFicRepo.getAuditFichier(datePhoto));
//
//	}
//
//	@Transactional
//	public void copyFromDsPrimToHistoJPA(Date datePhoto) {
//
//		List<AuditFichiers> fics = auditFicJpaRepo.findAuditFic(datePhoto);
//		auditFicHJpaRepo.saveAll(fics);
//	}
//
//}

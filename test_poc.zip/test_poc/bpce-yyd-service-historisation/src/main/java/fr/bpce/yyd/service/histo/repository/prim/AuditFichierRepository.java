package fr.bpce.yyd.service.histo.repository.prim;

import java.sql.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import fr.bpce.yyd.commun.model.AuditFichiers;

@Repository
public interface AuditFichierRepository extends JpaRepository<AuditFichiers, Integer> {

	@Query("SELECT audit FROM AuditFichiers audit WHERE audit.dateAudit >= :datePhoto")
	List<AuditFichiers> findAuditFic(@Param("datePhoto") Date datePhoto);

	@Query("SELECT audit FROM AuditFichiers audit WHERE trunc(audit.dateAudit) = :date")
	Page<AuditFichiers> findAuditFicByDate(@Param("date") java.util.Date date, Pageable pageable);

	@Query("SELECT audit FROM AuditFichiers audit WHERE id = :id")
	Page<AuditFichiers> findAuditById(@Param("id") Long id, Pageable pageable);

}

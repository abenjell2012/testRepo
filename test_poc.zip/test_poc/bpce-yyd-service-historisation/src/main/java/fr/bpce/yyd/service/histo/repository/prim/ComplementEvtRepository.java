package fr.bpce.yyd.service.histo.repository.prim;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import fr.bpce.yyd.commun.model.ComplementEvenement;

public interface ComplementEvtRepository extends JpaRepository<ComplementEvenement, Integer> {

	@Query("SELECT comp FROM ComplementEvenement comp WHERE comp.dateFin is null and datePhoto >= :datePhoto")
	List<ComplementEvenement> findComplementEvenemntWithNull(@Param("datePhoto") LocalDate datePhoto);

}

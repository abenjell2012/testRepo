package fr.bpce.yyd.service.histo.launch;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.JobOperator;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class HistoJobRunner {

	private static final Logger log = LoggerFactory.getLogger(HistoJobRunner.class);

	private SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");

	public static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");

	public static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyyMMdd");

	private static final String GET_RUNNING_EXECUTIONS = "SELECT E.JOB_EXECUTION_ID, E.START_TIME, E.END_TIME, E.STATUS, E.EXIT_CODE, E.EXIT_MESSAGE, E.CREATE_TIME, E.LAST_UPDATED, E.VERSION, "
			+ "E.JOB_INSTANCE_ID, E.JOB_CONFIGURATION_LOCATION from BATCH_JOB_EXECUTION E, BATCH_JOB_INSTANCE I where E.JOB_INSTANCE_ID=I.JOB_INSTANCE_ID and I.JOB_NAME=? and E.START_TIME is not NULL and E.END_TIME is NULL";

	private static final String GET_NB_RUNNING_EXECUTIONS = "SELECT count(*) from BATCH_JOB_EXECUTION E, BATCH_JOB_INSTANCE I where E.JOB_INSTANCE_ID=I.JOB_INSTANCE_ID and I.JOB_NAME=? and E.START_TIME is not NULL and E.END_TIME is NULL";

	@Autowired
	private JobExplorer jobExplorer;

	@Autowired
	private JobOperator jobOperator;

	@Autowired
	private JobLauncher jobLauncher;

	@Autowired
	@Qualifier("TEST_JOB")
	private Job job;

	@Scheduled(fixedDelay = 20000, initialDelay = 1000)
	public void fixedDelaySch() throws Exception {
		// run();
		// jobOperator.restart(8340L);
	}

	public void run() throws JobExecutionAlreadyRunningException, JobRestartException,
			JobInstanceAlreadyCompleteException, JobParametersInvalidException, ParseException {
		if (log.isInfoEnabled()) {
			log.info("The time is now {}", dateFormat.format(new Date()));
		}
		log.info("Debut BATCH NDOD : Restitution NIR");

		Set<JobExecution> exec = jobExplorer.findRunningJobExecutions("TEST_JOB");
		log.info("nb Executionjob en cours= {}", exec.size());
		JobParameters jobParameters = new JobParametersBuilder().addLong("id", new Date().getTime())
				.addDate("date", new SimpleDateFormat("dd/MM/yyyy").parse("20/10/2020")).toJobParameters();
		jobLauncher.run(job, jobParameters);

		log.info("Fin BATCH NDOD");
	}

}

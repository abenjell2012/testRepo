package fr.bpce.yyd.service.histo.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.zaxxer.hikari.HikariDataSource;

@Configuration
@PropertySource({ "classpath:config/application.yml" })
@EnableTransactionManagement
@EnableJpaRepositories(basePackages = "fr.bpce.yyd.service.histo.repository.histo", //
		entityManagerFactoryRef = "histoEntityManager", transactionManagerRef = "histoTransactionManager")
public class PersistenceHistoNdodConfiguration {

	@Bean
	@ConfigurationProperties("spring.histo-datasource")
	public DataSourceProperties histoDataSourceProperties() {
		return new DataSourceProperties();
	}

	@Bean
	@ConfigurationProperties("spring.histo-datasource.configuration")
	public DataSource histoDataSource() {
		return histoDataSourceProperties().initializeDataSourceBuilder().type(HikariDataSource.class).build();
	}

	@Bean
	public LocalContainerEntityManagerFactoryBean histoEntityManager(EntityManagerFactoryBuilder builder) {
		return builder.dataSource(histoDataSource()).packages("fr.bpce.yyd.commun.model").build();
	}

	@Bean
	public PlatformTransactionManager histoTransactionManager(
			final @Qualifier("histoEntityManager") LocalContainerEntityManagerFactoryBean histoEntityManager) {
		return new JpaTransactionManager(histoEntityManager.getObject());
	}

}

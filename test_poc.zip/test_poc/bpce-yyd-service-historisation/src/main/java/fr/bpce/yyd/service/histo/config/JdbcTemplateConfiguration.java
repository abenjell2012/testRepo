/*
 * package fr.bpce.yyd.service.histo.config;
 * 
 * import java.util.HashMap; import java.util.Map;
 * 
 * import javax.sql.DataSource;
 * 
 * import org.springframework.beans.factory.annotation.Qualifier; import
 * org.springframework.boot.autoconfigure.jdbc.DataSourceProperties; import
 * org.springframework.boot.context.properties.ConfigurationProperties; import
 * org.springframework.context.annotation.Bean; import
 * org.springframework.context.annotation.Configuration; import
 * org.springframework.context.annotation.Primary; import
 * org.springframework.context.annotation.PropertySource; import
 * org.springframework.data.transaction.ChainedTransactionManager; import
 * org.springframework.jdbc.core.JdbcTemplate; import
 * org.springframework.jdbc.datasource.DataSourceTransactionManager; import
 * org.springframework.transaction.PlatformTransactionManager; import
 * org.springframework.transaction.annotation.EnableTransactionManagement;
 * 
 * import com.zaxxer.hikari.HikariDataSource;
 * 
 * @Configuration
 * 
 * @PropertySource({ "classpath:config/application.yml" })
 * 
 * @EnableTransactionManagement public class JdbcTemplateConfiguration {
 * 
 * @Bean("hibernateProperties")
 * 
 * @ConfigurationProperties("spring.jpa.properties") public Map<String, String>
 * hibernateProperties() { return new HashMap<>(); }
 * 
 * @Bean
 * 
 * @Primary
 * 
 * @ConfigurationProperties("spring.datasource") public DataSourceProperties
 * primaryDataSourceProperties() { return new DataSourceProperties(); }
 * 
 * @Bean
 * 
 * @ConfigurationProperties("spring.histo-datasource") public
 * DataSourceProperties histoDataSourceProperties() { return new
 * DataSourceProperties(); }
 * 
 * @Bean
 * 
 * @Primary
 * 
 * @ConfigurationProperties("spring.datasource.configuration") public DataSource
 * primDataSource() { return
 * primaryDataSourceProperties().initializeDataSourceBuilder().type(
 * HikariDataSource.class).build(); }
 * 
 * @Bean
 * 
 * @ConfigurationProperties("spring.histo-datasource.configuration") public
 * DataSource histoDataSource() { return
 * histoDataSourceProperties().initializeDataSourceBuilder().type(
 * HikariDataSource.class).build(); }
 * 
 * @Bean public JdbcTemplate jdbcPrim() { return new
 * JdbcTemplate(primDataSource()); }
 * 
 * @Bean public JdbcTemplate jdbcHisto() { return new
 * JdbcTemplate(histoDataSource()); }
 * 
 * @Bean public PlatformTransactionManager primDsTransactionManager() {
 * DataSourceTransactionManager transactionManager = new
 * DataSourceTransactionManager();
 * transactionManager.setDataSource(primDataSource()); return
 * transactionManager; }
 * 
 * @Bean public PlatformTransactionManager histoDsTransactionManager() {
 * DataSourceTransactionManager transactionManager = new
 * DataSourceTransactionManager();
 * transactionManager.setDataSource(histoDataSource()); return
 * transactionManager; }
 * 
 * @Bean("chainedDsTransactionManager") public ChainedTransactionManager
 * chainedTransactionManager(
 * 
 * @Qualifier("primDsTransactionManager") PlatformTransactionManager txManager1,
 * 
 * @Qualifier("histoDsTransactionManager") PlatformTransactionManager
 * txManager2) { return new ChainedTransactionManager(txManager1, txManager2); }
 * 
 * }
 */
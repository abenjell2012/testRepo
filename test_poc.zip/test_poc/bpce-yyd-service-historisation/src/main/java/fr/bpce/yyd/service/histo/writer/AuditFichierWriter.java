package fr.bpce.yyd.service.histo.writer;

import java.util.List;

import org.springframework.batch.item.data.RepositoryItemWriter;
import org.springframework.util.CollectionUtils;

import fr.bpce.yyd.commun.model.AuditFichiers;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AuditFichierWriter extends RepositoryItemWriter<AuditFichiers> {

	@Override
	public void write(List<? extends AuditFichiers> items) throws Exception {
		log.info("Ecriture de " + items.size());
		if (!CollectionUtils.isEmpty(items)) {
			super.doWrite(items);
		}
	}

}

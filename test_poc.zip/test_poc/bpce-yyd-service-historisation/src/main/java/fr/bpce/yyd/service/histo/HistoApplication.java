package fr.bpce.yyd.service.histo;

import java.util.Map;
import java.util.Map.Entry;

import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
//@ComponentScan(basePackages = { "fr.bpce.yyd.service.histo" })
//@EntityScan(basePackages = { "fr.bpce.yyd.commun.model" })
@EnableBatchProcessing
@EnableScheduling
public class HistoApplication implements CommandLineRunner {

	@Autowired
	@Qualifier("hibernateProperties")
	Map<String, String> properties;

	// @Autowired
	// HistorisationServiceImpl histoService;

	public static void main(String[] args) {
		SpringApplication.run(HistoApplication.class, args);
		System.out.println("Application is running...");
	}

	@Override
	public void run(String... args) throws Exception {

		for (Entry<String, String> entry : properties.entrySet()) {
			System.out.println("key =" + entry.getKey());
			System.out.println("value =" + entry.getValue());
		}

		// histoService.copyFromDsPrimToHisto(Date.valueOf(LocalDate.of(2019, 9, 01)));

	}

}

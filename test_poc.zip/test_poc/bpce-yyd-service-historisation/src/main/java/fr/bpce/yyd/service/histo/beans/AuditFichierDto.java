package fr.bpce.yyd.service.histo.beans;

import java.sql.Date;

public class AuditFichierDto {

	private long id;

	private String codBq;

	private String nomFichier;

	private int nbLignes;

	private int nbLignesRejet;

	private Date dateAudit;

	private String codAudit;

	private String libelleAudit;

	private Long jobExecutionId;

	private Date datePhoto;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getNomFichier() {
		return nomFichier;
	}

	public void setNomFichier(String nomFichier) {
		this.nomFichier = nomFichier;
	}

	public String getCodBq() {
		return codBq;
	}

	public void setCodBq(String codBq) {
		this.codBq = codBq;
	}

	public Date getDateAudit() {
		return dateAudit;
	}

	public Date getDatePhoto() {
		return datePhoto;
	}

	public void setDatePhoto(Date datePhoto) {
		this.datePhoto = datePhoto;
	}

	public void setDateAudit(Date dateAudit) {
		this.dateAudit = dateAudit;
	}

	public int getNbLignes() {
		return nbLignes;
	}

	public void setNbLignes(int nbLignes) {
		this.nbLignes = nbLignes;
	}

	public int getNbLignesRejet() {
		return nbLignesRejet;
	}

	public void setNbLignesRejet(int nbLignesRejet) {
		this.nbLignesRejet = nbLignesRejet;
	}

	public String getCodAudit() {
		return codAudit;
	}

	public void setCodAudit(String codAudit) {
		this.codAudit = codAudit;
	}

	public String getLibCodAudit() {
		return libelleAudit;
	}

	public void setLibCodAudit(String libCodAudit) {
		this.libelleAudit = libCodAudit;
	}

	public Long getJobExecutionId() {
		return jobExecutionId;
	}

	public void setJobExecutionId(Long jobExecutionId) {
		this.jobExecutionId = jobExecutionId;
	}

}

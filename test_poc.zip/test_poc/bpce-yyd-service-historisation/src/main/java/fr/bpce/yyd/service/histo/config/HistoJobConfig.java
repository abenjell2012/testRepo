package fr.bpce.yyd.service.histo.config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.JobRegistry;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.configuration.support.JobRegistryBeanPostProcessor;
import org.springframework.batch.item.data.RepositoryItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.domain.Sort.Direction;

import fr.bpce.yyd.commun.model.AuditFichiers;
import fr.bpce.yyd.service.histo.repository.histo.AuditFichierHRepository;
import fr.bpce.yyd.service.histo.repository.prim.AuditFichierRepository;
import fr.bpce.yyd.service.histo.writer.AuditFichierWriter;

@Configuration
public class HistoJobConfig {

	@Autowired
	private JobBuilderFactory jobBuilders;

	@Autowired
	private StepBuilderFactory stepBuilders;

	@Autowired
	private AuditFichierHRepository auditFichierHRepository;

	@Autowired
	private AuditFichierRepository auditFichierRepository;

	@Bean
	public JobRegistryBeanPostProcessor jobRegistryBeanPostProcessor(JobRegistry jobRegistry) {
		JobRegistryBeanPostProcessor jobRegistryBeanPostProcessor = new JobRegistryBeanPostProcessor();
		jobRegistryBeanPostProcessor.setJobRegistry(jobRegistry);
		return jobRegistryBeanPostProcessor;
	}

	@Bean("TEST_JOB")
	public Job histoJob(@Qualifier("stepHistAuditFichier") Step step) {
		return jobBuilders.get("TEST_JOB").start(step).build();
	}

	@Bean
	public Step stepHistAuditFichier() {
		return stepBuilders.get("stepHistAuditFichier").<AuditFichiers, AuditFichiers>chunk(1000)//
				.reader(auditFicReader(null)).writer(auditFicWriter()).build();
	}

	@StepScope
	@Bean("auditFichierReader")
	public RepositoryItemReader<AuditFichiers> auditFicReader(@Value("#{jobParameters['date']}") java.util.Date date) {
		RepositoryItemReader<AuditFichiers> reader = new RepositoryItemReader<>();
		reader.setPageSize(1000);
		reader.setRepository(auditFichierRepository);
		reader.setSaveState(true);
		reader.setMethodName("findAuditFicByDate");
		List<java.util.Date> list = new ArrayList<>();
		list.add(date);
		reader.setArguments(list);
		HashMap<String, Direction> sorts = new HashMap<>();
		sorts.put("id", Direction.DESC);
		reader.setSort(sorts);
		return reader;

	}

	@StepScope
	@Bean("auditFichierWriter")
	public AuditFichierWriter auditFicWriter() {
		AuditFichierWriter itemWriter = new AuditFichierWriter();
		itemWriter.setRepository(auditFichierHRepository);
		itemWriter.setMethodName("save");
		return itemWriter;

	}

}

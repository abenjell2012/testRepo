

import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.transaction.ChainedTransactionManager;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;

import com.zaxxer.hikari.HikariDataSource;

@Configuration
@PropertySource({ "classpath:config/application.yml" })
@EnableJpaRepositories(basePackages = "fr.bpce.yyd.service.histo.repository.histo", entityManagerFactoryRef = "histoEntityManager", transactionManagerRef = "histoTransactionManager")
public class PersistenceDbSecondaryConfiguration {

	@Bean("histoEntityManager")
	public LocalContainerEntityManagerFactoryBean histoEntityManager(EntityManagerFactoryBuilder builder,
			@Qualifier("hibernateProperties") Map<String, String> maps) {
		return builder.dataSource(histoDataSource()).packages("fr.bpce.yyd.commun.model").properties(maps).build();
	}

	@Bean
	@ConfigurationProperties("spring.histo-datasource")
	public DataSourceProperties histoDataSourceProperties() {
		return new DataSourceProperties();
	}

	@Bean
	@ConfigurationProperties("spring.histo-datasource.configuration")
	public DataSource histoDataSource() {
		return histoDataSourceProperties().initializeDataSourceBuilder().type(HikariDataSource.class).build();
	}

	@Bean
	public PlatformTransactionManager histoTransactionManager(
			@Qualifier("histoEntityManager") LocalContainerEntityManagerFactoryBean histoEntityManager) {
		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(histoEntityManager.getObject());
		return transactionManager;
	}

	@Bean(name = "chainedJpaTransactionManager")
	public ChainedTransactionManager transactionManager(
			@Qualifier("histoTransactionManager") final PlatformTransactionManager histoTransactionManager,
			@Qualifier("primTransactionManager") final PlatformTransactionManager primTransactionManager) {
		return new ChainedTransactionManager(primTransactionManager, histoTransactionManager);
	}

}

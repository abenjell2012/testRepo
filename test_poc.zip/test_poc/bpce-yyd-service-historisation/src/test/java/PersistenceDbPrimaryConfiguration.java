

import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.zaxxer.hikari.HikariDataSource;

@Configuration
@PropertySource({ "classpath:config/application.yml" })
@EnableTransactionManagement
@EnableJpaRepositories(basePackages = "fr.bpce.yyd.service.histo.repository.prim", entityManagerFactoryRef = "primEntityManager", transactionManagerRef = "primTransactionManager")
public class PersistenceDbPrimaryConfiguration {

	@Primary
	@Bean("primEntityManager")
	public LocalContainerEntityManagerFactoryBean primEntityManager(EntityManagerFactoryBuilder builder) {
		return builder.dataSource(primDataSource()).packages("fr.bpce.yyd.commun.model")
				.properties(hibernateProperties()).build();
	}

	@Bean("hibernateProperties")
	@ConfigurationProperties("spring.jpa.properties")
	public Map<String, String> hibernateProperties() {
		return new HashMap<>();
	}

	@Bean
	@Primary
	@ConfigurationProperties("spring.datasource")
	public DataSourceProperties primaryDataSourceProperties() {
		return new DataSourceProperties();
	}

	@Bean
	@Primary
	@ConfigurationProperties("spring.datasource.configuration")
	public DataSource primDataSource() {
		return primaryDataSourceProperties().initializeDataSourceBuilder().type(HikariDataSource.class).build();
	}

	@Primary
	@Bean
	public PlatformTransactionManager primTransactionManager(
			@Qualifier("primEntityManager") LocalContainerEntityManagerFactoryBean primEntityManager) {
		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(primEntityManager.getObject());
		return transactionManager;
	}

}

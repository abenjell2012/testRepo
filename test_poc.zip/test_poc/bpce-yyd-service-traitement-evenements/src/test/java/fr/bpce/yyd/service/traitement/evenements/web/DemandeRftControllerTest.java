package fr.bpce.yyd.service.traitement.evenements.web;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.net.URI;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import fr.bpce.yyd.commun.model.TiersRFT;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.Statut;
import fr.bpce.yyd.service.commun.yyc.model.DemandeLotTiersRft;
import fr.bpce.yyd.service.commun.yyc.model.DemandeTiersRFT;
import fr.bpce.yyd.service.commun.yyc.model.ReponseLotTiersRft;
import fr.bpce.yyd.service.traitement.evenements.repositories.TiersRftRepository;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class DemandeRftControllerTest {

	private static final ObjectMapper om = new ObjectMapper();

	@LocalServerPort
	int serverPort;

	@Autowired
	private TestRestTemplate restTemplate;

	@Autowired
	private TiersRftRepository tiersRftRepo;
	private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");

	@Value("${api.security.username}")
	private String login;

	@Value("${api.security.password}")
	private String motDePass;


	@Before
	public void init() {
		TiersRFT tiersRft1 = new TiersRFT("40978", "1235567", "0000002827", "016150419",
		        LocalDate.parse("20190512", formatter));
		tiersRftRepo.save(tiersRft1);
		TiersRFT tiersRft2 = new TiersRFT("15007", "016150419", "0000002827", "016150419",
		        LocalDate.parse("20190512", formatter));
		tiersRftRepo.save(tiersRft2);
		TiersRFT tiersRft3 = new TiersRFT("30007", "0108149", "0000002841", "016650996",
		        LocalDate.parse("20190512", formatter));
		tiersRftRepo.save(tiersRft3);
		TiersRFT tiersRft4 = new TiersRFT("10107", "50118233", "0000002868", "024050676",
		        LocalDate.parse("20190512", formatter));
		tiersRftRepo.save(tiersRft4);
		TiersRFT tiersRft5 = new TiersRFT("30007", "0108149", "0000002841", "016650999",
		        LocalDate.parse("20190619", formatter));
		tiersRftRepo.save(tiersRft5);
		TiersRFT tiersRft6 = new TiersRFT("10107", "50118233", "0000002868", "024050676",
		        LocalDate.parse("20190620", formatter));
		tiersRftRepo.save(tiersRft6);

	}

	@Test
	public void find_login_ok() throws Exception {
	    String baseUrl = "http://localhost:" + serverPort + "/api/v1/tiersRft";

		URI uri = new URI(baseUrl);

		DemandeLotTiersRft tiersReq = new DemandeLotTiersRft(LocalDate.parse("20190518", formatter));
		tiersReq.getTiers().add(new DemandeTiersRFT("40978", "1235567"));
		tiersReq.getTiers().add(new DemandeTiersRFT("30007", "0108149"));
	    printJSON(tiersReq);


		ResponseEntity<ReponseLotTiersRft> response = restTemplate.withBasicAuth(login, motDePass).postForEntity(uri,
		        tiersReq, ReponseLotTiersRft.class);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		ReponseLotTiersRft body = response.getBody();
		assertNotNull(body);
		assertEquals(LocalDate.parse("20190518", formatter), body.getDateAppel());
		assertEquals(LocalDate.parse("20190512", formatter), body.getDateArreteMensuelle());
		assertEquals(2, body.getTiers().size());
		printJSON(response);
	}

	@Test
    public void find_login_ok_strange_case() throws Exception {
        String baseUrl = "http://localhost:" + serverPort + "/api/v1/tiersRft";

        URI uri = new URI(baseUrl);

        DemandeLotTiersRft tiersReq = new DemandeLotTiersRft(LocalDate.parse("20190621", formatter));
        tiersReq.getTiers().add(new DemandeTiersRFT("40978", "1235567"));
        tiersReq.getTiers().add(new DemandeTiersRFT("30007", "0108149"));
        tiersReq.getTiers().add(new DemandeTiersRFT("10107", "50118233"));


        ResponseEntity<ReponseLotTiersRft> response = restTemplate.withBasicAuth(login, motDePass).postForEntity(uri,
                tiersReq, ReponseLotTiersRft.class);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        ReponseLotTiersRft body = response.getBody();
        printJSON(response);

        assertNotNull(body);
        assertEquals(LocalDate.parse("20190621", formatter), body.getDateAppel());
        assertEquals(LocalDate.parse("20190620", formatter), body.getDateArreteMensuelle());
        assertEquals(3, body.getTiers().size());

        assertEquals(Statut.NON_TROUVE, body.getTiers().get(0).getStatut());
        assertEquals(Statut.NON_TROUVE, body.getTiers().get(1).getStatut());

        assertNull(body.getTiers().get(0).getIdRFT());
        assertNull(body.getTiers().get(1).getIdRFT());




    }

	@Test
    public void find_login_wrongPassword() throws Exception {
        String baseUrl = "http://localhost:" + serverPort + "/api/v1/tiersRft";

        URI uri = new URI(baseUrl);

        DemandeLotTiersRft tiersReq = new DemandeLotTiersRft(LocalDate.parse("20190512", formatter));
        tiersReq.getTiers().add(new DemandeTiersRFT("40978", "1235567"));
        tiersReq.getTiers().add(new DemandeTiersRFT("30007", "0108149"));

        ResponseEntity<ReponseLotTiersRft> response = restTemplate.withBasicAuth(login, "toto").postForEntity(uri,
                tiersReq, ReponseLotTiersRft.class);
        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());

    }

	@Test
	public void find_nologin_401() throws Exception {
	    String baseUrl = "http://localhost:" + serverPort + "/api/v1/tiersRft";

        URI uri = new URI(baseUrl);

		DemandeLotTiersRft tiersReq = new DemandeLotTiersRft(LocalDate.parse("20190512", formatter));
		tiersReq.getTiers().add(new DemandeTiersRFT("40978", "1235567"));
		tiersReq.getTiers().add(new DemandeTiersRFT("30007", "0108149"));

		ResponseEntity<ReponseLotTiersRft> response = restTemplate.postForEntity(uri, tiersReq,
		        ReponseLotTiersRft.class);

		assertEquals(MediaType.APPLICATION_JSON_UTF8, response.getHeaders().getContentType());
		assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());

	}

	private static void printJSON(Object object) {
		String result;
		try {
			result = om.writerWithDefaultPrettyPrinter().writeValueAsString(object);
			System.out.println(result);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
	}

}

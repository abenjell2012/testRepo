package fr.bpce.yyd.service.traitement.evenements.service.impl;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import fr.bpce.yyd.commun.constantes.Constant;
import fr.bpce.yyd.commun.enums.StatutAuditEvenement;
import fr.bpce.yyd.commun.enums.StatutEvenement;
import fr.bpce.yyd.commun.enums.StatutTiers;
import fr.bpce.yyd.commun.messages.dto.LotIdTiersDTO;
import fr.bpce.yyd.commun.model.AuditCalcul;
import fr.bpce.yyd.commun.model.AuditFichiers;
import fr.bpce.yyd.commun.model.ComplementEvenement;
import fr.bpce.yyd.commun.model.Evenement;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.MotifStatutTiers;
import fr.bpce.yyd.commun.model.PeriodeProbatoire;
import fr.bpce.yyd.commun.model.StatutHistorise;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.commun.model.reference.RefCliSeg;
import fr.bpce.yyd.commun.model.reference.RefCliSsClass;
import fr.bpce.yyd.commun.model.reference.RefImpactEvtMdc;
import fr.bpce.yyd.commun.repository.RefCliSsClassRepository;
import fr.bpce.yyd.commun.service.impl.RefCliSegServiceImpl;
import fr.bpce.yyd.service.commun.repository.AuditCalculRepository;
import fr.bpce.yyd.service.commun.repository.EvenementCalculeRepository;
import fr.bpce.yyd.service.commun.repository.EvenementImpactRepository;
import fr.bpce.yyd.service.commun.repository.EvenementRecuRepository;
import fr.bpce.yyd.service.commun.repository.IdentiteTiersRepository;
import fr.bpce.yyd.service.commun.repository.ParMdcBqSegRepository;
import fr.bpce.yyd.service.commun.repository.ParMdcSegRepository;
import fr.bpce.yyd.service.commun.repository.StatutTiersRepository;
import fr.bpce.yyd.service.commun.repository.TiersRepository;
import fr.bpce.yyd.service.commun.service.impl.AuditCalculServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.DefautServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.EvenementCalculeServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.EvenementImpactServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.EvenementRecuServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.IdentiteTiersServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.ParamMdcServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.ParametresNDoDImpl;
import fr.bpce.yyd.service.commun.service.impl.RechercheTiersServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.StatutTiersServiceImpl;
import fr.bpce.yyd.service.traitement.evenements.kafka.service.KafkaDemandeEncours;
import fr.bpce.yyd.service.traitement.evenements.repositories.ElementsDeCalculRepository;
import fr.bpce.yyd.service.traitement.evenements.repositories.EncoursTiersRepository;
import fr.bpce.yyd.service.traitement.evenements.repositories.NotificationEncoursRepository;
import fr.bpce.yyd.service.traitement.evenements.repositories.SuiviDemandeEncoursRepository;
import fr.bpce.yyd.service.traitement.evenements.repositories.SuiviEncoursTiersRepository;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
@ActiveProfiles(profiles = "ti")
public class ImpactDefautTest {

//  @TestConfiguration
//  public static class ConfigurationPourTest {
//
//      @SuppressWarnings("unchecked")
//      @Bean
//      public KafkaTemplate<String, DemandeEncours> demandeEncoursTemplate() {
//          return Mockito.mock(KafkaTemplate.class);
//      }
//      @Bean
//      public KafkaDemandeEncours producerDemandeEncours() {
//      return Mockito.mock(KafkaDemandeEncours.class);
//          }
//
//
//
//  }
	@Autowired
	private TestEntityManager entityManager;

	@Autowired
	private EvenementCalculeRepository evtCalcRepository;

	@Autowired
	private ElementsDeCalculRepository elemCalcRepository;

	@Autowired
	private EvenementRecuRepository evtRecuRepository;

	@Autowired
	private IdentiteTiersRepository identTiersRepository;

	@Autowired
	private StatutTiersRepository statutTiersRepository;

	@Autowired
	private TiersRepository tiersRepository;

	@Autowired
	private AuditCalculRepository auditCalculRepository;

	@Autowired
	private ParMdcSegRepository parMdcSegRepository;

	@Autowired
	private ParMdcBqSegRepository parMdcBqSegRepository;

	@Autowired
	private EvenementImpactRepository impactRepository;

	@Autowired
	private RefCliSsClassRepository cliSsClassRepository;

	private CalculServiceImpl calculService;

	private EvenementCalculeServiceImpl evtCalculService;

	private DefautServiceImpl defautService;

	private EvenementRecuServiceImpl evtRecuService;

	@Autowired
	private NotificationEncoursRepository repNotificationEncours;

	@Autowired
	private SuiviDemandeEncoursRepository repSuiviDemandeEncours;

	@Autowired
	private KafkaDemandeEncours producerDemandeEncours;

	@Autowired
	SuiviEncoursTiersRepository repSuiviEncoursTiers;

	@Autowired
	private EncoursTiersRepository repEncoursTiers;

	@Before
	public void assembleCalculService() {
		MockitoAnnotations.initMocks(this); // This is a key

		CalculServiceImpl csi = new CalculServiceImpl();

		ParamMdcServiceImpl paramService = new ParamMdcServiceImpl();
		paramService.setParMdcBqSegRepository(parMdcBqSegRepository);
		paramService.setParMdcSegRepository(parMdcSegRepository);
		ParametresNDoDImpl parametresNDoD = new ParametresNDoDImpl();
		parametresNDoD.setParamService(paramService);
		csi.setParametresNDoD(parametresNDoD);

		IdentiteTiersServiceImpl identTiersService = new IdentiteTiersServiceImpl();
		identTiersService.setIdentTiersRepository(identTiersRepository);

		csi.setIdentiteTiersService(identTiersService);

		AuditCalculServiceImpl acService = new AuditCalculServiceImpl();
		acService.setAuditCalculRepository(auditCalculRepository);

		evtCalculService = new EvenementCalculeServiceImpl();
		evtCalculService.setEvtCalculeRepository(evtCalcRepository);
		evtCalculService.setIdentiteTiersService(identTiersService);
		evtCalculService.setAuditCalculService(acService);
		evtCalculService.setParamsNDoD(parametresNDoD);
		csi.setEvtCalculeService(evtCalculService);
		EncoursServiceImpl encoursService = new EncoursServiceImpl();
		encoursService.setRepNotificationEncours(repNotificationEncours);
		encoursService.setRepSuiviDemandeEncours(repSuiviDemandeEncours);
		encoursService.setProducerDemandeEncours(producerDemandeEncours);

		StatutTiersServiceImpl statutTiersService = new StatutTiersServiceImpl();
		statutTiersService.setStatutTiersRepository(statutTiersRepository);

		EvenementImpactServiceImpl impactService = new EvenementImpactServiceImpl();
		impactService.setEvenementImpactRepository(impactRepository);

		RefCliSegServiceImpl cliSegService = new RefCliSegServiceImpl();
		cliSegService.setCliSsClassRepository(cliSsClassRepository);

		evtRecuService = new EvenementRecuServiceImpl();
		evtRecuService.setEvtRecuRepository(evtRecuRepository);
		evtRecuService.setImpactService(impactService);
		evtRecuService.setCliSegService(cliSegService);
		csi.setEvtRecuService(evtRecuService);
		csi.setServiceEncours(encoursService);
		csi.setElemCalcRepository(elemCalcRepository);
		csi.setRepEncoursTiers(repEncoursTiers);

		RechercheTiersServiceImpl rechTiersService = new RechercheTiersServiceImpl();
		rechTiersService.setTiersRepository(tiersRepository);

		defautService = new DefautServiceImpl();
		defautService.setEvtCalculeService(evtCalculService);
		defautService.setStatutTiersRepository(statutTiersRepository);
		defautService.setRechercheTiersService(rechTiersService);
		defautService.setIdentiteTiersService(identTiersService);
		defautService.setImpactService(impactService);
		defautService.setRefCliSegService(cliSegService);

		csi.setDefautService(defautService);
		csi.setAuditCalculService(acService);
		calculService = csi;
	}

	@Test
	public void impactDefautPCO() {

		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);
		Tiers tiers = new Tiers();
		IdentiteTiers id = new IdentiteTiers();
		id.setIdLocal("abcdefg");
		id.setCodeBanque("10107"); // Par exemple
		id.setCodeSegment("3200");
		id.setDateDebut(LocalDate.now().minusDays(5));
		tiers.addIdentite(id);
		tiers = entityManager.persistAndFlush(tiers);
		Evenement evtPco = new Evenement();
		evtPco.setCode("PCO");
		evtPco.setDateDebut(LocalDate.now());
		evtPco.setIdentiteInitiale(id);

		ComplementEvenement cePco = new ComplementEvenement();
		cePco.setDateMaj(evtPco.getDateDebut());
		cePco.setMontantArriere(BigDecimal.ZERO);
		cePco.setStatutEvt(StatutEvenement.ACT);
		cePco.setArriereLitige(false);
		cePco.setArriereTech(false);
		cePco.setAuditFichier(fic);
		cePco.setIdentiteInitiale(id);
		evtPco.addComplement(cePco);

		entityManager.persist(evtPco);

		// REF IMPACT EVT MDC
		RefImpactEvtMdc refImpact = new RefImpactEvtMdc();
		refImpact.setCodEvt("PCO");
		refImpact.setCategorieSegment(Constant.TOUS_AUTRES);
		refImpact.setImpact("D");
		refImpact.setGraviteImpact("CX");
		refImpact.setDateDebut(LocalDate.now().minusDays(100));
		entityManager.persist(refImpact);

		// REF_CLI_SEG
		RefCliSeg refCliSeg = new RefCliSeg();
		refCliSeg.setCodSegCli("3200");
		refCliSeg.setLibSegCli("PARTICULIERS");
		refCliSeg.setCodSsClassCli("RETPAR");
		refCliSeg.setTopSuppr("N");
		entityManager.persist(refCliSeg);

		// REF_CLI_SS_CLASS
		RefCliSsClass refClassSsClass = new RefCliSsClass();
		refClassSsClass.setCodSsClassCli("RETPAR");
		refClassSsClass.setLibSsClassCli("PARTICULIERS");
		refClassSsClass.setCodClassCli("RET");
		refClassSsClass.setTopSuppr("N");
		refClassSsClass.setCodTypNot("PART");
		entityManager.persist(refClassSsClass);

		entityManager.flush();

		LotIdTiersDTO lot = new LotIdTiersDTO();
		lot.addIdTiers(tiers.getId());

		// Act
		calculService.traiteMessage(lot);

		// Assert
		StatutHistorise statut = statutTiersRepository.getStatutADate(tiers.getId(), LocalDate.now()).get(0);
		Assert.assertEquals(StatutTiers.DEFAUT, statut.getStatut());
		Assert.assertEquals("PCO", statut.getMotif().getMotif());
		Assert.assertEquals("CX", statut.getGravite());
		Assert.assertEquals(LocalDate.now(), statut.getDateDebut());
	}

	@Test
	public void impactDefautDM() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);

		Tiers tiers = new Tiers();
		IdentiteTiers id = new IdentiteTiers();
		id.setCodeBanque("10107"); // Par exemple
		id.setIdLocal("abcdefg");
		id.setCodeSegment("3200");
		id.setDateDebut(LocalDate.now().minusDays(5));
		tiers.addIdentite(id);
		tiers = entityManager.persistAndFlush(tiers);

		Evenement evtPco = new Evenement();
		evtPco.setCode("PCO");
		evtPco.setDateDebut(LocalDate.now());
		evtPco.setIdentiteInitiale(id);

		ComplementEvenement cePco = new ComplementEvenement();
		cePco.setDateMaj(evtPco.getDateDebut());
		cePco.setMontantArriere(BigDecimal.ZERO);
		cePco.setStatutEvt(StatutEvenement.ACT);
		cePco.setArriereLitige(false);
		cePco.setArriereTech(false);
		cePco.setAuditFichier(fic);
		cePco.setIdentiteInitiale(id);
		evtPco.addComplement(cePco);

		entityManager.persist(evtPco);

		// REF IMPACT EVT MDC
		RefImpactEvtMdc refImpact = new RefImpactEvtMdc();
		refImpact.setCodEvt("PCO");
		refImpact.setCategorieSegment(Constant.TOUS_AUTRES);
		refImpact.setImpact("D");
		refImpact.setGraviteImpact("CX");
		refImpact.setDateDebut(LocalDate.now().minusDays(100));
		entityManager.persist(refImpact);

		// REF_CLI_SEG
		RefCliSeg refCliSeg = new RefCliSeg();
		refCliSeg.setCodSegCli("3200");
		refCliSeg.setLibSegCli("PARTICULIERS");
		refCliSeg.setCodSsClassCli("RETPAR");
		refCliSeg.setTopSuppr("N");
		entityManager.persist(refCliSeg);

		// REF_CLI_SS_CLASS
		RefCliSsClass refClassSsClass = new RefCliSsClass();
		refClassSsClass.setCodSsClassCli("RETPAR");
		refClassSsClass.setLibSsClassCli("PARTICULIERS");
		refClassSsClass.setCodClassCli("RET");
		refClassSsClass.setTopSuppr("N");
		refClassSsClass.setCodTypNot("PART");
		entityManager.persist(refClassSsClass);

		entityManager.flush();

		LotIdTiersDTO lot = new LotIdTiersDTO();
		lot.addIdTiers(tiers.getId());

		// Act
		calculService.traiteMessage(lot);

		// Assert
		StatutHistorise statut = statutTiersRepository.getStatutADate(tiers.getId(), LocalDate.now()).get(0);
		Assert.assertEquals(StatutTiers.DEFAUT, statut.getStatut());
		Assert.assertEquals("PCO", statut.getMotif().getMotif());
		Assert.assertEquals("CX", statut.getGravite());
		Assert.assertEquals(LocalDate.now(), statut.getDateDebut());
	}

	@Test
	public void impactEvtNotDefaut() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);

		Tiers tiers = new Tiers();
		IdentiteTiers id = new IdentiteTiers();
		id.setCodeBanque("10107"); // Par exemple
		id.setCodeSegment("3200");
		id.setDateDebut(LocalDate.now().minusDays(5));
		tiers.addIdentite(id);
		tiers = entityManager.persistAndFlush(tiers);

		Evenement evtDax = new Evenement();
		evtDax.setCode("DM");
		evtDax.setDateDebut(LocalDate.now());
		evtDax.setIdentiteInitiale(id);

		ComplementEvenement ceDax = new ComplementEvenement();
		ceDax.setDateMaj(evtDax.getDateDebut());
		ceDax.setMontantArriere(BigDecimal.ZERO);
		ceDax.setStatutEvt(StatutEvenement.ACT);
		ceDax.setArriereLitige(false);
		ceDax.setArriereTech(false);
		ceDax.setAuditFichier(fic);
		ceDax.setIdentiteInitiale(id);
		evtDax.addComplement(ceDax);

		entityManager.persist(evtDax);

		// REF_CLI_SEG
		RefCliSeg refCliSeg = new RefCliSeg();
		refCliSeg.setCodSegCli("3200");
		refCliSeg.setLibSegCli("PARTICULIERS");
		refCliSeg.setCodSsClassCli("RETPAR");
		refCliSeg.setTopSuppr("N");
		entityManager.persist(refCliSeg);

		// REF_CLI_SS_CLASS
		RefCliSsClass refClassSsClass = new RefCliSsClass();
		refClassSsClass.setCodSsClassCli("RETPAR");
		refClassSsClass.setLibSsClassCli("PARTICULIERS");
		refClassSsClass.setCodClassCli("RET");
		refClassSsClass.setTopSuppr("N");
		refClassSsClass.setCodTypNot("PART");
		entityManager.persist(refClassSsClass);

		entityManager.flush();

		LotIdTiersDTO lot = new LotIdTiersDTO();
		lot.addIdTiers(tiers.getId());

		// Act
		calculService.traiteMessage(lot);

		// Assert
		StatutHistorise statut = statutTiersRepository.getStatutADate(tiers.getId(), LocalDate.now()).get(0);
		Assert.assertEquals(StatutTiers.SAIN, statut.getStatut());
		Assert.assertNull(statut.getMotif());
		Assert.assertNull(statut.getGravite());
		Assert.assertEquals(LocalDate.now(), statut.getDateDebut());
	}

	@Test
	public void traiteUTPEnPresencePP() {

		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);
		Tiers tiers = new Tiers();

		IdentiteTiers id = new IdentiteTiers();
		id.setIdLocal("abcdefg");
		id.setCodeBanque("10107"); // Par exemple
		id.setCodeSegment("3200");
		id.setDateDebut(LocalDate.now().minusDays(5));
		tiers.addIdentite(id);
		tiers = entityManager.persistAndFlush(tiers);

		Evenement evtPco = new Evenement();
		evtPco.setCode("PCO");
		evtPco.setDateDebut(LocalDate.now());
		evtPco.setIdentiteInitiale(id);

		ComplementEvenement cePco = new ComplementEvenement();
		cePco.setDateMaj(evtPco.getDateDebut());
		cePco.setDatePhoto(evtPco.getDateDebut());
		cePco.setMontantArriere(BigDecimal.ZERO);
		cePco.setStatutEvt(StatutEvenement.ACT);
		cePco.setArriereLitige(false);
		cePco.setArriereTech(false);
		cePco.setAuditFichier(fic);
		cePco.setIdentiteInitiale(id);
		evtPco.addComplement(cePco);
		entityManager.persist(evtPco);

		// REF IMPACT EVT MDC
		RefImpactEvtMdc refImpact = new RefImpactEvtMdc();
		refImpact.setCodEvt("PCO");
		refImpact.setCategorieSegment(Constant.TOUS_AUTRES);
		refImpact.setImpact("D");
		refImpact.setGraviteImpact("CX");
		refImpact.setDateDebut(LocalDate.now().minusDays(100));
		entityManager.persist(refImpact);

		// REF_CLI_SEG
		RefCliSeg refCliSeg = new RefCliSeg();
		refCliSeg.setCodSegCli("3200");
		refCliSeg.setLibSegCli("PARTICULIERS");
		refCliSeg.setCodSsClassCli("RETPAR");
		refCliSeg.setTopSuppr("N");
		entityManager.persist(refCliSeg);

		// REF_CLI_SS_CLASS
		RefCliSsClass refClassSsClass = new RefCliSsClass();
		refClassSsClass.setCodSsClassCli("RETPAR");
		refClassSsClass.setLibSsClassCli("PARTICULIERS");
		refClassSsClass.setCodClassCli("RET");
		refClassSsClass.setTopSuppr("N");
		refClassSsClass.setCodTypNot("PART");
		entityManager.persist(refClassSsClass);

		PeriodeProbatoire pp = new PeriodeProbatoire();
		pp.setTiers(tiers);
		pp.setDateDebut(LocalDate.now().minusDays(10));
		entityManager.persist(pp);

		AuditCalcul ac = new AuditCalcul();
		ac.setCode("PP");
		ac.setDateEffet(LocalDate.now().minusDays(10));
		ac.setEvenementCalcule(pp);
		ac.setIdTiers(tiers.getId());
		ac.setStatut(StatutAuditEvenement.ACT);
		entityManager.persist(ac);

		StatutHistorise statutPP = new StatutHistorise();
		statutPP.setDateDeb(LocalDate.now().minusDays(10));
		statutPP.setMotif(new MotifStatutTiers(pp));
		statutPP.setStatut(StatutTiers.DEFAUT);
		statutPP.setTiers(tiers);
		entityManager.persist(statutPP);

		entityManager.flush();

		LotIdTiersDTO lot = new LotIdTiersDTO();
		lot.addIdTiers(tiers.getId());

		// Act
		calculService.traiteMessage(lot);

		// Assert
		StatutHistorise statut = statutTiersRepository.getStatutADate(tiers.getId(), LocalDate.now()).get(0);
		Assert.assertEquals(StatutTiers.DEFAUT, statut.getStatut());
		Assert.assertEquals("PCO", statut.getMotif().getMotif());
		Assert.assertEquals("CX", statut.getGravite());
		Assert.assertEquals(LocalDate.now(), statut.getDateDebut());

		StatutHistorise statutPeriodeProbatoire = statutTiersRepository.findById(statutPP.getId()).get();
		PeriodeProbatoire p = statutPeriodeProbatoire.getMotif().getPeriodeProbatoire();
		Assert.assertEquals(LocalDate.now(), p.getDateFin());
		List<AuditCalcul> a = (List<AuditCalcul>) auditCalculRepository.findAll();
		Assert.assertEquals(2, a.size());
	}

	@Test
	public void impactSainPuisPcoPuisPsuAnterieurSain() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);
		Tiers tiers = new Tiers();
		IdentiteTiers id = new IdentiteTiers();
		id.setIdLocal("abcdefg");
		id.setCodeBanque("10107"); // Par exemple
		id.setCodeSegment("3200");
		id.setDateDebut(LocalDate.now().minusDays(5));
		tiers.addIdentite(id);
		tiers = entityManager.persistAndFlush(tiers);

		LotIdTiersDTO lot = new LotIdTiersDTO(LocalDate.now().minusDays(5));
		lot.addIdTiers(tiers.getId());

		// Act
		calculService.traiteMessage(lot);

		// Arrange 2
		AuditFichiers fic2 = new AuditFichiers();
		fic2 = entityManager.persistAndFlush(fic2);
		Evenement evtPco = new Evenement();
		evtPco.setCode("PCO");
		evtPco.setDateDebut(LocalDate.now().plusDays(10));
		evtPco.setIdentiteInitiale(id);

		ComplementEvenement cePco = new ComplementEvenement();
		cePco.setDateMaj(evtPco.getDateDebut());
		cePco.setMontantArriere(BigDecimal.ZERO);
		cePco.setStatutEvt(StatutEvenement.ACT);
		cePco.setArriereLitige(false);
		cePco.setArriereTech(false);
		cePco.setAuditFichier(fic2);
		cePco.setIdentiteInitiale(id);
		evtPco.addComplement(cePco);
		entityManager.persist(evtPco);

		// REF IMPACT EVT MDC
		RefImpactEvtMdc refImpact = new RefImpactEvtMdc();
		refImpact.setCodEvt("PCO");
		refImpact.setCategorieSegment(Constant.TOUS_AUTRES);
		refImpact.setImpact("D");
		refImpact.setGraviteImpact("CX");
		refImpact.setDateDebut(LocalDate.now().minusDays(100));
		entityManager.persist(refImpact);

		// REF_CLI_SEG
		RefCliSeg refCliSeg = new RefCliSeg();
		refCliSeg.setCodSegCli("3200");
		refCliSeg.setLibSegCli("PARTICULIERS");
		refCliSeg.setCodSsClassCli("RETPAR");
		refCliSeg.setTopSuppr("N");
		entityManager.persist(refCliSeg);

		// REF_CLI_SS_CLASS
		RefCliSsClass refClassSsClass = new RefCliSsClass();
		refClassSsClass.setCodSsClassCli("RETPAR");
		refClassSsClass.setLibSsClassCli("PARTICULIERS");
		refClassSsClass.setCodClassCli("RET");
		refClassSsClass.setTopSuppr("N");
		refClassSsClass.setCodTypNot("PART");
		entityManager.persist(refClassSsClass);

		// REF IMPACT EVT MDC PSU
		RefImpactEvtMdc refImpact2 = new RefImpactEvtMdc();
		refImpact2.setCodEvt("PSU");
		refImpact2.setCategorieSegment(Constant.TOUS_AUTRES);
		refImpact2.setImpact("D");
		refImpact2.setGraviteImpact("CX");
		refImpact2.setDateDebut(LocalDate.now().minusDays(100));
		entityManager.persist(refImpact2);
		entityManager.flush();

		lot.setDateCalcul(LocalDate.now().plusDays(10));

		// Act 2
		calculService.traiteMessage(lot);

		// Arrange 3
		AuditFichiers fic3 = new AuditFichiers();
		fic3 = entityManager.persistAndFlush(fic3);
		Evenement evtPsu = new Evenement();
		evtPsu.setCode("PSU");
		evtPsu.setDateDebut(LocalDate.now().minusDays(50));
		evtPsu.setIdentiteInitiale(id);

		ComplementEvenement cePsu = new ComplementEvenement();
		cePsu.setDateMaj(evtPsu.getDateDebut());
		cePsu.setMontantArriere(BigDecimal.ZERO);
		cePsu.setStatutEvt(StatutEvenement.ACT);
		cePsu.setArriereLitige(false);
		cePsu.setArriereTech(false);
		cePsu.setAuditFichier(fic3);
		cePsu.setIdentiteInitiale(id);
		evtPsu.addComplement(cePsu);
		entityManager.persist(evtPsu);

		lot.setDateCalcul(LocalDate.now().plusDays(20));

		// Act 3
		calculService.traiteMessage(lot);

		// Assert
		List<StatutHistorise> statuts = statutTiersRepository.findAll();
		Assert.assertEquals(3, statuts.size());
		for (StatutHistorise statut : statuts) {
			if (StatutTiers.SAIN.equals(statut.getStatut())) {
				Assert.assertEquals(LocalDate.now().minusDays(5), statut.getDateDebut());
				Assert.assertEquals(LocalDate.now().plusDays(10), statut.getDateFin());
				Assert.assertTrue(statut.getAnnule());
			} else if ("PCO".equals(statut.getMotif().getMotif())) {
				Assert.assertEquals(LocalDate.now().plusDays(10), statut.getDateDebut());
				Assert.assertNull(statut.getDateFin());
			} else if ("PSU".equals(statut.getMotif().getMotif())) {
				Assert.assertEquals(LocalDate.now().minusDays(50), statut.getDateDebut());
				Assert.assertNull(statut.getDateFin());
			}
		}
	}

	@Test
	public void impactSainPuisPcoPuisPsuPendantSain() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);
		Tiers tiers = new Tiers();
		IdentiteTiers id = new IdentiteTiers();
		id.setIdLocal("abcdefg");
		id.setCodeBanque("10107"); // Par exemple
		id.setCodeSegment("3200");
		id.setDateDebut(LocalDate.now().minusDays(5));
		tiers.addIdentite(id);
		tiers = entityManager.persistAndFlush(tiers);

		LotIdTiersDTO lot = new LotIdTiersDTO(LocalDate.now().minusDays(5));
		lot.addIdTiers(tiers.getId());

		// Act
		calculService.traiteMessage(lot);

		// Arrange 2
		AuditFichiers fic2 = new AuditFichiers();
		fic2 = entityManager.persistAndFlush(fic2);
		Evenement evtPco = new Evenement();
		evtPco.setCode("PCO");
		evtPco.setDateDebut(LocalDate.now().plusDays(10));
		evtPco.setIdentiteInitiale(id);

		ComplementEvenement cePco = new ComplementEvenement();
		cePco.setDateMaj(evtPco.getDateDebut());
		cePco.setMontantArriere(BigDecimal.ZERO);
		cePco.setStatutEvt(StatutEvenement.ACT);
		cePco.setArriereLitige(false);
		cePco.setArriereTech(false);
		cePco.setAuditFichier(fic2);
		cePco.setIdentiteInitiale(id);
		evtPco.addComplement(cePco);

		entityManager.persist(evtPco);

		// REF IMPACT EVT MDC
		RefImpactEvtMdc refImpact = new RefImpactEvtMdc();
		refImpact.setCodEvt("PCO");
		refImpact.setCategorieSegment(Constant.TOUS_AUTRES);
		refImpact.setImpact("D");
		refImpact.setGraviteImpact("CX");
		refImpact.setDateDebut(LocalDate.now().minusDays(100));
		entityManager.persist(refImpact);

		// REF_CLI_SEG
		RefCliSeg refCliSeg = new RefCliSeg();
		refCliSeg.setCodSegCli("3200");
		refCliSeg.setLibSegCli("PARTICULIERS");
		refCliSeg.setCodSsClassCli("RETPAR");
		refCliSeg.setTopSuppr("N");
		entityManager.persist(refCliSeg);

		// REF_CLI_SS_CLASS
		RefCliSsClass refClassSsClass = new RefCliSsClass();
		refClassSsClass.setCodSsClassCli("RETPAR");
		refClassSsClass.setLibSsClassCli("PARTICULIERS");
		refClassSsClass.setCodClassCli("RET");
		refClassSsClass.setTopSuppr("N");
		refClassSsClass.setCodTypNot("PART");
		entityManager.persist(refClassSsClass);

		// REF IMPACT EVT MDC PSU
		RefImpactEvtMdc refImpact2 = new RefImpactEvtMdc();
		refImpact2.setCodEvt("PSU");
		refImpact2.setCategorieSegment(Constant.TOUS_AUTRES);
		refImpact2.setImpact("D");
		refImpact2.setGraviteImpact("CX");
		refImpact2.setDateDebut(LocalDate.now().minusDays(100));
		entityManager.persist(refImpact2);
		entityManager.flush();

		lot.setDateCalcul(LocalDate.now().plusDays(10));

		// Act 2
		calculService.traiteMessage(lot);

		// Arrange 3
		AuditFichiers fic3 = new AuditFichiers();
		fic3 = entityManager.persistAndFlush(fic3);
		Evenement evtPsu = new Evenement();
		evtPsu.setCode("PSU");
		evtPsu.setDateDebut(LocalDate.now().minusDays(3));
		evtPsu.setIdentiteInitiale(id);

		ComplementEvenement cePsu = new ComplementEvenement();
		cePsu.setDateMaj(evtPsu.getDateDebut());
		cePsu.setMontantArriere(BigDecimal.ZERO);
		cePsu.setStatutEvt(StatutEvenement.ACT);
		cePsu.setArriereLitige(false);
		cePsu.setArriereTech(false);
		cePsu.setAuditFichier(fic3);
		cePsu.setIdentiteInitiale(id);
		evtPsu.addComplement(cePsu);

		entityManager.persist(evtPsu);

		lot.setDateCalcul(LocalDate.now().plusDays(20));

		// Act 3
		calculService.traiteMessage(lot);

		// Assert
		List<StatutHistorise> statuts = statutTiersRepository.findAll();
		Assert.assertEquals(4, statuts.size());
		for (StatutHistorise statut : statuts) {
			if (StatutTiers.SAIN.equals(statut.getStatut()) && statut.getAnnule()) {
				Assert.assertEquals(LocalDate.now().minusDays(5), statut.getDateDebut());
				Assert.assertEquals(LocalDate.now().plusDays(10), statut.getDateFin());
			} else if (StatutTiers.SAIN.equals(statut.getStatut()) && !statut.getAnnule()) {
				Assert.assertEquals(LocalDate.now().minusDays(5), statut.getDateDebut());
				Assert.assertEquals(LocalDate.now().minusDays(3), statut.getDateFin());
			} else if ("PCO".equals(statut.getMotif().getMotif())) {
				Assert.assertEquals(LocalDate.now().plusDays(10), statut.getDateDebut());
				Assert.assertNull(statut.getDateFin());
			} else if ("PSU".equals(statut.getMotif().getMotif())) {
				Assert.assertEquals(LocalDate.now().minusDays(3), statut.getDateDebut());
				Assert.assertNull(statut.getDateFin());
			}
		}
	}

	@Test
	public void impactPcoHorsPeriodeReferentiel() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);
		Tiers tiers = new Tiers();
		IdentiteTiers id = new IdentiteTiers();
		id.setIdLocal("abcdefg");
		id.setCodeBanque("10107"); // Par exemple
		id.setCodeSegment("3200");
		id.setDateDebut(LocalDate.now().minusDays(5));
		tiers.addIdentite(id);
		tiers = entityManager.persistAndFlush(tiers);

		Evenement evtPco = new Evenement();
		evtPco.setCode("PCO");
		evtPco.setDateDebut(LocalDate.now().minusDays(50));
		evtPco.setIdentiteInitiale(id);

		ComplementEvenement cePco = new ComplementEvenement();
		cePco.setDateMaj(evtPco.getDateDebut());
		cePco.setMontantArriere(BigDecimal.ZERO);
		cePco.setStatutEvt(StatutEvenement.ACT);
		cePco.setArriereLitige(false);
		cePco.setArriereTech(false);
		cePco.setAuditFichier(fic);
		cePco.setIdentiteInitiale(id);
		evtPco.addComplement(cePco);

		entityManager.persist(evtPco);

		// REF IMPACT EVT MDC
		RefImpactEvtMdc refImpact = new RefImpactEvtMdc();
		refImpact.setCodEvt("PCO");
		refImpact.setCategorieSegment(Constant.TOUS_AUTRES);
		refImpact.setImpact("D");
		refImpact.setGraviteImpact("CX");
		refImpact.setDateDebut(LocalDate.now().minusDays(30));
		entityManager.persist(refImpact);

		// REF_CLI_SEG
		RefCliSeg refCliSeg = new RefCliSeg();
		refCliSeg.setCodSegCli("3200");
		refCliSeg.setLibSegCli("PARTICULIERS");
		refCliSeg.setCodSsClassCli("RETPAR");
		refCliSeg.setTopSuppr("N");
		entityManager.persist(refCliSeg);

		// REF_CLI_SS_CLASS
		RefCliSsClass refClassSsClass = new RefCliSsClass();
		refClassSsClass.setCodSsClassCli("RETPAR");
		refClassSsClass.setLibSsClassCli("PARTICULIERS");
		refClassSsClass.setCodClassCli("RET");
		refClassSsClass.setTopSuppr("N");
		refClassSsClass.setCodTypNot("PART");
		entityManager.persist(refClassSsClass);
		entityManager.flush();

		LotIdTiersDTO lot = new LotIdTiersDTO(LocalDate.now());
		lot.addIdTiers(tiers.getId());

		// Act
		calculService.traiteMessage(lot);

		// Assert
		List<StatutHistorise> statuts = statutTiersRepository.findAll();
		Assert.assertEquals(1, statuts.size());
		Assert.assertEquals(StatutTiers.SAIN, statuts.get(0).getStatut());
	}

	@Test
	public void sainSuccessifsWithDateRetro() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);
		Tiers tiers = new Tiers();
		IdentiteTiers id = new IdentiteTiers();
		id.setIdLocal("abcdefg");
		id.setCodeBanque("10107"); // Par exemple
		id.setCodeSegment("3200");
		id.setDateDebut(LocalDate.now().minusDays(5));
		tiers.addIdentite(id);
		tiers = entityManager.persistAndFlush(tiers);

		LotIdTiersDTO lot = new LotIdTiersDTO(LocalDate.now().minusDays(5));
		lot.addIdTiers(tiers.getId());

		// Act
		calculService.traiteMessage(lot);

		// Arrange 2
		lot.setDateCalcul(LocalDate.now().minusDays(10));

		// Act
		calculService.traiteMessage(lot);

		// Assert
		List<StatutHistorise> statuts = statutTiersRepository.findAll();
		Assert.assertEquals(1, statuts.size());
		Assert.assertEquals(StatutTiers.SAIN, statuts.get(0).getStatut());
	}

	@Test
	public void impactSainPuisPcoPuisPsu() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);
		Tiers tiers = new Tiers();
		IdentiteTiers id = new IdentiteTiers();
		id.setIdLocal("abcdefg");
		id.setCodeBanque("10107"); // Par exemple
		id.setCodeSegment("3200");
		id.setDateDebut(LocalDate.now().minusDays(5));
		tiers.addIdentite(id);
		tiers = entityManager.persistAndFlush(tiers);

		LotIdTiersDTO lot = new LotIdTiersDTO(LocalDate.now().minusDays(5));
		lot.addIdTiers(tiers.getId());

		// Act
		calculService.traiteMessage(lot);

		// Arrange 2
		AuditFichiers fic2 = new AuditFichiers();
		fic2 = entityManager.persistAndFlush(fic2);
		Evenement evtPco = new Evenement();
		evtPco.setCode("PCO");
		evtPco.setDateDebut(LocalDate.now().plusDays(10));
		evtPco.setIdentiteInitiale(id);

		ComplementEvenement cePco = new ComplementEvenement();
		cePco.setDateMaj(evtPco.getDateDebut());
		cePco.setMontantArriere(BigDecimal.ZERO);
		cePco.setStatutEvt(StatutEvenement.ACT);
		cePco.setArriereLitige(false);
		cePco.setArriereTech(false);
		cePco.setAuditFichier(fic2);
		cePco.setIdentiteInitiale(id);
		evtPco.addComplement(cePco);
		entityManager.persist(evtPco);

		// REF IMPACT EVT MDC
		RefImpactEvtMdc refImpact = new RefImpactEvtMdc();
		refImpact.setCodEvt("PCO");
		refImpact.setCategorieSegment(Constant.TOUS_AUTRES);
		refImpact.setImpact("D");
		refImpact.setGraviteImpact("CX");
		refImpact.setDateDebut(LocalDate.now().minusDays(100));
		entityManager.persist(refImpact);

		// REF_CLI_SEG
		RefCliSeg refCliSeg = new RefCliSeg();
		refCliSeg.setCodSegCli("3200");
		refCliSeg.setLibSegCli("PARTICULIERS");
		refCliSeg.setCodSsClassCli("RETPAR");
		refCliSeg.setTopSuppr("N");
		entityManager.persist(refCliSeg);

		// REF_CLI_SS_CLASS
		RefCliSsClass refClassSsClass = new RefCliSsClass();
		refClassSsClass.setCodSsClassCli("RETPAR");
		refClassSsClass.setLibSsClassCli("PARTICULIERS");
		refClassSsClass.setCodClassCli("RET");
		refClassSsClass.setTopSuppr("N");
		refClassSsClass.setCodTypNot("PART");
		entityManager.persist(refClassSsClass);

		// REF IMPACT EVT MDC PSU
		RefImpactEvtMdc refImpact2 = new RefImpactEvtMdc();
		refImpact2.setCodEvt("PSU");
		refImpact2.setCategorieSegment(Constant.TOUS_AUTRES);
		refImpact2.setImpact("D");
		refImpact2.setGraviteImpact("CX");
		refImpact2.setDateDebut(LocalDate.now().minusDays(100));
		entityManager.persist(refImpact2);
		entityManager.flush();

		lot.setDateCalcul(LocalDate.now().plusDays(10));

		// Act 2
		calculService.traiteMessage(lot);

		// Arrange 3
		AuditFichiers fic3 = new AuditFichiers();
		fic3 = entityManager.persistAndFlush(fic3);
		Evenement evtPsu = new Evenement();
		evtPsu.setCode("PSU");
		evtPsu.setDateDebut(LocalDate.now().plusDays(20));
		evtPsu.setIdentiteInitiale(id);

		ComplementEvenement cePsu = new ComplementEvenement();
		cePsu.setDateMaj(evtPsu.getDateDebut());
		cePsu.setMontantArriere(BigDecimal.ZERO);
		cePsu.setStatutEvt(StatutEvenement.ACT);
		cePsu.setArriereLitige(false);
		cePsu.setArriereTech(false);
		cePsu.setAuditFichier(fic3);
		cePsu.setIdentiteInitiale(id);
		evtPsu.addComplement(cePsu);
		entityManager.persist(evtPsu);

		lot.setDateCalcul(LocalDate.now().plusDays(20));

		// Act 3
		calculService.traiteMessage(lot);

		// Assert
		List<StatutHistorise> statuts = statutTiersRepository.findAll();
		Assert.assertEquals(3, statuts.size());
		for (StatutHistorise statut : statuts) {
			if (StatutTiers.SAIN.equals(statut.getStatut())) {
				Assert.assertEquals(LocalDate.now().minusDays(5), statut.getDateDebut());
				Assert.assertEquals(LocalDate.now().plusDays(10), statut.getDateFin());
			} else if ("PCO".equals(statut.getMotif().getMotif())) {
				Assert.assertEquals(LocalDate.now().plusDays(10), statut.getDateDebut());
				Assert.assertNull(statut.getDateFin());
			} else if ("PSU".equals(statut.getMotif().getMotif())) {
				Assert.assertEquals(LocalDate.now().plusDays(20), statut.getDateDebut());
				Assert.assertNull(statut.getDateFin());
			}
		}
	}

	@Test
	public void impactSainPuisPcoAnterieur() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);
		Tiers tiers = new Tiers();
		IdentiteTiers id = new IdentiteTiers();
		id.setIdLocal("abcdefg");
		id.setCodeBanque("10107"); // Par exemple
		id.setCodeSegment("3200");
		id.setDateDebut(LocalDate.now().minusDays(5));
		tiers.addIdentite(id);
		tiers = entityManager.persistAndFlush(tiers);

		LotIdTiersDTO lot = new LotIdTiersDTO(LocalDate.now().minusDays(5));
		lot.addIdTiers(tiers.getId());

		// Act
		calculService.traiteMessage(lot);

		// Arrange 2
		AuditFichiers fic2 = new AuditFichiers();
		fic2 = entityManager.persistAndFlush(fic2);
		Evenement evtPco = new Evenement();
		evtPco.setCode("PCO");
		evtPco.setDateDebut(LocalDate.now().minusDays(10));
		evtPco.setIdentiteInitiale(id);

		ComplementEvenement cePco = new ComplementEvenement();
		cePco.setDateMaj(evtPco.getDateDebut());
		cePco.setMontantArriere(BigDecimal.ZERO);
		cePco.setStatutEvt(StatutEvenement.ACT);
		cePco.setArriereLitige(false);
		cePco.setArriereTech(false);
		cePco.setAuditFichier(fic2);
		cePco.setIdentiteInitiale(id);
		evtPco.addComplement(cePco);
		entityManager.persist(evtPco);

		// REF IMPACT EVT MDC
		RefImpactEvtMdc refImpact = new RefImpactEvtMdc();
		refImpact.setCodEvt("PCO");
		refImpact.setCategorieSegment(Constant.TOUS_AUTRES);
		refImpact.setImpact("D");
		refImpact.setGraviteImpact("CX");
		refImpact.setDateDebut(LocalDate.now().minusDays(100));
		entityManager.persist(refImpact);

		// REF_CLI_SEG
		RefCliSeg refCliSeg = new RefCliSeg();
		refCliSeg.setCodSegCli("3200");
		refCliSeg.setLibSegCli("PARTICULIERS");
		refCliSeg.setCodSsClassCli("RETPAR");
		refCliSeg.setTopSuppr("N");
		entityManager.persist(refCliSeg);

		// REF_CLI_SS_CLASS
		RefCliSsClass refClassSsClass = new RefCliSsClass();
		refClassSsClass.setCodSsClassCli("RETPAR");
		refClassSsClass.setLibSsClassCli("PARTICULIERS");
		refClassSsClass.setCodClassCli("RET");
		refClassSsClass.setTopSuppr("N");
		refClassSsClass.setCodTypNot("PART");
		entityManager.persist(refClassSsClass);

		entityManager.flush();

		lot.setDateCalcul(LocalDate.now().plusDays(10));

		// Act 2
		calculService.traiteMessage(lot);

		// Assert
		List<StatutHistorise> statuts = statutTiersRepository.findAll();
		Assert.assertEquals(2, statuts.size());
		for (StatutHistorise statut : statuts) {
			if (StatutTiers.SAIN.equals(statut.getStatut())) {
				Assert.assertEquals(LocalDate.now().minusDays(5), statut.getDateDebut());
				Assert.assertEquals(LocalDate.now().minusDays(5), statut.getDateFin());
				Assert.assertTrue(statut.getAnnule());
			} else if ("PCO".equals(statut.getMotif().getMotif())) {
				Assert.assertEquals(LocalDate.now().minusDays(10), statut.getDateDebut());
				Assert.assertNull(statut.getDateFin());
			}
		}
	}

	@Test
	public void impactSainPuisPcoAnterieurAndDateCalculAnterieure() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);
		Tiers tiers = new Tiers();
		IdentiteTiers id = new IdentiteTiers();
		id.setIdLocal("abcdefg");
		id.setCodeBanque("10107"); // Par exemple
		id.setCodeSegment("3200");
		id.setDateDebut(LocalDate.now().minusDays(5));
		tiers.addIdentite(id);
		tiers = entityManager.persistAndFlush(tiers);

		LotIdTiersDTO lot = new LotIdTiersDTO(LocalDate.now().minusDays(5));
		lot.addIdTiers(tiers.getId());

		// Act
		calculService.traiteMessage(lot);

		// Arrange 2
		AuditFichiers fic2 = new AuditFichiers();
		fic2 = entityManager.persistAndFlush(fic2);
		Evenement evtPco = new Evenement();
		evtPco.setCode("PCO");
		evtPco.setDateDebut(LocalDate.now().minusDays(10));
		evtPco.setIdentiteInitiale(id);

		ComplementEvenement cePco = new ComplementEvenement();
		cePco.setDateMaj(evtPco.getDateDebut());
		cePco.setMontantArriere(BigDecimal.ZERO);
		cePco.setStatutEvt(StatutEvenement.ACT);
		cePco.setArriereLitige(false);
		cePco.setArriereTech(false);
		cePco.setAuditFichier(fic2);
		cePco.setIdentiteInitiale(id);
		evtPco.addComplement(cePco);
		entityManager.persist(evtPco);

		// REF IMPACT EVT MDC
		RefImpactEvtMdc refImpact = new RefImpactEvtMdc();
		refImpact.setCodEvt("PCO");
		refImpact.setCategorieSegment(Constant.TOUS_AUTRES);
		refImpact.setImpact("D");
		refImpact.setGraviteImpact("CX");
		refImpact.setDateDebut(LocalDate.now().minusDays(100));
		entityManager.persist(refImpact);

		// REF_CLI_SEG
		RefCliSeg refCliSeg = new RefCliSeg();
		refCliSeg.setCodSegCli("3200");
		refCliSeg.setLibSegCli("PARTICULIERS");
		refCliSeg.setCodSsClassCli("RETPAR");
		refCliSeg.setTopSuppr("N");
		entityManager.persist(refCliSeg);

		// REF_CLI_SS_CLASS
		RefCliSsClass refClassSsClass = new RefCliSsClass();
		refClassSsClass.setCodSsClassCli("RETPAR");
		refClassSsClass.setLibSsClassCli("PARTICULIERS");
		refClassSsClass.setCodClassCli("RET");
		refClassSsClass.setTopSuppr("N");
		refClassSsClass.setCodTypNot("PART");
		entityManager.persist(refClassSsClass);

		entityManager.flush();

		lot.setDateCalcul(LocalDate.now().minusDays(10));

		// Act 2
		calculService.traiteMessage(lot);

		// Assert
		List<StatutHistorise> statuts = statutTiersRepository.findAll();
		Assert.assertEquals(2, statuts.size());
		for (StatutHistorise statut : statuts) {
			if (StatutTiers.SAIN.equals(statut.getStatut())) {
				Assert.assertEquals(LocalDate.now().minusDays(5), statut.getDateDebut());
				Assert.assertEquals(LocalDate.now().minusDays(5), statut.getDateFin());
				Assert.assertTrue(statut.getAnnule());
			} else if ("PCO".equals(statut.getMotif().getMotif())) {
				Assert.assertEquals(LocalDate.now().minusDays(10), statut.getDateDebut());
				Assert.assertNull(statut.getDateFin());
			}
		}
	}

	@Test
	public void impactSainPuisPcoLeMemeJours() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);
		Tiers tiers = new Tiers();
		IdentiteTiers id = new IdentiteTiers();
		id.setIdLocal("abcdefg");
		id.setCodeBanque("10107"); // Par exemple
		id.setCodeSegment("3200");
		id.setDateDebut(LocalDate.now().minusDays(5));
		tiers.addIdentite(id);
		tiers = entityManager.persistAndFlush(tiers);

		LotIdTiersDTO lot = new LotIdTiersDTO(LocalDate.now().minusDays(5));
		lot.addIdTiers(tiers.getId());

		// Act
		calculService.traiteMessage(lot);

		// Arrange 2
		AuditFichiers fic2 = new AuditFichiers();
		fic2 = entityManager.persistAndFlush(fic2);
		Evenement evtPco = new Evenement();
		evtPco.setCode("PCO");
		evtPco.setDateDebut(LocalDate.now().minusDays(5));
		evtPco.setIdentiteInitiale(id);

		ComplementEvenement cePco = new ComplementEvenement();
		cePco.setDateMaj(evtPco.getDateDebut());
		cePco.setMontantArriere(BigDecimal.ZERO);
		cePco.setStatutEvt(StatutEvenement.ACT);
		cePco.setArriereLitige(false);
		cePco.setArriereTech(false);
		cePco.setAuditFichier(fic2);
		cePco.setIdentiteInitiale(id);
		evtPco.addComplement(cePco);
		entityManager.persist(evtPco);

		// REF IMPACT EVT MDC
		RefImpactEvtMdc refImpact = new RefImpactEvtMdc();
		refImpact.setCodEvt("PCO");
		refImpact.setCategorieSegment(Constant.TOUS_AUTRES);
		refImpact.setImpact("D");
		refImpact.setGraviteImpact("CX");
		refImpact.setDateDebut(LocalDate.now().minusDays(100));
		entityManager.persist(refImpact);

		// REF_CLI_SEG
		RefCliSeg refCliSeg = new RefCliSeg();
		refCliSeg.setCodSegCli("3200");
		refCliSeg.setLibSegCli("PARTICULIERS");
		refCliSeg.setCodSsClassCli("RETPAR");
		refCliSeg.setTopSuppr("N");
		entityManager.persist(refCliSeg);

		// REF_CLI_SS_CLASS
		RefCliSsClass refClassSsClass = new RefCliSsClass();
		refClassSsClass.setCodSsClassCli("RETPAR");
		refClassSsClass.setLibSsClassCli("PARTICULIERS");
		refClassSsClass.setCodClassCli("RET");
		refClassSsClass.setTopSuppr("N");
		refClassSsClass.setCodTypNot("PART");
		entityManager.persist(refClassSsClass);

		entityManager.flush();

		lot.setDateCalcul(LocalDate.now().plusDays(10));

		// Act 2
		calculService.traiteMessage(lot);

		// Assert
		List<StatutHistorise> statuts = statutTiersRepository.findAll();
		Assert.assertEquals(2, statuts.size());
		for (StatutHistorise statut : statuts) {
			if (StatutTiers.SAIN.equals(statut.getStatut())) {
				Assert.assertEquals(LocalDate.now().minusDays(5), statut.getDateDebut());
				Assert.assertEquals(LocalDate.now().minusDays(5), statut.getDateFin());
				Assert.assertTrue(statut.getAnnule());
			} else if ("PCO".equals(statut.getMotif().getMotif())) {
				Assert.assertEquals(LocalDate.now().minusDays(5), statut.getDateDebut());
				Assert.assertNull(statut.getDateFin());
			}
		}
	}
}
package fr.bpce.yyd.service.traitement.evenements.service.impl;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import fr.bpce.yyd.commun.constantes.Constant;
import fr.bpce.yyd.commun.enums.StatutEvenement;
import fr.bpce.yyd.commun.enums.StatutTiers;
import fr.bpce.yyd.commun.messages.dto.LotIdTiersDTO;
import fr.bpce.yyd.commun.model.AuditFichiers;
import fr.bpce.yyd.commun.model.ComplementEvenement;
import fr.bpce.yyd.commun.model.Evenement;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.StatutHistorise;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.commun.model.reference.RefCliSeg;
import fr.bpce.yyd.commun.model.reference.RefCliSsClass;
import fr.bpce.yyd.commun.model.reference.RefImpactEvtMdc;
import fr.bpce.yyd.commun.repository.RefCliSsClassRepository;
import fr.bpce.yyd.commun.service.impl.RefCliSegServiceImpl;
import fr.bpce.yyd.service.commun.beans.EvenementsCalculesTiers;
import fr.bpce.yyd.service.commun.repository.AuditCalculRepository;
import fr.bpce.yyd.service.commun.repository.EvenementCalculeRepository;
import fr.bpce.yyd.service.commun.repository.EvenementImpactRepository;
import fr.bpce.yyd.service.commun.repository.EvenementRecuRepository;
import fr.bpce.yyd.service.commun.repository.IdentiteTiersRepository;
import fr.bpce.yyd.service.commun.repository.ParMdcBqSegRepository;
import fr.bpce.yyd.service.commun.repository.ParMdcSegRepository;
import fr.bpce.yyd.service.commun.repository.StatutTiersRepository;
import fr.bpce.yyd.service.commun.repository.TiersRepository;
import fr.bpce.yyd.service.commun.service.AuditCalculService;
import fr.bpce.yyd.service.commun.service.impl.AuditCalculServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.DefautServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.EvenementCalculeServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.EvenementImpactServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.EvenementRecuServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.IdentiteTiersServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.ParamMdcServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.ParametresNDoDImpl;
import fr.bpce.yyd.service.commun.service.impl.RechercheTiersServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.StatutTiersServiceImpl;
import fr.bpce.yyd.service.traitement.evenements.kafka.service.KafkaDemandeEncours;
import fr.bpce.yyd.service.traitement.evenements.repositories.ElementsDeCalculRepository;
import fr.bpce.yyd.service.traitement.evenements.repositories.EncoursTiersRepository;
import fr.bpce.yyd.service.traitement.evenements.repositories.NotificationEncoursRepository;
import fr.bpce.yyd.service.traitement.evenements.repositories.SuiviDemandeEncoursRepository;
import fr.bpce.yyd.service.traitement.evenements.repositories.SuiviEncoursTiersRepository;
import fr.bpce.yyd.service.traitement.evenements.service.TiersService;

//entityManager.getEntityManager().getTransaction().commit();

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
public class CalculServiceImplSortieDeDefautTest {

	// a ajouter pour debug sur H2 localhost:8082
	// entityManager.getEntityManager().getTransaction().commit();

	@TestConfiguration
	public static class ConfigurationPourTest {

	}

	@Autowired
	private TestEntityManager entityManager;

	@Autowired
	private TiersService tiersService;

	@Autowired
	private EvenementCalculeRepository evtCalcRepository;

	@Autowired
	private ElementsDeCalculRepository elemCalcRepository;

	@Autowired
	private EvenementRecuRepository evtRecuRepository;

	@Autowired
	private IdentiteTiersRepository identTiersRepository;

	@Autowired
	private StatutTiersRepository statutTiersRepository;

	@Autowired
	private TiersRepository tiersRepository;

	@Autowired
	private AuditCalculRepository auditCalculRepository;

	@Autowired
	private ParMdcSegRepository parMdcSegRepository;

	@Autowired
	private ParMdcBqSegRepository parMdcBqSegRepository;

	@Autowired
	private EvenementImpactRepository impactRepository;

	@Autowired
	private RefCliSsClassRepository cliSsClassRepository;

	private CalculServiceImpl calculService;

	private EvenementCalculeServiceImpl evtCalculService;

	private DefautServiceImpl defautService;

	private EvenementRecuServiceImpl evtRecuService;

	@Autowired
	private NotificationEncoursRepository repNotificationEncours;

	@Autowired
	private SuiviDemandeEncoursRepository repSuiviDemandeEncours;

	@Autowired
	private KafkaDemandeEncours producerDemandeEncours;

	@Autowired
	private AuditCalculService auditCalculService;

	@Autowired
	SuiviEncoursTiersRepository repSuiviEncoursTiers;

	@Autowired
	private EncoursTiersRepository repEncoursTiers;

	private IdentiteTiersServiceImpl identTiersService;

	@Before
	public void assembleCalculService() {
		MockitoAnnotations.initMocks(this); // This is a key

		CalculServiceImpl csi = new CalculServiceImpl();

		ParamMdcServiceImpl paramService = new ParamMdcServiceImpl();
		paramService.setParMdcBqSegRepository(parMdcBqSegRepository);
		paramService.setParMdcSegRepository(parMdcSegRepository);
		ParametresNDoDImpl parametresNDoD = new ParametresNDoDImpl();
		parametresNDoD.setParamService(paramService);
		csi.setParametresNDoD(parametresNDoD);
		csi.setAuditCalculService(auditCalculService);
		csi.setTiersService(tiersService);

		identTiersService = new IdentiteTiersServiceImpl();
		identTiersService.setIdentTiersRepository(identTiersRepository);

		csi.setIdentiteTiersService(identTiersService);

		RefCliSegServiceImpl cliSegService = new RefCliSegServiceImpl();
		cliSegService.setCliSsClassRepository(cliSsClassRepository);

		IdentiteTiersServiceImpl identTiersService = new IdentiteTiersServiceImpl();
		identTiersService.setIdentTiersRepository(identTiersRepository);

		csi.setIdentiteTiersService(identTiersService);

		AuditCalculServiceImpl acService = new AuditCalculServiceImpl();
		acService.setAuditCalculRepository(auditCalculRepository);

		evtCalculService = new EvenementCalculeServiceImpl();
		evtCalculService.setEvtCalculeRepository(evtCalcRepository);
		evtCalculService.setIdentiteTiersService(identTiersService);
		evtCalculService.setAuditCalculService(acService);
		evtCalculService.setParamsNDoD(parametresNDoD);
		csi.setEvtCalculeService(evtCalculService);
		EncoursServiceImpl encoursService = new EncoursServiceImpl();
		encoursService.setRepNotificationEncours(repNotificationEncours);
		encoursService.setRepSuiviDemandeEncours(repSuiviDemandeEncours);
		encoursService.setProducerDemandeEncours(producerDemandeEncours);
		encoursService.setIdentTiersService(identTiersService);
		encoursService.setRefCliSegService(cliSegService);
		encoursService.setEchangeMocked(true);
		encoursService.setRecalculApresRepEncours(false);
		encoursService.setRepEncoursTiers(repEncoursTiers);
		parametresNDoD.setRefCliSegService(cliSegService);

		StatutTiersServiceImpl statutTiersService = new StatutTiersServiceImpl();
		statutTiersService.setStatutTiersRepository(statutTiersRepository);

		EvenementImpactServiceImpl impactService = new EvenementImpactServiceImpl();
		impactService.setEvenementImpactRepository(impactRepository);

		evtRecuService = new EvenementRecuServiceImpl();
		evtRecuService.setEvtRecuRepository(evtRecuRepository);
		evtRecuService.setImpactService(impactService);
		evtRecuService.setCliSegService(cliSegService);

		csi.setEvtRecuService(evtRecuService);
		csi.setServiceEncours(encoursService);
		csi.setElemCalcRepository(elemCalcRepository);
		csi.setRepEncoursTiers(repEncoursTiers);
		RechercheTiersServiceImpl rechTiersService = new RechercheTiersServiceImpl();
		rechTiersService.setTiersRepository(tiersRepository);

		defautService = new DefautServiceImpl();
		defautService.setEvtCalculeService(evtCalculService);
		defautService.setStatutTiersRepository(statutTiersRepository);
		defautService.setRechercheTiersService(rechTiersService);
		defautService.setIdentiteTiersService(identTiersService);
		defautService.setImpactService(impactService);
		defautService.setRefCliSegService(cliSegService);

		csi.setDefautService(defautService);
		calculService = csi;
	}

	@Test
	public void retourEnSainSurCreationPuisAnnulationUTP() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);
		Tiers tiers = new Tiers();

		IdentiteTiers id1 = new IdentiteTiers();
		id1.setCodeBanque("10107"); // Par exemple
		id1.setIdLocal("abcdefg");
		id1.setCodeSegment("3110");
		id1.setDateDebut(LocalDate.now().minusDays(100));
		tiers.addIdentite(id1);
		tiers = entityManager.persistAndFlush(tiers);

		Evenement evtDefaut = new Evenement();
		evtDefaut.setCode("PCO");
		evtDefaut.setIdentiteInitiale(id1);
		ComplementEvenement ceDefaut = new ComplementEvenement();
		ceDefaut.setDatePhoto(LocalDate.now().minusDays(3));
		ceDefaut.setDateMaj(ceDefaut.getDatePhoto().minusDays(1));
		ceDefaut.setMontantArriere(BigDecimal.ZERO);
		ceDefaut.setStatutEvt(StatutEvenement.ACT);
		ceDefaut.setArriereLitige(false);
		ceDefaut.setArriereTech(false);
		ceDefaut.setAuditFichier(fic);
		ceDefaut.setIdentiteInitiale(id1);
		evtDefaut.addComplement(ceDefaut);

		entityManager.persist(evtDefaut);

		// REF IMPACT EVT MDC
		RefImpactEvtMdc refImpact = new RefImpactEvtMdc();
		refImpact.setCodEvt("PCO");
		refImpact.setCategorieSegment(Constant.TOUS_AUTRES);
		refImpact.setImpact("D");
		refImpact.setGraviteImpact("CX");
		refImpact.setDateDebut(LocalDate.now().minusDays(100));
		entityManager.persist(refImpact);

		// REF_CLI_SEG
		RefCliSeg refCliSeg = new RefCliSeg();
		refCliSeg.setCodSegCli("3110");
		refCliSeg.setLibSegCli("PARTICULIERS");
		refCliSeg.setCodSsClassCli("RETPAR");
		refCliSeg.setTopSuppr("N");
		entityManager.persist(refCliSeg);

		// REF_CLI_SS_CLASS
		RefCliSsClass refClassSsClass = new RefCliSsClass();
		refClassSsClass.setCodSsClassCli("RETPAR");
		refClassSsClass.setLibSsClassCli("PARTICULIERS");
		refClassSsClass.setCodClassCli("RET");
		refClassSsClass.setTopSuppr("N");
		refClassSsClass.setCodTypNot("PART");
		entityManager.persist(refClassSsClass);

		entityManager.flush();

		// entityManager.getEntityManager().getTransaction().commit();

		// Act
		LocalDate dateCalc1 = LocalDate.now().minusDays(2);
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalc1);
		lot.addIdTiers(tiers.getId());
		calculService.traiteMessage(lot);

		// Assert
		List<StatutHistorise> optStatut = statutTiersRepository.getStatutADate(tiers.getId(), dateCalc1);
		Assert.assertFalse(optStatut.isEmpty());
		Assert.assertEquals(StatutTiers.DEFAUT, optStatut.get(0).getStatut());
		Assert.assertEquals(ceDefaut.getDateMaj(), optStatut.get(0).getDateDebut());

		// Arrange 2 - Passage en défaut, puis changement de valeurs sur les montants
		ComplementEvenement ceDefaut2 = new ComplementEvenement();
		ceDefaut2.setDatePhoto(LocalDate.now().plusDays(1));
		ceDefaut2.setDateMaj(LocalDate.now());
		ceDefaut2.setMontantArriere(BigDecimal.ZERO);
		ceDefaut2.setStatutEvt(StatutEvenement.ANN);
		ceDefaut2.setArriereLitige(false);
		ceDefaut2.setArriereTech(false);
		ceDefaut2.setMiseAJour(true);
		ceDefaut2.setAuditFichier(fic); // Pour en avoir un, même si ça n'est pas correct
		ceDefaut2.setIdentiteInitiale(id1);
		ceDefaut2.setEvenement(evtDefaut);
		ceDefaut.setDateFin(ceDefaut2.getDateDebut());

		entityManager.persist(ceDefaut2);

		entityManager.flush();

		// Act 2
		LocalDate dateCalc2 = LocalDate.now().plusDays(2);
		lot.setDateCalcul(dateCalc2);
		calculService.traiteMessage(lot);

		// Assert
		// Tier sain
		// le Statut Tiers précédent en défaut à été annulé
		// L'UTP a été cloturée => pas de PP.
		List<StatutHistorise> statutCourant = statutTiersRepository.getStatutADate(tiers.getId(), dateCalc2);
		Assert.assertEquals(StatutTiers.SAIN, statutCourant.get(0).getStatut());
		Assert.assertEquals(dateCalc2, statutCourant.get(0).getDateDebut()); // retour en sain a la date du calcul
		StatutHistorise sTiersRelu = entityManager.find(StatutHistorise.class, optStatut.get(0).getId());
		Assert.assertEquals(statutCourant.get(0).getDateDebut(), sTiersRelu.getDateFin());
		Assert.assertTrue(sTiersRelu.getAnnule());

		EvenementsCalculesTiers evtsCalcules = evtCalculService.rechercheEvenementsCalculesActifsADate(tiers.getId(),
				dateCalc2);
		Assert.assertNotNull(evtsCalcules);
		Assert.assertNull(evtsCalcules.getPeriodeProbatoire());
	}

}

package fr.bpce.yyd.service.traitement.evenements.service.impl;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import fr.bpce.yyd.commun.constantes.Constant;
import fr.bpce.yyd.commun.enums.StatutEvenement;
import fr.bpce.yyd.commun.enums.StatutTiers;
import fr.bpce.yyd.commun.messages.dto.LotIdTiersDTO;
import fr.bpce.yyd.commun.model.AuditFichiers;
import fr.bpce.yyd.commun.model.ComplementEvenement;
import fr.bpce.yyd.commun.model.Evenement;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.StatutHistorise;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.commun.model.reference.RefCliSeg;
import fr.bpce.yyd.commun.model.reference.RefCliSsClass;
import fr.bpce.yyd.commun.model.reference.RefImpactEvtMdc;
import fr.bpce.yyd.service.commun.repository.StatutTiersRepository;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
@ActiveProfiles(profiles = "ti")
public class AnnulationDefautUTPTest {

	@Autowired
	private TestEntityManager entityManager;

	@Autowired
	private CalculServiceImpl calculService;

	@Autowired
	private StatutTiersRepository statutTiersRepository;

	// pour debug avec base H2
	// entityManager.getEntityManager().getTransaction().commit();

	@Test
	public void TestAnnulationUTPlorsqueTiersEstRevenuSAIN() {
		// TEST JIRA 350 : https://jira.f.bbg/browse/NDODTR-350

		// DM ACT le 08/10, entrée en défaut le 08/10
		// DM CLO le 18/10 => PP
		// PP ACT le 18/10
		// retour en SAIN le 15/01, suite à la sortie de la PP 90jours
		// **** ANNULATION du DEFAUT DM le 20/01
		// Résultat attendu : on annule la ligne de defaut DM dans STATUT_TIERS

		// Arrange
		LocalDate date_08_10_2020 = LocalDate.of(2020, 10, 8);

		// table de Param
		// REF_CLI_SEG
		RefCliSeg refCliSeg = new RefCliSeg();
		refCliSeg.setCodSegCli("3200");
		refCliSeg.setLibSegCli("PARTICULIERS");
		refCliSeg.setCodSsClassCli("RETPAR");
		refCliSeg.setTopSuppr("N");
		entityManager.persist(refCliSeg);

		// REF_CLI_SS_CLASS
		RefCliSsClass refClassSsClass = new RefCliSsClass();
		refClassSsClass.setCodSsClassCli("RETPAR");
		refClassSsClass.setLibSsClassCli("PARTICULIERS");
		refClassSsClass.setCodClassCli("RET");
		refClassSsClass.setTopSuppr("N");
		refClassSsClass.setCodTypNot("PART");
		entityManager.persist(refClassSsClass);

		// REF IMPACT EVT MDC
		RefImpactEvtMdc refImpact = new RefImpactEvtMdc();
		refImpact.setCodEvt("DM");
		refImpact.setCategorieSegment(Constant.TOUS_AUTRES);
		refImpact.setImpact("D");
		refImpact.setGraviteImpact("DX");
		refImpact.setDateDebut(date_08_10_2020);
		entityManager.persist(refImpact);

		// ******* colecte DM actif le 08/10/2020
		AuditFichiers fic08Oct = new AuditFichiers();
		fic08Oct = entityManager.persistAndFlush(fic08Oct);
		Tiers tiers = new Tiers();
		IdentiteTiers id = new IdentiteTiers();
		id.setIdLocal("abcdefg");
		id.setCodeBanque("10107"); // Par exemple
		id.setCodeSegment("3200");
		id.setDateDebut(date_08_10_2020);
		tiers.addIdentite(id);
		tiers = entityManager.persistAndFlush(tiers);
		Evenement evtDM = new Evenement();
		evtDM.setCode("DM");
		evtDM.setDateDebut(date_08_10_2020);
		evtDM.setIdentiteInitiale(id);

		ComplementEvenement ceDMAct = new ComplementEvenement();
		ceDMAct.setDatePhoto(date_08_10_2020);
		ceDMAct.setDateMaj(ceDMAct.getDatePhoto());
		ceDMAct.setMontantArriere(BigDecimal.ZERO);
		ceDMAct.setStatutEvt(StatutEvenement.ACT);
		ceDMAct.setArriereLitige(false);
		ceDMAct.setArriereTech(false);
		ceDMAct.setAuditFichier(fic08Oct);
		ceDMAct.setIdentiteInitiale(id);
		evtDM.addComplement(ceDMAct);
		entityManager.persist(evtDM);

		// création du DEFAUT DX au 08/10
		LotIdTiersDTO lot = new LotIdTiersDTO();
		lot.addIdTiers(tiers.getId());
		calculService.traiteMessage(lot);

		// ***** colecte DM clos le 18/10/2020 => creation de PP
		LocalDate date_18_10_2020 = LocalDate.of(2020, 10, 18);

		AuditFichiers fic18Oct = new AuditFichiers();
		fic18Oct = entityManager.persistAndFlush(fic18Oct);

		ComplementEvenement ceDMClo = new ComplementEvenement();
		ceDMClo.setDatePhoto(date_18_10_2020);
		ceDMClo.setDateMaj(ceDMClo.getDatePhoto());
		ceDMClo.setMontantArriere(BigDecimal.ZERO);
		ceDMClo.setStatutEvt(StatutEvenement.CLO);
		ceDMClo.setArriereLitige(false);
		ceDMClo.setArriereTech(false);
		ceDMClo.setAuditFichier(fic18Oct);
		ceDMClo.setIdentiteInitiale(id);
		evtDM.addComplement(ceDMClo);

		ceDMAct.setDateFin(date_18_10_2020);
		entityManager.persist(evtDM);
		entityManager.persist(ceDMClo);
		entityManager.persist(ceDMAct);

		// cloture du DEFAUT DX deb 08/10, fin 18/10 et création de PP
		calculService.traiteMessage(lot);

		// ***** on passe les 90 jours (15/01) le tiers retour en SAIN puis on annule
		// l'evenement DM
		LocalDate date_15_01_2021 = LocalDate.of(2021, 01, 15);

		StatutHistorise statutDefautPP = statutTiersRepository.getStatutADate(tiers.getId(), date_15_01_2021).get(0);
		statutDefautPP.setDateFin(date_15_01_2021);

		StatutHistorise statutSain = new StatutHistorise();
		statutSain.setDateDeb(date_15_01_2021);
		statutSain.setTiers(tiers);
		statutSain.setStatut(StatutTiers.SAIN);

		entityManager.persist(statutDefautPP);
		entityManager.persist(statutSain);

		// annule l'evt DM
		ComplementEvenement ceDMAnn = new ComplementEvenement();
		ceDMAnn.setDatePhoto(date_15_01_2021);
		ceDMAnn.setDateMaj(ceDMClo.getDatePhoto());
		ceDMAnn.setMontantArriere(BigDecimal.ZERO);
		ceDMAnn.setStatutEvt(StatutEvenement.ANN);
		ceDMAnn.setArriereLitige(false);
		ceDMAnn.setArriereTech(false);
		ceDMAnn.setAuditFichier(fic18Oct);
		ceDMAnn.setIdentiteInitiale(id);
		evtDM.addComplement(ceDMAnn);

		ceDMClo.setDateFin(date_15_01_2021);
		entityManager.persist(evtDM);
		entityManager.persist(ceDMClo);
		entityManager.persist(ceDMAnn);

		// Le tiers a 3 lignes dans STATUT_TIERS, on veut qu'aprés le traitement la
		// ligne DEFAUT DM
		calculService.traiteMessage(lot);

		// entityManager.getEntityManager().getTransaction().commit();
		// entityManager.flush();

		// Assert
		List<StatutHistorise> allStatut = statutTiersRepository.findAll();

		Assert.assertEquals(3, allStatut.size());

		// Satut defaut DM
		StatutHistorise statutDM = allStatut.get(0);
		Assert.assertEquals(date_08_10_2020, statutDM.getDateDebut());
		Assert.assertEquals(date_18_10_2020, statutDM.getDateFin());
		Assert.assertTrue(statutDM.getAnnule());

		// statut defaut PP
		StatutHistorise statutPP = allStatut.get(1);
		Assert.assertEquals(date_18_10_2020, statutPP.getDateDebut());
		Assert.assertEquals(date_15_01_2021, statutPP.getDateFin());
		Assert.assertTrue(!statutPP.getAnnule());

		// statut SAIN
		StatutHistorise statutSainPostPP = allStatut.get(2);
		Assert.assertEquals(date_15_01_2021, statutSainPostPP.getDateDebut());
		Assert.assertNull(statutSainPostPP.getDateFin());
		Assert.assertTrue(!statutSainPostPP.getAnnule());
	}

}
package fr.bpce.yyd.service.traitement.evenements.service.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.UUID;

import org.junit.After;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.test.context.junit4.SpringRunner;

import fr.bpce.yyd.commun.enums.CodeParamMdc;
import fr.bpce.yyd.commun.enums.StatutEvenement;
import fr.bpce.yyd.commun.model.AuditFichiers;
import fr.bpce.yyd.commun.model.ComplementEvenement;
import fr.bpce.yyd.commun.model.EncoursTiers;
import fr.bpce.yyd.commun.model.Evenement;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.ParMdcBqSeg;
import fr.bpce.yyd.commun.model.ParMdcSeg;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.commun.model.reference.RefCliSeg;
import fr.bpce.yyd.commun.model.reference.RefCliSsClass;
import fr.bpce.yyd.service.commun.repository.IdentiteTiersRepository;
import fr.bpce.yyd.service.commun.repository.StatutTiersRepository;
import fr.bpce.yyd.service.commun.repository.TiersRepository;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.NotifEncours;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.ReponseEncours;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.ReponseEncoursTiers;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.TypeAgregat;
import fr.bpce.yyd.service.traitement.evenements.entities.NotificationEncours;
import fr.bpce.yyd.service.traitement.evenements.entities.StatutEncoursTiers;
import fr.bpce.yyd.service.traitement.evenements.entities.SuiviDemandeEncours;
import fr.bpce.yyd.service.traitement.evenements.entities.SuiviEncoursTiers;
import fr.bpce.yyd.service.traitement.evenements.repositories.EncoursTiersRepository;
import fr.bpce.yyd.service.traitement.evenements.repositories.NotificationEncoursRepository;
import fr.bpce.yyd.service.traitement.evenements.repositories.SuiviDemandeEncoursRepository;
import fr.bpce.yyd.service.traitement.evenements.repositories.SuiviEncoursTiersRepository;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
public class ReceptionNotifEncoursTest {

	@Autowired
	private EncoursServiceImpl encoursService;

	@Autowired
	private TiersRepository tiersRepo;

	@Autowired
	private IdentiteTiersRepository identityTiers;

	@Autowired
	private StatutTiersRepository statutTiersRepo;

	@Autowired
	private SuiviEncoursTiersRepository repSuiviEncoursTiers;

	@Autowired
	private EncoursTiersRepository repEncoursTiers;

	@Autowired
	private SuiviDemandeEncoursRepository repSuiviDemandeEncours;

	@Autowired
	private NotificationEncoursRepository notificationEncoursRepo;

	@Autowired
	private TestEntityManager entityManager;

	@After
	public void deleteEntities() {
		repEncoursTiers.deleteAll();
		repSuiviEncoursTiers.deleteAll();
		repSuiviDemandeEncours.deleteAll();
		statutTiersRepo.deleteAll();
		identityTiers.deleteAll();
		tiersRepo.deleteAll();
		notificationEncoursRepo.deleteAll();
	}

	@Test
	public void receiveNotificationEncoursTest() {

		encoursService.setEchangeMocked(false);
		SimpleDateFormat df = new SimpleDateFormat("dd/MM/YYYY");
		String today = df.format(new Date());
		LocalDate dateDebut = LocalDate.of(2020, 12, 01);
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/YYYY");
		// Tiers retail
		String codeBq1 = "10108";
		String idLocal1 = "1011234566";
		String codeSeg1 = "3200";
		// Tiers hors retail
		String codeBq2 = "10107";
		String idLocal2 = "1011234567";
		String codeSeg2 = "1010";
		String idRft = "0000016578";

		// création tiers retail avec IMX actif significatif
		Long idTiers1 = createTiersRetail(codeBq1, idLocal1, codeSeg1, dateDebut);
		// création tiers hors retail avec DAX actif significatif
		Long idTiers2 = createTiersHorsRetail(codeBq2, idLocal2, codeSeg2, idRft, dateDebut);
		// Simulation de la récéption de notif
		String msgId = UUID.randomUUID().toString();
		LocalDate dateArrete = LocalDate.of(2021, 01, 01);
		NotifEncours message = new NotifEncours(dateArrete);
		// ACT
		encoursService.saveEncoursNotification(message, msgId);

		// Vérifier la persistence de la notification mensuelle
		List<NotificationEncours> notifsList = (List<NotificationEncours>) notificationEncoursRepo.findAll();
		assertEquals(1, notifsList.size());
		assertEquals(dateArrete, notifsList.get(0).getDateArrete());
		assertEquals(today, df.format(notifsList.get(0).getDateNotif()));

		assertEquals(msgId, notifsList.get(0).getMsgId());

		// Vérifier la persistence des demandes d'encours
		List<SuiviDemandeEncours> suiviDemEncoursList = repSuiviDemandeEncours.findAll();
		assertEquals(1, suiviDemEncoursList.size());
		SuiviDemandeEncours suiviDem = suiviDemEncoursList.get(0);
		assertNotNull(suiviDem);
		assertEquals(dateArrete, suiviDem.getDateEncours());
		assertEquals(today, df.format(suiviDem.getDateDemande()));

		// Vérifier les informations des tiers demandés
		List<SuiviEncoursTiers> suiviEncoursTiersList = repSuiviEncoursTiers.findAll();
		assertEquals(2, suiviEncoursTiersList.size());
		SuiviEncoursTiers suiviTiers1 = suiviEncoursTiersList.get(0);
		SuiviEncoursTiers suiviTiers2 = suiviEncoursTiersList.get(1);
		assertNotNull(suiviTiers1);
		assertNotNull(suiviTiers2);
		// Aggréation LOCAL pour Tiers retail
		assertEquals(codeBq1, suiviTiers1.getCodeBanque());
		assertEquals(idLocal1, suiviTiers1.getIdLocal());
		assertEquals(null, suiviTiers1.getIdFederal());
		assertEquals(StatutEncoursTiers.ATTENTE, suiviTiers1.getStatut());
		assertEquals(suiviDem.getId(), suiviTiers1.getSuiviDemandeEncours().getId());
		assertEquals(TypeAgregat.L, suiviTiers1.getTypeAgregat());
		// Aggréation NATIONAL pour Tiers retail
		assertEquals(null, suiviTiers2.getCodeBanque());
		assertEquals(null, suiviTiers2.getIdLocal());
		assertEquals(idRft, suiviTiers2.getIdFederal());
		assertEquals(StatutEncoursTiers.ATTENTE, suiviTiers1.getStatut());
		assertEquals(suiviDem.getId(), suiviTiers2.getSuiviDemandeEncours().getId());
		assertEquals(TypeAgregat.N, suiviTiers2.getTypeAgregat());

		// ASTUCE pour retrouver le lien entre la demande et le suivi
		suiviDem.setEncoursTiers(new HashSet<SuiviEncoursTiers>(suiviEncoursTiersList));
		// Simulation de la réponse
		ReponseEncours msgReponseKafka = simulRepEncoursTiers(dateArrete, suiviEncoursTiersList);
		encoursService.traiterReponseEncours(msgReponseKafka, suiviDem.getMsgId());
		// Vérification Demande
		List<SuiviDemandeEncours> suiviDemEncoursLNew = repSuiviDemandeEncours.findAll();
		assertEquals(1, suiviDemEncoursLNew.size());
		SuiviDemandeEncours suiviDemAjour = suiviDemEncoursLNew.get(0);
		assertNotNull(suiviDemAjour);
		assertEquals(suiviDem.getId(), suiviDemAjour.getId());
		assertNull(suiviDemAjour.getCodeErreur());
		assertNull(suiviDemAjour.getMsgErreur());
		assertEquals(dateArrete, suiviDemAjour.getDateArreteMensuelle());
		assertEquals(LocalDateTime.now().format(dtf), suiviDemAjour.getDateTraitementRMN().format(dtf));
		// Vérification Suivi par tiers
		List<SuiviEncoursTiers> suiviEncoursTiersLNew = repSuiviEncoursTiers.findAll();
		assertEquals(2, suiviEncoursTiersLNew.size());
		assertEquals(StatutEncoursTiers.NON_REJETE, suiviEncoursTiersLNew.get(0).getStatut());
		assertEquals(StatutEncoursTiers.REJETE, suiviEncoursTiersLNew.get(1).getStatut());
		// Vérification encours_tiers
		List<EncoursTiers> encoursTiers = repEncoursTiers.findAll(Sort.by(Direction.DESC, "montantEncoursBrut"));
		assertEquals(2, encoursTiers.size());
		// Tiers 1
		assertEquals(new BigDecimal("20000"), encoursTiers.get(0).getMontantEncoursBrut());
		assertEquals(today, df.format(encoursTiers.get(0).getDateImport()));
		assertEquals(dateArrete, encoursTiers.get(0).getDatePhoto());
		assertEquals(idTiers1, encoursTiers.get(0).getIdTiers());
		// Tiers 2
		assertEquals(new BigDecimal("0"), encoursTiers.get(1).getMontantEncoursBrut());
		assertEquals(today, df.format(encoursTiers.get(1).getDateImport()));
		assertEquals(dateArrete, encoursTiers.get(1).getDatePhoto());
		assertEquals(idTiers2, encoursTiers.get(1).getIdTiers());

	}

	public ReponseEncours simulRepEncoursTiers(LocalDate dateArrete, List<SuiviEncoursTiers> suiviEncoursTiersList) {
		ReponseEncours response = new ReponseEncours(dateArrete, dateArrete, false);
		response.setDateTraitement(LocalDateTime.now());
		for (SuiviEncoursTiers suiviEncoursTiers : suiviEncoursTiersList) {
			ReponseEncoursTiers rpEncours = new ReponseEncoursTiers();
			if ("0000016578".equals(suiviEncoursTiers.getIdFederal())) {
				rpEncours.setStatutRejet(true);
			} else {
				rpEncours.setStatutRejet(false);
			}
			rpEncours.setTypeAgregat(suiviEncoursTiers.getTypeAgregat());
			rpEncours.setIdRft(suiviEncoursTiers.getIdFederal());
			rpEncours.setClientId(suiviEncoursTiers.getIdLocal());
			rpEncours.setCodeFournisseur(suiviEncoursTiers.getCodeBanque());
			rpEncours.setMntEngBrutBil(new BigDecimal("20000"));
			rpEncours.setMntEngBrut(new BigDecimal("20000"));
			rpEncours.setMntEngBrutHbil(new BigDecimal("20000"));
			rpEncours.setTopEng(true);
			response.getEncoursTiers().add(rpEncours);
		}
		return response;
	}

	private Long createTiersRetail(String codeBq, String idLocal, String codeSeg, LocalDate dateDebut) {
		// Fichier
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);
		// Tiers
		Tiers tiers1 = new Tiers();
		IdentiteTiers id1 = new IdentiteTiers();
		id1.setCodeBanque(codeBq);
		id1.setIdLocal(idLocal);
		id1.setCodeSegment(codeSeg);
		id1.setDateDebut(dateDebut);
		tiers1.addIdentite(id1);
		tiers1 = entityManager.persistAndFlush(tiers1);
		// Evenement
		Evenement evtImx = new Evenement();
		evtImx.setCode("IMX");
		evtImx.setIdentiteInitiale(id1);
		evtImx.setDateDebut(dateDebut);
		ComplementEvenement ceImx = new ComplementEvenement();
		ceImx.setDatePhoto(dateDebut);
		ceImx.setDateMaj(dateDebut);
		ceImx.setMontantArriere(new BigDecimal("150.00"));
		ceImx.setStatutEvt(StatutEvenement.ACT);
		ceImx.setArriereLitige(false);
		ceImx.setArriereTech(false);
		ceImx.setAuditFichier(fic);
		ceImx.setIdentiteInitiale(id1);
		evtImx.addComplement(ceImx);
		entityManager.persistAndFlush(evtImx);
		// REF_CLI_SEG
		RefCliSeg refCliSeg = new RefCliSeg();
		refCliSeg.setCodSegCli(codeSeg);
		refCliSeg.setLibSegCli("PARTICULIERS");
		refCliSeg.setCodSsClassCli("RETPAR");
		refCliSeg.setTopSuppr("N");
		entityManager.persist(refCliSeg);
		// REF_CLI_SS_CLASS
		RefCliSsClass refClassSsClass = new RefCliSsClass();
		refClassSsClass.setCodSsClassCli("RETPAR");
		refClassSsClass.setLibSsClassCli("PARTICULIERS");
		refClassSsClass.setCodClassCli("RET");
		refClassSsClass.setTopSuppr("N");
		refClassSsClass.setCodTypNot("PART");
		entityManager.persistAndFlush(refClassSsClass);

		ParMdcBqSeg paramSeuilR = new ParMdcBqSeg();
		paramSeuilR.setCodeParam(CodeParamMdc.SEUIL_EUR_RETAIL);
		paramSeuilR.setCodeSegment("*");
		paramSeuilR.setCodeBq("*");
		paramSeuilR.setDateDebut(dateDebut);
		paramSeuilR.setValeurParam("100");
		entityManager.persistAndFlush(paramSeuilR);

		return tiers1.getId();

	}

	private Long createTiersHorsRetail(String codeBq, String idLocal, String codeSeg, String idRft,
			LocalDate dateDebut) {
		// Fichier
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);
		// Tiers
		Tiers tiers1 = new Tiers();
		tiers1.setIdFederal(idRft);
		IdentiteTiers id1 = new IdentiteTiers();
		id1.setCodeBanque(codeBq);
		id1.setIdLocal(idLocal);
		id1.setCodeSegment(codeSeg);
		id1.setDateDebut(dateDebut);
		tiers1.addIdentite(id1);
		tiers1 = entityManager.persistAndFlush(tiers1);
		// Evenement
		Evenement evtImx = new Evenement();
		evtImx.setCode("DAX");
		evtImx.setIdentiteInitiale(id1);
		evtImx.setDateDebut(dateDebut);
		ComplementEvenement ceImx = new ComplementEvenement();
		ceImx.setDatePhoto(dateDebut);
		ceImx.setDateMaj(dateDebut);
		ceImx.setMontantArriere(new BigDecimal("510.00"));
		ceImx.setStatutEvt(StatutEvenement.ACT);
		ceImx.setArriereLitige(false);
		ceImx.setArriereTech(false);
		ceImx.setAuditFichier(fic);
		ceImx.setIdentiteInitiale(id1);
		evtImx.addComplement(ceImx);
		entityManager.persistAndFlush(evtImx);
		// REF_CLI_SEG
		RefCliSeg refCliSeg = new RefCliSeg();
		refCliSeg.setCodSegCli(codeSeg);
		refCliSeg.setLibSegCli("ENTREPRISES CLIENTELE NON FINANCIERE");
		refCliSeg.setCodSsClassCli("COR001");
		refCliSeg.setTopSuppr("N");
		entityManager.persistAndFlush(refCliSeg);
		// REF_CLI_SS_CLASS
		RefCliSsClass refClassSsClass = new RefCliSsClass();
		refClassSsClass.setCodSsClassCli("COR001");
		refClassSsClass.setLibSsClassCli("ENTREPRISES CLIENTELE NON FINANCIERE");
		refClassSsClass.setCodClassCli("COR");
		refClassSsClass.setTopSuppr("N");
		refClassSsClass.setCodTypNot("CORP");
		entityManager.persistAndFlush(refClassSsClass);

		// PAR_MDC_BQ_SEG
		ParMdcBqSeg paramSeuilHR = new ParMdcBqSeg();
		paramSeuilHR.setCodeParam(CodeParamMdc.SEUIL_EUR_HORS_RETAIL);
		paramSeuilHR.setCodeSegment("*");
		paramSeuilHR.setCodeBq("*");
		paramSeuilHR.setDateDebut(dateDebut);
		paramSeuilHR.setValeurParam("500");
		entityManager.persistAndFlush(paramSeuilHR);

		return tiers1.getId();

	}

	@Test
	public void receiveNotificationSansTiersDemandeTest() {

		encoursService.setEchangeMocked(false);
		SimpleDateFormat df = new SimpleDateFormat("dd/MM/YYYY");
		String today = df.format(new Date());
		// Simulation de la récéption de notif
		String msgId = UUID.randomUUID().toString();
		LocalDate dateArrete = LocalDate.of(2020, 01, 01);
		NotifEncours message = new NotifEncours(dateArrete);
		// ACT
		encoursService.saveEncoursNotification(message, msgId);

		// Vérifier la persistence de la notification mensuelle
		List<NotificationEncours> notifsList = (List<NotificationEncours>) notificationEncoursRepo.findAll();
		assertEquals(1, notifsList.size());
		assertEquals(dateArrete, notifsList.get(0).getDateArrete());
		assertEquals(today, df.format(notifsList.get(0).getDateNotif()));
		assertEquals(msgId, notifsList.get(0).getMsgId());

		List<SuiviDemandeEncours> suiviDemEncoursList = repSuiviDemandeEncours.findAll();
		assertEquals(0, suiviDemEncoursList.size());

		List<SuiviEncoursTiers> suiviEncoursTiersList = repSuiviEncoursTiers.findAll();
		assertEquals(0, suiviEncoursTiersList.size());

	}

	@Test
	public void receiveNotificationEncoursAvecAgregRegionalTest() {

		encoursService.setEchangeMocked(false);
		SimpleDateFormat df = new SimpleDateFormat("dd/MM/YYYY");
		String today = df.format(new Date());
		LocalDate dateDebut = LocalDate.of(2019, 9, 01);
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/YYYY");

		String codeBq1 = "11128";
		String idLocal1 = "1011234567";
		String codeSeg1 = "3200";
		// création tiers retail avec IMX actif significatif
		Long tiersId = createTiersRetail(codeBq1, idLocal1, codeSeg1, dateDebut);
		// PAR_MDC_SEG pour l'aggrégation régionale
		ParMdcSeg paramAgregReg = new ParMdcSeg();
		paramAgregReg.setCodeParam(CodeParamMdc.CODE_BQ_AGREG_REGIONALE);
		paramAgregReg.setCodeSegment("*");
		paramAgregReg.setDateDebut(dateDebut);
		paramAgregReg.setValeurParam("11128,43199");
		entityManager.persistAndFlush(paramAgregReg);
		// PAR_MDC_SEG pour date calcul courante
		ParMdcSeg paramDateCour = new ParMdcSeg();
		paramDateCour.setCodeParam(CodeParamMdc.DATE_CALCUL_COURANTE);
		paramDateCour.setCodeSegment("*");
		paramDateCour.setDateDebut(dateDebut);
		paramDateCour.setValeurParam("20191002");
		entityManager.persistAndFlush(paramDateCour);
		// Simulation de la récéption de notif
		String msgId = UUID.randomUUID().toString();
		LocalDate dateArrete = LocalDate.of(2019, 10, 01);
		LocalDate dateCalculCourantePlus1 = LocalDate.of(2019, 10, 03);

		NotifEncours message = new NotifEncours(dateArrete);
		// ACT
		encoursService.saveEncoursNotification(message, msgId);

		// Vérifier la persistence de la notification mensuelle
		List<NotificationEncours> notifsList = (List<NotificationEncours>) notificationEncoursRepo.findAll();
		assertEquals(1, notifsList.size());
		assertEquals(dateArrete, notifsList.get(0).getDateArrete());
		assertEquals(today, df.format(notifsList.get(0).getDateNotif()));
		assertEquals(msgId, notifsList.get(0).getMsgId());

		// Vérifier la persistence des demandes d'encours
		List<SuiviDemandeEncours> suiviDemEncoursList = repSuiviDemandeEncours.findAll();
		assertEquals(1, suiviDemEncoursList.size());
		SuiviDemandeEncours suiviDem = suiviDemEncoursList.get(0);
		assertNotNull(suiviDem);
		assertEquals(dateCalculCourantePlus1, suiviDem.getDateEncours());
		assertEquals(today, df.format(suiviDem.getDateDemande()));

		// Vérifier les informations des tiers demandés
		List<SuiviEncoursTiers> suiviEncoursTiersList = repSuiviEncoursTiers.findAll();
		assertEquals(1, suiviEncoursTiersList.size());
		SuiviEncoursTiers suiviTiers1 = suiviEncoursTiersList.get(0);
		assertNotNull(suiviTiers1);
		// Aggréation LOCAL pour Tiers retail
		assertEquals(codeBq1, suiviTiers1.getCodeBanque());
		assertEquals(idLocal1, suiviTiers1.getIdLocal());
		assertEquals(null, suiviTiers1.getIdFederal());
		assertEquals(StatutEncoursTiers.ATTENTE, suiviTiers1.getStatut());
		assertEquals(suiviDem.getId(), suiviTiers1.getSuiviDemandeEncours().getId());
		assertEquals(TypeAgregat.R, suiviTiers1.getTypeAgregat());

		// ASTUCE pour retrouver le lien entre la demande et le suivi
		suiviDem.setEncoursTiers(new HashSet<SuiviEncoursTiers>(suiviEncoursTiersList));
		// Simulation de la réponse
		ReponseEncours msgReponseKafka = simulRepEncoursTiers(dateCalculCourantePlus1, suiviEncoursTiersList);
		encoursService.traiterReponseEncours(msgReponseKafka, suiviDem.getMsgId());
		// Vérification Demande
		List<SuiviDemandeEncours> suiviDemEncoursLNew = repSuiviDemandeEncours.findAll();
		assertEquals(1, suiviDemEncoursLNew.size());
		SuiviDemandeEncours suiviDemAjour = suiviDemEncoursLNew.get(0);
		assertNotNull(suiviDemAjour);
		assertEquals(suiviDem.getId(), suiviDemAjour.getId());
		assertNull(suiviDemAjour.getCodeErreur());
		assertNull(suiviDemAjour.getMsgErreur());
		assertEquals(dateCalculCourantePlus1, suiviDemAjour.getDateArreteMensuelle());
		assertEquals(LocalDateTime.now().format(dtf), suiviDemAjour.getDateTraitementRMN().format(dtf));
		// Vérification Suivi par tiers
		List<SuiviEncoursTiers> suiviEncoursTiersLNew = repSuiviEncoursTiers.findAll();
		assertEquals(1, suiviEncoursTiersLNew.size());
		assertEquals(StatutEncoursTiers.NON_REJETE, suiviEncoursTiersLNew.get(0).getStatut());
		// Vérification encours_tiers
		List<EncoursTiers> encoursTiers = repEncoursTiers.findAll();
		assertEquals(1, encoursTiers.size());
		// Tiers 1
		assertEquals(new BigDecimal("20000"), encoursTiers.get(0).getMontantEncoursBrut());
		assertEquals(today, df.format(encoursTiers.get(0).getDateImport()));
		assertEquals(dateCalculCourantePlus1, encoursTiers.get(0).getDatePhoto());
		assertEquals(tiersId, encoursTiers.get(0).getIdTiers());

	}

}

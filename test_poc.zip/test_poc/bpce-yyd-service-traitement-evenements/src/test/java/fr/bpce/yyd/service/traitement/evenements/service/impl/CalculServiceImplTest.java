package fr.bpce.yyd.service.traitement.evenements.service.impl;

import static org.mockito.Mockito.times;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.tuple.Pair;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import fr.bpce.yyd.commun.enums.CategorieSegment;
import fr.bpce.yyd.commun.enums.StatutEvenement;
import fr.bpce.yyd.commun.model.ArriereSignificatif;
import fr.bpce.yyd.commun.model.AuditCalcul;
import fr.bpce.yyd.commun.model.ComplementEvenement;
import fr.bpce.yyd.commun.model.ElementsDeCalcul;
import fr.bpce.yyd.commun.model.EncoursTiers;
import fr.bpce.yyd.commun.model.Evenement;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.StatutHistorise;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.commun.model.reference.RefImpactEvtMdc;
import fr.bpce.yyd.commun.repository.RefCliSsClassRepository;
import fr.bpce.yyd.commun.service.impl.RefCliSegServiceImpl;
import fr.bpce.yyd.service.commun.beans.EvenementsATraiter;
import fr.bpce.yyd.service.commun.contexte.ContexteCalculTiers;
import fr.bpce.yyd.service.commun.repository.AuditCalculRepository;
import fr.bpce.yyd.service.commun.repository.EvenementCalculeRepository;
import fr.bpce.yyd.service.commun.repository.EvenementImpactRepository;
import fr.bpce.yyd.service.commun.repository.EvenementRecuRepository;
import fr.bpce.yyd.service.commun.repository.IdentiteTiersRepository;
import fr.bpce.yyd.service.commun.repository.StatutTiersRepository;
import fr.bpce.yyd.service.commun.repository.TiersRepository;
import fr.bpce.yyd.service.commun.service.ParamMdcService;
import fr.bpce.yyd.service.commun.service.impl.AuditCalculServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.EvenementCalculeServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.EvenementImpactServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.EvenementRecuServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.IdentiteTiersServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.ParametresNDoDImpl;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.TypeAgregat;
import fr.bpce.yyd.service.traitement.evenements.entities.InfoEncoursTiers;
import fr.bpce.yyd.service.traitement.evenements.repositories.EncoursTiersRepository;
import fr.bpce.yyd.service.traitement.evenements.service.EncoursService;

@RunWith(PowerMockRunner.class)
@PrepareForTest(ContexteCalculTiers.class)
public class CalculServiceImplTest {

	private static CalculServiceImpl srv = new CalculServiceImpl();

	private static TiersServiceImpl tiersServiceImpl = new TiersServiceImpl();

	private static AuditCalculServiceImpl autCalculServiceImpl = new AuditCalculServiceImpl();

	private static EvenementCalculeServiceImpl evtCalServiceImpl = new EvenementCalculeServiceImpl();

	private static EvenementRecuServiceImpl evtRecuService = new EvenementRecuServiceImpl();

	private static EvenementImpactServiceImpl impactService = new EvenementImpactServiceImpl();

	private static RefCliSegServiceImpl cliSegService = new RefCliSegServiceImpl();

	private static EncoursServiceImpl encSrv = new EncoursServiceImpl();

	// Cette propriété, valorisée, sera retounée par le TiersRepository
	private static List<Object[]> listeARetounerParLeRepository;

	// Cette propriété, valorisée, sera retounée par le TiersRepository
	private static List<RefImpactEvtMdc> listeARetounerParLeRepositoryImpact;

	// Cette propriété, valorisée, sera retounée par le TiersRepository
	private static String aRetounerParLeRepositoryCliSsClass;

	// Cette propriété, valorisée, sera retounée par le TiersRepository
	private static InfoEncoursTiers infoEncoursARetournerParLeService;

	// Cette propriété, valorisée, sera retounée par le TiersRepository
	private static List<IdentiteTiers> listIdentitesARetournerParLeService;

	private static Optional<Tiers> tiersARetourner;

	private static List<TypeAgregat> listTypeAgregatARetourner;

	private static String codBqAgregNatListARetourner;

	private static List<EncoursTiers> encoursTiersListARetourner;

	@BeforeClass
	public static void init() {
		// On met en place la mécanique de retour.
		EvenementImpactRepository evenementImpactRepository = Mockito.mock(EvenementImpactRepository.class);
		Mockito.when(evenementImpactRepository.findAllRefImpactEvtMdcADate(Mockito.any()))
				.thenAnswer(new Answer<List<RefImpactEvtMdc>>() {

					@Override
					public List<RefImpactEvtMdc> answer(InvocationOnMock invocation) throws Throwable {
						return listeARetounerParLeRepositoryImpact;
					}
				});
		impactService.setEvenementImpactRepository(evenementImpactRepository);

		RefCliSsClassRepository cliSsClassRepository = Mockito.mock(RefCliSsClassRepository.class);

		Mockito.when(cliSsClassRepository.rechercherCategorieSegment(Mockito.any())).thenAnswer(new Answer<String>() {

			@Override
			public String answer(InvocationOnMock invocation) throws Throwable {
				return aRetounerParLeRepositoryCliSsClass;
			}
		});

		cliSegService.setCliSsClassRepository(cliSsClassRepository);

		EvenementRecuRepository repo = Mockito.mock(EvenementRecuRepository.class);
		Mockito.when(repo.rechercheEvenementsActifsADate(Mockito.any(), Mockito.any()))
				.thenAnswer(new Answer<List<Object[]>>() {

					@Override
					public List<Object[]> answer(InvocationOnMock invocation) throws Throwable {
						return listeARetounerParLeRepository;
					}
				});

		evtRecuService.setEvtRecuRepository(repo);
		evtRecuService.setCliSegService(cliSegService);
		evtRecuService.setImpactService(impactService);

		EncoursService serviceEncours = Mockito.mock(EncoursService.class);
		Mockito.when(serviceEncours.rechercheEncoursTiersADate(Mockito.any(), Mockito.any(), Mockito.any()))
				.thenAnswer(new Answer<InfoEncoursTiers>() {

					@Override
					public InfoEncoursTiers answer(InvocationOnMock invocation) throws Throwable {
						return infoEncoursARetournerParLeService;
					}
				});

		srv.setServiceEncours(serviceEncours);

		ParametresNDoDImpl paramNDod = new ParametresNDoDImpl();
		paramNDod.setRefCliSegService(cliSegService);
		ParamMdcService paramSrv = Mockito.mock(ParamMdcService.class);
		Mockito.when(paramSrv.getParamMdcBqSegValueADate(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(null);
		Mockito.when(paramSrv.getParamMdcSegValueADate(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(null);
		paramNDod.setParamService(paramSrv);
		srv.setParametresNDoD(paramNDod);

		IdentiteTiersRepository identiteTiersRepo = Mockito.mock(IdentiteTiersRepository.class);
		Mockito.when(identiteTiersRepo.rechercheIdentitesActivesADate(Mockito.any()))
				.thenAnswer(new Answer<List<IdentiteTiers>>() {

					@Override
					public List<IdentiteTiers> answer(InvocationOnMock invocation) throws Throwable {
						return listIdentitesARetournerParLeService;
					}
				});

		IdentiteTiersServiceImpl identiteTiersService = new IdentiteTiersServiceImpl();
		identiteTiersService.setIdentTiersRepository(identiteTiersRepo);

		srv.setEvtRecuService(evtRecuService);
		srv.setIdentiteTiersService(identiteTiersService);

		TiersRepository tiersRepository = Mockito.mock(TiersRepository.class);
		Mockito.when(tiersRepository.findById(Mockito.any())).thenAnswer(new Answer<Optional<Tiers>>() {

			@Override
			public Optional<Tiers> answer(InvocationOnMock invocation) throws Throwable {
				return tiersARetourner;
			}
		});

		Mockito.when(paramSrv.getParamMdcSegValueADate(Mockito.any(), Mockito.any(), Mockito.any()))
				.thenAnswer(new Answer<String>() {
					@Override
					public String answer(InvocationOnMock invocation) throws Throwable {
						return codBqAgregNatListARetourner;
					}
				});

		EncoursTiersRepository repEncoursTiers = Mockito.mock(EncoursTiersRepository.class);
		Mockito.when(repEncoursTiers.searchListTypeAgregaDemandeEncours(Mockito.any(), Mockito.any()))
				.thenAnswer(new Answer<List<TypeAgregat>>() {

					@Override
					public List<TypeAgregat> answer(InvocationOnMock invocation) throws Throwable {
						return listTypeAgregatARetourner;
					}
				});

		Mockito.when(
				repEncoursTiers.searchListTypeAgregaFederaleDemandeEncours(Mockito.any(), Mockito.any(), Mockito.any()))
				.thenAnswer(new Answer<List<TypeAgregat>>() {
					@Override
					public List<TypeAgregat> answer(InvocationOnMock invocation) throws Throwable {
						return listTypeAgregatARetourner;
					}
				});

		Mockito.when(repEncoursTiers.searchIdTiersAndDatePhoto(Mockito.any(), Mockito.any()))
				.thenAnswer(new Answer<List<EncoursTiers>>() {
					@Override
					public List<EncoursTiers> answer(InvocationOnMock invocation) throws Throwable {
						return encoursTiersListARetourner;
					}
				});

		encSrv.setIdentTiersService(identiteTiersService);
		encSrv.setRefCliSegService(cliSegService);
		encSrv.setTiersRepository(tiersRepository);
		encSrv.setRepEncoursTiers(repEncoursTiers);
		encSrv.setParametresNdodSrvc(paramNDod);
	}

	@Before
	public void initListeRetour() {
		listIdentitesARetournerParLeService = new ArrayList<>();
		listeARetounerParLeRepository = new ArrayList<>();
		infoEncoursARetournerParLeService = null;

		tiersARetourner = null;
		listTypeAgregatARetourner = new ArrayList<>();
		codBqAgregNatListARetourner = null;
		encoursTiersListARetourner = new ArrayList<>();
	}

	@Test
	public void aucunEvenement() {
		// Arrange - on ne retourne rien

		// Act
		EvenementsATraiter eat = evtRecuService.rechercheEvenementsATraiterADate(null, LocalDate.now());

		// Assert
		Assert.assertNotNull(eat);
		Assert.assertTrue(eat.getArrieres().isEmpty());
		Assert.assertTrue(eat.getEvenementsDefaut().isEmpty());
	}

	@Test
	public void aucunEvementDesBonsTypes() {
		// Arrange
		Tiers tier = new Tiers();

		Evenement evt1 = new Evenement();
		evt1.setCode("IM1");
		IdentiteTiers id1 = new IdentiteTiers();
		id1.setCodeSegment("3200");
		evt1.setIdentiteInitiale(id1);
		tier.addIdentite(id1);
		ComplementEvenement ce1 = new ComplementEvenement();
		ce1.setStatutEvt(StatutEvenement.ACT);
		evt1.addComplement(ce1);
		ce1.setEvenement(evt1);

		Evenement evt2 = new Evenement();
		evt2.setCode("F");
		evt2.setIdentiteInitiale(id1);
		ComplementEvenement ce2 = new ComplementEvenement();
		ce2.setStatutEvt(StatutEvenement.ACT);
		evt2.addComplement(ce2);
		ce2.setEvenement(evt2);

		listeARetounerParLeRepository.add(new Object[] { ce1, evt1 });
		listeARetounerParLeRepository.add(new Object[] { ce2, evt2 });

		// Act
		EvenementsATraiter eat = evtRecuService.rechercheEvenementsATraiterADate(null, LocalDate.now());

		// Assert
		Assert.assertNotNull(eat);
		Assert.assertTrue(eat.getArrieres().isEmpty());
		Assert.assertTrue(eat.getEvenementsDefaut().isEmpty());
	}

	@Test
	public void evementDeTypesVaries() {
		// Arrange
		Tiers tier = new Tiers();

		Evenement evt1 = new Evenement();
		evt1.setCode("IM1");
		IdentiteTiers id1 = new IdentiteTiers();
		id1.setCodeSegment("3200");
		evt1.setIdentiteInitiale(id1);
		tier.addIdentite(id1);
		ComplementEvenement ce1 = new ComplementEvenement();
		ce1.setStatutEvt(StatutEvenement.ACT);
		evt1.addComplement(ce1);
		ce1.setEvenement(evt1);

		Evenement evtImx = new Evenement();
		evtImx.setCode("IMX");
		evtImx.setIdentiteInitiale(id1);
		ComplementEvenement ceImx = new ComplementEvenement();
		ceImx.setStatutEvt(StatutEvenement.ACT);
		evtImx.addComplement(ceImx);
		ceImx.setEvenement(evtImx);

		Evenement evtDefaut = new Evenement();
		evtDefaut.setCode("DM");
		evtDefaut.setIdentiteInitiale(id1);
		ComplementEvenement ceDefaut = new ComplementEvenement();
		ceDefaut.setStatutEvt(StatutEvenement.ACT);
		evtDefaut.addComplement(ceDefaut);
		ceDefaut.setEvenement(evtDefaut);

		Evenement evt3 = new Evenement();
		evt3.setCode("F");
		evt3.setIdentiteInitiale(id1);
		ComplementEvenement ce3 = new ComplementEvenement();
		ce3.setStatutEvt(StatutEvenement.ACT);
		evt3.addComplement(ce3);
		ce3.setEvenement(evt3);

		Evenement evtDax = new Evenement();
		evtDax.setCode("DAX");
		evtDax.setIdentiteInitiale(id1);
		ComplementEvenement ceDax = new ComplementEvenement();
		ceDax.setStatutEvt(StatutEvenement.ACT);
		evtDax.addComplement(ceDax);
		ceDax.setEvenement(evtDax);

		listeARetounerParLeRepository.add(new Object[] { ce1, evt1 });
		listeARetounerParLeRepository.add(new Object[] { ceImx, evtImx });
		listeARetounerParLeRepository.add(new Object[] { ceDefaut, evtDefaut });
		listeARetounerParLeRepository.add(new Object[] { ce3, evt3 });
		listeARetounerParLeRepository.add(new Object[] { ceDax, evtDax });
		listIdentitesARetournerParLeService.add(id1);

		EvenementsATraiter evts = new EvenementsATraiter();
		evts.addArriere(ceDax);
		evts.addForbearance(ce3);
		evts.addArriere(ceImx);

		PowerMockito.mockStatic(ContexteCalculTiers.class);
		PowerMockito.when(ContexteCalculTiers.getIdentiteTiers(Mockito.any()))
				.thenReturn(listIdentitesARetournerParLeService);
		PowerMockito.when(ContexteCalculTiers.getEvenementsATraiter(Mockito.any())).thenReturn(evts);

		// Act
		EvenementsATraiter eat = evtRecuService.rechercheEvenementsATraiterADate(1L, LocalDate.now());

		// Assert
		Assert.assertNotNull(eat);
		Assert.assertEquals(2, eat.getArrieres().size());
		Assert.assertTrue(eat.getArrieres().contains(ceDax));
		Assert.assertTrue(eat.getArrieres().contains(ceImx));
		Assert.assertEquals(0, eat.getEvenementsDefaut().size());
	}

	@Test
	public void rechercheIdentiteADateTropTot() {
		// Arrange
		Evenement evt = new Evenement();
		IdentiteTiers ident = new IdentiteTiers();
		ident.setDateDebut(LocalDate.now().plusDays(1));
		evt.setIdentiteInitiale(ident);

		// Act
		IdentiteTiers identPourDate = srv.donneIdentiteTiersPourDate(evt, LocalDate.now());

		// Assert
		Assert.assertNull(identPourDate);
	}

	@Test
	public void rechercheIdentiteADateLeJourMeme() {
		// Arrange
		Evenement evt = new Evenement();
		IdentiteTiers ident = new IdentiteTiers();
		ident.setDateDebut(LocalDate.now());
		evt.setIdentiteInitiale(ident);

		// Act
		IdentiteTiers identPourDate = srv.donneIdentiteTiersPourDate(evt, LocalDate.now());

		// Assert
		Assert.assertNotNull(identPourDate);
		Assert.assertEquals(ident, identPourDate);
	}

	@Test
	public void rechercheIdentiteADateDerniereIdentite() {
		// Arrange
		Evenement evt = new Evenement();
		IdentiteTiers ident1 = new IdentiteTiers();
		ident1.setDateDebut(LocalDate.now().minusDays(3));
		ident1.setDateFin(LocalDate.now().minusDays(1));
		evt.setIdentiteInitiale(ident1);
		IdentiteTiers ident2 = new IdentiteTiers();
		ident2.setDateDebut(ident1.getDateFin());
		ident1.setSuivante(ident2);

		// Act
		IdentiteTiers identPourDate = srv.donneIdentiteTiersPourDate(evt, LocalDate.now());

		// Assert
		Assert.assertNotNull(identPourDate);
		Assert.assertEquals(ident2, identPourDate);
	}

	@Test
	public void rechercheIdentiteADateIdentiteEnMilieuDeListe() {
		// Arrange
		Evenement evt = new Evenement();
		IdentiteTiers ident1 = new IdentiteTiers();
		ident1.setDateDebut(LocalDate.now().minusDays(3));
		ident1.setDateFin(LocalDate.now().minusDays(1));
		evt.setIdentiteInitiale(ident1);
		IdentiteTiers ident2 = new IdentiteTiers();
		ident2.setDateDebut(ident1.getDateFin());
		ident1.setDateFin(LocalDate.now().plusDays(1));
		ident1.setSuivante(ident2);
		IdentiteTiers ident3 = new IdentiteTiers();
		ident3.setDateDebut(ident2.getDateFin());
		ident2.setSuivante(ident3);

		// Act
		IdentiteTiers identPourDate = srv.donneIdentiteTiersPourDate(evt, LocalDate.now());

		// Assert
		Assert.assertNotNull(identPourDate);
		Assert.assertEquals(ident2, identPourDate);
	}

	@Test
	public void significativiteElementsNonSignificatifAbsolu() {
		// Arrange
		ElementsDeCalcul calc = new ElementsDeCalcul();
		calc.setMontantAbsolu(new BigDecimal("99"));
		calc.setSeuilAbsolu(100);

		// Act
		boolean significatif = calc.isSignificatif();

		// Assert
		Assert.assertFalse(significatif);
	}

	@Test
	public void significativiteElementsNonSignificatifRelatif() {
		// Arrange
		ElementsDeCalcul calc = new ElementsDeCalcul();
		calc.setMontantAbsolu(new BigDecimal("100"));
		calc.setMontantRelatif(new BigDecimal("0.005"));
		calc.setSeuilAbsolu(100);
		calc.setSeuilRelatif(new BigDecimal("0.01"));

		// Act
		boolean significatif = calc.isSignificatif();

		// Assert
		Assert.assertFalse(significatif);
	}

	@Test
	public void significativiteElementsSignificatifAbsolu() {
		// Arrange
		ElementsDeCalcul calc = new ElementsDeCalcul();
		calc.setMontantAbsolu(new BigDecimal("100"));
		calc.setSeuilAbsolu(100);

		// Act
		boolean significatif = calc.isSignificatif();

		// Assert
		Assert.assertTrue(significatif);
	}

	@Test
	public void significativiteElementsSignificatifRelatif() {
		// Arrange
		ElementsDeCalcul calc = new ElementsDeCalcul();
		calc.setMontantAbsolu(new BigDecimal("100"));
		calc.setMontantRelatif(new BigDecimal("0.01"));
		calc.setSeuilAbsolu(100);
		calc.setSeuilRelatif(new BigDecimal("0.01"));

		// Act
		boolean significatif = calc.isSignificatif();

		// Assert
		Assert.assertTrue(significatif);
	}

	@Test
	public void calculeElementsASNonSignificatifAbsoluRetail() {
		// Arrange
		// Retail (part, puis prof), montant absolu non significatif, pas d'encours
		Tiers tier = new Tiers();

		IdentiteTiers id1 = new IdentiteTiers();
		id1.setDateDebut(LocalDate.now().minusDays(5));
		tier.addIdentite(id1);

		Evenement evtImx = new Evenement();
		evtImx.setCode("IMX");
		evtImx.setIdentiteInitiale(id1);
		ComplementEvenement ceImx = new ComplementEvenement();
		ceImx.setMontantArriere(new BigDecimal("50.00"));
		ceImx.setStatutEvt(StatutEvenement.ACT);
		evtImx.addComplement(ceImx);

		Evenement evtDax = new Evenement();
		evtDax.setCode("DAX");
		evtDax.setIdentiteInitiale(id1);
		ComplementEvenement ceDax = new ComplementEvenement();
		ceDax.setMontantArriere(new BigDecimal("45.50"));
		ceDax.setStatutEvt(StatutEvenement.ACT);
		evtDax.addComplement(ceDax);

		Evenement evtDax2 = new Evenement();
		evtDax2.setCode("DAX");
		evtDax2.setIdentiteInitiale(id1);
		ComplementEvenement ceDax2 = new ComplementEvenement();
		ceDax2.setMontantArriere(new BigDecimal("60.0"));
		ceDax2.setStatutEvt(StatutEvenement.CLO);
		evtDax2.addComplement(ceDax2);

		List<ComplementEvenement> complements = new ArrayList<>();
		complements.add(ceImx);
		complements.add(ceDax2);
		complements.add(ceDax);

		Long guid = java.util.UUID.randomUUID().getMostSignificantBits();
		infoEncoursARetournerParLeService = new InfoEncoursTiers(tier.getId(), LocalDate.now());
		listIdentitesARetournerParLeService.add(id1);
		// Act - particulier
		id1.setCodeSegment("3200");

		PowerMockito.mockStatic(ContexteCalculTiers.class);
		PowerMockito.when(ContexteCalculTiers.getIdentiteTiers(Mockito.any()))
				.thenReturn(listIdentitesARetournerParLeService);

		Pair<ElementsDeCalcul, InfoEncoursTiers> calc = srv.calculeElementsAS(complements, tier.getId(),
				LocalDate.now(), guid, LocalDate.now());

		// Assert
		Assert.assertNotNull(calc.getLeft());
		Assert.assertFalse(calc.getLeft().isSignificatif());

		// Act - professionnel
		id1.setCodeSegment("3110");
		Pair<ElementsDeCalcul, InfoEncoursTiers> calc2 = srv.calculeElementsAS(complements, tier.getId(),
				LocalDate.now(), guid, LocalDate.now());

		// Assert
		Assert.assertNotNull(calc2.getLeft());
		Assert.assertFalse(calc2.getLeft().isSignificatif());
	}

	@Test
	public void calculeElementsASNonSignificatifRelatifRetail() {
		// Arrange
		// Retail (part, puis prof), montant absolu significatif, relatif non
		// significatif
		Tiers tier = new Tiers();

		IdentiteTiers id1 = new IdentiteTiers();
		id1.setDateDebut(LocalDate.now().minusDays(5));
		tier.addIdentite(id1);

		Evenement evtImx = new Evenement();
		evtImx.setCode("IMX");
		evtImx.setIdentiteInitiale(id1);
		ComplementEvenement ceImx = new ComplementEvenement();
		ceImx.setMontantArriere(new BigDecimal("50.00"));
		ceImx.setStatutEvt(StatutEvenement.ACT);
		evtImx.addComplement(ceImx);

		Evenement evtDax = new Evenement();
		evtDax.setCode("DAX");
		evtDax.setIdentiteInitiale(id1);
		ComplementEvenement ceDax = new ComplementEvenement();
		ceDax.setMontantArriere(new BigDecimal("65.50"));
		ceDax.setStatutEvt(StatutEvenement.ACT);
		evtDax.addComplement(ceDax);

		Evenement evtDax2 = new Evenement();
		evtDax2.setCode("DAX");
		evtDax2.setIdentiteInitiale(id1);
		ComplementEvenement ceDax2 = new ComplementEvenement();
		ceDax2.setMontantArriere(new BigDecimal("60.0"));
		ceDax2.setStatutEvt(StatutEvenement.CLO);
		evtDax2.addComplement(ceDax2);

		List<ComplementEvenement> complements = new ArrayList<>();
		complements.add(ceImx);
		complements.add(ceDax2);
		complements.add(ceDax);

		Long guid = java.util.UUID.randomUUID().getMostSignificantBits();

		infoEncoursARetournerParLeService = new InfoEncoursTiers(tier.getId(), LocalDate.now());
		infoEncoursARetournerParLeService.setMontantEncours(new BigDecimal("100000"));
		listIdentitesARetournerParLeService.add(id1);
		// Act - particulier
		id1.setCodeSegment("3200");

		PowerMockito.mockStatic(ContexteCalculTiers.class);
		PowerMockito.when(ContexteCalculTiers.getIdentiteTiers(Mockito.any()))
				.thenReturn(listIdentitesARetournerParLeService);
		Pair<ElementsDeCalcul, InfoEncoursTiers> calc = srv.calculeElementsAS(complements, tier.getId(),
				LocalDate.now(), guid, LocalDate.now());

		// Assert
		Assert.assertNotNull(calc.getLeft());
		Assert.assertFalse(calc.getLeft().isSignificatif());

		// Act - professionnel
		id1.setCodeSegment("3110");
		// ElementsDeCalcul calc2 = srv.calculeElementsAS(complements, tier.getId(),
		// LocalDate.now(), guid);

		// Assert
		// Assert.assertNotNull(calc2);
		// Assert.assertFalse(calc2.isSignificatif());
	}

	@Test
	public void calculeElementsASSignificatifAbsoluRetail() {
		// Arrange
		// Retail (part, puis prof), montant absolu significatif, pas d'encours
		Tiers tier = new Tiers();

		IdentiteTiers id1 = new IdentiteTiers();
		id1.setDateDebut(LocalDate.now().minusDays(5));
		tier.addIdentite(id1);

		Evenement evtImx = new Evenement();
		evtImx.setCode("IMX");
		evtImx.setIdentiteInitiale(id1);
		ComplementEvenement ceImx = new ComplementEvenement();
		ceImx.setMontantArriere(new BigDecimal("50.00"));
		ceImx.setStatutEvt(StatutEvenement.ACT);
		evtImx.addComplement(ceImx);

		Evenement evtDax = new Evenement();
		evtDax.setCode("DAX");
		evtDax.setIdentiteInitiale(id1);
		ComplementEvenement ceDax = new ComplementEvenement();
		ceDax.setMontantArriere(new BigDecimal("65.50"));
		ceDax.setStatutEvt(StatutEvenement.ACT);
		evtDax.addComplement(ceDax);

		Evenement evtDax2 = new Evenement();
		evtDax2.setCode("DAX");
		evtDax2.setIdentiteInitiale(id1);
		ComplementEvenement ceDax2 = new ComplementEvenement();
		ceDax2.setMontantArriere(new BigDecimal("60.0"));
		ceDax2.setStatutEvt(StatutEvenement.CLO);
		evtDax2.addComplement(ceDax2);

		List<ComplementEvenement> complements = new ArrayList<>();
		complements.add(ceImx);
		complements.add(ceDax2);
		complements.add(ceDax);

		Long guid = java.util.UUID.randomUUID().getMostSignificantBits();

		// Act - particulier
		id1.setCodeSegment("3200");
		aRetounerParLeRepositoryCliSsClass = CategorieSegment.PROF.name();
		infoEncoursARetournerParLeService = new InfoEncoursTiers(tier.getId(), LocalDate.now());
		listIdentitesARetournerParLeService.add(id1);

		PowerMockito.mockStatic(ContexteCalculTiers.class);
		PowerMockito.when(ContexteCalculTiers.getIdentiteTiers(Mockito.any()))
				.thenReturn(listIdentitesARetournerParLeService);
		Pair<ElementsDeCalcul, InfoEncoursTiers> calc = srv.calculeElementsAS(complements, tier.getId(),
				LocalDate.now(), guid, LocalDate.now());

		// Assert
		Assert.assertNotNull(calc.getLeft());
		Assert.assertTrue(calc.getLeft().isSignificatif());

		// Act - professionnel
		id1.setCodeSegment("3110");
		Pair<ElementsDeCalcul, InfoEncoursTiers> calc2 = srv.calculeElementsAS(complements, tier.getId(),
				LocalDate.now(), guid, LocalDate.now());

		// Assert
		Assert.assertNotNull(calc2.getLeft());
		Assert.assertTrue(calc2.getLeft().isSignificatif());
	}

	@Test
	public void calculeElementsASSignificatifRelatifRetail() {
		// Arrange
		// Retail (part, puis prof), montant absolu significatif, montant relatif
		// significatif
		Tiers tier = new Tiers();

		IdentiteTiers id1 = new IdentiteTiers();
		id1.setDateDebut(LocalDate.now().minusDays(5));
		tier.addIdentite(id1);

		Evenement evtImx = new Evenement();
		evtImx.setCode("IMX");
		evtImx.setIdentiteInitiale(id1);
		ComplementEvenement ceImx = new ComplementEvenement();
		ceImx.setMontantArriere(new BigDecimal("50.00"));
		ceImx.setStatutEvt(StatutEvenement.ACT);
		evtImx.addComplement(ceImx);

		Evenement evtDax = new Evenement();
		evtDax.setCode("DAX");
		evtDax.setIdentiteInitiale(id1);
		ComplementEvenement ceDax = new ComplementEvenement();
		ceDax.setMontantArriere(new BigDecimal("65.50"));
		ceDax.setStatutEvt(StatutEvenement.ACT);
		evtDax.addComplement(ceDax);

		Evenement evtDax2 = new Evenement();
		evtDax2.setCode("DAX");
		evtDax2.setIdentiteInitiale(id1);
		ComplementEvenement ceDax2 = new ComplementEvenement();
		ceDax2.setMontantArriere(new BigDecimal("60.0"));
		ceDax2.setStatutEvt(StatutEvenement.CLO);
		evtDax2.addComplement(ceDax2);

		List<ComplementEvenement> complements = new ArrayList<>();
		complements.add(ceImx);
		complements.add(ceDax2);
		complements.add(ceDax);

		infoEncoursARetournerParLeService = new InfoEncoursTiers(tier.getId(), LocalDate.now());
		infoEncoursARetournerParLeService.setMontantEncours(new BigDecimal("10000"));
		aRetounerParLeRepositoryCliSsClass = CategorieSegment.PART.name();
		listIdentitesARetournerParLeService.add(id1);

		Long guid = java.util.UUID.randomUUID().getMostSignificantBits();

		// Act - particulier
		id1.setCodeSegment("3200");
		PowerMockito.mockStatic(ContexteCalculTiers.class);
		PowerMockito.when(ContexteCalculTiers.getIdentiteTiers(Mockito.any()))
				.thenReturn(listIdentitesARetournerParLeService);
		Pair<ElementsDeCalcul, InfoEncoursTiers> calc = srv.calculeElementsAS(complements, tier.getId(),
				LocalDate.now(), guid, LocalDate.now());

		// Assert
		Assert.assertNotNull(calc.getLeft());
		Assert.assertTrue(calc.getLeft().isSignificatif());

		// Act - professionnel
		id1.setCodeSegment("3110");
		Pair<ElementsDeCalcul, InfoEncoursTiers> calc2 = srv.calculeElementsAS(complements, tier.getId(),
				LocalDate.now(), guid, LocalDate.now());

		// Assert
		Assert.assertNotNull(calc2.getLeft());
		Assert.assertTrue(calc2.getLeft().isSignificatif());
	}

	@Test
	public void calculeElementsASNonSignificatifAbsoluHorsRetail() {
		// Arrange
		// Hors retail, montant absolu non significatif, pas d'encours
		Tiers tier = new Tiers();

		IdentiteTiers id1 = new IdentiteTiers();
		id1.setCodeSegment("1010");
		id1.setDateDebut(LocalDate.now().minusDays(5));
		tier.addIdentite(id1);

		Evenement evtImx = new Evenement();
		evtImx.setCode("IMX");
		evtImx.setIdentiteInitiale(id1);
		ComplementEvenement ceImx = new ComplementEvenement();
		ceImx.setMontantArriere(new BigDecimal("350.00"));
		ceImx.setStatutEvt(StatutEvenement.ACT);
		evtImx.addComplement(ceImx);

		Evenement evtDax = new Evenement();
		evtDax.setCode("DAX");
		evtDax.setIdentiteInitiale(id1);
		ComplementEvenement ceDax = new ComplementEvenement();
		ceDax.setMontantArriere(new BigDecimal("145.50"));
		ceDax.setStatutEvt(StatutEvenement.ACT);
		evtDax.addComplement(ceDax);

		Evenement evtDax2 = new Evenement();
		evtDax2.setCode("DAX");
		evtDax2.setIdentiteInitiale(id1);
		ComplementEvenement ceDax2 = new ComplementEvenement();
		ceDax2.setMontantArriere(new BigDecimal("260.0"));
		ceDax2.setStatutEvt(StatutEvenement.CLO);
		evtDax2.addComplement(ceDax2);

		List<ComplementEvenement> complements = new ArrayList<>();
		complements.add(ceImx);
		complements.add(ceDax2);
		complements.add(ceDax);

		Long guid = java.util.UUID.randomUUID().getMostSignificantBits();

		infoEncoursARetournerParLeService = new InfoEncoursTiers(tier.getId(), LocalDate.now());

		listIdentitesARetournerParLeService.add(id1);

		aRetounerParLeRepositoryCliSsClass = CategorieSegment.CORP.name();

		PowerMockito.mockStatic(ContexteCalculTiers.class);
		PowerMockito.when(ContexteCalculTiers.getIdentiteTiers(Mockito.any()))
				.thenReturn(listIdentitesARetournerParLeService);

		// Act
		Pair<ElementsDeCalcul, InfoEncoursTiers> calc = srv.calculeElementsAS(complements, tier.getId(),
				LocalDate.now(), guid, LocalDate.now());

		// Assert
		Assert.assertNotNull(calc.getLeft());
		Assert.assertFalse(calc.getLeft().isSignificatif());
	}

	@Test
	public void calculeElementsASNonSignificatifRelatifHorsRetail() {
		// Arrange
		// Hors retail, montant absolu significatif, relatif non significatif
		Tiers tier = new Tiers();

		IdentiteTiers id1 = new IdentiteTiers();
		id1.setCodeSegment("1010");
		id1.setDateDebut(LocalDate.now().minusDays(5));
		tier.addIdentite(id1);

		Evenement evtImx = new Evenement();
		evtImx.setCode("IMX");
		evtImx.setIdentiteInitiale(id1);
		ComplementEvenement ceImx = new ComplementEvenement();
		ceImx.setMontantArriere(new BigDecimal("350.00"));
		ceImx.setStatutEvt(StatutEvenement.ACT);
		evtImx.addComplement(ceImx);

		Evenement evtDax = new Evenement();
		evtDax.setCode("DAX");
		evtDax.setIdentiteInitiale(id1);
		ComplementEvenement ceDax = new ComplementEvenement();
		ceDax.setMontantArriere(new BigDecimal("165.50"));
		ceDax.setStatutEvt(StatutEvenement.ACT);
		evtDax.addComplement(ceDax);

		Evenement evtDax2 = new Evenement();
		evtDax2.setCode("DAX");
		evtDax2.setIdentiteInitiale(id1);
		ComplementEvenement ceDax2 = new ComplementEvenement();
		ceDax2.setMontantArriere(new BigDecimal("260.0"));
		ceDax2.setStatutEvt(StatutEvenement.CLO);
		evtDax2.addComplement(ceDax2);

		List<ComplementEvenement> complements = new ArrayList<>();
		complements.add(ceImx);
		complements.add(ceDax2);
		complements.add(ceDax);

		infoEncoursARetournerParLeService = new InfoEncoursTiers(tier.getId(), LocalDate.now());
		infoEncoursARetournerParLeService.setMontantEncours(new BigDecimal("100000"));
		listIdentitesARetournerParLeService.add(id1);
		Long guid = java.util.UUID.randomUUID().getMostSignificantBits();

		// Act
		PowerMockito.mockStatic(ContexteCalculTiers.class);
		PowerMockito.when(ContexteCalculTiers.getIdentiteTiers(Mockito.any()))
				.thenReturn(listIdentitesARetournerParLeService);

		Pair<ElementsDeCalcul, InfoEncoursTiers> calc = srv.calculeElementsAS(complements, tier.getId(),
				LocalDate.now(), guid, LocalDate.now());

		// Assert
		Assert.assertNotNull(calc.getLeft());
		Assert.assertFalse(calc.getLeft().isSignificatif());
	}

	@Test
	public void calculeElementsASSignificatifAbsoluHorsRetail() {
		// Arrange
		// Hors retail, montant absolu significatif, pas d'encours
		Tiers tier = new Tiers();

		IdentiteTiers id1 = new IdentiteTiers();
		id1.setCodeSegment("1010");
		id1.setDateDebut(LocalDate.now().minusDays(5));
		tier.addIdentite(id1);

		Evenement evtImx = new Evenement();
		evtImx.setCode("IMX");
		evtImx.setIdentiteInitiale(id1);
		ComplementEvenement ceImx = new ComplementEvenement();
		ceImx.setMontantArriere(new BigDecimal("350.00"));
		ceImx.setStatutEvt(StatutEvenement.ACT);
		evtImx.addComplement(ceImx);

		Evenement evtDax = new Evenement();
		evtDax.setCode("DAX");
		evtDax.setIdentiteInitiale(id1);
		ComplementEvenement ceDax = new ComplementEvenement();
		ceDax.setMontantArriere(new BigDecimal("165.50"));
		ceDax.setStatutEvt(StatutEvenement.ACT);
		evtDax.addComplement(ceDax);

		Evenement evtDax2 = new Evenement();
		evtDax2.setCode("DAX");
		evtDax2.setIdentiteInitiale(id1);
		ComplementEvenement ceDax2 = new ComplementEvenement();
		ceDax2.setMontantArriere(new BigDecimal("260.0"));
		ceDax2.setStatutEvt(StatutEvenement.CLO);
		evtDax2.addComplement(ceDax2);

		List<ComplementEvenement> complements = new ArrayList<>();
		complements.add(ceImx);
		complements.add(ceDax2);
		complements.add(ceDax);

		Long guid = java.util.UUID.randomUUID().getMostSignificantBits();
		infoEncoursARetournerParLeService = new InfoEncoursTiers(tier.getId(), LocalDate.now());
		listIdentitesARetournerParLeService.add(id1);
		// Act
		PowerMockito.mockStatic(ContexteCalculTiers.class);
		PowerMockito.when(ContexteCalculTiers.getIdentiteTiers(Mockito.any()))
				.thenReturn(listIdentitesARetournerParLeService);
		Pair<ElementsDeCalcul, InfoEncoursTiers> calc = srv.calculeElementsAS(complements, tier.getId(),
				LocalDate.now(), guid, LocalDate.now());

		// Assert
		Assert.assertNotNull(calc.getLeft());
		Assert.assertTrue(calc.getLeft().isSignificatif());
	}

	@Test
	public void calculeElementsASSignificatifRelatifHorsRetail() {
		// Arrange
		// Hors retail, montant absolu significatif, montant relatif significatif
		Tiers tier = new Tiers();

		IdentiteTiers id1 = new IdentiteTiers();
		id1.setCodeSegment("1010");
		id1.setDateDebut(LocalDate.now().minusDays(5));
		tier.addIdentite(id1);

		Evenement evtImx = new Evenement();
		evtImx.setCode("IMX");
		evtImx.setIdentiteInitiale(id1);
		ComplementEvenement ceImx = new ComplementEvenement();
		ceImx.setMontantArriere(new BigDecimal("350.00"));
		ceImx.setStatutEvt(StatutEvenement.ACT);
		evtImx.addComplement(ceImx);

		Evenement evtDax = new Evenement();
		evtDax.setCode("DAX");
		evtDax.setIdentiteInitiale(id1);
		ComplementEvenement ceDax = new ComplementEvenement();
		ceDax.setMontantArriere(new BigDecimal("165.50"));
		ceDax.setStatutEvt(StatutEvenement.ACT);
		evtDax.addComplement(ceDax);

		Evenement evtDax2 = new Evenement();
		evtDax2.setCode("DAX");
		evtDax2.setIdentiteInitiale(id1);
		ComplementEvenement ceDax2 = new ComplementEvenement();
		ceDax2.setMontantArriere(new BigDecimal("260.0"));
		ceDax2.setStatutEvt(StatutEvenement.CLO);
		evtDax2.addComplement(ceDax2);

		List<ComplementEvenement> complements = new ArrayList<>();
		complements.add(ceImx);
		complements.add(ceDax2);
		complements.add(ceDax);

		infoEncoursARetournerParLeService = new InfoEncoursTiers(tier.getId(), LocalDate.now());
		infoEncoursARetournerParLeService.setMontantEncours(new BigDecimal("50000"));
		listIdentitesARetournerParLeService.add(id1);
		Long guid = java.util.UUID.randomUUID().getMostSignificantBits();

		PowerMockito.mockStatic(ContexteCalculTiers.class);
		PowerMockito.when(ContexteCalculTiers.getIdentiteTiers(Mockito.any()))
				.thenReturn(listIdentitesARetournerParLeService);

		// Act
		Pair<ElementsDeCalcul, InfoEncoursTiers> calc = srv.calculeElementsAS(complements, tier.getId(),
				LocalDate.now(), guid, LocalDate.now());

		// Assert
		Assert.assertNotNull(calc.getLeft());
		Assert.assertTrue(calc.getLeft().isSignificatif());
	}

	@Test
	public void classementDeuxDates() {
		// Arrange
		LocalDate ancienne = LocalDate.now().minusDays(4);
		LocalDate recente = LocalDate.now();
		Optional<LocalDate> optAncienne = Optional.of(ancienne);
		Optional<LocalDate> optRecente = Optional.of(recente);
		Optional<LocalDate> optVide = Optional.empty();

		// Test 1 - deux vides
		Optional<LocalDate> ret = srv.dateLaPlusRecente(optVide, optVide);
		Assert.assertFalse(ret.isPresent());

		// Test 2 - la premiere vide
		ret = srv.dateLaPlusRecente(optVide, optRecente);
		Assert.assertTrue(ret.isPresent());
		Assert.assertEquals(recente, ret.get());

		// Test 3 - la seconde vide
		ret = srv.dateLaPlusRecente(optRecente, optVide);
		Assert.assertTrue(ret.isPresent());
		Assert.assertEquals(recente, ret.get());

		// Test 4.1 - aucune vide
		ret = srv.dateLaPlusRecente(optRecente, optAncienne);
		Assert.assertTrue(ret.isPresent());
		Assert.assertEquals(recente, ret.get());

		// Test 4.2 - aucune vide
		ret = srv.dateLaPlusRecente(optAncienne, optRecente);
		Assert.assertTrue(ret.isPresent());
		Assert.assertEquals(recente, ret.get());
	}

	@Test
	public void clotureEvenementCalcul() {

		EvenementCalculeRepository evenementCalculeRepository = Mockito.mock(EvenementCalculeRepository.class);
		evtCalServiceImpl.setEvtCalculeRepository(evenementCalculeRepository);
		ArriereSignificatif as = new ArriereSignificatif();
		as.setDateDebut(LocalDate.of(2019, 8, 3));
		Mockito.when(evenementCalculeRepository.rechercheEvenementCalculTiers(Mockito.any()))
				.thenReturn(Arrays.asList(as));

		// Act
		evtCalServiceImpl.clotureEvenementCalcul(1l, LocalDate.of(2019, 9, 3));

		as.setDateFin(LocalDate.of(2019, 9, 3));

		Mockito.verify(evenementCalculeRepository, times(1)).saveAll(Arrays.asList(as));
	}

	@Test
	public void clotureAuditCalcul() {

		AuditCalculRepository auditCalculRepository = Mockito.mock(AuditCalculRepository.class);
		autCalculServiceImpl.setAuditCalculRepository(auditCalculRepository);

		Mockito.when(auditCalculRepository.rechercheAuditCalculAClotuer(Mockito.any()))
				.thenReturn(Arrays.asList(new AuditCalcul()));

		// Act
		autCalculServiceImpl.clotureAuditCalcul(1l, LocalDate.of(2019, 9, 3));

		Mockito.verify(auditCalculRepository, times(1)).save(Mockito.any(AuditCalcul.class));
	}

	@Test
	public void clotureStatusTiers() {

		StatutTiersRepository statutTiersRepository = Mockito.mock(StatutTiersRepository.class);
		tiersServiceImpl.setStatutTiersRepository(statutTiersRepository);
		StatutHistorise statusTiers = new StatutHistorise();
		statusTiers.setDateDeb(LocalDate.of(2019, 8, 3));

		Mockito.when(statutTiersRepository.findStatusTiersActive(Mockito.any())).thenReturn(Arrays.asList(statusTiers));

		tiersServiceImpl.clotureStatusTiers(1l, LocalDate.of(2019, 9, 3));

		statusTiers.setDateFin(LocalDate.of(2019, 9, 3));

		Mockito.verify(statutTiersRepository, times(1)).saveAll(Arrays.asList(statusTiers));

	}

	@Test
	public void testNonRaffraichissementEncoursLocal() {
		// Arrange
		InfoEncoursTiers infoEncoursTiers = new InfoEncoursTiers(1l, LocalDate.now());
		infoEncoursTiers.setDemandeEncoursAEnvoyer(false);

		Tiers tiers = new Tiers(1l);
		IdentiteTiers id = new IdentiteTiers("idTierLoc", "banq1", "3200", "siren");
		tiers.addIdentite(id);
		listIdentitesARetournerParLeService.add(id);

		PowerMockito.mockStatic(ContexteCalculTiers.class);
		PowerMockito.when(ContexteCalculTiers.getIdentiteTiers(Mockito.any()))
				.thenReturn(listIdentitesARetournerParLeService);

		tiersARetourner = Optional.of(tiers);
		codBqAgregNatListARetourner = "banq2";
		listTypeAgregatARetourner.add(TypeAgregat.L);

		encoursTiersListARetourner.add(new EncoursTiers(LocalDate.now(), 1l, new Date(), new BigDecimal(5000)));

		// Act
		infoEncoursTiers = encSrv.rechercheEncoursTiers(1l, LocalDate.now(), LocalDate.now(), infoEncoursTiers, false);

		// Assert
		Assert.assertFalse(infoEncoursTiers.isDemandeEncoursAEnvoyer());
		Assert.assertNotNull(infoEncoursTiers.getMontantEncours());
	}

	@Test
	public void testNonRaffraichissementEncoursNational() {
		// Arrange
		InfoEncoursTiers infoEncoursTiers = new InfoEncoursTiers(1l, LocalDate.now());
		infoEncoursTiers.setDemandeEncoursAEnvoyer(false);

		Tiers tiers = new Tiers(1l, "idFederal1");
		IdentiteTiers id = new IdentiteTiers("idTierLoc", "banq1", "1010", "siren");
		tiers.addIdentite(id);
		listIdentitesARetournerParLeService.add(id);

		PowerMockito.mockStatic(ContexteCalculTiers.class);
		PowerMockito.when(ContexteCalculTiers.getIdentiteTiers(Mockito.any()))
				.thenReturn(listIdentitesARetournerParLeService);

		tiersARetourner = Optional.of(tiers);
		codBqAgregNatListARetourner = "banq2";
		listTypeAgregatARetourner.add(TypeAgregat.N);

		encoursTiersListARetourner.add(new EncoursTiers(LocalDate.now(), 1l, new Date(), new BigDecimal(5000)));

		// Act
		infoEncoursTiers = encSrv.rechercheEncoursTiers(1l, LocalDate.now(), LocalDate.now(), infoEncoursTiers, false);

		// Assert
		Assert.assertFalse(infoEncoursTiers.isDemandeEncoursAEnvoyer());
		Assert.assertNotNull(infoEncoursTiers.getMontantEncours());
	}

	@Test
	public void testNonRaffraichissementEncoursRegional() {
		// Arrange
		InfoEncoursTiers infoEncoursTiers = new InfoEncoursTiers(1l, LocalDate.now());
		infoEncoursTiers.setDemandeEncoursAEnvoyer(false);

		Tiers tiers = new Tiers(1l);
		IdentiteTiers id = new IdentiteTiers("idTierLoc", "banq2", "3200", "siren");
		tiers.addIdentite(id);
		listIdentitesARetournerParLeService.add(id);

		PowerMockito.mockStatic(ContexteCalculTiers.class);
		PowerMockito.when(ContexteCalculTiers.getIdentiteTiers(Mockito.any()))
				.thenReturn(listIdentitesARetournerParLeService);

		tiersARetourner = Optional.of(tiers);
		codBqAgregNatListARetourner = "banq2";
		listTypeAgregatARetourner.add(TypeAgregat.R);

		encoursTiersListARetourner.add(new EncoursTiers(LocalDate.now(), 1l, new Date(), new BigDecimal(5000)));

		// Act
		infoEncoursTiers = encSrv.rechercheEncoursTiers(1l, LocalDate.now(), LocalDate.now(), infoEncoursTiers, false);

		// Assert
		Assert.assertFalse(infoEncoursTiers.isDemandeEncoursAEnvoyer());
		Assert.assertNotNull(infoEncoursTiers.getMontantEncours());
	}

	@Test
	public void testRaffraichissementEncoursPassageNational2Local() {
		// Arrange
		InfoEncoursTiers infoEncoursTiers = new InfoEncoursTiers(1l, LocalDate.now());
		infoEncoursTiers.setDemandeEncoursAEnvoyer(false);

		Tiers tiers = new Tiers(1l);
		IdentiteTiers id = new IdentiteTiers("idTierLoc", "banq1", "3200", "siren");
		tiers.addIdentite(id);
		listIdentitesARetournerParLeService.add(id);

		PowerMockito.mockStatic(ContexteCalculTiers.class);
		PowerMockito.when(ContexteCalculTiers.getIdentiteTiers(Mockito.any()))
				.thenReturn(listIdentitesARetournerParLeService);

		tiersARetourner = Optional.of(tiers);
		codBqAgregNatListARetourner = "banq2";
		listTypeAgregatARetourner.add(TypeAgregat.N);

		encoursTiersListARetourner.add(new EncoursTiers(LocalDate.now(), 1l, new Date(), new BigDecimal(5000)));

		// Act
		infoEncoursTiers = encSrv.rechercheEncoursTiers(1l, LocalDate.now(), LocalDate.now(), infoEncoursTiers, false);

		// Assert
		Assert.assertTrue(infoEncoursTiers.isDemandeEncoursAEnvoyer());
		Assert.assertNull(infoEncoursTiers.getMontantEncours());
	}

	@Test
	public void testRaffraichissementEncoursPassageNational2Regional() {
		// Arrange
		InfoEncoursTiers infoEncoursTiers = new InfoEncoursTiers(1l, LocalDate.now());
		infoEncoursTiers.setDemandeEncoursAEnvoyer(false);

		Tiers tiers = new Tiers(1l);
		IdentiteTiers id = new IdentiteTiers("idTierLoc", "banq2", "3200", "siren");
		tiers.addIdentite(id);
		listIdentitesARetournerParLeService.add(id);

		PowerMockito.mockStatic(ContexteCalculTiers.class);
		PowerMockito.when(ContexteCalculTiers.getIdentiteTiers(Mockito.any()))
				.thenReturn(listIdentitesARetournerParLeService);

		tiersARetourner = Optional.of(tiers);
		codBqAgregNatListARetourner = "banq2";
		listTypeAgregatARetourner.add(TypeAgregat.N);

		encoursTiersListARetourner.add(new EncoursTiers(LocalDate.now(), 1l, new Date(), new BigDecimal(5000)));

		// Act
		infoEncoursTiers = encSrv.rechercheEncoursTiers(1l, LocalDate.now(), LocalDate.now(), infoEncoursTiers, false);

		// Assert
		Assert.assertTrue(infoEncoursTiers.isDemandeEncoursAEnvoyer());
		Assert.assertNull(infoEncoursTiers.getMontantEncours());
	}

	@Test
	public void testRaffraichissementEncoursPassageLocal2National() {
		// Arrange
		InfoEncoursTiers infoEncoursTiers = new InfoEncoursTiers(1l, LocalDate.now());
		infoEncoursTiers.setDemandeEncoursAEnvoyer(false);

		Tiers tiers = new Tiers(1l, "idFederal1");
		IdentiteTiers id = new IdentiteTiers("idTierLoc", "banq1", "3200", "siren");
		tiers.addIdentite(id);
		listIdentitesARetournerParLeService.add(id);

		PowerMockito.mockStatic(ContexteCalculTiers.class);
		PowerMockito.when(ContexteCalculTiers.getIdentiteTiers(Mockito.any()))
				.thenReturn(listIdentitesARetournerParLeService);

		tiersARetourner = Optional.of(tiers);
		codBqAgregNatListARetourner = "banq2";
		listTypeAgregatARetourner.add(TypeAgregat.L);

		encoursTiersListARetourner.add(new EncoursTiers(LocalDate.now(), 1l, new Date(), new BigDecimal(5000)));

		// Act
		infoEncoursTiers = encSrv.rechercheEncoursTiers(1l, LocalDate.now(), LocalDate.now(), infoEncoursTiers, false);

		// Assert
		Assert.assertTrue(infoEncoursTiers.isDemandeEncoursAEnvoyer());
		Assert.assertNull(infoEncoursTiers.getMontantEncours());
	}

	@Test
	public void testRaffraichissementEncoursPassageLocal2Regional() {
		// Arrange
		InfoEncoursTiers infoEncoursTiers = new InfoEncoursTiers(1l, LocalDate.now());
		infoEncoursTiers.setDemandeEncoursAEnvoyer(false);

		Tiers tiers = new Tiers(1l);
		IdentiteTiers id = new IdentiteTiers("idTierLoc", "banq2", "3200", "siren");
		tiers.addIdentite(id);
		listIdentitesARetournerParLeService.add(id);

		PowerMockito.mockStatic(ContexteCalculTiers.class);
		PowerMockito.when(ContexteCalculTiers.getIdentiteTiers(Mockito.any()))
				.thenReturn(listIdentitesARetournerParLeService);

		tiersARetourner = Optional.of(tiers);
		codBqAgregNatListARetourner = "banq2";
		listTypeAgregatARetourner.add(TypeAgregat.L);

		encoursTiersListARetourner.add(new EncoursTiers(LocalDate.now(), 1l, new Date(), new BigDecimal(5000)));

		// Act
		infoEncoursTiers = encSrv.rechercheEncoursTiers(1l, LocalDate.now(), LocalDate.now(), infoEncoursTiers, false);

		// Assert
		Assert.assertTrue(infoEncoursTiers.isDemandeEncoursAEnvoyer());
		Assert.assertNull(infoEncoursTiers.getMontantEncours());
	}

	@Test
	public void testRaffraichissementEncoursPassageRegional2National() {
		// Arrange
		InfoEncoursTiers infoEncoursTiers = new InfoEncoursTiers(1l, LocalDate.now());
		infoEncoursTiers.setDemandeEncoursAEnvoyer(false);

		Tiers tiers = new Tiers(1l, "idFederal1");
		IdentiteTiers id = new IdentiteTiers("idTierLoc", "banq1", "1010", "siren");
		tiers.addIdentite(id);
		listIdentitesARetournerParLeService.add(id);

		PowerMockito.mockStatic(ContexteCalculTiers.class);
		PowerMockito.when(ContexteCalculTiers.getIdentiteTiers(Mockito.any()))
				.thenReturn(listIdentitesARetournerParLeService);

		tiersARetourner = Optional.of(tiers);
		codBqAgregNatListARetourner = "banq2";
		listTypeAgregatARetourner.add(TypeAgregat.R);

		encoursTiersListARetourner.add(new EncoursTiers(LocalDate.now(), 1l, new Date(), new BigDecimal(5000)));

		// Act
		infoEncoursTiers = encSrv.rechercheEncoursTiers(1l, LocalDate.now(), LocalDate.now(), infoEncoursTiers, false);

		// Assert
		Assert.assertTrue(infoEncoursTiers.isDemandeEncoursAEnvoyer());
		Assert.assertNull(infoEncoursTiers.getMontantEncours());
	}

	@Test
	public void testRaffraichissementEncoursPassageRegional2Local() {
		// Arrange
		InfoEncoursTiers infoEncoursTiers = new InfoEncoursTiers(1l, LocalDate.now());
		infoEncoursTiers.setDemandeEncoursAEnvoyer(false);

		Tiers tiers = new Tiers(1l);
		IdentiteTiers id = new IdentiteTiers("idTierLoc", "banq1", "3200", "siren");
		tiers.addIdentite(id);
		listIdentitesARetournerParLeService.add(id);

		PowerMockito.mockStatic(ContexteCalculTiers.class);
		PowerMockito.when(ContexteCalculTiers.getIdentiteTiers(Mockito.any()))
				.thenReturn(listIdentitesARetournerParLeService);

		tiersARetourner = Optional.of(tiers);
		codBqAgregNatListARetourner = "banq2";
		listTypeAgregatARetourner.add(TypeAgregat.R);

		encoursTiersListARetourner.add(new EncoursTiers(LocalDate.now(), 1l, new Date(), new BigDecimal(5000)));

		// Act
		infoEncoursTiers = encSrv.rechercheEncoursTiers(1l, LocalDate.now(), LocalDate.now(), infoEncoursTiers, false);

		// Assert
		Assert.assertTrue(infoEncoursTiers.isDemandeEncoursAEnvoyer());
		Assert.assertNull(infoEncoursTiers.getMontantEncours());
	}
}
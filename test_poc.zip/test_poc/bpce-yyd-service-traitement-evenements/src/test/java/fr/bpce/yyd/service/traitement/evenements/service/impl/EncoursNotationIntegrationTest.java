package fr.bpce.yyd.service.traitement.evenements.service.impl;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.junit.After;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import fr.bpce.yyd.commun.model.EncoursTiers;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.service.commun.repository.IdentiteTiersRepository;
import fr.bpce.yyd.service.commun.repository.StatutTiersRepository;
import fr.bpce.yyd.service.commun.repository.TiersRepository;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.ReponseEncours;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.ReponseEncoursTiers;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.TypeAgregat;
import fr.bpce.yyd.service.traitement.evenements.entities.StatutEncoursTiers;
import fr.bpce.yyd.service.traitement.evenements.entities.SuiviDemandeEncours;
import fr.bpce.yyd.service.traitement.evenements.entities.SuiviEncoursTiers;
import fr.bpce.yyd.service.traitement.evenements.repositories.EncoursTiersRepository;
import fr.bpce.yyd.service.traitement.evenements.repositories.SuiviDemandeEncoursRepository;
import fr.bpce.yyd.service.traitement.evenements.repositories.SuiviEncoursTiersRepository;
import fr.bpce.yyd.service.traitement.evenements.service.EncoursService;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
public class EncoursNotationIntegrationTest {
	// a ajouter pour debug sur H2
	// em.getEntityManager().getTransaction().commit();

	@Autowired
	private EncoursService encoursService;

	@Autowired
	TiersRepository tiersRepo;

	@Autowired
	IdentiteTiersRepository identityTiers;

	@Autowired
	StatutTiersRepository statutTiersRepo;

	@Autowired
	SuiviEncoursTiersRepository repSuiviEncoursTiers;

	@Autowired
	private EncoursTiersRepository repEncoursTiers;

	@Autowired
	private SuiviDemandeEncoursRepository repSuiviDemandeEncours;

	@After
	public void deleteEntities() {
		repEncoursTiers.deleteAll();
		repSuiviEncoursTiers.deleteAll();
		repSuiviDemandeEncours.deleteAll();
		statutTiersRepo.deleteAll();
		identityTiers.deleteAll();
		tiersRepo.deleteAll();
	}

	@Test
	public void receiveReponseEncoursWithoutPreviousDemande() {

		Tiers tiers2 = new Tiers();
		IdentiteTiers id2 = new IdentiteTiers();
		id2.setCodeBanque("10108");
		id2.setIdLocal("1011");
		id2.setDateDebut(LocalDate.now().minusDays(10));
		tiers2.addIdentite(id2);

		Tiers tiers3 = new Tiers();
		IdentiteTiers id3 = new IdentiteTiers();
		tiers3.setIdFederal("1920");
		id3.setDateDebut(LocalDate.now().minusDays(10));
		tiers3.addIdentite(id3);

		tiers2 = tiersRepo.saveAndFlush(tiers2);
		tiers3 = tiersRepo.saveAndFlush(tiers3);

		String msgId = UUID.randomUUID().toString();

		ReponseEncours rp = new ReponseEncours(LocalDate.now(), LocalDate.now(), false);
		ReponseEncoursTiers rpt1 = new ReponseEncoursTiers(false, "1920", null, null, BigDecimal.valueOf(10.0),
				BigDecimal.valueOf(10.0), BigDecimal.valueOf(10.0), true);
		ReponseEncoursTiers rpt2 = new ReponseEncoursTiers(true, null, "10108", "1011", null, null, null, false);
		rp.getEncoursTiers().add(rpt1);
		rp.getEncoursTiers().add(rpt2);

		encoursService.traiterReponseEncours(rp, msgId);

		List<SuiviEncoursTiers> lSuiviEncoursTiers = repSuiviEncoursTiers.findAll();
		Assert.assertEquals(0, lSuiviEncoursTiers.size());

		List<EncoursTiers> lEncoursTiers = repEncoursTiers.findAll();
		Assert.assertEquals(0, lEncoursTiers.size());

	}

	@Test
	public void receiveReponseEncoursWithPreviousDemande() {

		Tiers tiers2 = new Tiers();
		IdentiteTiers id2 = new IdentiteTiers();
		id2.setCodeBanque("10108");
		id2.setIdLocal("1011");
		id2.setDateDebut(LocalDate.now().minusDays(10));
		tiers2.addIdentite(id2);

		Tiers tiers3 = new Tiers();
		IdentiteTiers id3 = new IdentiteTiers();
		tiers3.setIdFederal("1920");
		id3.setDateDebut(LocalDate.now().minusDays(10));
		tiers3.addIdentite(id3);

		tiers2 = tiersRepo.saveAndFlush(tiers2);
		tiers3 = tiersRepo.saveAndFlush(tiers3);

		String msgId = UUID.randomUUID().toString();

		SuiviDemandeEncours suiviDB = new SuiviDemandeEncours(msgId, new Date(), LocalDate.now(),
				LocalDate.now().minusDays(10), null);

		suiviDB.getEncoursTiers().add(new SuiviEncoursTiers(TypeAgregat.L, suiviDB, tiers2, tiers2.getIdFederal(),
				id2.getCodeBanque(), id2.getIdLocal(), StatutEncoursTiers.ATTENTE));

		suiviDB.getEncoursTiers().add(new SuiviEncoursTiers(TypeAgregat.N, suiviDB, tiers3, tiers3.getIdFederal(),
				id3.getCodeBanque(), id3.getIdLocal(), StatutEncoursTiers.ATTENTE));

		repSuiviDemandeEncours.saveAndFlush(suiviDB);

		ReponseEncours rp = new ReponseEncours(LocalDate.now(), LocalDate.now(), false);
		ReponseEncoursTiers rpt1 = new ReponseEncoursTiers(false, "1920", null, null, BigDecimal.valueOf(10.0),
				BigDecimal.valueOf(10.0), BigDecimal.valueOf(10.0), true);
		ReponseEncoursTiers rpt2 = new ReponseEncoursTiers(true, null, "10108", "1011", null, null, null, false);
		rp.getEncoursTiers().add(rpt1);
		rp.getEncoursTiers().add(rpt2);

		encoursService.traiterReponseEncours(rp, msgId);

		List<SuiviEncoursTiers> lSuiviEncoursTiers = repSuiviEncoursTiers.findAll();
		Assert.assertEquals(2, lSuiviEncoursTiers.size());

		List<EncoursTiers> lEncoursTiers = repEncoursTiers.findAll();
		Assert.assertEquals(2, lEncoursTiers.size());

	}

	@Test
	public void searchLastResponseWithCodeErreur() {

		Tiers tiers2 = new Tiers();
		IdentiteTiers id2 = new IdentiteTiers();
		id2.setCodeBanque("10108");
		id2.setIdLocal("1011");
		id2.setDateDebut(LocalDate.now().minusDays(10));
		tiers2.addIdentite(id2);

		Tiers tiers3 = new Tiers();
		IdentiteTiers id3 = new IdentiteTiers();
		tiers3.setIdFederal("1920");
		id3.setDateDebut(LocalDate.now().minusDays(10));
		tiers3.addIdentite(id3);

		tiers2 = tiersRepo.saveAndFlush(tiers2);
		tiers3 = tiersRepo.saveAndFlush(tiers3);

		String msgId = UUID.randomUUID().toString();
		String msgId2 = UUID.randomUUID().toString();

		SuiviDemandeEncours suiviDB1 = new SuiviDemandeEncours(msgId, new Date(), LocalDate.now(),
				LocalDate.now().minusDays(10), null);
		suiviDB1.getEncoursTiers().add(new SuiviEncoursTiers(TypeAgregat.L, suiviDB1, tiers2, tiers2.getIdFederal(),
				id2.getCodeBanque(), id2.getIdLocal(), StatutEncoursTiers.ATTENTE));
		suiviDB1.getEncoursTiers().add(new SuiviEncoursTiers(TypeAgregat.N, suiviDB1, tiers3, tiers3.getIdFederal(),
				id3.getCodeBanque(), id3.getIdLocal(), StatutEncoursTiers.ATTENTE));

		SuiviDemandeEncours suiviDB2 = new SuiviDemandeEncours(msgId2, new Date(), LocalDate.now(), LocalDate.now(),
				"error");
		suiviDB2.getEncoursTiers().add(new SuiviEncoursTiers(TypeAgregat.L, suiviDB2, tiers2, tiers2.getIdFederal(),
				id2.getCodeBanque(), id2.getIdLocal(), StatutEncoursTiers.ATTENTE));
		suiviDB2.getEncoursTiers().add(new SuiviEncoursTiers(TypeAgregat.N, suiviDB2, tiers3, tiers3.getIdFederal(),
				id3.getCodeBanque(), id3.getIdLocal(), StatutEncoursTiers.ATTENTE));

		repSuiviDemandeEncours.saveAndFlush(suiviDB1);
		repSuiviDemandeEncours.saveAndFlush(suiviDB2);

		LocalDate lastDate = repSuiviEncoursTiers.searchLastRespWithCodeErreur(tiers2.getId(), LocalDate.now());

		Assert.assertEquals(lastDate, LocalDate.now());

	}

	@Test
	public void searchLastEncoursTiers() {

		Tiers tiers2 = new Tiers();
		IdentiteTiers id2 = new IdentiteTiers();
		id2.setCodeBanque("10108");
		id2.setIdLocal("1011");
		id2.setDateDebut(LocalDate.now().minusDays(10));
		tiers2.addIdentite(id2);

		Tiers tiers3 = new Tiers();
		IdentiteTiers id3 = new IdentiteTiers();
		tiers3.setIdFederal("1920");
		id3.setDateDebut(LocalDate.now().minusDays(10));
		tiers3.addIdentite(id3);

		tiers2 = tiersRepo.saveAndFlush(tiers2);

		EncoursTiers encours1 = new EncoursTiers(LocalDate.now().minusDays(10), tiers2.getId(), new Date(),
				BigDecimal.valueOf(100.10));

		EncoursTiers encours2 = new EncoursTiers(LocalDate.now().minusDays(5), tiers2.getId(), new Date(),
				BigDecimal.valueOf(100.10));

		EncoursTiers encours3 = new EncoursTiers(LocalDate.now(), tiers3.getId(), new Date(),
				BigDecimal.valueOf(100.10));

		repEncoursTiers.saveAndFlush(encours1);
		repEncoursTiers.saveAndFlush(encours2);
		repEncoursTiers.saveAndFlush(encours3);

		List<EncoursTiers> lEncours = repEncoursTiers.searchIdTiersAndDatePhoto(tiers2.getId(),
				LocalDate.now().minusDays(5));
		Assert.assertEquals(1, lEncours.size());
		Assert.assertEquals(LocalDate.now().minusDays(5), lEncours.get(0).getDatePhoto());
		LocalDate datePhoto = repEncoursTiers.searchDatePhoto(LocalDate.now().minusDays(3));
		Assert.assertTrue(datePhoto.isEqual(LocalDate.now().minusDays(5)));

	}

}

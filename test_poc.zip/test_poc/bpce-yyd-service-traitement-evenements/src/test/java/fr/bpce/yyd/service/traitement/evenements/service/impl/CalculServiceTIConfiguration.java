package fr.bpce.yyd.service.traitement.evenements.service.impl;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScan.Filter;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.FilterType;
import org.springframework.context.annotation.Profile;

import fr.bpce.yyd.service.traitement.evenements.service.TiersService;

@Profile("ti")
@Configuration
@ComponentScan( /**
				 * basePackages = { "fr.bpce.yyd.service.commun",
				 * "fr.bpce.yyd.service.traitement.evenements.repository",
				 * "fr.bpce.yyd.service.traitement.evenements.service" , "fr.bpce.yyd.commun" },
				 **/
		excludeFilters = { /**
							 * @Filter(type = FilterType.REGEX, pattern = "fr.bpce.yyd.service.traitement*")
							 *              ,
							 */
				@Filter(type = FilterType.ASSIGNABLE_TYPE, value = TiersService.class) })
public class CalculServiceTIConfiguration {

}

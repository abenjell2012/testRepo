package fr.bpce.yyd.service.traitement.evenements.service.impl;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.test.context.junit4.SpringRunner;

import fr.bpce.yyd.commun.constantes.Constant;
import fr.bpce.yyd.commun.enums.EvenementArriereSignificatif;
import fr.bpce.yyd.commun.enums.StatutAuditEvenement;
import fr.bpce.yyd.commun.enums.StatutEvenement;
import fr.bpce.yyd.commun.enums.StatutTiers;
import fr.bpce.yyd.commun.messages.dto.LotIdTiersDTO;
import fr.bpce.yyd.commun.model.ArriereSignificatif;
import fr.bpce.yyd.commun.model.AuditCalcul;
import fr.bpce.yyd.commun.model.AuditFichiers;
import fr.bpce.yyd.commun.model.ComplementArriere;
import fr.bpce.yyd.commun.model.ComplementEvenement;
import fr.bpce.yyd.commun.model.ElementsDeCalcul;
import fr.bpce.yyd.commun.model.Evenement;
import fr.bpce.yyd.commun.model.EvenementCalcule;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.MotifStatutTiers;
import fr.bpce.yyd.commun.model.PeriodeProbatoire;
import fr.bpce.yyd.commun.model.StatutHistorise;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.commun.model.reference.RefCliSeg;
import fr.bpce.yyd.commun.model.reference.RefCliSsClass;
import fr.bpce.yyd.commun.model.reference.RefImpactEvtMdc;
import fr.bpce.yyd.commun.repository.RefCliSsClassRepository;
import fr.bpce.yyd.commun.service.impl.RefCliSegServiceImpl;
import fr.bpce.yyd.service.commun.beans.EvenementsATraiter;
import fr.bpce.yyd.service.commun.beans.EvenementsCalculesTiers;
import fr.bpce.yyd.service.commun.contexte.ContexteCalculTiers;
import fr.bpce.yyd.service.commun.repository.AuditCalculRepository;
import fr.bpce.yyd.service.commun.repository.EvenementCalculeRepository;
import fr.bpce.yyd.service.commun.repository.EvenementImpactRepository;
import fr.bpce.yyd.service.commun.repository.EvenementRecuRepository;
import fr.bpce.yyd.service.commun.repository.IdentiteTiersRepository;
import fr.bpce.yyd.service.commun.repository.ParMdcBqSegRepository;
import fr.bpce.yyd.service.commun.repository.ParMdcSegRepository;
import fr.bpce.yyd.service.commun.repository.StatutTiersRepository;
import fr.bpce.yyd.service.commun.repository.TiersRepository;
import fr.bpce.yyd.service.commun.service.AuditCalculService;
import fr.bpce.yyd.service.commun.service.impl.AuditCalculServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.DefautServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.EvenementCalculeServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.EvenementImpactServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.EvenementRecuServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.IdentiteTiersServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.ParamMdcServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.ParametresNDoDImpl;
import fr.bpce.yyd.service.commun.service.impl.RechercheTiersServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.StatutTiersServiceImpl;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.DemandeEncours;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.TypeAgregat;
import fr.bpce.yyd.service.traitement.evenements.entities.StatutEncoursTiers;
import fr.bpce.yyd.service.traitement.evenements.entities.SuiviDemandeEncours;
import fr.bpce.yyd.service.traitement.evenements.entities.SuiviEncoursTiers;
import fr.bpce.yyd.service.traitement.evenements.kafka.service.KafkaDemandeEncours;
import fr.bpce.yyd.service.traitement.evenements.kafka.service.ProducerLotIdTiers;
import fr.bpce.yyd.service.traitement.evenements.repositories.ElementsDeCalculRepository;
import fr.bpce.yyd.service.traitement.evenements.repositories.EncoursTiersRepository;
import fr.bpce.yyd.service.traitement.evenements.repositories.NotificationEncoursRepository;
import fr.bpce.yyd.service.traitement.evenements.repositories.SuiviDemandeEncoursRepository;
import fr.bpce.yyd.service.traitement.evenements.repositories.SuiviEncoursTiersRepository;
import fr.bpce.yyd.service.traitement.evenements.service.TiersService;

//entityManager.getEntityManager().getTransaction().commit();

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
public class CalculServiceImplIntegrationTest {

	// a ajouter pour debug sur H2 localhost:8082
	// entityManager.getEntityManager().getTransaction().commit();

	@TestConfiguration
	public static class ConfigurationPourTest {

		@SuppressWarnings("unchecked")
		@Bean
		public KafkaTemplate<String, DemandeEncours> demandeEncoursTemplate() {
			return Mockito.mock(KafkaTemplate.class);
		}

		@SuppressWarnings("unchecked")
		@Bean
		public KafkaTemplate<String, LotIdTiersDTO> lotIdTiersTemplate() {
			return Mockito.mock(KafkaTemplate.class);
		}

		@Bean
		public KafkaDemandeEncours producerDemandeEncours() {
			return Mockito.mock(KafkaDemandeEncours.class);
		}

		@Bean
		public ProducerLotIdTiers producerLotIdTiers() {
			return Mockito.mock(ProducerLotIdTiers.class);
		}

	}

	@Autowired
	private TestEntityManager entityManager;

	@Autowired
	private TiersService tiersService;

	@Autowired
	private EvenementCalculeRepository evtCalcRepository;

	@Autowired
	private ElementsDeCalculRepository elemCalcRepository;

	@Autowired
	private EvenementRecuRepository evtRecuRepository;

	@Autowired
	private IdentiteTiersRepository identTiersRepository;

	@Autowired
	private StatutTiersRepository statutTiersRepository;

	@Autowired
	private TiersRepository tiersRepository;

	@Autowired
	private AuditCalculRepository auditCalculRepository;

	@Autowired
	private ParMdcSegRepository parMdcSegRepository;

	@Autowired
	private ParMdcBqSegRepository parMdcBqSegRepository;

	@Autowired
	private EvenementImpactRepository impactRepository;

	@Autowired
	private RefCliSsClassRepository cliSsClassRepository;

	private CalculServiceImpl calculService;

	private EvenementCalculeServiceImpl evtCalculService;

	private DefautServiceImpl defautService;

	private EvenementRecuServiceImpl evtRecuService;

	@Autowired
	private NotificationEncoursRepository repNotificationEncours;

	@Autowired
	private SuiviDemandeEncoursRepository repSuiviDemandeEncours;

	@Autowired
	private KafkaDemandeEncours producerDemandeEncours;

	@Autowired
	private AuditCalculService auditCalculService;

	@Autowired
	SuiviEncoursTiersRepository repSuiviEncoursTiers;

	@Autowired
	private EncoursTiersRepository repEncoursTiers;

	private IdentiteTiersServiceImpl identTiersService;

	@Before
	public void assembleCalculService() {
		MockitoAnnotations.initMocks(this); // This is a key

		CalculServiceImpl csi = new CalculServiceImpl();

		ParamMdcServiceImpl paramService = new ParamMdcServiceImpl();
		paramService.setParMdcBqSegRepository(parMdcBqSegRepository);
		paramService.setParMdcSegRepository(parMdcSegRepository);
		ParametresNDoDImpl parametresNDoD = new ParametresNDoDImpl();
		parametresNDoD.setParamService(paramService);
		csi.setParametresNDoD(parametresNDoD);
		csi.setAuditCalculService(auditCalculService);
		csi.setTiersService(tiersService);

		identTiersService = new IdentiteTiersServiceImpl();
		identTiersService.setIdentTiersRepository(identTiersRepository);

		csi.setIdentiteTiersService(identTiersService);

		RefCliSegServiceImpl cliSegService = new RefCliSegServiceImpl();
		cliSegService.setCliSsClassRepository(cliSsClassRepository);

		IdentiteTiersServiceImpl identTiersService = new IdentiteTiersServiceImpl();
		identTiersService.setIdentTiersRepository(identTiersRepository);

		csi.setIdentiteTiersService(identTiersService);

		AuditCalculServiceImpl acService = new AuditCalculServiceImpl();
		acService.setAuditCalculRepository(auditCalculRepository);

		evtCalculService = new EvenementCalculeServiceImpl();
		evtCalculService.setEvtCalculeRepository(evtCalcRepository);
		evtCalculService.setIdentiteTiersService(identTiersService);
		evtCalculService.setAuditCalculService(acService);
		evtCalculService.setParamsNDoD(parametresNDoD);
		csi.setEvtCalculeService(evtCalculService);
		EncoursServiceImpl encoursService = new EncoursServiceImpl();
		encoursService.setRepNotificationEncours(repNotificationEncours);
		encoursService.setRepSuiviDemandeEncours(repSuiviDemandeEncours);
		encoursService.setProducerDemandeEncours(producerDemandeEncours);
		encoursService.setIdentTiersService(identTiersService);
		encoursService.setRefCliSegService(cliSegService);
		encoursService.setEchangeMocked(true);
		encoursService.setRecalculApresRepEncours(false);
		encoursService.setRepEncoursTiers(repEncoursTiers);
		parametresNDoD.setRefCliSegService(cliSegService);

		StatutTiersServiceImpl statutTiersService = new StatutTiersServiceImpl();
		statutTiersService.setStatutTiersRepository(statutTiersRepository);

		EvenementImpactServiceImpl impactService = new EvenementImpactServiceImpl();
		impactService.setEvenementImpactRepository(impactRepository);

		evtRecuService = new EvenementRecuServiceImpl();
		evtRecuService.setEvtRecuRepository(evtRecuRepository);
		evtRecuService.setImpactService(impactService);
		evtRecuService.setCliSegService(cliSegService);

		csi.setEvtRecuService(evtRecuService);
		csi.setServiceEncours(encoursService);
		csi.setElemCalcRepository(elemCalcRepository);
		csi.setRepEncoursTiers(repEncoursTiers);
		RechercheTiersServiceImpl rechTiersService = new RechercheTiersServiceImpl();
		rechTiersService.setTiersRepository(tiersRepository);

		defautService = new DefautServiceImpl();
		defautService.setEvtCalculeService(evtCalculService);
		defautService.setStatutTiersRepository(statutTiersRepository);
		defautService.setRechercheTiersService(rechTiersService);
		defautService.setIdentiteTiersService(identTiersService);
		defautService.setImpactService(impactService);
		defautService.setRefCliSegService(cliSegService);

		csi.setDefautService(defautService);
		calculService = csi;
	}

	@Test
	public void requeteLectureEvenementsCollectesPourCalcul() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);

		Tiers tiers = new Tiers();

		IdentiteTiers id1 = new IdentiteTiers();
		id1.setCodeBanque("10107"); // Par exemple
		id1.setIdLocal("abcdefg");
		id1.setCodeSegment("1010");
		id1.setDateDebut(LocalDate.now().minusDays(5));
		tiers.addIdentite(id1);

		tiers = entityManager.persistAndFlush(tiers);

		Evenement evtImx = new Evenement();
		evtImx.setCode("IMX");
		evtImx.setIdentiteInitiale(id1);
		ComplementEvenement ceImx = new ComplementEvenement();
		ceImx.setDatePhoto(LocalDate.now());
		ceImx.setDateMaj(ceImx.getDatePhoto().minusDays(2));
		ceImx.setMontantArriere(new BigDecimal("350.00"));
		ceImx.setStatutEvt(StatutEvenement.ACT);
		ceImx.setArriereLitige(false);
		ceImx.setArriereTech(false);
		ceImx.setAuditFichier(fic);
		ceImx.setIdentiteInitiale(id1);
		evtImx.addComplement(ceImx);
		ComplementEvenement ceImx2 = new ComplementEvenement();
		ceImx2.setDatePhoto(LocalDate.now().plusDays(1));
		ceImx2.setDateMaj(ceImx2.getDatePhoto().minusDays(1));
		ceImx.setDateFin(ceImx2.getDatePhoto());
		ceImx2.setMontantArriere(new BigDecimal("450.00"));
		ceImx2.setStatutEvt(StatutEvenement.ACT);
		ceImx2.setArriereLitige(false);
		ceImx2.setArriereTech(false);
		ceImx2.setMiseAJour(true);
		ceImx2.setAuditFichier(fic);
		ceImx2.setIdentiteInitiale(id1);
		evtImx.addComplement(ceImx2);

		entityManager.persist(evtImx);

		Evenement evtDax = new Evenement();
		evtDax.setCode("DAX");
		evtDax.setIdentiteInitiale(id1);
		ComplementEvenement ceDax = new ComplementEvenement();
		ceDax.setDatePhoto(LocalDate.now().minusDays(1));
		ceDax.setDateMaj(ceDax.getDatePhoto().minusDays(1));
		ceDax.setMontantArriere(new BigDecimal("165.50"));
		ceDax.setStatutEvt(StatutEvenement.ACT);
		ceDax.setArriereLitige(false);
		ceDax.setArriereTech(true);
		ceDax.setAuditFichier(fic);
		ceDax.setIdentiteInitiale(id1);
		evtDax.addComplement(ceDax);

		entityManager.persist(evtDax);

		Evenement evtDax2 = new Evenement();
		evtDax2.setCode("DAX");
		evtDax2.setIdentiteInitiale(id1);
		ComplementEvenement ceDax2 = new ComplementEvenement();
		ceDax2.setDatePhoto(LocalDate.now().minusDays(1));
		ceDax2.setDateMaj(ceDax2.getDatePhoto().minusDays(1));
		ceDax2.setMontantArriere(new BigDecimal("260.0"));
		ceDax2.setStatutEvt(StatutEvenement.CLO);
		ceDax2.setArriereLitige(false);
		ceDax2.setArriereTech(false);
		ceDax2.setAuditFichier(fic);
		ceDax2.setIdentiteInitiale(id1);
		evtDax2.addComplement(ceDax2);

		entityManager.persist(evtDax2);

		Evenement evtDefaut = new Evenement();
		evtDefaut.setCode("PCO");
		evtDefaut.setIdentiteInitiale(id1);
		ComplementEvenement ceDefaut = new ComplementEvenement();
		ceDefaut.setDatePhoto(LocalDate.now().minusDays(3));
		ceDefaut.setDateMaj(ceDefaut.getDatePhoto());
		ceDefaut.setMontantArriere(BigDecimal.ZERO);
		ceDefaut.setStatutEvt(StatutEvenement.ACT);
		ceDefaut.setArriereLitige(false);
		ceDefaut.setArriereTech(false);
		ceDefaut.setAuditFichier(fic);
		ceDefaut.setIdentiteInitiale(id1);
		evtDefaut.addComplement(ceDefaut);

		entityManager.persist(evtDefaut);
		entityManager.flush();

		// Act
		LotIdTiersDTO lot = new LotIdTiersDTO(LocalDate.now());
		lot.addIdTiers(tiers.getId());
		Map<Long, List<IdentiteTiers>> identitiesMap = new HashMap<Long, List<IdentiteTiers>>();
		List<IdentiteTiers> identList = new ArrayList<IdentiteTiers>();
		identList.add(id1);
		identitiesMap.put(tiers.getId(), identList);
		Map<Long, EvenementsATraiter> mapEvtsRecus = evtRecuService.rechercheEvenementsATraiterADate(lot,
				identitiesMap);
		EvenementsATraiter complEvts = mapEvtsRecus.get(tiers.getId());

		// Assert
		Assert.assertNotNull(complEvts);
		Assert.assertEquals(3, complEvts.getArrieres().size());
		Assert.assertTrue(complEvts.getArrieres().contains(ceImx));
	}

	@Test
	public void requeteLectureEvenementsCalculesADate() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);

		Tiers tiers = new Tiers();

		IdentiteTiers id1 = new IdentiteTiers();
		id1.setCodeBanque("10107"); // Par exemple
		id1.setCodeSegment("1010");
		id1.setDateDebut(LocalDate.now().minusDays(5));
		tiers.addIdentite(id1);

		ArriereSignificatif as1 = new ArriereSignificatif();
		as1.setDateDebut(LocalDate.now().minusDays(10));
		as1.setDateFin(LocalDate.now().minusDays(7));

		ArriereSignificatif as2 = new ArriereSignificatif();
		as2.setDateDebut(LocalDate.now().minusDays(1));
		as2.setDateFin(LocalDate.now().plusDays(3));

		ArriereSignificatif as3 = new ArriereSignificatif();
		as3.setDateDebut(LocalDate.now().plusDays(5));

		PeriodeProbatoire pp = new PeriodeProbatoire();
		pp.setDateDebut(LocalDate.now().minusDays(4));

		tiers.addEvenementCalcule(as1).addEvenementCalcule(as2).addEvenementCalcule(as3).addEvenementCalcule(pp);

		tiers = entityManager.persistAndFlush(tiers);

		// Act
		List<EvenementCalcule> evtsCalcActifs = evtCalcRepository.rechercheEvenementsCalculesActifsADate(tiers.getId(),
				LocalDate.now());

		// Assert
		Assert.assertNotNull(evtsCalcActifs);
		Assert.assertEquals(2, evtsCalcActifs.size());
		Assert.assertEquals(pp, evtsCalcActifs.get(0));
		Assert.assertEquals(as2, evtsCalcActifs.get(1));
	}

	@Test
	public void creationArriereSignificatifSurIMXInitial() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);

		Tiers tiers = new Tiers();

		IdentiteTiers id1 = new IdentiteTiers();
		id1.setCodeBanque("10107"); // Par exemple
		id1.setIdLocal("abcdefg");
		id1.setCodeSegment("3110"); // PRO
		id1.setDateDebut(LocalDate.now().minusDays(10));
		tiers.addIdentite(id1);

		tiers = entityManager.persistAndFlush(tiers);

		Evenement evtImx = new Evenement();
		evtImx.setCode("IMX");
		evtImx.setIdentiteInitiale(id1);
		evtImx.setDateDebut(LocalDate.now().minusDays(5));
		ComplementEvenement ceImx = new ComplementEvenement();
		ceImx.setDatePhoto(LocalDate.now().minusDays(1));
		ceImx.setDateMaj(evtImx.getDateDebut());
		ceImx.setMontantArriere(new BigDecimal("1550.00"));
		ceImx.setStatutEvt(StatutEvenement.ACT);
		ceImx.setArriereLitige(false);
		ceImx.setArriereTech(false);
		ceImx.setAuditFichier(fic);
		ceImx.setIdentiteInitiale(id1);
		evtImx.addComplement(ceImx);

		entityManager.persist(evtImx);

		entityManager.flush();

		LotIdTiersDTO lot = new LotIdTiersDTO();
		lot.addIdTiers(tiers.getId());

		// Act
		calculService.traiteMessage(lot);

		// Assert
		List<EvenementCalcule> evtsCalcActifs = evtCalcRepository.rechercheEvenementsCalculesActifsADate(tiers.getId(),
				LocalDate.now());
		Assert.assertNotNull(evtsCalcActifs);
		Assert.assertEquals(1, evtsCalcActifs.size());
		ArriereSignificatif as = (ArriereSignificatif) evtsCalcActifs.get(0);
		Assert.assertEquals(evtImx.getDateDebut(), as.getDateDebut());
	}

	@Test
	public void creationArriereSignificatifSurIMXMisAJour() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);

		Tiers tiers = new Tiers();

		IdentiteTiers id1 = new IdentiteTiers();
		id1.setCodeBanque("10107"); // Par exemple
		id1.setIdLocal("abcdefg");
		id1.setCodeSegment("1010"); // CORP
		id1.setDateDebut(LocalDate.now().minusDays(10));
		tiers.addIdentite(id1);

		tiers = entityManager.persistAndFlush(tiers);

		Evenement evtImx = new Evenement();
		evtImx.setCode("IMX");
		evtImx.setIdentiteInitiale(id1);
		evtImx.setDateDebut(LocalDate.now().minusDays(5));
		ComplementEvenement ceImx = new ComplementEvenement();
		ceImx.setDatePhoto(LocalDate.now().minusDays(2));
		ceImx.setDateMaj(evtImx.getDateDebut());
		ceImx.setMontantArriere(new BigDecimal("350.00"));
		ceImx.setStatutEvt(StatutEvenement.ACT);
		ceImx.setArriereLitige(false);
		ceImx.setArriereTech(false);
		ceImx.setAuditFichier(fic);
		ceImx.setIdentiteInitiale(id1);
		evtImx.addComplement(ceImx);

		ComplementEvenement ceImx2 = new ComplementEvenement();
		ceImx2.setDatePhoto(LocalDate.now().minusDays(1));
		ceImx.setDateFin(ceImx2.getDatePhoto());
		ceImx2.setDateMaj(evtImx.getDateDebut());
		ceImx2.setMontantArriere(new BigDecimal("1550.00"));
		ceImx2.setStatutEvt(StatutEvenement.ACT);
		ceImx2.setArriereLitige(false);
		ceImx2.setArriereTech(false);
		ceImx2.setMiseAJour(true);
		ceImx2.setAuditFichier(fic);
		ceImx2.setIdentiteInitiale(id1);
		evtImx.addComplement(ceImx2);

		entityManager.persist(evtImx);

		entityManager.flush();

		LotIdTiersDTO lot = new LotIdTiersDTO();
		lot.addIdTiers(tiers.getId());

		// Act
		calculService.traiteMessage(lot);

		// Assert
		List<EvenementCalcule> evtsCalcActifs = evtCalcRepository.rechercheEvenementsCalculesActifsADate(tiers.getId(),
				LocalDate.now());
		Assert.assertNotNull(evtsCalcActifs);
		Assert.assertEquals(1, evtsCalcActifs.size());
		ArriereSignificatif as = (ArriereSignificatif) evtsCalcActifs.get(0);
		Assert.assertEquals(ceImx2.getDatePhoto(), as.getDateDebut());
	}

	@Test
	public void creationArriereSignificatifSurEvtsMultiples() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);

		Tiers tiers = new Tiers();

		IdentiteTiers id1 = new IdentiteTiers();
		id1.setCodeBanque("10107"); // Par exemple
		id1.setIdLocal("abcdefg");
		id1.setCodeSegment("1010"); // CORP
		id1.setDateDebut(LocalDate.now().minusDays(10));
		tiers.addIdentite(id1);

		tiers = entityManager.persistAndFlush(tiers);

		Evenement evtImx = new Evenement();
		evtImx.setCode("IMX");
		evtImx.setIdentiteInitiale(id1);
		evtImx.setDateDebut(LocalDate.now().minusDays(5));
		ComplementEvenement ceImx = new ComplementEvenement();
		ceImx.setDatePhoto(LocalDate.now().minusDays(1));
		ceImx.setDateMaj(evtImx.getDateDebut());
		ceImx.setMontantArriere(new BigDecimal("850.00"));
		ceImx.setStatutEvt(StatutEvenement.ACT);
		ceImx.setArriereLitige(false);
		ceImx.setArriereTech(false);
		ceImx.setAuditFichier(fic);
		ceImx.setIdentiteInitiale(id1);
		evtImx.addComplement(ceImx);

		entityManager.persist(evtImx);

		Evenement evtDax = new Evenement();
		evtDax.setCode("DAX");
		evtDax.setIdentiteInitiale(id1);
		evtDax.setDateDebut(LocalDate.now().minusDays(2));
		ComplementEvenement ceDax = new ComplementEvenement();
		ceDax.setDatePhoto(LocalDate.now().minusDays(1));
		ceDax.setDateMaj(evtDax.getDateDebut());
		ceDax.setMontantArriere(new BigDecimal("765.50"));
		ceDax.setStatutEvt(StatutEvenement.ACT);
		ceDax.setArriereLitige(false);
		ceDax.setArriereTech(false);
		ceDax.setAuditFichier(fic);
		ceDax.setIdentiteInitiale(id1);
		evtDax.addComplement(ceDax);

		entityManager.persist(evtDax);

		entityManager.flush();

		LotIdTiersDTO lot = new LotIdTiersDTO();
		lot.addIdTiers(tiers.getId());

		// Act
		calculService.traiteMessage(lot);

		// Assert
		List<EvenementCalcule> evtsCalcActifs = evtCalcRepository.rechercheEvenementsCalculesActifsADate(tiers.getId(),
				LocalDate.now());
		Assert.assertNotNull(evtsCalcActifs);
		Assert.assertEquals(1, evtsCalcActifs.size());
		ArriereSignificatif as = (ArriereSignificatif) evtsCalcActifs.get(0);
		Assert.assertEquals(ceDax.getDateMaj(), as.getDateDebut());
		ElementsDeCalcul calc = as.getComplement().getEntree();
		Assert.assertNotNull(calc);
		Assert.assertEquals(0,
				ceImx.getMontantArriere().add(ceDax.getMontantArriere()).compareTo(calc.getMontantAbsolu()));
	}

	@Test
	public void creationPuisClotureArriereSignificatifSurEvtsMultiples() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);

		Tiers tiers = new Tiers();

		IdentiteTiers id1 = new IdentiteTiers();
		id1.setCodeBanque("10107"); // Par exemple
		id1.setIdLocal("abcdefg");
		id1.setCodeSegment("1010"); // CORP
		id1.setDateDebut(LocalDate.now().minusDays(10));
		tiers.addIdentite(id1);

		tiers = entityManager.persistAndFlush(tiers);

		Evenement evtImx = new Evenement();
		evtImx.setCode("IMX");
		evtImx.setIdentiteInitiale(id1);
		evtImx.setDateDebut(LocalDate.now().minusDays(5));
		ComplementEvenement ceImx = new ComplementEvenement();
		ceImx.setDatePhoto(LocalDate.now().minusDays(1));
		ceImx.setDateMaj(evtImx.getDateDebut());
		ceImx.setMontantArriere(new BigDecimal("950.00"));
		ceImx.setStatutEvt(StatutEvenement.ACT);
		ceImx.setArriereLitige(false);
		ceImx.setArriereTech(false);
		ceImx.setAuditFichier(fic);
		ceImx.setIdentiteInitiale(id1);
		evtImx.addComplement(ceImx);

		entityManager.persist(evtImx);

		Evenement evtDax = new Evenement();
		evtDax.setCode("DAX");
		evtDax.setIdentiteInitiale(id1);
		evtDax.setDateDebut(LocalDate.now().minusDays(2));
		ComplementEvenement ceDax = new ComplementEvenement();
		ceDax.setDatePhoto(LocalDate.now().minusDays(1));
		ceDax.setDateMaj(evtDax.getDateDebut());
		ceDax.setMontantArriere(new BigDecimal("565.50"));
		ceDax.setStatutEvt(StatutEvenement.ACT);
		ceDax.setArriereLitige(false);
		ceDax.setArriereTech(false);
		ceDax.setAuditFichier(fic);
		ceDax.setIdentiteInitiale(id1);
		evtDax.addComplement(ceDax);

		entityManager.persist(evtDax);

		entityManager.flush();

		LotIdTiersDTO lot = new LotIdTiersDTO();
		lot.addIdTiers(tiers.getId());
		lot.setDateCalcul(LocalDate.now());

		// Act
		calculService.traiteMessage(lot);

		// Assert
		List<EvenementCalcule> evtsCalcActifs = evtCalcRepository.rechercheEvenementsCalculesActifsADate(tiers.getId(),
				lot.getDateCalcul());
		Assert.assertNotNull(evtsCalcActifs);
		Assert.assertEquals(1, evtsCalcActifs.size());
		ArriereSignificatif as = (ArriereSignificatif) evtsCalcActifs.get(0);
		Assert.assertEquals(ceDax.getDateMaj(), as.getDateDebut());
		ElementsDeCalcul calc = as.getComplement().getEntree();
		Assert.assertNotNull(calc);
		Assert.assertEquals(0,
				ceImx.getMontantArriere().add(ceDax.getMontantArriere()).compareTo(calc.getMontantAbsolu()));

		// Arrange 2 - changement de valeurs sur les montants
		ComplementEvenement ceImx2 = new ComplementEvenement();
		ceImx2.setDatePhoto(LocalDate.now().plusDays(1));
		ceImx.setDateFin(ceImx2.getDatePhoto());
		ceImx2.setDateMaj(evtImx.getDateDebut());
		ceImx2.setMontantArriere(new BigDecimal("250.00"));
		ceImx2.setStatutEvt(StatutEvenement.ACT);
		ceImx2.setArriereLitige(false);
		ceImx2.setArriereTech(false);
		ceImx2.setMiseAJour(true);
		ceImx2.setAuditFichier(fic);
		ceImx2.setIdentiteInitiale(id1);
		evtImx.addComplement(ceImx2);

		entityManager.persist(ceImx2);
		entityManager.flush();

		lot.setDateCalcul(LocalDate.now().plusDays(2));

		// Act 2
		calculService.traiteMessage(lot);

		// Assert
		// La période d'arriéré significatif a été coturée => à date de second
		// calcul,
		// il n'existe plus arriéré significatif.
		List<EvenementCalcule> evtsCalcActifs2 = evtCalcRepository.rechercheEvenementsCalculesActifsADate(tiers.getId(),
				lot.getDateCalcul());
		Assert.assertNotNull(evtsCalcActifs2);
		Assert.assertEquals(0, evtsCalcActifs2.size());

		// En recherchant l'ancien arriéré significatif, on voit sa date de fin
		// correctement valorisée ainsi que son calcul de sortie.
		List<EvenementCalcule> evtsCalcActifsPrealablement = evtCalcRepository
				.rechercheEvenementsCalculesActifsADate(tiers.getId(), LocalDate.now());
		Assert.assertNotNull(evtsCalcActifsPrealablement);
		Assert.assertEquals(1, evtsCalcActifsPrealablement.size());
		ArriereSignificatif asClot = (ArriereSignificatif) evtsCalcActifsPrealablement.get(0);
		Assert.assertEquals(ceDax.getDateMaj(), asClot.getDateDebut());
		Assert.assertEquals(ceImx2.getDatePhoto(), asClot.getDateFin());
		ElementsDeCalcul calcFin = asClot.getComplement().getSortie();
		Assert.assertNotNull(calc);
		Assert.assertEquals(0,
				ceImx2.getMontantArriere().add(ceDax.getMontantArriere()).compareTo(calcFin.getMontantAbsolu()));

	}

	@Test
	public void debutPeriodeProbatoireSurCreationPuisClotureArriereSignificatifSurEvtsMultiples() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);

		Tiers tiers = new Tiers();

		IdentiteTiers id1 = new IdentiteTiers();
		id1.setCodeBanque("10107"); // Par exemple
		id1.setIdLocal("abcdefg");
		id1.setCodeSegment("1010"); // CORP
		id1.setDateDebut(LocalDate.now().minusDays(15));
		tiers.addIdentite(id1);

		tiers = entityManager.persistAndFlush(tiers);

		Evenement evtImx = new Evenement();
		evtImx.setCode("IMX");
		evtImx.setIdentiteInitiale(id1);
		evtImx.setDateDebut(LocalDate.now().minusDays(12));
		ComplementEvenement ceImx = new ComplementEvenement();
		ceImx.setDatePhoto(evtImx.getDateDebut().plusDays(1));
		ceImx.setDateMaj(evtImx.getDateDebut());
		ceImx.setMontantArriere(new BigDecimal("850.00"));
		ceImx.setStatutEvt(StatutEvenement.ACT);
		ceImx.setArriereLitige(false);
		ceImx.setArriereTech(false);
		ceImx.setAuditFichier(fic);
		ceImx.setIdentiteInitiale(id1);
		evtImx.addComplement(ceImx);

		entityManager.persist(evtImx);

		Evenement evtDax = new Evenement();
		evtDax.setCode("DAX");
		evtDax.setIdentiteInitiale(id1);
		evtDax.setDateDebut(LocalDate.now().minusDays(10));
		ComplementEvenement ceDax = new ComplementEvenement();
		ceDax.setDatePhoto(evtDax.getDateDebut().plusDays(1));
		ceDax.setDateMaj(evtDax.getDateDebut());
		ceDax.setMontantArriere(new BigDecimal("765.50"));
		ceDax.setStatutEvt(StatutEvenement.ACT);
		ceDax.setArriereLitige(false);
		ceDax.setArriereTech(false);
		ceDax.setAuditFichier(fic);
		ceDax.setIdentiteInitiale(id1);
		evtDax.addComplement(ceDax);

		entityManager.persist(evtDax);

		entityManager.flush();

		// Act
		LocalDate dateCalc1 = LocalDate.now().minusDays(2);
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalc1);
		lot.addIdTiers(tiers.getId());
		calculService.traiteMessage(lot);

		// Assert
		List<EvenementCalcule> evtsCalcActifs = evtCalcRepository.rechercheEvenementsCalculesActifsADate(tiers.getId(),
				dateCalc1);
		Assert.assertNotNull(evtsCalcActifs);
		Assert.assertEquals(1, evtsCalcActifs.size());
		ArriereSignificatif as = (ArriereSignificatif) evtsCalcActifs.get(0);
		Assert.assertEquals(ceDax.getDateMaj(), as.getDateDebut());
		ElementsDeCalcul calc = as.getComplement().getEntree();
		Assert.assertNotNull(calc);
		Assert.assertEquals(0,
				ceImx.getMontantArriere().add(ceDax.getMontantArriere()).compareTo(calc.getMontantAbsolu()));

		// Arrange 2 - Passage en défaut, puis changement de valeurs sur les montants
		as.getComplement().setDernierEvenementEnvoye(EvenementArriereSignificatif.AR3);
		Map<Long, EvenementsCalculesTiers> evtsCalc = evtCalculService.rechercheEvenementsCalculesActifsADate(lot);

		Map<Long, List<IdentiteTiers>> identitiesMap = new HashMap<Long, List<IdentiteTiers>>();
		List<IdentiteTiers> identList = new ArrayList<IdentiteTiers>();
		identList.add(id1);
		identitiesMap.put(tiers.getId(), identList);
		Map<Long, EvenementsATraiter> evtsRecus = evtRecuService.rechercheEvenementsATraiterADate(lot, identitiesMap);
		Map<Long, List<StatutHistorise>> status = defautService.getStatutsADate(lot);
		Map<Long, List<IdentiteTiers>> identities = identTiersService.rechercheIdentitesActivesADate(lot);
		ContexteCalculTiers.init(evtsRecus, status, identities, evtsCalc);
		defautService.entreeEnDefaut(tiers, LocalDate.now().minusDays(3), new MotifStatutTiers(as), LocalDate.now());
		ContexteCalculTiers.clear();

		ComplementEvenement ceImx2 = new ComplementEvenement();
		ceImx2.setDatePhoto(LocalDate.now().plusDays(1));
		ceImx.setDateFin(ceImx2.getDatePhoto());
		ceImx2.setDateMaj(evtImx.getDateDebut());
		ceImx2.setMontantArriere(new BigDecimal("250.00"));
		ceImx2.setStatutEvt(StatutEvenement.ACT);
		ceImx2.setArriereLitige(false);
		ceImx2.setArriereTech(false);
		ceImx2.setMiseAJour(true);
		ceImx2.setAuditFichier(fic);
		ceImx2.setIdentiteInitiale(id1);
		evtImx.addComplement(ceImx2);

		entityManager.persist(ceImx2);
		entityManager.flush();
		entityManager.detach(as);

		// Act 2
		LocalDate dateCalc2 = LocalDate.now().plusDays(87);
		lot.setDateCalcul(dateCalc2);
		calculService.traiteMessage(lot);

		// Assert
		// La période d'arriéré significatif a été cloturée => à date de second
		// calcul,
		// il n'existe plus arriéré significatif. Mais une période probatoire a été
		// commencée.
		// On vérifie également, en audit, que l'AR3 a été clos à la bonne date.
		Map<Long, EvenementsCalculesTiers> evtsCalc2 = evtCalculService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalcules = evtsCalc2.get(tiers.getId());

		Assert.assertNotNull(evtsCalcules);
		Assert.assertNull(evtsCalcules.getArriereSignigicatif());
		Assert.assertNotNull(evtsCalcules.getPeriodeProbatoire());
		Assert.assertEquals(ceImx2.getDateDebut(), evtsCalcules.getPeriodeProbatoire().getDateDebut());

		ArriereSignificatif asRelu = entityManager.find(ArriereSignificatif.class, as.getId());
		Assert.assertEquals(ceImx2.getDateDebut(), asRelu.getDateFin());
		Assert.assertFalse(asRelu.getAuditCalcul().isEmpty());
		AuditCalcul audit = asRelu.getAuditCalcul().iterator().next();
		Assert.assertEquals(EvenementArriereSignificatif.AR3.name(), audit.getCode());
		Assert.assertEquals(StatutAuditEvenement.CLO, audit.getStatut());
		Assert.assertEquals(ceImx2.getDateDebut(), audit.getDateEffet());
	}

	@Test
	public void retourEnSeinSurCreationPuisClotureArriereSignificatifSurEvtsMultiplesTechnique() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);

		Tiers tiers = new Tiers();

		IdentiteTiers id1 = new IdentiteTiers();
		id1.setCodeBanque("10107"); // Par exemple
		id1.setIdLocal("abcdefg");
		id1.setCodeSegment("1010"); // CORP
		id1.setDateDebut(LocalDate.now().minusDays(15));
		tiers.addIdentite(id1);

		tiers = entityManager.persistAndFlush(tiers);

		Evenement evtImx = new Evenement();
		evtImx.setCode("IMX");
		evtImx.setIdentiteInitiale(id1);
		evtImx.setDateDebut(LocalDate.now().minusDays(12));
		ComplementEvenement ceImx = new ComplementEvenement();
		ceImx.setDatePhoto(evtImx.getDateDebut().plusDays(1));
		ceImx.setDateMaj(evtImx.getDateDebut());
		ceImx.setMontantArriere(new BigDecimal("750.00"));
		ceImx.setStatutEvt(StatutEvenement.ACT);
		ceImx.setArriereLitige(false);
		ceImx.setArriereTech(false);
		ceImx.setAuditFichier(fic);
		ceImx.setIdentiteInitiale(id1);
		evtImx.addComplement(ceImx);

		entityManager.persist(evtImx);

		Evenement evtDax = new Evenement();
		evtDax.setCode("DAX");
		evtDax.setIdentiteInitiale(id1);
		evtDax.setDateDebut(LocalDate.now().minusDays(10));
		ComplementEvenement ceDax = new ComplementEvenement();
		ceDax.setDatePhoto(evtDax.getDateDebut().plusDays(1));
		ceDax.setDateMaj(evtDax.getDateDebut());
		ceDax.setMontantArriere(new BigDecimal("765.50"));
		ceDax.setStatutEvt(StatutEvenement.ACT);
		ceDax.setArriereLitige(false);
		ceDax.setArriereTech(false);
		ceDax.setAuditFichier(fic);
		ceDax.setIdentiteInitiale(id1);
		evtDax.addComplement(ceDax);

		entityManager.persist(evtDax);

		entityManager.flush();

		// Act
		LocalDate dateCalc1 = LocalDate.now().minusDays(2);
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalc1);
		lot.addIdTiers(tiers.getId());
		calculService.traiteMessage(lot);

		// Assert
		List<EvenementCalcule> evtsCalcActifs = evtCalcRepository.rechercheEvenementsCalculesActifsADate(tiers.getId(),
				dateCalc1);
		Assert.assertNotNull(evtsCalcActifs);
		Assert.assertEquals(1, evtsCalcActifs.size());
		ArriereSignificatif as = (ArriereSignificatif) evtsCalcActifs.get(0);
		Assert.assertEquals(ceDax.getDateMaj(), as.getDateDebut());
		ElementsDeCalcul calc = as.getComplement().getEntree();
		Assert.assertNotNull(calc);
		Assert.assertEquals(0,
				ceImx.getMontantArriere().add(ceDax.getMontantArriere()).compareTo(calc.getMontantAbsolu()));

		// Arrange 2 - Passage en défaut, puis changement de valeurs sur les montants
		as.getComplement().setDernierEvenementEnvoye(EvenementArriereSignificatif.AR3);
		Map<Long, EvenementsCalculesTiers> evtsCalc = evtCalculService.rechercheEvenementsCalculesActifsADate(lot);
		Map<Long, List<IdentiteTiers>> identitiesMap = new HashMap<Long, List<IdentiteTiers>>();
		List<IdentiteTiers> identList = new ArrayList<IdentiteTiers>();
		identList.add(id1);
		identitiesMap.put(tiers.getId(), identList);
		Map<Long, EvenementsATraiter> evtsRecus = evtRecuService.rechercheEvenementsATraiterADate(lot, identitiesMap);
		Map<Long, List<StatutHistorise>> status = defautService.getStatutsADate(lot);
		Map<Long, List<IdentiteTiers>> identities = identTiersService.rechercheIdentitesActivesADate(lot);
		ContexteCalculTiers.init(evtsRecus, status, identities, evtsCalc);
		defautService.entreeEnDefaut(tiers, LocalDate.now().minusDays(3), new MotifStatutTiers(as), LocalDate.now());
		ContexteCalculTiers.clear();

		StatutHistorise sTiers = statutTiersRepository.getStatutADate(tiers.getId(), dateCalc1).get(0);
		entityManager.detach(sTiers);

		ComplementEvenement ceImx2 = new ComplementEvenement();
		ceImx2.setDatePhoto(LocalDate.now().plusDays(1));
		ceImx.setDateFin(ceImx2.getDatePhoto());
		ceImx2.setDateMaj(evtImx.getDateDebut());
		ceImx2.setMontantArriere(new BigDecimal("550.00"));
		ceImx2.setStatutEvt(StatutEvenement.ACT);
		ceImx2.setArriereLitige(false);
		ceImx2.setArriereTech(true);
		ceImx2.setMiseAJour(true);
		ceImx2.setAuditFichier(fic);
		ceImx2.setIdentiteInitiale(id1);
		evtImx.addComplement(ceImx2);

		ComplementEvenement ceDax2 = new ComplementEvenement();
		ceDax2.setDatePhoto(LocalDate.now().plusDays(1));
		ceDax.setDateFin(ceDax2.getDatePhoto());
		ceDax2.setDateMaj(evtDax.getDateDebut());
		ceDax2.setMontantArriere(new BigDecimal("165.50"));
		ceDax2.setStatutEvt(StatutEvenement.ACT);
		ceDax2.setArriereLitige(false);
		ceDax2.setArriereTech(true);
		ceDax2.setMiseAJour(true);
		ceDax2.setAuditFichier(fic);
		ceDax2.setIdentiteInitiale(id1);
		evtDax.addComplement(ceDax2);

		entityManager.persist(ceImx2);
		entityManager.persist(ceDax2);
		entityManager.flush();
		entityManager.detach(as);

		// Act 2
		LocalDate dateCalc2 = LocalDate.now().plusDays(87);
		lot.setDateCalcul(dateCalc2);
		calculService.traiteMessage(lot);

		// Assert
		// Le tiers est SAIN
		// le Statut Tiers précédent en défaut à été annulé
		// La période d'arriéré significatif a été cloturée => à date de second
		// calcul,
		// il n'existe plus arriéré significatif.
		// il n'existe pas de PP
		// On vérifie également, en audit, que l'AR3 a été clos à la bonne date.
		List<StatutHistorise> statutCourant = statutTiersRepository.getStatutADate(tiers.getId(), dateCalc2);
		Assert.assertEquals(StatutTiers.SAIN, statutCourant.get(0).getStatut());
		Assert.assertEquals(dateCalc2, statutCourant.get(0).getDateDebut()); // création à la date calcul
		StatutHistorise sTiersRelu = entityManager.find(StatutHistorise.class, sTiers.getId());
		Assert.assertEquals(statutCourant.get(0).getDateDebut(), sTiersRelu.getDateFin());
		Assert.assertTrue(sTiersRelu.getAnnule());

		Map<Long, EvenementsCalculesTiers> evtsCalc2 = evtCalculService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalcules = evtsCalc2.get(tiers.getId());

		Assert.assertNull(evtsCalcules);

		ArriereSignificatif asRelu = entityManager.find(ArriereSignificatif.class, as.getId());
		Assert.assertEquals(dateCalc2, asRelu.getDateFin()); // sur la date calcul
		Assert.assertFalse(asRelu.getAuditCalcul().isEmpty());
		AuditCalcul audit = asRelu.getAuditCalcul().iterator().next();
		Assert.assertEquals(EvenementArriereSignificatif.AR3.name(), audit.getCode());
		Assert.assertEquals(StatutAuditEvenement.CLO, audit.getStatut());
		Assert.assertEquals(dateCalc2, audit.getDateEffet()); // sur la date calcul courante
	}

	@Test
	public void retourEnSeinSurCreationPuisClotureArriereSignificatifSurEvtAnnules() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);

		Tiers tiers = new Tiers();

		IdentiteTiers id1 = new IdentiteTiers();
		id1.setCodeBanque("10107"); // Par exemple
		id1.setIdLocal("abcdefg");
		id1.setCodeSegment("1010"); // CORP
		id1.setDateDebut(LocalDate.now().minusDays(15));
		tiers.addIdentite(id1);

		tiers = entityManager.persistAndFlush(tiers);

		Evenement evtImx = new Evenement();
		evtImx.setCode("IMX");
		evtImx.setIdentiteInitiale(id1);
		evtImx.setDateDebut(LocalDate.now().minusDays(10));
		ComplementEvenement ceImx = new ComplementEvenement();
		ceImx.setDatePhoto(evtImx.getDateDebut().plusDays(1));
		ceImx.setDateMaj(evtImx.getDateDebut());
		ceImx.setMontantArriere(new BigDecimal("1550.00"));
		ceImx.setStatutEvt(StatutEvenement.ACT);
		ceImx.setArriereLitige(false);
		ceImx.setArriereTech(false);
		ceImx.setAuditFichier(fic);
		ceImx.setIdentiteInitiale(id1);
		evtImx.addComplement(ceImx);

		entityManager.persist(evtImx);

		Evenement evtDax = new Evenement();
		evtDax.setCode("DAX");
		evtDax.setIdentiteInitiale(id1);
		evtDax.setDateDebut(LocalDate.now().minusDays(10));
		ComplementEvenement ceDax = new ComplementEvenement();
		ceDax.setDatePhoto(evtDax.getDateDebut().plusDays(1));
		ceDax.setDateMaj(evtDax.getDateDebut());
		ceDax.setMontantArriere(new BigDecimal("365.50"));
		ceDax.setStatutEvt(StatutEvenement.ACT);
		ceDax.setArriereLitige(false);
		ceDax.setArriereTech(false);
		ceDax.setAuditFichier(fic);
		ceDax.setIdentiteInitiale(id1);
		evtDax.addComplement(ceDax);

		entityManager.persist(evtDax);

		entityManager.flush();

		// Act
		LocalDate dateCalc1 = LocalDate.now().minusDays(2);
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalc1);
		lot.addIdTiers(tiers.getId());
		calculService.traiteMessage(lot);

		// Assert
		List<EvenementCalcule> evtsCalcActifs = evtCalcRepository.rechercheEvenementsCalculesActifsADate(tiers.getId(),
				dateCalc1);
		Assert.assertNotNull(evtsCalcActifs);
		Assert.assertEquals(1, evtsCalcActifs.size());
		ArriereSignificatif as = (ArriereSignificatif) evtsCalcActifs.get(0);
		Assert.assertEquals(ceDax.getDateMaj(), as.getDateDebut());
		ElementsDeCalcul calc = as.getComplement().getEntree();
		Assert.assertNotNull(calc);
		Assert.assertEquals(0,
				ceImx.getMontantArriere().add(ceDax.getMontantArriere()).compareTo(calc.getMontantAbsolu()));

		// Arrange 2 - Passage en défaut, puis changement de valeurs sur les montants
		as.getComplement().setDernierEvenementEnvoye(EvenementArriereSignificatif.AR3);

		Map<Long, EvenementsCalculesTiers> evtsCalc = evtCalculService.rechercheEvenementsCalculesActifsADate(lot);
		Map<Long, List<IdentiteTiers>> identitiesMap = new HashMap<Long, List<IdentiteTiers>>();
		List<IdentiteTiers> identList = new ArrayList<IdentiteTiers>();
		identList.add(id1);
		identitiesMap.put(tiers.getId(), identList);
		Map<Long, EvenementsATraiter> evtsRecus = evtRecuService.rechercheEvenementsATraiterADate(lot, identitiesMap);
		Map<Long, List<StatutHistorise>> status = defautService.getStatutsADate(lot);
		Map<Long, List<IdentiteTiers>> identities = identTiersService.rechercheIdentitesActivesADate(lot);
		ContexteCalculTiers.init(evtsRecus, status, identities, evtsCalc);
		defautService.entreeEnDefaut(tiers, dateCalc1, new MotifStatutTiers(as), LocalDate.now());
		ContexteCalculTiers.clear();

		StatutHistorise sTiers = statutTiersRepository.getStatutADate(tiers.getId(), dateCalc1).get(0);
		entityManager.detach(sTiers);

		ComplementEvenement ceImx2 = new ComplementEvenement();
		ceImx2.setDatePhoto(LocalDate.now().plusDays(1));
		ceImx.setDateFin(ceImx2.getDatePhoto());
		ceImx2.setDateMaj(evtImx.getDateDebut());
		ceImx2.setMontantArriere(new BigDecimal("1550.00"));
		ceImx2.setStatutEvt(StatutEvenement.ANN);
		ceImx2.setArriereLitige(false);
		ceImx2.setArriereTech(false);
		ceImx2.setMiseAJour(true);
		ceImx2.setAuditFichier(fic);
		ceImx2.setIdentiteInitiale(id1);
		evtImx.addComplement(ceImx2);

		ComplementEvenement ceDax2 = new ComplementEvenement();
		ceDax2.setDatePhoto(LocalDate.now().plusDays(1));
		ceDax.setDateFin(ceDax2.getDatePhoto());
		ceDax2.setDateMaj(evtDax.getDateDebut());
		ceDax2.setMontantArriere(new BigDecimal("365.50"));
		ceDax2.setStatutEvt(StatutEvenement.ANN);
		ceDax2.setArriereLitige(false);
		ceDax2.setArriereTech(false);
		ceDax2.setMiseAJour(true);
		ceDax2.setAuditFichier(fic);
		ceDax2.setIdentiteInitiale(id1);
		evtDax.addComplement(ceDax2);

		entityManager.persist(ceImx2);
		entityManager.persist(ceDax2);
		entityManager.flush();
		entityManager.detach(as);

		// Act 2
		LocalDate dateCalc2 = LocalDate.now().plusDays(87);
		lot.setDateCalcul(dateCalc2);
		calculService.traiteMessage(lot);

		// Assert
		// Le tiers est SAIN
		// le Statut Tiers précédent en défaut à été annulé
		// La période d'arriéré significatif a été cloturée => à date de second
		// calcul,
		// il n'existe plus arriéré significatif.
		// il n'existe pas de PP
		// On vérifie également, en audit, que l'AR3 a été clos à la bonne date.

		List<StatutHistorise> statutCourant = statutTiersRepository.getStatutADate(tiers.getId(), dateCalc2);

		Assert.assertEquals(StatutTiers.SAIN, statutCourant.get(0).getStatut());
		Assert.assertEquals(dateCalc2, statutCourant.get(0).getDateDebut()); // le statut commence à la date du
																				// calcul
		StatutHistorise sTiersRelu = entityManager.find(StatutHistorise.class, sTiers.getId());
		Assert.assertEquals(statutCourant.get(0).getDateDebut(), sTiersRelu.getDateFin());
		Assert.assertTrue(sTiersRelu.getAnnule());

		Map<Long, EvenementsCalculesTiers> evtsCalc2 = evtCalculService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalcules2 = evtsCalc2.get(tiers.getId());
		Assert.assertNull(evtsCalcules2);

		ArriereSignificatif asRelu = entityManager.find(ArriereSignificatif.class, as.getId());
		Assert.assertEquals(dateCalc2, asRelu.getDateFin()); // l'AS se cloture à la date du calcul
		Assert.assertFalse(asRelu.getAuditCalcul().isEmpty());
		AuditCalcul audit = asRelu.getAuditCalcul().iterator().next();
		Assert.assertEquals(EvenementArriereSignificatif.AR3.name(), audit.getCode());
		Assert.assertEquals(StatutAuditEvenement.CLO, audit.getStatut());
		Assert.assertEquals(dateCalc2, audit.getDateEffet());// l'audit se cloture à la date du calcul
	}

	@Test
	public void retourEnSainSurCreationPuisClotureArriereSignificatifSurEvtUniqueLitige() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);

		Tiers tiers = new Tiers();

		IdentiteTiers id1 = new IdentiteTiers();
		id1.setCodeBanque("10107"); // Par exemple
		id1.setIdLocal("abcdefg");
		id1.setCodeSegment("1010"); // CORP
		id1.setDateDebut(LocalDate.now().minusDays(100));
		tiers.addIdentite(id1);

		tiers = entityManager.persistAndFlush(tiers);

		Evenement evtImx = new Evenement();
		evtImx.setCode("IMX");
		evtImx.setIdentiteInitiale(id1);
		evtImx.setDateDebut(LocalDate.now().minusDays(95));
		ComplementEvenement ceImx = new ComplementEvenement();
		ceImx.setDatePhoto(evtImx.getDateDebut().plusDays(1));
		ceImx.setDateMaj(evtImx.getDateDebut());
		ceImx.setMontantArriere(new BigDecimal("1500.00"));
		ceImx.setStatutEvt(StatutEvenement.ACT);
		ceImx.setArriereLitige(false);
		ceImx.setArriereTech(false);
		ceImx.setAuditFichier(fic);
		ceImx.setIdentiteInitiale(id1);
		evtImx.addComplement(ceImx);

		entityManager.persist(evtImx);
		entityManager.flush();

		// Act
		LocalDate dateCalc1 = LocalDate.now().minusDays(2);
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalc1);
		lot.addIdTiers(tiers.getId());
		calculService.traiteMessage(lot);

		// Assert
		List<EvenementCalcule> evtsCalcActifs = evtCalcRepository.rechercheEvenementsCalculesActifsADate(tiers.getId(),
				dateCalc1);
		Assert.assertNotNull(evtsCalcActifs);
		Assert.assertEquals(1, evtsCalcActifs.size());
		ArriereSignificatif as = (ArriereSignificatif) evtsCalcActifs.get(0);
		ElementsDeCalcul calc = as.getComplement().getEntree();
		Assert.assertNotNull(calc);

		// Arrange 2 - Passage en défaut, puis changement de valeurs sur les montants
		as.getComplement().setDernierEvenementEnvoye(EvenementArriereSignificatif.AR3);
		Map<Long, EvenementsCalculesTiers> evtsCalc = evtCalculService.rechercheEvenementsCalculesActifsADate(lot);
		Map<Long, List<IdentiteTiers>> identitiesMap = new HashMap<Long, List<IdentiteTiers>>();
		List<IdentiteTiers> identList = new ArrayList<IdentiteTiers>();
		identList.add(id1);
		identitiesMap.put(tiers.getId(), identList);
		Map<Long, EvenementsATraiter> evtsRecus = evtRecuService.rechercheEvenementsATraiterADate(lot, identitiesMap);
		Map<Long, List<StatutHistorise>> status = defautService.getStatutsADate(lot);
		Map<Long, List<IdentiteTiers>> identities = identTiersService.rechercheIdentitesActivesADate(lot);
		ContexteCalculTiers.init(evtsRecus, status, identities, evtsCalc);
		defautService.entreeEnDefaut(tiers, LocalDate.now().minusDays(3), new MotifStatutTiers(as), LocalDate.now());
		ContexteCalculTiers.clear();

		StatutHistorise sTiers = statutTiersRepository.getStatutADate(tiers.getId(), dateCalc1).get(0);
		entityManager.detach(sTiers);

		ComplementEvenement ceImx2 = new ComplementEvenement();
		ceImx2.setDatePhoto(LocalDate.now().plusDays(1));
		ceImx.setDateFin(ceImx2.getDatePhoto());
		ceImx2.setDateMaj(evtImx.getDateDebut());
		ceImx2.setMontantArriere(new BigDecimal("1000.00"));
		ceImx2.setStatutEvt(StatutEvenement.ACT);
		ceImx2.setArriereLitige(true);
		ceImx2.setArriereTech(false);
		ceImx2.setMiseAJour(true);
		ceImx2.setAuditFichier(fic);
		ceImx2.setIdentiteInitiale(id1);
		evtImx.addComplement(ceImx2);

		entityManager.persist(ceImx2);
		entityManager.flush();
		entityManager.detach(as);

		// Act 2
		LocalDate dateCalc2 = LocalDate.now().plusDays(87);
		lot.setDateCalcul(dateCalc2);
		calculService.traiteMessage(lot);

		// Assert
		// Le tiers est SAIN
		// le Statut Tiers précédent en défaut à été annulé
		// La période d'arriéré significatif a été cloturée => à date de second
		// calcul,
		// il n'existe plus arriéré significatif.
		// il n'existe pas de PP
		// On vérifie également, en audit, que l'AR3 a été clos à la bonne date.
		List<StatutHistorise> statutCourant = statutTiersRepository.getStatutADate(tiers.getId(), dateCalc2);
		Assert.assertEquals(StatutTiers.SAIN, statutCourant.get(0).getStatut());
		Assert.assertEquals(dateCalc2, statutCourant.get(0).getDateDebut()); // création à la date calcul
		StatutHistorise sTiersRelu = entityManager.find(StatutHistorise.class, sTiers.getId());
		Assert.assertEquals(statutCourant.get(0).getDateDebut(), sTiersRelu.getDateFin());
		Assert.assertTrue(sTiersRelu.getAnnule());

		Map<Long, EvenementsCalculesTiers> evtsCalc2 = evtCalculService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalcules = evtsCalc2.get(tiers.getId());

		Assert.assertNull(evtsCalcules);

		ArriereSignificatif asRelu = entityManager.find(ArriereSignificatif.class, as.getId());
		Assert.assertEquals(dateCalc2, asRelu.getDateFin()); // sur la date calcul
		Assert.assertFalse(asRelu.getAuditCalcul().isEmpty());
		AuditCalcul audit = asRelu.getAuditCalcul().iterator().next();
		Assert.assertEquals(EvenementArriereSignificatif.AR3.name(), audit.getCode());
		Assert.assertEquals(StatutAuditEvenement.CLO, audit.getStatut());
		Assert.assertEquals(dateCalc2, audit.getDateEffet()); // sur date calcul
	}

	@Test
	public void debutPeriodeProbatoireSurCreationPuisClotureUTP() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);

		Tiers tiers = new Tiers();

		IdentiteTiers id1 = new IdentiteTiers();
		id1.setCodeBanque("10107"); // Par exemple
		id1.setIdLocal("abcdefg");
		id1.setCodeSegment("3110");
		id1.setDateDebut(LocalDate.now().minusDays(100));
		tiers.addIdentite(id1);

		tiers = entityManager.persistAndFlush(tiers);

		Evenement evtDefaut = new Evenement();
		evtDefaut.setCode("PCO");
		evtDefaut.setIdentiteInitiale(id1);
		ComplementEvenement ceDefaut = new ComplementEvenement();
		ceDefaut.setDatePhoto(LocalDate.now().minusDays(3));
		ceDefaut.setDateMaj(ceDefaut.getDatePhoto().minusDays(1));
		ceDefaut.setMontantArriere(BigDecimal.ZERO);
		ceDefaut.setStatutEvt(StatutEvenement.ACT);
		ceDefaut.setArriereLitige(false);
		ceDefaut.setArriereTech(false);
		ceDefaut.setAuditFichier(fic);
		ceDefaut.setIdentiteInitiale(id1);
		evtDefaut.addComplement(ceDefaut);

		entityManager.persist(evtDefaut);

		// REF IMPACT EVT MDC
		RefImpactEvtMdc refImpact = new RefImpactEvtMdc();
		refImpact.setCodEvt("PCO");
		refImpact.setCategorieSegment(Constant.TOUS_AUTRES);
		refImpact.setImpact("D");
		refImpact.setGraviteImpact("CX");
		refImpact.setDateDebut(LocalDate.now().minusDays(100));
		entityManager.persist(refImpact);

		// REF_CLI_SEG
		RefCliSeg refCliSeg = new RefCliSeg();
		refCliSeg.setCodSegCli("3110");
		refCliSeg.setLibSegCli("PARTICULIERS");
		refCliSeg.setCodSsClassCli("RETPAR");
		refCliSeg.setTopSuppr("N");
		entityManager.persist(refCliSeg);

		// REF_CLI_SS_CLASS
		RefCliSsClass refClassSsClass = new RefCliSsClass();
		refClassSsClass.setCodSsClassCli("RETPAR");
		refClassSsClass.setLibSsClassCli("PARTICULIERS");
		refClassSsClass.setCodClassCli("RET");
		refClassSsClass.setTopSuppr("N");
		refClassSsClass.setCodTypNot("PART");
		entityManager.persist(refClassSsClass);

		entityManager.flush();

		// Act
		LocalDate dateCalc1 = LocalDate.now().minusDays(2);
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalc1);
		lot.addIdTiers(tiers.getId());
		calculService.traiteMessage(lot);

		// Assert
		List<StatutHistorise> optStatut = statutTiersRepository.getStatutADate(tiers.getId(), dateCalc1);
		Assert.assertFalse(optStatut.isEmpty());
		Assert.assertEquals(StatutTiers.DEFAUT, optStatut.get(0).getStatut());
		Assert.assertEquals(ceDefaut.getDateMaj(), optStatut.get(0).getDateDebut());
		String oldGravite = optStatut.get(0).getGravite();

		// Arrange 2 - Passage en défaut, puis changement de valeurs sur les montants
		ComplementEvenement ceDefaut2 = new ComplementEvenement();
		ceDefaut2.setDatePhoto(LocalDate.now().plusDays(1));
		ceDefaut2.setDateMaj(LocalDate.now());
		ceDefaut2.setMontantArriere(BigDecimal.ZERO);
		ceDefaut2.setStatutEvt(StatutEvenement.CLO);
		ceDefaut2.setArriereLitige(false);
		ceDefaut2.setArriereTech(false);
		ceDefaut2.setMiseAJour(true);
		ceDefaut2.setAuditFichier(fic); // Pour en avoir un, même si ça n'est pas correct
		ceDefaut2.setIdentiteInitiale(id1);
		ceDefaut2.setEvenement(evtDefaut);
		ceDefaut.setDateFin(ceDefaut2.getDateDebut());

		entityManager.persist(ceDefaut2);

		entityManager.flush();

		// Act 2
		LocalDate dateCalc2 = LocalDate.now().plusDays(2);
		lot.setDateCalcul(dateCalc2);
		calculService.traiteMessage(lot);

		optStatut = statutTiersRepository.getStatutADate(tiers.getId(), dateCalc2);
		String newGravite = optStatut.get(0).getGravite();

		// Assert
		// L'UTP a été cloturée => une période probatoire a été commencée.
		Map<Long, EvenementsCalculesTiers> evtsCalcs = evtCalculService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalcules = evtsCalcs.get(tiers.getId());
		Assert.assertNotNull(evtsCalcules);
		Assert.assertNotNull(evtsCalcules.getPeriodeProbatoire());
		Assert.assertEquals(ceDefaut2.getDateDebut(), evtsCalcules.getPeriodeProbatoire().getDateDebut());
		Assert.assertEquals(newGravite, oldGravite);
	}

	@Test
	public void retourEnSainSurCreationPuisAnnulationUTP() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);
		Tiers tiers = new Tiers();

		IdentiteTiers id1 = new IdentiteTiers();
		id1.setCodeBanque("10107"); // Par exemple
		id1.setIdLocal("abcdefg");
		id1.setCodeSegment("3110");
		id1.setDateDebut(LocalDate.now().minusDays(100));
		tiers.addIdentite(id1);
		tiers = entityManager.persistAndFlush(tiers);

		Evenement evtDefaut = new Evenement();
		evtDefaut.setCode("PCO");
		evtDefaut.setIdentiteInitiale(id1);
		ComplementEvenement ceDefaut = new ComplementEvenement();
		ceDefaut.setDatePhoto(LocalDate.now().minusDays(3));
		ceDefaut.setDateMaj(ceDefaut.getDatePhoto().minusDays(1));
		ceDefaut.setMontantArriere(BigDecimal.ZERO);
		ceDefaut.setStatutEvt(StatutEvenement.ACT);
		ceDefaut.setArriereLitige(false);
		ceDefaut.setArriereTech(false);
		ceDefaut.setAuditFichier(fic);
		ceDefaut.setIdentiteInitiale(id1);
		evtDefaut.addComplement(ceDefaut);

		entityManager.persist(evtDefaut);

		// REF IMPACT EVT MDC
		RefImpactEvtMdc refImpact = new RefImpactEvtMdc();
		refImpact.setCodEvt("PCO");
		refImpact.setCategorieSegment(Constant.TOUS_AUTRES);
		refImpact.setImpact("D");
		refImpact.setGraviteImpact("CX");
		refImpact.setDateDebut(LocalDate.now().minusDays(100));
		entityManager.persist(refImpact);

		// REF_CLI_SEG
		RefCliSeg refCliSeg = new RefCliSeg();
		refCliSeg.setCodSegCli("3110");
		refCliSeg.setLibSegCli("PARTICULIERS");
		refCliSeg.setCodSsClassCli("RETPAR");
		refCliSeg.setTopSuppr("N");
		entityManager.persist(refCliSeg);

		// REF_CLI_SS_CLASS
		RefCliSsClass refClassSsClass = new RefCliSsClass();
		refClassSsClass.setCodSsClassCli("RETPAR");
		refClassSsClass.setLibSsClassCli("PARTICULIERS");
		refClassSsClass.setCodClassCli("RET");
		refClassSsClass.setTopSuppr("N");
		refClassSsClass.setCodTypNot("PART");
		entityManager.persist(refClassSsClass);

		entityManager.flush();

		// entityManager.getEntityManager().getTransaction().commit();

		// Act
		LocalDate dateCalc1 = LocalDate.now().minusDays(2);
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalc1);
		lot.addIdTiers(tiers.getId());
		calculService.traiteMessage(lot);

		// Assert
		List<StatutHistorise> optStatut = statutTiersRepository.getStatutADate(tiers.getId(), dateCalc1);
		Assert.assertFalse(optStatut.isEmpty());
		Assert.assertEquals(StatutTiers.DEFAUT, optStatut.get(0).getStatut());
		Assert.assertEquals(ceDefaut.getDateMaj(), optStatut.get(0).getDateDebut());

		// Arrange 2 - Passage en défaut, puis changement de valeurs sur les montants
		ComplementEvenement ceDefaut2 = new ComplementEvenement();
		ceDefaut2.setDatePhoto(LocalDate.now().plusDays(1));
		ceDefaut2.setDateMaj(LocalDate.now());
		ceDefaut2.setMontantArriere(BigDecimal.ZERO);
		ceDefaut2.setStatutEvt(StatutEvenement.ANN);
		ceDefaut2.setArriereLitige(false);
		ceDefaut2.setArriereTech(false);
		ceDefaut2.setMiseAJour(true);
		ceDefaut2.setAuditFichier(fic); // Pour en avoir un, même si ça n'est pas correct
		ceDefaut2.setIdentiteInitiale(id1);
		ceDefaut2.setEvenement(evtDefaut);
		ceDefaut.setDateFin(ceDefaut2.getDateDebut());

		entityManager.persist(ceDefaut2);

		entityManager.flush();

		// Act 2
		LocalDate dateCalc2 = LocalDate.now().plusDays(2);
		lot.setDateCalcul(dateCalc2);
		calculService.traiteMessage(lot);

		// Assert
		// Tier sain
		// le Statut Tiers précédent en défaut à été annulé
		// L'UTP a été cloturée => pas de PP.
		List<StatutHistorise> statutCourant = statutTiersRepository.getStatutADate(tiers.getId(), dateCalc2);
		Assert.assertEquals(StatutTiers.SAIN, statutCourant.get(0).getStatut());
		Assert.assertEquals(dateCalc2, statutCourant.get(0).getDateDebut()); // début du statut a la date du calcul
		StatutHistorise sTiersRelu = entityManager.find(StatutHistorise.class, optStatut.get(0).getId());
		Assert.assertEquals(statutCourant.get(0).getDateDebut(), sTiersRelu.getDateFin());
		Assert.assertTrue(sTiersRelu.getAnnule());

		EvenementsCalculesTiers evtsCalcules = evtCalculService.rechercheEvenementsCalculesActifsADate(tiers.getId(),
				dateCalc2);
		Assert.assertNotNull(evtsCalcules);
		Assert.assertNull(evtsCalcules.getPeriodeProbatoire());
	}

	@Test
	public void multiUTP() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);

		Tiers tiers = new Tiers();

		IdentiteTiers id1 = new IdentiteTiers();
		id1.setCodeBanque("10107"); // Par exemple
		id1.setIdLocal("abcdefg");
		id1.setCodeSegment("3110");
		id1.setDateDebut(LocalDate.now().minusDays(100));
		tiers.addIdentite(id1);

		tiers = entityManager.persistAndFlush(tiers);

		Evenement evtDefaut = new Evenement();
		evtDefaut.setCode("PCO");
		evtDefaut.setIdentiteInitiale(id1);
		ComplementEvenement ceDefaut = new ComplementEvenement();
		ceDefaut.setDatePhoto(LocalDate.now().minusDays(3));
		ceDefaut.setDateMaj(ceDefaut.getDatePhoto().minusDays(1));
		ceDefaut.setMontantArriere(BigDecimal.ZERO);
		ceDefaut.setStatutEvt(StatutEvenement.ACT);
		ceDefaut.setArriereLitige(false);
		ceDefaut.setArriereTech(false);
		ceDefaut.setAuditFichier(fic);
		ceDefaut.setIdentiteInitiale(id1);
		evtDefaut.addComplement(ceDefaut);

		entityManager.persist(evtDefaut);

		// REF IMPACT EVT MDC
		RefImpactEvtMdc refImpact = new RefImpactEvtMdc();
		refImpact.setCodEvt("PCO");
		refImpact.setCategorieSegment(Constant.TOUS_AUTRES);
		refImpact.setImpact("D");
		refImpact.setGraviteImpact("CX");
		refImpact.setDateDebut(LocalDate.now().minusDays(100));
		entityManager.persist(refImpact);

		// REF_CLI_SEG
		RefCliSeg refCliSeg = new RefCliSeg();
		refCliSeg.setCodSegCli("3110");
		refCliSeg.setLibSegCli("PARTICULIERS");
		refCliSeg.setCodSsClassCli("RETPAR");
		refCliSeg.setTopSuppr("N");
		entityManager.persist(refCliSeg);

		// REF_CLI_SS_CLASS
		RefCliSsClass refClassSsClass = new RefCliSsClass();
		refClassSsClass.setCodSsClassCli("RETPAR");
		refClassSsClass.setLibSsClassCli("PARTICULIERS");
		refClassSsClass.setCodClassCli("RET");
		refClassSsClass.setTopSuppr("N");
		refClassSsClass.setCodTypNot("PART");
		entityManager.persist(refClassSsClass);

		entityManager.flush();

		// Act
		LocalDate dateCalc1 = LocalDate.now().minusDays(2);
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalc1);
		lot.addIdTiers(tiers.getId());
		calculService.traiteMessage(lot);

		// Assert
		List<StatutHistorise> optStatut = statutTiersRepository.getStatutADate(tiers.getId(), dateCalc1);
		Assert.assertFalse(optStatut.isEmpty());
		Assert.assertEquals(StatutTiers.DEFAUT, optStatut.get(0).getStatut());
		Assert.assertEquals(ceDefaut.getDateMaj(), optStatut.get(0).getDateDebut());

		// Arrange 2 - Second UTP
		Evenement evtDefaut2 = new Evenement();
		evtDefaut2.setCode("PCO");
		evtDefaut2.setIdentiteInitiale(id1);
		ComplementEvenement ceDefaut2 = new ComplementEvenement();
		ceDefaut2.setDatePhoto(LocalDate.now());
		ceDefaut2.setDateMaj(ceDefaut2.getDatePhoto().minusDays(1));
		ceDefaut2.setMontantArriere(BigDecimal.ZERO);
		ceDefaut2.setStatutEvt(StatutEvenement.ACT);
		ceDefaut2.setArriereLitige(false);
		ceDefaut2.setArriereTech(false);
		ceDefaut2.setAuditFichier(fic);
		ceDefaut2.setIdentiteInitiale(id1);
		evtDefaut2.addComplement(ceDefaut2);

		entityManager.persist(evtDefaut2);

		entityManager.flush();

		// Act 2
		LocalDate dateCalc2 = LocalDate.now().plusDays(2);
		lot.setDateCalcul(dateCalc2);
		calculService.traiteMessage(lot);

		// Assert
		// Tiers en défaut avec deux statuts
		List<StatutHistorise> statutsCourants = statutTiersRepository.getStatutADate(tiers.getId(), dateCalc2);
		Assert.assertEquals(2, statutsCourants.size());
		Assert.assertEquals(StatutTiers.DEFAUT, statutsCourants.get(0).getStatut());
		Assert.assertEquals("PCO", statutsCourants.get(0).getMotif().getMotif());
		Assert.assertEquals(StatutTiers.DEFAUT, statutsCourants.get(1).getStatut());
		Assert.assertEquals("PCO", statutsCourants.get(1).getMotif().getMotif());

	}

	@Test
	public void clotureTiers() {

		// Arrange
		Tiers tiers = new Tiers();
		entityManager.persist(tiers);

		ArriereSignificatif as = new ArriereSignificatif();
		as.setDateDebut(LocalDate.of(2019, 8, 3));
		as.setTiers(tiers);
		entityManager.persist(as);

		AuditCalcul auditCalcul = new AuditCalcul();
		auditCalcul.setCode("AR3");
		auditCalcul.setDateGeneration(LocalDateTime.now());
		auditCalcul.setDateEffet(LocalDate.of(2019, 8, 3));
		auditCalcul.setEvenementCalcule(as);
		auditCalcul.setStatut(StatutAuditEvenement.ACT);
		entityManager.persist(auditCalcul);

		StatutHistorise statusTiers = new StatutHistorise();
		statusTiers.setStatut(StatutTiers.SAIN);
		statusTiers.setAnnule(Boolean.FALSE);
		statusTiers.setDateDeb(LocalDate.of(2019, 8, 3));
		statusTiers.setTiers(tiers);
		entityManager.persist(statusTiers);

		LotIdTiersDTO lotIdTiersDTO = new LotIdTiersDTO();
		lotIdTiersDTO.setDateCalcul(LocalDate.of(2019, 9, 3));
		lotIdTiersDTO.addIdTiers(tiers.getId());

		// Act
		calculService.traiteMessageCloture(lotIdTiersDTO);

		// Assert
		statusTiers.setDateFin(LocalDate.of(2019, 9, 3));
		Optional<StatutHistorise> statusTiersOptional = statutTiersRepository.findById(statusTiers.getId());
		Assert.assertTrue(statusTiersOptional.isPresent());
		StatutHistorise statusTiersActual = statusTiersOptional.get();
		Assert.assertEquals(statusTiers, statusTiersActual);

		as.setDateFin(LocalDate.of(2019, 9, 3));
		Optional<EvenementCalcule> asOptional = evtCalcRepository.findById(as.getId());
		Assert.assertTrue(asOptional.isPresent());
		EvenementCalcule asActual = asOptional.get();
		Assert.assertEquals(as, asActual);

		Iterable<AuditCalcul> auditCalculs = auditCalculRepository.findAll();
		for (AuditCalcul auditCalculItem : auditCalculs) {
			if (auditCalculItem.getId() == auditCalcul.getId()) {
				Assert.assertEquals(auditCalcul, auditCalculItem);
			} else {
				Assert.assertEquals("AR3", auditCalculItem.getCode());
				Assert.assertEquals(StatutAuditEvenement.CLO, auditCalculItem.getStatut());
				Assert.assertEquals(LocalDate.of(2019, 9, 3), auditCalculItem.getDateEffet());
				Assert.assertEquals(tiers.getId(), auditCalculItem.getIdTiers());
			}
		}
	}

	@Test
	public void initStatutSain() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);

		Tiers tiers = new Tiers();

		IdentiteTiers id = new IdentiteTiers();
		id.setCodeBanque("10107"); // Par exemple
		id.setIdLocal("abcdefg");
		id.setCodeSegment("3120"); // PRO
		id.setDateDebut(LocalDate.now().minusDays(20));
		id.setDateFin(LocalDate.now().minusDays(10));
		tiers.addIdentite(id);
		IdentiteTiers id1 = new IdentiteTiers();
		id1.setCodeBanque("10107"); // Par exemple
		id1.setIdLocal("abcdefg");
		id1.setCodeSegment("3110"); // PRO
		id1.setDateDebut(LocalDate.now().minusDays(10));
		id.setSuivante(id1);
		tiers.addIdentite(id1);
		tiers = entityManager.persistAndFlush(tiers);

		Evenement evtImx = new Evenement();
		evtImx.setCode("IMX");
		evtImx.setIdentiteInitiale(id);
		evtImx.setDateDebut(LocalDate.now().minusDays(5));
		ComplementEvenement ceImx = new ComplementEvenement();
		ceImx.setDatePhoto(LocalDate.now().minusDays(1));
		ceImx.setDateMaj(evtImx.getDateDebut());
		ceImx.setMontantArriere(new BigDecimal("15.00"));
		ceImx.setStatutEvt(StatutEvenement.ACT);
		ceImx.setArriereLitige(false);
		ceImx.setArriereTech(false);
		ceImx.setAuditFichier(fic);
		ceImx.setIdentiteInitiale(id);
		evtImx.addComplement(ceImx);

		entityManager.persist(evtImx);

		entityManager.flush();

		// Act
		LotIdTiersDTO lot = new LotIdTiersDTO(LocalDate.now());
		lot.addIdTiers(tiers.getId());
		calculService.traiteMessage(lot);

		// Assert
		List<StatutHistorise> statuts = statutTiersRepository.findStatusTiersActive(tiers.getId());
		Assert.assertEquals(1, statuts.size());
		Assert.assertEquals(StatutTiers.SAIN, statuts.get(0).getStatut());
		Assert.assertEquals(LocalDate.now(), statuts.get(0).getDateDebut());
	}

	@Test
	public void ClotureArriereSignificatifSurClotureImx() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);

		Tiers tiers = new Tiers();

		IdentiteTiers id1 = new IdentiteTiers();
		id1.setCodeBanque("10107"); // Par exemple
		id1.setIdLocal("abcdefg");
		id1.setCodeSegment("1010"); // CORP
		id1.setDateDebut(LocalDate.now().minusDays(10));
		tiers.addIdentite(id1);

		tiers = entityManager.persistAndFlush(tiers);

		ElementsDeCalcul edc = new ElementsDeCalcul();
		edc.setTiers(tiers);
		entityManager.persist(edc);

		ArriereSignificatif as = new ArriereSignificatif();
		as.setTiers(tiers);
		as.setDateDebut(LocalDate.now());
		ComplementArriere complAS = new ComplementArriere();
		complAS.setEntree(edc);
		as.setComplement(complAS);
		entityManager.persistAndFlush(as);

		Evenement evtImx = new Evenement();
		evtImx.setCode("IMX");
		evtImx.setIdentiteInitiale(id1);
		evtImx.setDateDebut(LocalDate.now().minusDays(25));

		ComplementEvenement ceImx = new ComplementEvenement();
		ceImx.setDatePhoto(LocalDate.now().minusDays(1));
		ceImx.setDateMaj(LocalDate.now().minusDays(1));
		ceImx.setMontantArriere(new BigDecimal("0.00"));
		ceImx.setStatutEvt(StatutEvenement.CLO);
		ceImx.setArriereLitige(false);
		ceImx.setArriereTech(false);
		ceImx.setAuditFichier(fic);
		ceImx.setIdentiteInitiale(id1);
		evtImx.addComplement(ceImx);

		entityManager.persist(evtImx);
		entityManager.flush();

		SuiviDemandeEncours suivDem = new SuiviDemandeEncours("msgId", new Date(), LocalDate.now().minusDays(15),
				LocalDate.now().minusDays(20), null);
		SuiviEncoursTiers suivEnc = new SuiviEncoursTiers(TypeAgregat.L, suivDem, tiers, null, "10107", "abcdefg",
				StatutEncoursTiers.NON_REJETE);
		entityManager.persist(suivDem);
		entityManager.persist(suivEnc);
		entityManager.flush();

		LotIdTiersDTO lot = new LotIdTiersDTO();
		lot.addIdTiers(tiers.getId());
		lot.setDateCalcul(LocalDate.now());

		// Act
		calculService.traiteMessage(lot);

		// Assert
		List<EvenementCalcule> evtsCalcActifs = (List<EvenementCalcule>) evtCalcRepository.findAll();
		Assert.assertNotNull(evtsCalcActifs);
		Assert.assertEquals(1, evtsCalcActifs.size());
		ArriereSignificatif asClo = (ArriereSignificatif) evtsCalcActifs.get(0);
		Assert.assertEquals(ceImx.getDateMaj(), asClo.getDateFin());
	}

	@Test
	public void ClotureArriereSignificatifSurCollecteEncours() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);

		Tiers tiers = new Tiers();

		IdentiteTiers id1 = new IdentiteTiers();
		id1.setCodeBanque("10107"); // Par exemple
		id1.setIdLocal("abcdefg");
		id1.setCodeSegment("1010"); // CORP
		id1.setDateDebut(LocalDate.now().minusDays(10));
		tiers.addIdentite(id1);

		tiers = entityManager.persistAndFlush(tiers);

		ElementsDeCalcul edc = new ElementsDeCalcul();
		edc.setTiers(tiers);
		entityManager.persist(edc);

		ArriereSignificatif as = new ArriereSignificatif();
		as.setTiers(tiers);
		as.setDateDebut(LocalDate.now());
		ComplementArriere complAS = new ComplementArriere();
		complAS.setEntree(edc);
		as.setComplement(complAS);
		entityManager.persistAndFlush(as);

		Evenement evtImx = new Evenement();
		evtImx.setCode("IMX");
		evtImx.setIdentiteInitiale(id1);
		evtImx.setDateDebut(LocalDate.now().minusDays(25));

		ComplementEvenement ceImx = new ComplementEvenement();
		ceImx.setDatePhoto(LocalDate.now().minusDays(1));
		ceImx.setDateMaj(LocalDate.now().minusDays(10));
		ceImx.setMontantArriere(new BigDecimal("0.00"));
		ceImx.setStatutEvt(StatutEvenement.CLO);
		ceImx.setArriereLitige(false);
		ceImx.setArriereTech(false);
		ceImx.setAuditFichier(fic);
		ceImx.setIdentiteInitiale(id1);
		evtImx.addComplement(ceImx);

		entityManager.persist(evtImx);
		entityManager.flush();

		SuiviDemandeEncours suivDem = new SuiviDemandeEncours("msgId", new Date(), LocalDate.now().minusDays(5),
				LocalDate.now().minusDays(20), null);
		SuiviEncoursTiers suivEnc = new SuiviEncoursTiers(TypeAgregat.L, suivDem, tiers, null, "10107", "abcdefg",
				StatutEncoursTiers.NON_REJETE);
		entityManager.persist(suivDem);
		entityManager.persist(suivEnc);
		entityManager.flush();

		LotIdTiersDTO lot = new LotIdTiersDTO();
		lot.addIdTiers(tiers.getId());
		lot.setDateCalcul(LocalDate.now());

		// Act
		calculService.traiteMessage(lot);

		// Assert
		List<EvenementCalcule> evtsCalcActifs = (List<EvenementCalcule>) evtCalcRepository.findAll();
		Assert.assertNotNull(evtsCalcActifs);
		Assert.assertEquals(1, evtsCalcActifs.size());
		ArriereSignificatif asClo = (ArriereSignificatif) evtsCalcActifs.get(0);
		Assert.assertEquals(suivDem.getDateEncours(), asClo.getDateFin());
	}

	@Test
	public void debutPeriodeProbatoirePuisClotureMemeSeconde() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);

		Tiers tiers = new Tiers();

		IdentiteTiers id1 = new IdentiteTiers();
		id1.setCodeBanque("10107"); // Par exemple
		id1.setIdLocal("abcdefg");
		id1.setCodeSegment("3110");
		id1.setDateDebut(LocalDate.now().minusDays(15));
		tiers.addIdentite(id1);

		tiers = entityManager.persistAndFlush(tiers);

		Evenement evtImx = new Evenement();
		evtImx.setCode("IMX");
		evtImx.setIdentiteInitiale(id1);
		evtImx.setDateDebut(LocalDate.now().minusDays(12));
		ComplementEvenement ceImx = new ComplementEvenement();
		ceImx.setDatePhoto(evtImx.getDateDebut().plusDays(1));
		ceImx.setDateMaj(evtImx.getDateDebut());
		ceImx.setMontantArriere(new BigDecimal("1500.00"));
		ceImx.setStatutEvt(StatutEvenement.ACT);
		ceImx.setArriereLitige(false);
		ceImx.setArriereTech(false);
		ceImx.setAuditFichier(fic);
		ceImx.setIdentiteInitiale(id1);
		evtImx.addComplement(ceImx);
		entityManager.persist(evtImx);

		entityManager.flush();

		// Act
		LocalDate dateCalc1 = LocalDate.now().minusDays(2);
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalc1);
		lot.addIdTiers(tiers.getId());
		calculService.traiteMessage(lot);

		// Assert
		List<EvenementCalcule> evtsCalcActifs = evtCalcRepository.rechercheEvenementsCalculesActifsADate(tiers.getId(),
				dateCalc1);
		ArriereSignificatif as = (ArriereSignificatif) evtsCalcActifs.get(0);

		// Arrange 2 - Passage en défaut, puis changement de valeurs sur les montants
		as.getComplement().setDernierEvenementEnvoye(EvenementArriereSignificatif.AR3);
		Map<Long, EvenementsCalculesTiers> evtsCalc = evtCalculService.rechercheEvenementsCalculesActifsADate(lot);

		Map<Long, List<IdentiteTiers>> identitiesMap = new HashMap<Long, List<IdentiteTiers>>();
		List<IdentiteTiers> identList = new ArrayList<IdentiteTiers>();
		identList.add(id1);
		identitiesMap.put(tiers.getId(), identList);
		Map<Long, EvenementsATraiter> evtsRecus = evtRecuService.rechercheEvenementsATraiterADate(lot, identitiesMap);
		Map<Long, List<StatutHistorise>> status = defautService.getStatutsADate(lot);
		Map<Long, List<IdentiteTiers>> identities = identTiersService.rechercheIdentitesActivesADate(lot);
		ContexteCalculTiers.init(evtsRecus, status, identities, evtsCalc);
		defautService.entreeEnDefaut(tiers, LocalDate.now().minusDays(3), new MotifStatutTiers(as), LocalDate.now());
		ContexteCalculTiers.clear();

		ComplementEvenement ceImx2 = new ComplementEvenement();
		ceImx2.setDatePhoto(LocalDate.now().plusDays(1));
		ceImx.setDateFin(ceImx2.getDatePhoto());
		ceImx2.setDateMaj(LocalDate.now().plusDays(1));
		ceImx2.setMontantArriere(new BigDecimal("250.00"));
		ceImx2.setStatutEvt(StatutEvenement.CLO);
		ceImx2.setArriereLitige(false);
		ceImx2.setArriereTech(false);
		ceImx2.setMiseAJour(true);
		ceImx2.setAuditFichier(fic);
		ceImx2.setIdentiteInitiale(id1);
		evtImx.addComplement(ceImx2);

		entityManager.persist(ceImx2);
		entityManager.flush();
		entityManager.detach(as);

		Evenement evtDefaut = new Evenement();
		evtDefaut.setCode("PCO");
		evtDefaut.setIdentiteInitiale(id1);
		ComplementEvenement ceDefaut = new ComplementEvenement();
		ceDefaut.setDatePhoto(LocalDate.now().minusDays(3));
		ceDefaut.setDateMaj(ceDefaut.getDatePhoto());
		ceDefaut.setMontantArriere(BigDecimal.ZERO);
		ceDefaut.setStatutEvt(StatutEvenement.ACT);
		ceDefaut.setArriereLitige(false);
		ceDefaut.setArriereTech(false);
		ceDefaut.setAuditFichier(fic);
		ceDefaut.setIdentiteInitiale(id1);
		evtDefaut.addComplement(ceDefaut);
		entityManager.persist(evtDefaut);

		// REF IMPACT EVT MDC
		RefImpactEvtMdc refImpact = new RefImpactEvtMdc();
		refImpact.setCodEvt("PCO");
		refImpact.setCategorieSegment(Constant.TOUS_AUTRES);
		refImpact.setImpact("D");
		refImpact.setGraviteImpact("CX");
		refImpact.setDateDebut(LocalDate.now().minusDays(100));
		entityManager.persist(refImpact);

		// REF_CLI_SEG
		RefCliSeg refCliSeg = new RefCliSeg();
		refCliSeg.setCodSegCli("3110");
		refCliSeg.setLibSegCli("PARTICULIERS");
		refCliSeg.setCodSsClassCli("RETPAR");
		refCliSeg.setTopSuppr("N");
		entityManager.persist(refCliSeg);

		// REF_CLI_SS_CLASS
		RefCliSsClass refClassSsClass = new RefCliSsClass();
		refClassSsClass.setCodSsClassCli("RETPAR");
		refClassSsClass.setLibSsClassCli("PARTICULIERS");
		refClassSsClass.setCodClassCli("RET");
		refClassSsClass.setTopSuppr("N");
		refClassSsClass.setCodTypNot("PART");
		entityManager.persist(refClassSsClass);

		// Act 2
		LocalDate dateCalc2 = LocalDate.now().plusDays(87);
		lot.setDateCalcul(dateCalc2);
		calculService.traiteMessage(lot);

		List<AuditCalcul> PPList = StreamSupport.stream(auditCalculRepository.findAll().spliterator(), false)
				.collect(Collectors.toList()).stream().filter(x -> "PP".equals(x.getCode()))
				.collect(Collectors.toList());

		Assert.assertEquals(2, PPList.size());
		// Assert.assertNotEquals(PPList.get(0).getDateGeneration(),
		// PPList.get(1).getDateGeneration());
	}

	@Test
	public void changementHorsRetailVersRetailTiersDefautPCO() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);

		Tiers tiers = new Tiers();

		IdentiteTiers id1 = new IdentiteTiers();
		id1.setCodeBanque("10107");
		id1.setIdLocal("abcdefg");
		id1.setCodeSegment("1010");
		id1.setDateDebut(LocalDate.now().minusDays(15));
		tiers.addIdentite(id1);
		tiers = entityManager.persistAndFlush(tiers);

		Evenement evtDefaut = new Evenement();
		evtDefaut.setCode("PCO");
		evtDefaut.setIdentiteInitiale(id1);
		ComplementEvenement ceDefaut = new ComplementEvenement();
		ceDefaut.setDatePhoto(LocalDate.now().minusDays(3));
		ceDefaut.setDateMaj(ceDefaut.getDatePhoto());
		ceDefaut.setMontantArriere(BigDecimal.ZERO);
		ceDefaut.setStatutEvt(StatutEvenement.ACT);
		ceDefaut.setArriereLitige(false);
		ceDefaut.setArriereTech(false);
		ceDefaut.setAuditFichier(fic);
		ceDefaut.setIdentiteInitiale(id1);
		evtDefaut.addComplement(ceDefaut);
		entityManager.persist(evtDefaut);

		// REF IMPACT EVT MDC
		RefImpactEvtMdc refImpact = new RefImpactEvtMdc();
		refImpact.setCodEvt("PCO");
		refImpact.setCategorieSegment(Constant.TOUS_AUTRES);
		refImpact.setImpact("D");
		refImpact.setGraviteImpact("CX");
		refImpact.setDateDebut(LocalDate.now().minusDays(100));
		entityManager.persist(refImpact);

		// REF_CLI_SEG
		RefCliSeg refCliSeg = new RefCliSeg();
		refCliSeg.setCodSegCli("3110");
		refCliSeg.setLibSegCli("CORPORATES");
		refCliSeg.setCodSsClassCli("COR010");
		refCliSeg.setTopSuppr("N");
		entityManager.persist(refCliSeg);

		// REF_CLI_SS_CLASS
		RefCliSsClass refClassSsClass = new RefCliSsClass();
		refClassSsClass.setCodSsClassCli("COR010");
		refClassSsClass.setLibSsClassCli("CORPORATES");
		refClassSsClass.setCodClassCli("COR");
		refClassSsClass.setTopSuppr("N");
		refClassSsClass.setCodTypNot("CORP");
		entityManager.persist(refClassSsClass);

		// REF_CLI_SEG
		RefCliSeg refCliSeg2 = new RefCliSeg();
		refCliSeg2.setCodSegCli("1010");
		refCliSeg2.setLibSegCli("PARTICULIERS");
		refCliSeg2.setCodSsClassCli("RETPAR");
		refCliSeg2.setTopSuppr("N");
		entityManager.persist(refCliSeg2);

		// REF_CLI_SS_CLASS
		RefCliSsClass refClassSsClass2 = new RefCliSsClass();
		refClassSsClass2.setCodSsClassCli("RETPAR");
		refClassSsClass2.setLibSsClassCli("PARTICULIERS");
		refClassSsClass2.setCodClassCli("RET");
		refClassSsClass2.setTopSuppr("N");
		refClassSsClass2.setCodTypNot("PART");
		entityManager.persist(refClassSsClass2);

		entityManager.flush();

		// Act
		LocalDate dateCalc1 = LocalDate.now().minusDays(2);
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalc1);
		lot.addIdTiers(tiers.getId());
		calculService.traiteMessage(lot);

		// Assert
		Tiers tiers2 = new Tiers();

		IdentiteTiers id2 = new IdentiteTiers();
		id2.setCodeBanque("10107");
		id2.setIdLocal("abcdefg");
		id2.setCodeSegment("3110");
		id2.setDateDebut(LocalDate.now().minusDays(10));
		tiers2.addIdentite(id2);
		tiers2 = entityManager.persist(tiers2);

		id1.setDateFin(id2.getDateDebut());
		id1.setSuivante(id2);

		entityManager.flush();

		// Act 2
		LocalDate dateCalc2 = LocalDate.now();
		lot.setDateCalcul(dateCalc2);
		lot.addIdTiers(tiers2.getId());
		calculService.traiteMessage(lot);

		List<StatutHistorise> statutList = StreamSupport
				.stream(statutTiersRepository.findAllByOrderByIdAsc().spliterator(), false)
				.collect(Collectors.toList());

		Assert.assertEquals(3, statutList.size());
		Assert.assertEquals(StatutTiers.DEFAUT, statutList.get(0).getStatut());
		Assert.assertEquals(dateCalc2, statutList.get(0).getDateFin());
		Assert.assertEquals(tiers, statutList.get(0).getTiers());
		Assert.assertEquals(StatutTiers.DEFAUT, statutList.get(1).getStatut());
		Assert.assertEquals("PP", statutList.get(1).getMotif().getMotif());
		Assert.assertNull(statutList.get(1).getDateFin());
		Assert.assertEquals(dateCalc2, statutList.get(1).getDateDebut());
		Assert.assertEquals(tiers, statutList.get(1).getTiers());
		Assert.assertEquals(StatutTiers.DEFAUT, statutList.get(2).getStatut());
		Assert.assertNull(statutList.get(2).getDateFin());
		Assert.assertEquals(tiers2, statutList.get(2).getTiers());

	}

	@Test
	public void changementRetailVersHorsRetailTiersDefautPCO() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);

		Tiers tiers = new Tiers();

		IdentiteTiers id1 = new IdentiteTiers();
		id1.setCodeBanque("10107");
		id1.setIdLocal("abcdefg");
		id1.setCodeSegment("3110");
		id1.setDateDebut(LocalDate.now().minusDays(15));
		tiers.addIdentite(id1);
		tiers = entityManager.persistAndFlush(tiers);

		Evenement evtDefaut = new Evenement();
		evtDefaut.setCode("PCO");
		evtDefaut.setIdentiteInitiale(id1);
		ComplementEvenement ceDefaut = new ComplementEvenement();
		ceDefaut.setDatePhoto(LocalDate.now().minusDays(3));
		ceDefaut.setDateMaj(ceDefaut.getDatePhoto());
		ceDefaut.setMontantArriere(BigDecimal.ZERO);
		ceDefaut.setStatutEvt(StatutEvenement.ACT);
		ceDefaut.setArriereLitige(false);
		ceDefaut.setArriereTech(false);
		ceDefaut.setAuditFichier(fic);
		ceDefaut.setIdentiteInitiale(id1);
		evtDefaut.addComplement(ceDefaut);
		entityManager.persist(evtDefaut);

		// REF IMPACT EVT MDC
		RefImpactEvtMdc refImpact = new RefImpactEvtMdc();
		refImpact.setCodEvt("PCO");
		refImpact.setCategorieSegment(Constant.TOUS_AUTRES);
		refImpact.setImpact("D");
		refImpact.setGraviteImpact("CX");
		refImpact.setDateDebut(LocalDate.now().minusDays(100));
		entityManager.persist(refImpact);

		// REF_CLI_SEG
		RefCliSeg refCliSeg = new RefCliSeg();
		refCliSeg.setCodSegCli("1010");
		refCliSeg.setLibSegCli("CORPORATES");
		refCliSeg.setCodSsClassCli("COR010");
		refCliSeg.setTopSuppr("N");
		entityManager.persist(refCliSeg);

		// REF_CLI_SS_CLASS
		RefCliSsClass refClassSsClass = new RefCliSsClass();
		refClassSsClass.setCodSsClassCli("COR010");
		refClassSsClass.setLibSsClassCli("CORPORATES");
		refClassSsClass.setCodClassCli("COR");
		refClassSsClass.setTopSuppr("N");
		refClassSsClass.setCodTypNot("CORP");
		entityManager.persist(refClassSsClass);

		// REF_CLI_SEG
		RefCliSeg refCliSeg2 = new RefCliSeg();
		refCliSeg2.setCodSegCli("3110");
		refCliSeg2.setLibSegCli("PARTICULIERS");
		refCliSeg2.setCodSsClassCli("RETPAR");
		refCliSeg2.setTopSuppr("N");
		entityManager.persist(refCliSeg2);

		// REF_CLI_SS_CLASS
		RefCliSsClass refClassSsClass2 = new RefCliSsClass();
		refClassSsClass2.setCodSsClassCli("RETPAR");
		refClassSsClass2.setLibSsClassCli("PARTICULIERS");
		refClassSsClass2.setCodClassCli("RET");
		refClassSsClass2.setTopSuppr("N");
		refClassSsClass2.setCodTypNot("PART");
		entityManager.persist(refClassSsClass2);

		entityManager.flush();

		// Act
		LocalDate dateCalc1 = LocalDate.now().minusDays(2);
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalc1);
		lot.addIdTiers(tiers.getId());
		calculService.traiteMessage(lot);

		// Assert
		Tiers tiers2 = new Tiers();

		IdentiteTiers id2 = new IdentiteTiers();
		id2.setCodeBanque("10107");
		id2.setIdLocal("abcdefg");
		id2.setCodeSegment("1010");
		id2.setDateDebut(LocalDate.now().minusDays(10));
		tiers2.addIdentite(id2);
		tiers2 = entityManager.persist(tiers2);

		id1.setDateFin(id2.getDateDebut());
		id1.setSuivante(id2);

		entityManager.flush();

		// Act 2
		LocalDate dateCalc2 = LocalDate.now();
		lot.setDateCalcul(dateCalc2);
		lot.addIdTiers(tiers2.getId());
		calculService.traiteMessage(lot);

		List<StatutHistorise> statutList = StreamSupport
				.stream(statutTiersRepository.findAllByOrderByIdAsc().spliterator(), false)
				.collect(Collectors.toList());

		Assert.assertEquals(3, statutList.size());
		Assert.assertEquals(StatutTiers.DEFAUT, statutList.get(0).getStatut());
		Assert.assertEquals(dateCalc2, statutList.get(0).getDateFin());
		Assert.assertEquals(tiers, statutList.get(0).getTiers());
		Assert.assertEquals(StatutTiers.DEFAUT, statutList.get(1).getStatut());
		Assert.assertEquals("PP", statutList.get(1).getMotif().getMotif());
		Assert.assertNull(statutList.get(1).getDateFin());
		Assert.assertEquals(dateCalc2, statutList.get(1).getDateDebut());
		Assert.assertEquals(tiers, statutList.get(1).getTiers());
		Assert.assertEquals(StatutTiers.DEFAUT, statutList.get(2).getStatut());
		Assert.assertNull(statutList.get(2).getDateFin());
		Assert.assertEquals(tiers2, statutList.get(2).getTiers());
	}

	@Test
	public void changementHorsRetailPartageVersRetailTiersDefautPCO() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);

		Tiers tiers = new Tiers();

		IdentiteTiers id1 = new IdentiteTiers();
		id1.setCodeBanque("10107");
		id1.setIdLocal("abcdefg");
		id1.setCodeSegment("1010");
		id1.setDateDebut(LocalDate.now().minusDays(15));
		tiers.addIdentite(id1);

		IdentiteTiers id3 = new IdentiteTiers();
		id3.setCodeBanque("12128");
		id3.setIdLocal("abcde");
		id3.setCodeSegment("1010");
		id3.setDateDebut(LocalDate.now().minusDays(15));
		tiers.addIdentite(id3);
		tiers = entityManager.persistAndFlush(tiers);

		Evenement evtDefaut = new Evenement();
		evtDefaut.setCode("PCO");
		evtDefaut.setIdentiteInitiale(id1);
		ComplementEvenement ceDefaut = new ComplementEvenement();
		ceDefaut.setDatePhoto(LocalDate.now().minusDays(3));
		ceDefaut.setDateMaj(ceDefaut.getDatePhoto());
		ceDefaut.setMontantArriere(BigDecimal.ZERO);
		ceDefaut.setStatutEvt(StatutEvenement.ACT);
		ceDefaut.setArriereLitige(false);
		ceDefaut.setArriereTech(false);
		ceDefaut.setAuditFichier(fic);
		ceDefaut.setIdentiteInitiale(id1);
		evtDefaut.addComplement(ceDefaut);
		entityManager.persist(evtDefaut);

		Evenement evtForbearence = new Evenement();
		evtForbearence.setCode("F");
		evtForbearence.setIdentiteInitiale(id3);
		ComplementEvenement ceEvtForbearence = new ComplementEvenement();
		ceEvtForbearence.setDatePhoto(LocalDate.now().minusDays(3));
		ceEvtForbearence.setDateMaj(ceEvtForbearence.getDatePhoto());
		ceEvtForbearence.setMontantArriere(BigDecimal.ZERO);
		ceEvtForbearence.setStatutEvt(StatutEvenement.ACT);
		ceEvtForbearence.setArriereLitige(false);
		ceEvtForbearence.setArriereTech(false);
		ceEvtForbearence.setAuditFichier(fic);
		ceEvtForbearence.setIdentiteInitiale(id3);
		evtForbearence.addComplement(ceEvtForbearence);
		entityManager.persist(evtForbearence);

		// REF IMPACT EVT MDC
		RefImpactEvtMdc refImpact = new RefImpactEvtMdc();
		refImpact.setCodEvt("PCO");
		refImpact.setCategorieSegment(Constant.TOUS_AUTRES);
		refImpact.setImpact("D");
		refImpact.setGraviteImpact("CX");
		refImpact.setDateDebut(LocalDate.now().minusDays(100));
		entityManager.persist(refImpact);

		// REF_CLI_SEG
		RefCliSeg refCliSeg = new RefCliSeg();
		refCliSeg.setCodSegCli("3110");
		refCliSeg.setLibSegCli("CORPORATES");
		refCliSeg.setCodSsClassCli("COR010");
		refCliSeg.setTopSuppr("N");
		entityManager.persist(refCliSeg);

		// REF_CLI_SS_CLASS
		RefCliSsClass refClassSsClass = new RefCliSsClass();
		refClassSsClass.setCodSsClassCli("COR010");
		refClassSsClass.setLibSsClassCli("CORPORATES");
		refClassSsClass.setCodClassCli("COR");
		refClassSsClass.setTopSuppr("N");
		refClassSsClass.setCodTypNot("CORP");
		entityManager.persist(refClassSsClass);

		// REF_CLI_SEG
		RefCliSeg refCliSeg2 = new RefCliSeg();
		refCliSeg2.setCodSegCli("1010");
		refCliSeg2.setLibSegCli("PARTICULIERS");
		refCliSeg2.setCodSsClassCli("RETPAR");
		refCliSeg2.setTopSuppr("N");
		entityManager.persist(refCliSeg2);

		// REF_CLI_SS_CLASS
		RefCliSsClass refClassSsClass2 = new RefCliSsClass();
		refClassSsClass2.setCodSsClassCli("RETPAR");
		refClassSsClass2.setLibSsClassCli("PARTICULIERS");
		refClassSsClass2.setCodClassCli("RET");
		refClassSsClass2.setTopSuppr("N");
		refClassSsClass2.setCodTypNot("PART");
		entityManager.persist(refClassSsClass2);

		entityManager.flush();

		// Act
		LocalDate dateCalc1 = LocalDate.now().minusDays(2);
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalc1);
		lot.addIdTiers(tiers.getId());
		calculService.traiteMessage(lot);

		// Assert
		Tiers tiers2 = new Tiers();

		IdentiteTiers id2 = new IdentiteTiers();
		id2.setCodeBanque("10107");
		id2.setIdLocal("abcdefg");
		id2.setCodeSegment("3110");
		id2.setDateDebut(LocalDate.now().minusDays(10));
		tiers2.addIdentite(id2);
		tiers2 = entityManager.persist(tiers2);

		id1.setDateFin(id2.getDateDebut());
		id1.setSuivante(id2);

		entityManager.flush();

		// Act 2
		LocalDate dateCalc2 = LocalDate.now();
		lot.setDateCalcul(dateCalc2);
		lot.addIdTiers(tiers2.getId());
		calculService.traiteMessage(lot);

		List<StatutHistorise> statutList = StreamSupport
				.stream(statutTiersRepository.findAllByOrderByIdAsc().spliterator(), false)
				.collect(Collectors.toList());

		Assert.assertEquals(3, statutList.size());
		Assert.assertEquals(StatutTiers.DEFAUT, statutList.get(0).getStatut());
		Assert.assertEquals(dateCalc2, statutList.get(0).getDateFin());
		Assert.assertEquals(tiers, statutList.get(0).getTiers());
		Assert.assertEquals(StatutTiers.DEFAUT, statutList.get(1).getStatut());
		Assert.assertEquals("PP", statutList.get(1).getMotif().getMotif());
		Assert.assertEquals(dateCalc2, statutList.get(1).getDateDebut());
		Assert.assertNull(statutList.get(1).getDateFin());
		Assert.assertEquals(tiers, statutList.get(1).getTiers());
		Assert.assertEquals(StatutTiers.DEFAUT, statutList.get(2).getStatut());
		Assert.assertNull(statutList.get(2).getDateFin());
		Assert.assertEquals(tiers2, statutList.get(2).getTiers());
	}

	@Test
	public void changementHorsRetailPartageVersRetailTiersMultiDefautPCO() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);

		Tiers tiers = new Tiers();

		IdentiteTiers id1 = new IdentiteTiers();
		id1.setCodeBanque("10107");
		id1.setIdLocal("abcdefg");
		id1.setCodeSegment("1010");
		id1.setDateDebut(LocalDate.now().minusDays(15));
		tiers.addIdentite(id1);

		IdentiteTiers id3 = new IdentiteTiers();
		id3.setCodeBanque("12128");
		id3.setIdLocal("abcde");
		id3.setCodeSegment("1010");
		id3.setDateDebut(LocalDate.now().minusDays(15));
		tiers.addIdentite(id3);
		tiers = entityManager.persistAndFlush(tiers);

		Evenement evtDefaut = new Evenement();
		evtDefaut.setCode("PCO");
		evtDefaut.setIdentiteInitiale(id1);
		ComplementEvenement ceDefaut = new ComplementEvenement();
		ceDefaut.setDatePhoto(LocalDate.now().minusDays(3));
		ceDefaut.setDateMaj(ceDefaut.getDatePhoto());
		ceDefaut.setMontantArriere(BigDecimal.ZERO);
		ceDefaut.setStatutEvt(StatutEvenement.ACT);
		ceDefaut.setArriereLitige(false);
		ceDefaut.setArriereTech(false);
		ceDefaut.setAuditFichier(fic);
		ceDefaut.setIdentiteInitiale(id1);
		evtDefaut.addComplement(ceDefaut);
		entityManager.persist(evtDefaut);

		Evenement evtForbearence = new Evenement();
		evtForbearence.setCode("PCO");
		evtForbearence.setIdentiteInitiale(id3);
		ComplementEvenement ceEvtForbearence = new ComplementEvenement();
		ceEvtForbearence.setDatePhoto(LocalDate.now().minusDays(3));
		ceEvtForbearence.setDateMaj(ceEvtForbearence.getDatePhoto());
		ceEvtForbearence.setMontantArriere(BigDecimal.ZERO);
		ceEvtForbearence.setStatutEvt(StatutEvenement.ACT);
		ceEvtForbearence.setArriereLitige(false);
		ceEvtForbearence.setArriereTech(false);
		ceEvtForbearence.setAuditFichier(fic);
		ceEvtForbearence.setIdentiteInitiale(id3);
		evtForbearence.addComplement(ceEvtForbearence);
		entityManager.persist(evtForbearence);

		// REF IMPACT EVT MDC
		RefImpactEvtMdc refImpact = new RefImpactEvtMdc();
		refImpact.setCodEvt("PCO");
		refImpact.setCategorieSegment(Constant.TOUS_AUTRES);
		refImpact.setImpact("D");
		refImpact.setGraviteImpact("CX");
		refImpact.setDateDebut(LocalDate.now().minusDays(100));
		entityManager.persist(refImpact);

		// REF_CLI_SEG
		RefCliSeg refCliSeg = new RefCliSeg();
		refCliSeg.setCodSegCli("3110");
		refCliSeg.setLibSegCli("CORPORATES");
		refCliSeg.setCodSsClassCli("COR010");
		refCliSeg.setTopSuppr("N");
		entityManager.persist(refCliSeg);

		// REF_CLI_SS_CLASS
		RefCliSsClass refClassSsClass = new RefCliSsClass();
		refClassSsClass.setCodSsClassCli("COR010");
		refClassSsClass.setLibSsClassCli("CORPORATES");
		refClassSsClass.setCodClassCli("COR");
		refClassSsClass.setTopSuppr("N");
		refClassSsClass.setCodTypNot("CORP");
		entityManager.persist(refClassSsClass);

		// REF_CLI_SEG
		RefCliSeg refCliSeg2 = new RefCliSeg();
		refCliSeg2.setCodSegCli("1010");
		refCliSeg2.setLibSegCli("PARTICULIERS");
		refCliSeg2.setCodSsClassCli("RETPAR");
		refCliSeg2.setTopSuppr("N");
		entityManager.persist(refCliSeg2);

		// REF_CLI_SS_CLASS
		RefCliSsClass refClassSsClass2 = new RefCliSsClass();
		refClassSsClass2.setCodSsClassCli("RETPAR");
		refClassSsClass2.setLibSsClassCli("PARTICULIERS");
		refClassSsClass2.setCodClassCli("RET");
		refClassSsClass2.setTopSuppr("N");
		refClassSsClass2.setCodTypNot("PART");
		entityManager.persist(refClassSsClass2);

		entityManager.flush();

		// Act
		LocalDate dateCalc1 = LocalDate.now().minusDays(2);
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalc1);
		lot.addIdTiers(tiers.getId());
		calculService.traiteMessage(lot);

		// Assert
		Tiers tiers2 = new Tiers();

		IdentiteTiers id2 = new IdentiteTiers();
		id2.setCodeBanque("10107");
		id2.setIdLocal("abcdefg");
		id2.setCodeSegment("3110");
		id2.setDateDebut(LocalDate.now().minusDays(10));
		tiers2.addIdentite(id2);
		tiers2 = entityManager.persist(tiers2);

		id1.setDateFin(id2.getDateDebut());
		id1.setSuivante(id2);

		entityManager.flush();

		// Act 2
		LocalDate dateCalc2 = LocalDate.now();
		lot.setDateCalcul(dateCalc2);
		lot.addIdTiers(tiers2.getId());
		calculService.traiteMessage(lot);

		List<StatutHistorise> statutList = StreamSupport
				.stream(statutTiersRepository.findAllByOrderByIdAsc().spliterator(), false)
				.collect(Collectors.toList());

		Assert.assertEquals(3, statutList.size());
		Assert.assertEquals(StatutTiers.DEFAUT, statutList.get(0).getStatut());
		Assert.assertEquals("PCO", statutList.get(0).getMotif().getMotif());
		Assert.assertNull(statutList.get(0).getDateFin());
		Assert.assertEquals(tiers, statutList.get(0).getTiers());

		Assert.assertEquals(StatutTiers.DEFAUT, statutList.get(1).getStatut());
		Assert.assertEquals("PCO", statutList.get(1).getMotif().getMotif());
		Assert.assertEquals(dateCalc2, statutList.get(1).getDateFin());
		Assert.assertEquals(tiers, statutList.get(1).getTiers());

		Assert.assertEquals(StatutTiers.DEFAUT, statutList.get(2).getStatut());
		Assert.assertEquals("PCO", statutList.get(2).getMotif().getMotif());
		Assert.assertNull(statutList.get(2).getDateFin());
		Assert.assertEquals(tiers2, statutList.get(2).getTiers());
	}

	@Test
	public void clotureASAvecChangementSegment() {
		// Arrange
		// REF_CLI_SEG
		RefCliSeg refCliSeg = new RefCliSeg();
		refCliSeg.setCodSegCli("3200");
		refCliSeg.setLibSegCli("PARTICULIERS");
		refCliSeg.setCodSsClassCli("RETPAR");
		refCliSeg.setTopSuppr("N");
		entityManager.persist(refCliSeg);

		// REF_CLI_SS_CLASS
		RefCliSsClass refClassSsClass = new RefCliSsClass();
		refClassSsClass.setCodSsClassCli("RETPAR");
		refClassSsClass.setLibSsClassCli("PARTICULIERS");
		refClassSsClass.setCodClassCli("RET");
		refClassSsClass.setTopSuppr("N");
		refClassSsClass.setCodTypNot("PART");
		entityManager.persist(refClassSsClass);

		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);

		Tiers tiers = new Tiers();

		IdentiteTiers id1 = new IdentiteTiers();
		id1.setCodeBanque("10107"); // Par exemple
		id1.setIdLocal("abcdefg");
		id1.setCodeSegment("3200"); // PART
		id1.setDateDebut(LocalDate.now().minusDays(15));
		tiers.addIdentite(id1);

		tiers = entityManager.persistAndFlush(tiers);

		Evenement evtImx = new Evenement();
		evtImx.setCode("IMX");
		evtImx.setIdentiteInitiale(id1);
		evtImx.setDateDebut(LocalDate.now().minusDays(12));
		ComplementEvenement ceImx = new ComplementEvenement();
		ceImx.setDatePhoto(evtImx.getDateDebut().plusDays(1));
		ceImx.setDateMaj(evtImx.getDateDebut());
		ceImx.setMontantArriere(new BigDecimal("200.00"));
		ceImx.setStatutEvt(StatutEvenement.ACT);
		ceImx.setArriereLitige(false);
		ceImx.setArriereTech(false);
		ceImx.setAuditFichier(fic);
		ceImx.setIdentiteInitiale(id1);
		evtImx.addComplement(ceImx);

		entityManager.persist(evtImx);

		entityManager.flush();

		// Act
		LocalDate dateCalc1 = LocalDate.now().minusDays(2);
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalc1);
		lot.addIdTiers(tiers.getId());
		calculService.traiteMessage(lot);

		// Assert
		List<EvenementCalcule> evtsCalcActifs = evtCalcRepository.rechercheEvenementsCalculesActifsADate(tiers.getId(),
				dateCalc1);
		Assert.assertNotNull(evtsCalcActifs);
		Assert.assertEquals(1, evtsCalcActifs.size());
		ArriereSignificatif as = (ArriereSignificatif) evtsCalcActifs.get(0);
		Assert.assertEquals(ceImx.getDateMaj(), as.getDateDebut());
		ElementsDeCalcul calc = as.getComplement().getEntree();
		Assert.assertNotNull(calc);
		Assert.assertEquals(0, ceImx.getMontantArriere().compareTo(calc.getMontantAbsolu()));

		// Arrange 2
		as.getComplement().setDernierEvenementEnvoye(EvenementArriereSignificatif.AR3);
		Map<Long, EvenementsCalculesTiers> evtsCalc = evtCalculService.rechercheEvenementsCalculesActifsADate(lot);

		Map<Long, List<IdentiteTiers>> identitiesMap = new HashMap<Long, List<IdentiteTiers>>();
		List<IdentiteTiers> identList = new ArrayList<IdentiteTiers>();
		identList.add(id1);
		identitiesMap.put(tiers.getId(), identList);
		Map<Long, EvenementsATraiter> evtsRecus = evtRecuService.rechercheEvenementsATraiterADate(lot, identitiesMap);
		Map<Long, List<StatutHistorise>> status = defautService.getStatutsADate(lot);
		Map<Long, List<IdentiteTiers>> identities = identTiersService.rechercheIdentitesActivesADate(lot);
		ContexteCalculTiers.init(evtsRecus, status, identities, evtsCalc);
		defautService.entreeEnDefaut(tiers, LocalDate.now().plusDays(80), new MotifStatutTiers(as), LocalDate.now());
		ContexteCalculTiers.clear();

		// REF_CLI_SEG
		RefCliSeg refCliSeg2 = new RefCliSeg();
		refCliSeg2.setCodSegCli("1010");
		refCliSeg2.setLibSegCli("CORPORATE");
		refCliSeg2.setCodSsClassCli("COR010");
		refCliSeg2.setTopSuppr("N");
		entityManager.persist(refCliSeg2);

		// REF_CLI_SS_CLASS
		RefCliSsClass refClassSsClass2 = new RefCliSsClass();
		refClassSsClass2.setCodSsClassCli("COR010");
		refClassSsClass2.setLibSsClassCli("CORPORATE");
		refClassSsClass2.setCodClassCli("COR");
		refClassSsClass2.setTopSuppr("N");
		refClassSsClass2.setCodTypNot("CORP");
		entityManager.persist(refClassSsClass2);

		Evenement evtDax = new Evenement();
		evtDax.setCode("DAX");
		evtDax.setIdentiteInitiale(id1);
		evtDax.setDateDebut(LocalDate.now().plusDays(85));
		ComplementEvenement ceDax = new ComplementEvenement();
		ceDax.setDatePhoto(evtDax.getDateDebut());
		ceDax.setDateMaj(evtDax.getDateDebut());
		ceDax.setMontantArriere(new BigDecimal("165.50"));
		ceDax.setStatutEvt(StatutEvenement.ACT);
		ceDax.setArriereLitige(false);
		ceDax.setArriereTech(false);
		ceDax.setAuditFichier(fic);
		ceDax.setIdentiteInitiale(id1);
		evtDax.addComplement(ceDax);

		entityManager.persist(evtDax);

		IdentiteTiers id2 = new IdentiteTiers();
		id2.setCodeBanque("10107"); // Par exemple
		id2.setIdLocal("abcdefg");
		id2.setCodeSegment("1010"); // CORP
		id2.setDateDebut(LocalDate.now().plusDays(90));
		id1.setSuivante(id2);
		id1.setDateFin(id2.getDateDebut());
		tiers.addIdentite(id2);

		entityManager.persist(id2);
		entityManager.flush();
		entityManager.detach(as);

		// Act 2
		LocalDate dateCalc2 = LocalDate.now().plusDays(100);
		lot.setDateCalcul(dateCalc2);
		calculService.traiteMessage(lot);

		// Assert
		Map<Long, EvenementsCalculesTiers> evtsCalc2 = evtCalculService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalcules = evtsCalc2.get(tiers.getId());

		Assert.assertNotNull(evtsCalcules);
		Assert.assertNull(evtsCalcules.getArriereSignigicatif());
		Assert.assertNotNull(evtsCalcules.getPeriodeProbatoire());
		Assert.assertEquals(dateCalc2, evtsCalcules.getPeriodeProbatoire().getDateDebut());

		ArriereSignificatif asRelu = entityManager.find(ArriereSignificatif.class, as.getId());
		Assert.assertEquals(dateCalc2, asRelu.getDateFin());
		Assert.assertFalse(asRelu.getAuditCalcul().isEmpty());
		AuditCalcul audit = asRelu.getAuditCalcul().iterator().next();
		Assert.assertEquals(EvenementArriereSignificatif.AR3.name(), audit.getCode());
		Assert.assertEquals(StatutAuditEvenement.CLO, audit.getStatut());
		Assert.assertEquals(dateCalc2, audit.getDateEffet());
	}

	@Test
	public void creationASAvecChangementSegment() {
		// Arrange
		// REF_CLI_SEG
		RefCliSeg refCliSeg = new RefCliSeg();
		refCliSeg.setCodSegCli("3200");
		refCliSeg.setLibSegCli("PARTICULIERS");
		refCliSeg.setCodSsClassCli("RETPAR");
		refCliSeg.setTopSuppr("N");
		entityManager.persist(refCliSeg);

		// REF_CLI_SS_CLASS
		RefCliSsClass refClassSsClass = new RefCliSsClass();
		refClassSsClass.setCodSsClassCli("RETPAR");
		refClassSsClass.setLibSsClassCli("PARTICULIERS");
		refClassSsClass.setCodClassCli("RET");
		refClassSsClass.setTopSuppr("N");
		refClassSsClass.setCodTypNot("PART");
		entityManager.persist(refClassSsClass);

		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);

		Tiers tiers = new Tiers();

		IdentiteTiers id1 = new IdentiteTiers();
		id1.setCodeBanque("10107"); // Par exemple
		id1.setIdLocal("abcdefg");
		id1.setCodeSegment("1010"); // CORP
		id1.setDateDebut(LocalDate.now().minusDays(15));
		tiers.addIdentite(id1);

		tiers = entityManager.persistAndFlush(tiers);

		Evenement evtImx = new Evenement();
		evtImx.setCode("IMX");
		evtImx.setIdentiteInitiale(id1);
		evtImx.setDateDebut(LocalDate.now().minusDays(12));
		ComplementEvenement ceImx = new ComplementEvenement();
		ceImx.setDatePhoto(evtImx.getDateDebut().plusDays(1));
		ceImx.setDateMaj(evtImx.getDateDebut());
		ceImx.setMontantArriere(new BigDecimal("200.00"));
		ceImx.setStatutEvt(StatutEvenement.ACT);
		ceImx.setArriereLitige(false);
		ceImx.setArriereTech(false);
		ceImx.setAuditFichier(fic);
		ceImx.setIdentiteInitiale(id1);
		evtImx.addComplement(ceImx);

		entityManager.persist(evtImx);

		entityManager.flush();

		// Act
		LocalDate dateCalc1 = LocalDate.now().minusDays(10);
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalc1);
		lot.addIdTiers(tiers.getId());
		calculService.traiteMessage(lot);

		// Assert
		List<EvenementCalcule> evtsCalcActifs = evtCalcRepository.rechercheEvenementsCalculesActifsADate(tiers.getId(),
				dateCalc1);
		Assert.assertEquals(0, evtsCalcActifs.size());
		List<StatutHistorise> statitsActifs = statutTiersRepository.findAll();
		Assert.assertEquals(1, statitsActifs.size());
		Assert.assertEquals(StatutTiers.SAIN, statitsActifs.get(0).getStatut());
		Assert.assertEquals(dateCalc1, statitsActifs.get(0).getDateDebut());

		// Arrange 2
		// REF_CLI_SEG
		RefCliSeg refCliSeg2 = new RefCliSeg();
		refCliSeg2.setCodSegCli("1010");
		refCliSeg2.setLibSegCli("CORPORATE");
		refCliSeg2.setCodSsClassCli("COR010");
		refCliSeg2.setTopSuppr("N");
		entityManager.persist(refCliSeg2);

		// REF_CLI_SS_CLASS
		RefCliSsClass refClassSsClass2 = new RefCliSsClass();
		refClassSsClass2.setCodSsClassCli("COR010");
		refClassSsClass2.setLibSsClassCli("CORPORATE");
		refClassSsClass2.setCodClassCli("COR");
		refClassSsClass2.setTopSuppr("N");
		refClassSsClass2.setCodTypNot("CORP");
		entityManager.persist(refClassSsClass2);

		IdentiteTiers id2 = new IdentiteTiers();
		id2.setCodeBanque("10107"); // Par exemple
		id2.setIdLocal("abcdefg");
		id2.setCodeSegment("3200"); // PART
		id2.setDateDebut(LocalDate.now().minusDays(8));
		id1.setSuivante(id2);
		id1.setDateFin(id2.getDateDebut());
		tiers.addIdentite(id2);

		entityManager.persist(id2);
		entityManager.flush();

		// Act 2
		LocalDate dateCalc2 = LocalDate.now().minusDays(5);
		lot.setDateCalcul(dateCalc2);
		calculService.traiteMessage(lot);

		// Assert
		Map<Long, EvenementsCalculesTiers> evtsCalc2 = evtCalculService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalcules = evtsCalc2.get(tiers.getId());

		Assert.assertNotNull(evtsCalcules);
		ArriereSignificatif as = evtsCalcules.getArriereSignigicatif();
		Assert.assertEquals(ceImx.getDateMaj(), as.getDateDebut());
		ElementsDeCalcul calc = as.getComplement().getEntree();
		Assert.assertNotNull(calc);
		Assert.assertEquals(0, ceImx.getMontantArriere().compareTo(calc.getMontantAbsolu()));

	}

	@Test
	public void debutPeriodeProbatoireSurAnnulationDAXEtClotureIMX() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);

		Tiers tiers = new Tiers();

		IdentiteTiers id1 = new IdentiteTiers();
		id1.setCodeBanque("10107"); // Par exemple
		id1.setIdLocal("abcdefg");
		id1.setCodeSegment("3110");
		id1.setDateDebut(LocalDate.now().minusDays(100));
		tiers.addIdentite(id1);

		tiers = entityManager.persistAndFlush(tiers);

		Evenement evtImx = new Evenement();
		evtImx.setCode("IMX");
		evtImx.setIdentiteInitiale(id1);
		evtImx.setDateDebut(LocalDate.now().minusDays(100));
		ComplementEvenement ceImx = new ComplementEvenement();
		ceImx.setDatePhoto(evtImx.getDateDebut().plusDays(1));
		ceImx.setDateMaj(evtImx.getDateDebut());
		ceImx.setMontantArriere(new BigDecimal("1500.00"));
		ceImx.setStatutEvt(StatutEvenement.ACT);
		ceImx.setArriereLitige(false);
		ceImx.setArriereTech(false);
		ceImx.setAuditFichier(fic);
		ceImx.setIdentiteInitiale(id1);
		evtImx.addComplement(ceImx);
		entityManager.persist(evtImx);

		Evenement evtDAX = new Evenement();
		evtDAX.setCode("DAX");
		evtDAX.setIdentiteInitiale(id1);
		evtDAX.setDateDebut(LocalDate.now().minusDays(100));
		ComplementEvenement ceDax = new ComplementEvenement();
		ceDax.setDatePhoto(evtDAX.getDateDebut().plusDays(1));
		ceDax.setDateMaj(evtDAX.getDateDebut());
		ceDax.setMontantArriere(new BigDecimal("15.00"));
		ceDax.setStatutEvt(StatutEvenement.ACT);
		ceDax.setArriereLitige(false);
		ceDax.setArriereTech(false);
		ceDax.setAuditFichier(fic);
		ceDax.setIdentiteInitiale(id1);
		evtDAX.addComplement(ceDax);
		entityManager.persist(evtDAX);

		Evenement evtDefaut = new Evenement();
		evtDefaut.setCode("PCO");
		evtDefaut.setIdentiteInitiale(id1);
		ComplementEvenement ceDefaut = new ComplementEvenement();
		ceDefaut.setDatePhoto(LocalDate.now().minusDays(1));
		ceDefaut.setDateMaj(ceDefaut.getDatePhoto());
		ceDefaut.setMontantArriere(BigDecimal.ZERO);
		ceDefaut.setStatutEvt(StatutEvenement.ACT);
		ceDefaut.setArriereLitige(false);
		ceDefaut.setArriereTech(false);
		ceDefaut.setAuditFichier(fic);
		ceDefaut.setIdentiteInitiale(id1);
		evtDefaut.addComplement(ceDefaut);
		entityManager.persist(evtDefaut);

		// REF IMPACT EVT MDC
		RefImpactEvtMdc refImpact = new RefImpactEvtMdc();
		refImpact.setCodEvt("PCO");
		refImpact.setCategorieSegment(Constant.TOUS_AUTRES);
		refImpact.setImpact("D");
		refImpact.setGraviteImpact("CX");
		refImpact.setDateDebut(LocalDate.now().minusDays(100));
		entityManager.persist(refImpact);

		// REF_CLI_SEG
		RefCliSeg refCliSeg = new RefCliSeg();
		refCliSeg.setCodSegCli("3110");
		refCliSeg.setLibSegCli("PARTICULIERS");
		refCliSeg.setCodSsClassCli("RETPAR");
		refCliSeg.setTopSuppr("N");
		entityManager.persist(refCliSeg);

		// REF_CLI_SS_CLASS
		RefCliSsClass refClassSsClass = new RefCliSsClass();
		refClassSsClass.setCodSsClassCli("RETPAR");
		refClassSsClass.setLibSsClassCli("PARTICULIERS");
		refClassSsClass.setCodClassCli("RET");
		refClassSsClass.setTopSuppr("N");
		refClassSsClass.setCodTypNot("PART");
		entityManager.persist(refClassSsClass);

		entityManager.flush();

		// Act
		LocalDate dateCalc1 = LocalDate.now().minusDays(90);
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalc1);
		lot.addIdTiers(tiers.getId());
		calculService.traiteMessage(lot);

		// Creation de l'UTP PCO
		dateCalc1 = LocalDate.now();
		lot.setDateCalcul(dateCalc1);
		calculService.traiteMessage(lot);

		// Assert
		List<EvenementCalcule> evtsCalcActifs = evtCalcRepository.rechercheEvenementsCalculesActifsADate(tiers.getId(),
				dateCalc1);
		ArriereSignificatif as = (ArriereSignificatif) evtsCalcActifs.get(0);

		// Arrange 2 - Passage en défaut, puis changement de valeurs sur les montants
		as.getComplement().setDernierEvenementEnvoye(EvenementArriereSignificatif.AR3);
		Map<Long, EvenementsCalculesTiers> evtsCalc = evtCalculService.rechercheEvenementsCalculesActifsADate(lot);

		Map<Long, List<IdentiteTiers>> identitiesMap = new HashMap<Long, List<IdentiteTiers>>();
		List<IdentiteTiers> identList = new ArrayList<IdentiteTiers>();
		identList.add(id1);
		identitiesMap.put(tiers.getId(), identList);
		Map<Long, EvenementsATraiter> evtsRecus = evtRecuService.rechercheEvenementsATraiterADate(lot, identitiesMap);
		Map<Long, List<StatutHistorise>> status = defautService.getStatutsADate(lot);
		Map<Long, List<IdentiteTiers>> identities = identTiersService.rechercheIdentitesActivesADate(lot);
		ContexteCalculTiers.init(evtsRecus, status, identities, evtsCalc);
		defautService.entreeEnDefaut(tiers, LocalDate.now().minusDays(10), new MotifStatutTiers(as), LocalDate.now());
		ContexteCalculTiers.clear();

		ComplementEvenement ceImx2 = new ComplementEvenement();
		ceImx2.setDatePhoto(LocalDate.now().minusDays(5));
		ceImx.setDateFin(ceImx2.getDatePhoto());
		ceImx2.setDateMaj(ceImx2.getDatePhoto());
		ceImx2.setMontantArriere(new BigDecimal("0.00"));
		ceImx2.setStatutEvt(StatutEvenement.CLO);
		ceImx2.setArriereLitige(false);
		ceImx2.setArriereTech(false);
		ceImx2.setMiseAJour(true);
		ceImx2.setAuditFichier(fic);
		ceImx2.setIdentiteInitiale(id1);
		evtImx.addComplement(ceImx2);
		entityManager.persist(ceImx2);

		ComplementEvenement ceDax2 = new ComplementEvenement();
		ceDax2.setDatePhoto(LocalDate.now().minusDays(5));
		ceDax.setDateFin(ceDax2.getDatePhoto());
		ceDax2.setDateMaj(ceDax2.getDatePhoto());
		ceDax2.setMontantArriere(new BigDecimal("0.00"));
		ceDax2.setStatutEvt(StatutEvenement.ANN);
		ceDax2.setArriereLitige(false);
		ceDax2.setArriereTech(false);
		ceDax2.setMiseAJour(true);
		ceDax2.setAuditFichier(fic);
		ceDax2.setIdentiteInitiale(id1);
		evtDAX.addComplement(ceDax2);
		entityManager.persist(ceDax2);

		entityManager.flush();
		entityManager.detach(as);

		// Act 2
		LocalDate dateCalc2 = LocalDate.now().plusDays(1);
		lot.setDateCalcul(dateCalc2);
		calculService.traiteMessage(lot);

		List<StatutHistorise> statutList = StreamSupport.stream(statutTiersRepository.findAll().spliterator(), false)
				.collect(Collectors.toList()).stream().filter(x -> x.getDateFin() == null).collect(Collectors.toList());

		Assert.assertEquals(1, statutList.size());
		Assert.assertEquals("PCO", statutList.get(0).getMotif().getMotif());
	}

	@Test
	public void debutPeriodeProbatoireSurAnnulationDAXEtIMX() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);

		Tiers tiers = new Tiers();

		IdentiteTiers id1 = new IdentiteTiers();
		id1.setCodeBanque("10107"); // Par exemple
		id1.setIdLocal("abcdefg");
		id1.setCodeSegment("3110");
		id1.setDateDebut(LocalDate.now().minusDays(100));
		tiers.addIdentite(id1);

		tiers = entityManager.persistAndFlush(tiers);

		Evenement evtImx = new Evenement();
		evtImx.setCode("IMX");
		evtImx.setIdentiteInitiale(id1);
		evtImx.setDateDebut(LocalDate.now().minusDays(100));
		ComplementEvenement ceImx = new ComplementEvenement();
		ceImx.setDatePhoto(evtImx.getDateDebut().plusDays(1));
		ceImx.setDateMaj(evtImx.getDateDebut());
		ceImx.setMontantArriere(new BigDecimal("1500.00"));
		ceImx.setStatutEvt(StatutEvenement.ACT);
		ceImx.setArriereLitige(false);
		ceImx.setArriereTech(false);
		ceImx.setAuditFichier(fic);
		ceImx.setIdentiteInitiale(id1);
		evtImx.addComplement(ceImx);
		entityManager.persist(evtImx);

		Evenement evtDAX = new Evenement();
		evtDAX.setCode("DAX");
		evtDAX.setIdentiteInitiale(id1);
		evtDAX.setDateDebut(LocalDate.now().minusDays(100));
		ComplementEvenement ceDax = new ComplementEvenement();
		ceDax.setDatePhoto(evtDAX.getDateDebut().plusDays(1));
		ceDax.setDateMaj(evtDAX.getDateDebut());
		ceDax.setMontantArriere(new BigDecimal("15.00"));
		ceDax.setStatutEvt(StatutEvenement.ACT);
		ceDax.setArriereLitige(false);
		ceDax.setArriereTech(false);
		ceDax.setAuditFichier(fic);
		ceDax.setIdentiteInitiale(id1);
		evtDAX.addComplement(ceDax);
		entityManager.persist(evtDAX);

		Evenement evtDefaut = new Evenement();
		evtDefaut.setCode("PCO");
		evtDefaut.setIdentiteInitiale(id1);
		ComplementEvenement ceDefaut = new ComplementEvenement();
		ceDefaut.setDatePhoto(LocalDate.now().minusDays(1));
		ceDefaut.setDateMaj(ceDefaut.getDatePhoto());
		ceDefaut.setMontantArriere(BigDecimal.ZERO);
		ceDefaut.setStatutEvt(StatutEvenement.ACT);
		ceDefaut.setArriereLitige(false);
		ceDefaut.setArriereTech(false);
		ceDefaut.setAuditFichier(fic);
		ceDefaut.setIdentiteInitiale(id1);
		evtDefaut.addComplement(ceDefaut);
		entityManager.persist(evtDefaut);

		// REF IMPACT EVT MDC
		RefImpactEvtMdc refImpact = new RefImpactEvtMdc();
		refImpact.setCodEvt("PCO");
		refImpact.setCategorieSegment(Constant.TOUS_AUTRES);
		refImpact.setImpact("D");
		refImpact.setGraviteImpact("CX");
		refImpact.setDateDebut(LocalDate.now().minusDays(100));
		entityManager.persist(refImpact);

		// REF_CLI_SEG
		RefCliSeg refCliSeg = new RefCliSeg();
		refCliSeg.setCodSegCli("3110");
		refCliSeg.setLibSegCli("PARTICULIERS");
		refCliSeg.setCodSsClassCli("RETPAR");
		refCliSeg.setTopSuppr("N");
		entityManager.persist(refCliSeg);

		// REF_CLI_SS_CLASS
		RefCliSsClass refClassSsClass = new RefCliSsClass();
		refClassSsClass.setCodSsClassCli("RETPAR");
		refClassSsClass.setLibSsClassCli("PARTICULIERS");
		refClassSsClass.setCodClassCli("RET");
		refClassSsClass.setTopSuppr("N");
		refClassSsClass.setCodTypNot("PART");
		entityManager.persist(refClassSsClass);

		entityManager.flush();

		// Act
		LocalDate dateCalc1 = LocalDate.now().minusDays(90);
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalc1);
		lot.addIdTiers(tiers.getId());
		calculService.traiteMessage(lot);

		// Creation de l'UTP PCO
		dateCalc1 = LocalDate.now();
		lot.setDateCalcul(dateCalc1);
		calculService.traiteMessage(lot);

		// Assert
		List<EvenementCalcule> evtsCalcActifs = evtCalcRepository.rechercheEvenementsCalculesActifsADate(tiers.getId(),
				dateCalc1);
		ArriereSignificatif as = (ArriereSignificatif) evtsCalcActifs.get(0);

		// Arrange 2 - Passage en défaut, puis changement de valeurs sur les montants
		as.getComplement().setDernierEvenementEnvoye(EvenementArriereSignificatif.AR3);
		Map<Long, EvenementsCalculesTiers> evtsCalc = evtCalculService.rechercheEvenementsCalculesActifsADate(lot);

		Map<Long, List<IdentiteTiers>> identitiesMap = new HashMap<Long, List<IdentiteTiers>>();
		List<IdentiteTiers> identList = new ArrayList<IdentiteTiers>();
		identList.add(id1);
		identitiesMap.put(tiers.getId(), identList);
		Map<Long, EvenementsATraiter> evtsRecus = evtRecuService.rechercheEvenementsATraiterADate(lot, identitiesMap);
		Map<Long, List<StatutHistorise>> status = defautService.getStatutsADate(lot);
		Map<Long, List<IdentiteTiers>> identities = identTiersService.rechercheIdentitesActivesADate(lot);
		ContexteCalculTiers.init(evtsRecus, status, identities, evtsCalc);
		defautService.entreeEnDefaut(tiers, LocalDate.now().minusDays(10), new MotifStatutTiers(as), LocalDate.now());
		ContexteCalculTiers.clear();

		ComplementEvenement ceImx2 = new ComplementEvenement();
		ceImx2.setDatePhoto(LocalDate.now().minusDays(5));
		ceImx.setDateFin(ceImx2.getDatePhoto());
		ceImx2.setDateMaj(ceImx2.getDatePhoto());
		ceImx2.setMontantArriere(new BigDecimal("0.00"));
		ceImx2.setStatutEvt(StatutEvenement.ANN);
		ceImx2.setArriereLitige(false);
		ceImx2.setArriereTech(false);
		ceImx2.setMiseAJour(true);
		ceImx2.setAuditFichier(fic);
		ceImx2.setIdentiteInitiale(id1);
		evtImx.addComplement(ceImx2);
		entityManager.persist(ceImx2);

		ComplementEvenement ceDax2 = new ComplementEvenement();
		ceDax2.setDatePhoto(LocalDate.now().minusDays(5));
		ceDax.setDateFin(ceDax2.getDatePhoto());
		ceDax2.setDateMaj(ceDax2.getDatePhoto());
		ceDax2.setMontantArriere(new BigDecimal("0.00"));
		ceDax2.setStatutEvt(StatutEvenement.ANN);
		ceDax2.setArriereLitige(false);
		ceDax2.setArriereTech(false);
		ceDax2.setMiseAJour(true);
		ceDax2.setAuditFichier(fic);
		ceDax2.setIdentiteInitiale(id1);
		evtDAX.addComplement(ceDax2);
		entityManager.persist(ceDax2);

		entityManager.flush();
		entityManager.detach(as);

		// Act 2
		LocalDate dateCalc2 = LocalDate.now().plusDays(1);
		lot.setDateCalcul(dateCalc2);
		calculService.traiteMessage(lot);

		List<StatutHistorise> statutList = StreamSupport.stream(statutTiersRepository.findAll().spliterator(), false)
				.collect(Collectors.toList()).stream().filter(x -> x.getDateFin() == null).collect(Collectors.toList());

		Assert.assertEquals(1, statutList.size());
		Assert.assertEquals("PCO", statutList.get(0).getMotif().getMotif());
	}

	@Test
	public void debutPeriodeProbatoireSurClotureDAXEtIMX() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);

		Tiers tiers = new Tiers();

		IdentiteTiers id1 = new IdentiteTiers();
		id1.setCodeBanque("10107"); // Par exemple
		id1.setIdLocal("abcdefg");
		id1.setCodeSegment("3110");
		id1.setDateDebut(LocalDate.now().minusDays(100));
		tiers.addIdentite(id1);

		tiers = entityManager.persistAndFlush(tiers);

		Evenement evtImx = new Evenement();
		evtImx.setCode("IMX");
		evtImx.setIdentiteInitiale(id1);
		evtImx.setDateDebut(LocalDate.now().minusDays(100));
		ComplementEvenement ceImx = new ComplementEvenement();
		ceImx.setDatePhoto(evtImx.getDateDebut().plusDays(1));
		ceImx.setDateMaj(evtImx.getDateDebut());
		ceImx.setMontantArriere(new BigDecimal("1500.00"));
		ceImx.setStatutEvt(StatutEvenement.ACT);
		ceImx.setArriereLitige(false);
		ceImx.setArriereTech(false);
		ceImx.setAuditFichier(fic);
		ceImx.setIdentiteInitiale(id1);
		evtImx.addComplement(ceImx);
		entityManager.persist(evtImx);

		Evenement evtDAX = new Evenement();
		evtDAX.setCode("DAX");
		evtDAX.setIdentiteInitiale(id1);
		evtDAX.setDateDebut(LocalDate.now().minusDays(100));
		ComplementEvenement ceDax = new ComplementEvenement();
		ceDax.setDatePhoto(evtDAX.getDateDebut().plusDays(1));
		ceDax.setDateMaj(evtDAX.getDateDebut());
		ceDax.setMontantArriere(new BigDecimal("15.00"));
		ceDax.setStatutEvt(StatutEvenement.ACT);
		ceDax.setArriereLitige(false);
		ceDax.setArriereTech(false);
		ceDax.setAuditFichier(fic);
		ceDax.setIdentiteInitiale(id1);
		evtDAX.addComplement(ceDax);
		entityManager.persist(evtDAX);

		Evenement evtDefaut = new Evenement();
		evtDefaut.setCode("PCO");
		evtDefaut.setIdentiteInitiale(id1);
		ComplementEvenement ceDefaut = new ComplementEvenement();
		ceDefaut.setDatePhoto(LocalDate.now().minusDays(1));
		ceDefaut.setDateMaj(ceDefaut.getDatePhoto());
		ceDefaut.setMontantArriere(BigDecimal.ZERO);
		ceDefaut.setStatutEvt(StatutEvenement.ACT);
		ceDefaut.setArriereLitige(false);
		ceDefaut.setArriereTech(false);
		ceDefaut.setAuditFichier(fic);
		ceDefaut.setIdentiteInitiale(id1);
		evtDefaut.addComplement(ceDefaut);
		entityManager.persist(evtDefaut);

		// REF IMPACT EVT MDC
		RefImpactEvtMdc refImpact = new RefImpactEvtMdc();
		refImpact.setCodEvt("PCO");
		refImpact.setCategorieSegment(Constant.TOUS_AUTRES);
		refImpact.setImpact("D");
		refImpact.setGraviteImpact("CX");
		refImpact.setDateDebut(LocalDate.now().minusDays(100));
		entityManager.persist(refImpact);

		// REF_CLI_SEG
		RefCliSeg refCliSeg = new RefCliSeg();
		refCliSeg.setCodSegCli("3110");
		refCliSeg.setLibSegCli("PARTICULIERS");
		refCliSeg.setCodSsClassCli("RETPAR");
		refCliSeg.setTopSuppr("N");
		entityManager.persist(refCliSeg);

		// REF_CLI_SS_CLASS
		RefCliSsClass refClassSsClass = new RefCliSsClass();
		refClassSsClass.setCodSsClassCli("RETPAR");
		refClassSsClass.setLibSsClassCli("PARTICULIERS");
		refClassSsClass.setCodClassCli("RET");
		refClassSsClass.setTopSuppr("N");
		refClassSsClass.setCodTypNot("PART");
		entityManager.persist(refClassSsClass);

		entityManager.flush();

		// Act
		LocalDate dateCalc1 = LocalDate.now().minusDays(90);
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalc1);
		lot.addIdTiers(tiers.getId());
		calculService.traiteMessage(lot);

		// Creation de l'UTP PCO
		dateCalc1 = LocalDate.now();
		lot.setDateCalcul(dateCalc1);
		calculService.traiteMessage(lot);

		// Assert
		List<EvenementCalcule> evtsCalcActifs = evtCalcRepository.rechercheEvenementsCalculesActifsADate(tiers.getId(),
				dateCalc1);
		ArriereSignificatif as = (ArriereSignificatif) evtsCalcActifs.get(0);

		// Arrange 2 - Passage en défaut, puis changement de valeurs sur les montants
		as.getComplement().setDernierEvenementEnvoye(EvenementArriereSignificatif.AR3);
		Map<Long, EvenementsCalculesTiers> evtsCalc = evtCalculService.rechercheEvenementsCalculesActifsADate(lot);

		Map<Long, List<IdentiteTiers>> identitiesMap = new HashMap<Long, List<IdentiteTiers>>();
		List<IdentiteTiers> identList = new ArrayList<IdentiteTiers>();
		identList.add(id1);
		identitiesMap.put(tiers.getId(), identList);
		Map<Long, EvenementsATraiter> evtsRecus = evtRecuService.rechercheEvenementsATraiterADate(lot, identitiesMap);
		Map<Long, List<StatutHistorise>> status = defautService.getStatutsADate(lot);
		Map<Long, List<IdentiteTiers>> identities = identTiersService.rechercheIdentitesActivesADate(lot);
		ContexteCalculTiers.init(evtsRecus, status, identities, evtsCalc);
		defautService.entreeEnDefaut(tiers, LocalDate.now().minusDays(10), new MotifStatutTiers(as), LocalDate.now());
		ContexteCalculTiers.clear();

		ComplementEvenement ceImx2 = new ComplementEvenement();
		ceImx2.setDatePhoto(LocalDate.now().minusDays(5));
		ceImx.setDateFin(ceImx2.getDatePhoto());
		ceImx2.setDateMaj(ceImx2.getDatePhoto());
		ceImx2.setMontantArriere(new BigDecimal("0.00"));
		ceImx2.setStatutEvt(StatutEvenement.CLO);
		ceImx2.setArriereLitige(false);
		ceImx2.setArriereTech(false);
		ceImx2.setMiseAJour(true);
		ceImx2.setAuditFichier(fic);
		ceImx2.setIdentiteInitiale(id1);
		evtImx.addComplement(ceImx2);
		entityManager.persist(ceImx2);

		ComplementEvenement ceDax2 = new ComplementEvenement();
		ceDax2.setDatePhoto(LocalDate.now().minusDays(5));
		ceDax.setDateFin(ceDax2.getDatePhoto());
		ceDax2.setDateMaj(ceDax2.getDatePhoto());
		ceDax2.setMontantArriere(new BigDecimal("0.00"));
		ceDax2.setStatutEvt(StatutEvenement.CLO);
		ceDax2.setArriereLitige(false);
		ceDax2.setArriereTech(false);
		ceDax2.setMiseAJour(true);
		ceDax2.setAuditFichier(fic);
		ceDax2.setIdentiteInitiale(id1);
		evtDAX.addComplement(ceDax2);
		entityManager.persist(ceDax2);

		entityManager.flush();
		entityManager.detach(as);

		// Act 2
		LocalDate dateCalc2 = LocalDate.now().plusDays(1);
		lot.setDateCalcul(dateCalc2);
		calculService.traiteMessage(lot);

		List<StatutHistorise> statutList = StreamSupport.stream(statutTiersRepository.findAll().spliterator(), false)
				.collect(Collectors.toList()).stream().filter(x -> x.getDateFin() == null).collect(Collectors.toList());

		Assert.assertEquals(1, statutList.size());
		Assert.assertEquals("PCO", statutList.get(0).getMotif().getMotif());
	}
}

package fr.bpce.yyd.service.traitement.evenements.service.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class StatutTiersDTO implements Serializable {

	private static final long serialVersionUID = -4119948613119523049L;

	private String statut;
	private String dateDebut;
	private List<MotifDefautDTO> motifs = new ArrayList<>();

	public StatutTiersDTO() {
	}

	public StatutTiersDTO(String statut, String dateDebut) {
		this.statut = statut;
		this.dateDebut = dateDebut;
	}

	public String getStatut() {
		return statut;
	}

	public void setStatut(String statut) {
		this.statut = statut;
	}

	public String getDateDebut() {
		return dateDebut;
	}

	public void setDateDebut(String dateDebut) {
		this.dateDebut = dateDebut;
	}

	public void addMotif(MotifDefautDTO motifDefaut) {
		motifs.add(motifDefaut);
	}

	public List<MotifDefautDTO> getMotifs() {
		return motifs;
	}

	public void setMotifs(List<MotifDefautDTO> motifs) {
		this.motifs = motifs;
	}
}

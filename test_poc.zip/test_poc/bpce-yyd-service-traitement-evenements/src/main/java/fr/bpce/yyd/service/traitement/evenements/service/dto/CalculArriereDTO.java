package fr.bpce.yyd.service.traitement.evenements.service.dto;

import java.io.Serializable;

public class CalculArriereDTO implements Serializable {

	private static final long serialVersionUID = -1371081568127481555L;

	private String montantAbsolu;
	private String montantRelatif;
	private String montantEncours;
	private boolean significatif;
	private String dateCalcul;

	public String getMontantAbsolu() {
		return montantAbsolu;
	}

	public void setMontantAbsolu(String montantAbsolu) {
		this.montantAbsolu = montantAbsolu;
	}

	public String getMontantRelatif() {
		return montantRelatif;
	}

	public void setMontantRelatif(String montantRelatif) {
		this.montantRelatif = montantRelatif;
	}

	public boolean isSignificatif() {
		return significatif;
	}

	public void setSignificatif(boolean significatif) {
		this.significatif = significatif;
	}

	public String getDateCalcul() {
		return dateCalcul;
	}

	public void setDateCalcul(String dateCalcul) {
		this.dateCalcul = dateCalcul;
	}

	public String getMontantEncours() {
		return montantEncours;
	}

	public void setMontantEncours(String montantEncours) {
		this.montantEncours = montantEncours;
	}

}

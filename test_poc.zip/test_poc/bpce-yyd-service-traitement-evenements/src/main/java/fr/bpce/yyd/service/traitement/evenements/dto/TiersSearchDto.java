package fr.bpce.yyd.service.traitement.evenements.dto;

import java.io.Serializable;
import java.util.List;

import fr.bpce.yyd.service.traitement.evenements.enums.TypeRecherche;
import lombok.*;

/**
 * @author Abdelkabir
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TiersSearchDto implements Serializable {

	private static final long serialVersionUID = -6433498710787126887L;

	private Long   id;
	private String idRft;
	private String siren;
	private String idLocal;
	private String codeBanque;
	private String raisonSociale;
	private String segment;
	private String libelleSeg;

	@Data
	@NoArgsConstructor
	public static class SearchQuery {

		private String critere;
		private String valeur;
		private TypeRecherche type;
		private String codeBanque;
		private List<String> perimetre;
	}
}

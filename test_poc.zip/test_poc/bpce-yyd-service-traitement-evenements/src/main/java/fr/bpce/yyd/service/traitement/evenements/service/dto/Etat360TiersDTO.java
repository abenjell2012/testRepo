package fr.bpce.yyd.service.traitement.evenements.service.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Etat360TiersDTO implements Serializable {

	private static final long serialVersionUID = 4471252771282104855L;

	private String dateEtat;
	private Long idInterne;
	private String idFereral;

	private StatutTiersDTO statut;

	private List<IdentiteTiersDTO> identitesActives = new ArrayList<>();
	private List<EvenementRecuDTO> evenementsRecus = new ArrayList<>();
	private List<EvenementCalculeDTO> evenementsCalcules = new ArrayList<>();

	private CalculArriereDTO dernierCalculADate;

	public Long getIdInterne() {
		return idInterne;
	}

	public void setIdInterne(Long idInterne) {
		this.idInterne = idInterne;
	}

	public String getIdRFT() {
		return idFereral;
	}

	public void setIdRFT(String idFereral) {
		this.idFereral = idFereral;
	}

	public StatutTiersDTO getStatut() {
		return statut;
	}

	public void setStatut(StatutTiersDTO statut) {
		this.statut = statut;
	}

	public List<EvenementRecuDTO> getEvenementsRecus() {
		return evenementsRecus;
	}

	public Etat360TiersDTO addEvenementRecu(EvenementRecuDTO evt) {
		evenementsRecus.add(evt);
		return this;
	}

	public void setEvenementsRecus(List<EvenementRecuDTO> evenementsRecus) {
		this.evenementsRecus = evenementsRecus;
	}

	public List<EvenementCalculeDTO> getEvenementsCalcules() {
		return evenementsCalcules;
	}

	public Etat360TiersDTO addEvenementCalcule(EvenementCalculeDTO evt) {
		evenementsCalcules.add(evt);
		return this;
	}

	public void setEvenementsCalcules(List<EvenementCalculeDTO> evenementsCalcules) {
		this.evenementsCalcules = evenementsCalcules;
	}

	public String getDateEtat() {
		return dateEtat;
	}

	public void setDateEtat(String dateEtat) {
		this.dateEtat = dateEtat;
	}

	public List<IdentiteTiersDTO> getIdentitesActives() {
		return identitesActives;
	}

	public Etat360TiersDTO addIdentiteActive(IdentiteTiersDTO ident) {
		identitesActives.add(ident);
		return this;
	}

	public void setIdentitesActives(List<IdentiteTiersDTO> identitesActives) {
		this.identitesActives = identitesActives;
	}

	public CalculArriereDTO getDernierCalculADate() {
		return dernierCalculADate;
	}

	public void setDernierCalculADate(CalculArriereDTO dernierCalculADate) {
		this.dernierCalculADate = dernierCalculADate;
	}
}

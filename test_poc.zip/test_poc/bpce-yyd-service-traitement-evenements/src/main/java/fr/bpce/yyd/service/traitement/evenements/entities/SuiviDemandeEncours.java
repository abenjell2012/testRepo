package fr.bpce.yyd.service.traitement.evenements.entities;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import fr.bpce.yyd.commun.converters.LocalDatePersistenceConverter;
import fr.bpce.yyd.commun.converters.LocalDateTimePersistenceConverter;

@Entity
@Table(name = "SUIVI_DEMANDE_ENCOURS")
public class SuiviDemandeEncours implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "MSGID", length = 36)
	private String msgId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "DATE_DEMANDE")
	private Date dateDemande;

	@Convert(converter = LocalDatePersistenceConverter.class)
	@Column(name = "DATE_ENCOURS")
	private LocalDate dateEncours;

	@Convert(converter = LocalDatePersistenceConverter.class)
	@Column(name = "DATE_ARRETE_MENSUELLE")
	private LocalDate dateArreteMensuelle;

	@Column(name = "CODE_ERREUR", length = 30)
	private String codeErreur;

	@Column(name = "MSG_ERREUR", length = 250)
	private String msgErreur;

	@Convert(converter = LocalDateTimePersistenceConverter.class)
	@Column(name = "DATE_TRAITEMENT_RMN")
	private LocalDateTime dateTraitementRMN;

	@OneToMany(mappedBy = "suiviDemandeEncours", cascade = { CascadeType.PERSIST })
	private Set<SuiviEncoursTiers> encoursTiers = new HashSet<>();

	public SuiviDemandeEncours(String msgId, Date dateDemande, LocalDate dateEncours, LocalDate dateArreteMensuelle,
			String codeErreur) {
		this.msgId = msgId;
		this.dateDemande = dateDemande;
		this.dateEncours = dateEncours;
		this.dateArreteMensuelle = dateArreteMensuelle;
		this.codeErreur = codeErreur;
	}

	public SuiviDemandeEncours(String msgId, Date dateDemande, LocalDate dateEncours, LocalDate dateArreteMensuelle) {
		this(msgId, dateDemande, dateEncours, dateArreteMensuelle, null);
	}

	public SuiviDemandeEncours(String msgId, Date dateDemande, LocalDate dateEncours) {
		this(msgId, dateDemande, dateEncours, null, null);
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getMsgId() {
		return msgId;
	}

	public void setMsgId(String msgId) {
		this.msgId = msgId;
	}

	public Date getDateDemande() {
		return dateDemande;
	}

	public void setDateDemande(Date dateDemande) {
		this.dateDemande = dateDemande;
	}

	public LocalDate getDateEncours() {
		return dateEncours;
	}

	public void setDateEncours(LocalDate dateEncours) {
		this.dateEncours = dateEncours;
	}

	public LocalDate getDateArreteMensuelle() {
		return dateArreteMensuelle;
	}

	public void setDateArreteMensuelle(LocalDate dateArreteMensuelle) {
		this.dateArreteMensuelle = dateArreteMensuelle;
	}

	public String getCodeErreur() {
		return codeErreur;
	}

	public void setCodeErreur(String codeErreur) {
		this.codeErreur = codeErreur;
	}

	public Set<SuiviEncoursTiers> getEncoursTiers() {
		return encoursTiers;
	}

	public void setEncoursTiers(Set<SuiviEncoursTiers> encoursTiers) {
		this.encoursTiers = encoursTiers;
	}

	public SuiviDemandeEncours() {
	}

	public String getMsgErreur() {
		return msgErreur;
	}

	public void setMsgErreur(String msgErreur) {
		this.msgErreur = msgErreur;
	}

	public LocalDateTime getDateTraitementRMN() {
		return dateTraitementRMN;
	}

	public void setDateTraitementRMN(LocalDateTime dateTraitementRMN) {
		this.dateTraitementRMN = dateTraitementRMN;
	}
}

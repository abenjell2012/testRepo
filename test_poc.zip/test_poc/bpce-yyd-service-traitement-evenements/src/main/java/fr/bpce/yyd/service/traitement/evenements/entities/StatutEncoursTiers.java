package fr.bpce.yyd.service.traitement.evenements.entities;

public enum StatutEncoursTiers {
	ATTENTE, REJETE, NON_REJETE;
}

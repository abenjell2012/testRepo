package fr.bpce.yyd.service.traitement.evenements.kafka.service;

import fr.bpce.yyd.service.commun.yyc.kafka.dto.DemandeEncours;

public interface KafkaDemandeEncours {

	void send(DemandeEncours data, String msgId);

}

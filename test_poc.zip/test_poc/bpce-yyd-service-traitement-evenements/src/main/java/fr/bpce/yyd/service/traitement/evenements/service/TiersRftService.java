package fr.bpce.yyd.service.traitement.evenements.service;

import java.time.LocalDate;

import fr.bpce.yyd.service.commun.yyc.model.DemandeLotTiersRft;
import fr.bpce.yyd.service.commun.yyc.model.ReponseLotTiersRft;


public interface TiersRftService {

	ReponseLotTiersRft processRequest(DemandeLotTiersRft request);
	LocalDate getDateArrete(LocalDate dateAppel);
}

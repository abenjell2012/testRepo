package fr.bpce.yyd.service.traitement.evenements.service.impl;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Lists;

import fr.bpce.yyd.commun.enums.CategorieSegment;
import fr.bpce.yyd.commun.messages.dto.LotIdTiersDTO;
import fr.bpce.yyd.commun.model.EncoursTiers;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.commun.service.RefCliSegService;
import fr.bpce.yyd.service.commun.beans.InfoTiers;
import fr.bpce.yyd.service.commun.repository.IdentiteTiersRepository;
import fr.bpce.yyd.service.commun.repository.TiersRepository;
import fr.bpce.yyd.service.commun.service.IdentiteTiersService;
import fr.bpce.yyd.service.commun.service.ParametresNDoD;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.DemandeEncours;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.DemandeEncoursTiers;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.NotifEncours;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.ReponseEncours;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.ReponseEncoursTiers;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.TypeAgregat;
import fr.bpce.yyd.service.traitement.evenements.entities.InfoEncoursTiers;
import fr.bpce.yyd.service.traitement.evenements.entities.NotificationEncours;
import fr.bpce.yyd.service.traitement.evenements.entities.StatutEncoursTiers;
import fr.bpce.yyd.service.traitement.evenements.entities.SuiviDemandeEncours;
import fr.bpce.yyd.service.traitement.evenements.entities.SuiviEncoursTiers;
import fr.bpce.yyd.service.traitement.evenements.kafka.service.KafkaDemandeEncours;
import fr.bpce.yyd.service.traitement.evenements.kafka.service.ProducerLotIdTiers;
import fr.bpce.yyd.service.traitement.evenements.repositories.EncoursTiersRepository;
import fr.bpce.yyd.service.traitement.evenements.repositories.NotificationEncoursRepository;
import fr.bpce.yyd.service.traitement.evenements.repositories.SuiviDemandeEncoursRepository;
import fr.bpce.yyd.service.traitement.evenements.repositories.SuiviEncoursTiersRepository;
import fr.bpce.yyd.service.traitement.evenements.service.EncoursService;

@Service
public class EncoursServiceImpl implements EncoursService {

	private static final Logger LOG = LoggerFactory.getLogger(EncoursServiceImpl.class);

	@Value("${echange-encours.mocked}")
	private boolean echangeMocked;

	@Value("${echange-encours.recalculApresRepEncours}")
	private boolean recalculApresRepEncours;

	@Value("${echange-encours.initEncoursAfterNotif.active}")
	private boolean initEncours;

	@Value("${echange-encours.initEncoursAfterNotif.nbDaysToScan}")
	private int nbDaysToScan;

	@Value("${kafka.nbTiersLot}")
	private String nbTiersLot;

	@Autowired
	private IdentiteTiersService identTiersService;

	@Autowired
	private TiersRepository tiersRepository;

	@Autowired
	private RefCliSegService refCliSegService;

	@Autowired
	private NotificationEncoursRepository repNotificationEncours;

	@Autowired
	private SuiviDemandeEncoursRepository repSuiviDemandeEncours;

	@Autowired
	private SuiviEncoursTiersRepository repSuiviEncoursTiers;

	@Autowired
	private KafkaDemandeEncours producerDemandeEncours;

	@Autowired
	private ProducerLotIdTiers kafkaLotTiers;

	@Autowired
	private EncoursTiersRepository repEncoursTiers;

	@Autowired
	private ParametresNDoD parametresNdodSrvc;

	@Autowired
	private IdentiteTiersRepository identiteTiersRepo;

	/**
	 * {@inheritDoc}
	 */
	@Override
	public InfoEncoursTiers rechercheEncoursTiersADate(Long idTiers, LocalDate dateDemande, LocalDate datePhoto) {
		InfoEncoursTiers infoEncoursTiers = new InfoEncoursTiers(idTiers, dateDemande);
		infoEncoursTiers.setDemandeEncoursAEnvoyer(false);
		return rechercheEncoursTiers(idTiers, dateDemande, datePhoto, infoEncoursTiers, echangeMocked);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public InfoEncoursTiers rechercheEncoursTiers(Long idTiers, LocalDate dateDemande, LocalDate datePhoto,
			InfoEncoursTiers infoEncoursTiers, boolean mocked) {
		if (mocked) {
			String segmentTiers = identTiersService.donneSegmentDuTiers(idTiers, dateDemande);
			String catSeg = refCliSegService.getCategorieSegment(segmentTiers);
			if (CategorieSegment.PART.name().equals(catSeg) || CategorieSegment.PROF.name().equals(catSeg)
					|| CategorieSegment.NSEG.name().equals(catSeg)) {
				// Retail
				infoEncoursTiers.setMontantEncours(new BigDecimal(5000));
			} else { // Hors retail
				infoEncoursTiers.setMontantEncours(new BigDecimal(150000));
			}
		} else {
			Optional<Tiers> tiersOpt = tiersRepository.findById(idTiers);
			String idFederal = tiersOpt.isPresent() ? tiersOpt.get().getIdFederal() : null;
			TypeAgregat typeAgregat = TypeAgregat.N;
			List<TypeAgregat> typeAgregaList = null;

			if (idFederal == null) {
				String codeBanque = identTiersService.donneCodeBanqueDuTiersRetail(idTiers, dateDemande);
				typeAgregat = calculateTypeAgregat(codeBanque, dateDemande);
				typeAgregaList = repEncoursTiers.searchListTypeAgregaDemandeEncours(idTiers, datePhoto);
			} else {
				typeAgregaList = repEncoursTiers.searchListTypeAgregaFederaleDemandeEncours(idTiers, datePhoto,
						idFederal);
			}
			completeInfoEncours(idTiers, datePhoto, infoEncoursTiers, typeAgregaList, typeAgregat);
		}
		return infoEncoursTiers;
	}

	private void completeInfoEncours(Long idTiers, LocalDate datePhoto, InfoEncoursTiers infoEncoursTiers,
			List<TypeAgregat> typeAgregaList, TypeAgregat typeAgregat) {
		if (typeAgregaList != null && !typeAgregaList.isEmpty() && typeAgregat.equals(typeAgregaList.get(0))) {
			List<EncoursTiers> encoursTiersList = repEncoursTiers.searchIdTiersAndDatePhoto(idTiers, datePhoto);
			if (encoursTiersList != null && !encoursTiersList.isEmpty()) {
				// si encours present = datePhoto alors le prendre.
				infoEncoursTiers.setDatePhoto(encoursTiersList.get(0).getDatePhoto());
				if (encoursTiersList.get(0) != null) {
					infoEncoursTiers.setMontantEncours(encoursTiersList.get(0).getMontantEncoursBrut());
				} else {
					// faire une demande d'encours à Notation
					infoEncoursTiers.setMontantEncours(null);
					infoEncoursTiers.setDemandeEncoursAEnvoyer(true);
				}
				// sinon retourner null (= seuil relatif positif).
			} else {
				// faire une demande d'encours à Notation
				infoEncoursTiers.setMontantEncours(null);
				infoEncoursTiers.setDemandeEncoursAEnvoyer(true);
			}
		} else {
			// faire une demande d'encours à Notation
			infoEncoursTiers.setMontantEncours(null);
			infoEncoursTiers.setDemandeEncoursAEnvoyer(true);
		}
	}

	@Override
	public void saveEncoursNotification(NotifEncours message, String msgId) {
		repNotificationEncours.save(new NotificationEncours(msgId, new Date(), message.getDateArreteMensuelle()));
		if (initEncours && !echangeMocked) {
			LocalDate dateCalculBase = parametresNdodSrvc.getDateCalculCourante();
			LocalDate dateDemande = dateCalculBase == null ? message.getDateArreteMensuelle()
					: dateCalculBase.plusDays(1);
			initDemandeEncoursApresNotif(dateDemande);
		}
	}

	@Override
	public void initDemandeEncoursApresNotif(LocalDate datedemande) {

		List<InfoTiers> tiersInfosList = tiersRepository.listAllTiersWithEvt2(datedemande);
		// infos sur le nombre de tiers pour les demandes d'encours
		if (tiersInfosList.isEmpty()) {
			LOG.warn("aucun tiers avec IMX, DAX actifs");
		} else {
			LOG.warn("{} tiers avec IMX, DAX actifs", tiersInfosList.size());
		}

		SuiviDemandeEncours suiviDemandeEncoursDb = null;
		List<SuiviEncoursTiers> listSuiviEncoursDb = null;
		DemandeEncours demandeEncoursKfk = null;
		List<DemandeEncoursTiers> listDemandeEncoursTiersKfk = null;
		List<String> listCliFederaux = new ArrayList<>();

		List<List<InfoTiers>> splittedList = Lists.partition(tiersInfosList, 990);
		for (List<InfoTiers> listInfoTiers : splittedList) {
			// faire des demandes par partition de 990
			String msgId = UUID.randomUUID().toString();
			// Suivi Demande stocké en base
			suiviDemandeEncoursDb = new SuiviDemandeEncours(msgId, new Date(), datedemande);
			repSuiviDemandeEncours.saveAndFlush(suiviDemandeEncoursDb);
			listSuiviEncoursDb = new ArrayList<>();

			// Message de demande KAFKA
			demandeEncoursKfk = new DemandeEncours(datedemande);
			listDemandeEncoursTiersKfk = new ArrayList<>();

			completeDemandesEncours(datedemande, suiviDemandeEncoursDb, listSuiviEncoursDb, listDemandeEncoursTiersKfk,
					listCliFederaux, listInfoTiers);

			if (!listSuiviEncoursDb.isEmpty()) {
				repSuiviEncoursTiers.saveAll(listSuiviEncoursDb);
				repSuiviEncoursTiers.flush();
				LOG.info("insertion de {} lignes dans la table SUIVI_ENCOURS_TIERS", listSuiviEncoursDb.size());

			}
			if (!listDemandeEncoursTiersKfk.isEmpty()) {
				demandeEncoursKfk.setListTiers(listDemandeEncoursTiersKfk);
				producerDemandeEncours.send(demandeEncoursKfk, msgId);
			}

		}

	}

	private void completeDemandesEncours(LocalDate datedemande, SuiviDemandeEncours suiviDemandeEncoursDb,
			List<SuiviEncoursTiers> listSuiviEncoursDb, List<DemandeEncoursTiers> listDemandeEncoursTiersKfk,
			List<String> listCliFederaux, List<InfoTiers> listInfoTiers) {

		for (InfoTiers tiersInfo : listInfoTiers) {
			Tiers tiers = new Tiers(tiersInfo.getIdTiers(), tiersInfo.getIdFederal());
			if (tiersInfo.getIdFederal() != null && !listCliFederaux.contains(tiersInfo.getIdFederal())) {
				SuiviEncoursTiers suiviEncoursDb = new SuiviEncoursTiers(TypeAgregat.N, suiviDemandeEncoursDb, tiers,
						tiersInfo.getIdFederal(), null, null, StatutEncoursTiers.ATTENTE);
				listSuiviEncoursDb.add(suiviEncoursDb);
				listDemandeEncoursTiersKfk
						.add(new DemandeEncoursTiers(TypeAgregat.N, tiersInfo.getIdFederal(), null, null));
				listCliFederaux.add(tiersInfo.getIdFederal());
			} else {
				if (tiersInfo.getIdFederal() == null && tiersInfo.getCodeBanque() != null
						&& tiersInfo.getIdLocal() != null) {
					TypeAgregat typeAgreg = calculateTypeAgregat(tiersInfo.getCodeBanque(), datedemande);
					SuiviEncoursTiers suiviEncoursDb = new SuiviEncoursTiers(typeAgreg, suiviDemandeEncoursDb, tiers,
							null, tiersInfo.getCodeBanque(), tiersInfo.getIdLocal(), StatutEncoursTiers.ATTENTE);
					listSuiviEncoursDb.add(suiviEncoursDb);
					listDemandeEncoursTiersKfk.add(new DemandeEncoursTiers(typeAgreg, null, tiersInfo.getCodeBanque(),
							tiersInfo.getIdLocal()));
				}
			}
		}
	}

	private TypeAgregat calculateTypeAgregat(String codeBanque, LocalDate dateCalcul) {
		TypeAgregat typeAg = TypeAgregat.L;
		List<String> codBqAgregNatList = parametresNdodSrvc.getCodBqAgregationNationale(dateCalcul);
		if (codBqAgregNatList.contains(codeBanque)) {
			typeAg = TypeAgregat.R;
		}
		return typeAg;
	}

	@Override
	@Transactional
	public void traiterReponseEncours(ReponseEncours msgReponseKafka, String msgId) {
		// recherche de la demande en BDD correspondante à la réponse grace au msgID
		SuiviDemandeEncours suiviDemande = repSuiviDemandeEncours.findByMsgIdAndDateEncours(msgId,
				msgReponseKafka.getDateEncours());
		List<Long> listIdTiersArecalculer = new ArrayList<>();
		if (suiviDemande != null) {
			List<EncoursTiers> encoursTiersList = new ArrayList<>();
			suiviDemande.setCodeErreur(msgReponseKafka.getCodeErreur());
			suiviDemande.setMsgErreur(msgReponseKafka.getMessageErreur());
			suiviDemande.setDateTraitementRMN(msgReponseKafka.getDateTraitement());
			suiviDemande.setDateArreteMensuelle(msgReponseKafka.getDateArreteMensuelle());
			if (Boolean.TRUE.equals(msgReponseKafka.getCodeRetour())) {
				LOG.info("Rejet de la demande ou incident technique pour la demande {} , {} ", suiviDemande.getId(),
						suiviDemande.getMsgErreur());
				for (SuiviEncoursTiers suiviEncoursDB : suiviDemande.getEncoursTiers()) {
					suiviEncoursDB.setStatut(StatutEncoursTiers.REJETE);
				}
				repSuiviDemandeEncours.saveAndFlush(suiviDemande);
			} else {
				Map<String, ReponseEncoursTiers> mapMsgEncours = getMapMsgRepEncours(msgReponseKafka.getEncoursTiers());

				for (SuiviEncoursTiers suiviEncoursDB : suiviDemande.getEncoursTiers()) {
					String idFederal = suiviEncoursDB.getIdFederal();
					String codeBanque = suiviEncoursDB.getCodeBanque();
					String idLocal = suiviEncoursDB.getIdLocal();
					StringBuilder key = new StringBuilder();
					key.append(idFederal).append("#").append(codeBanque).append("#").append(idLocal);
					ReponseEncoursTiers msgReponseEncours = mapMsgEncours.get(key.toString());
					// si on trouve une réponse pour le triplet en question
					// (idFederal,codeBanque,idLocal)
					if (msgReponseEncours != null) {
						Boolean estClientRejete = msgReponseEncours.getStatutRejet();
						if (Boolean.TRUE.equals(estClientRejete)) {
							suiviEncoursDB.setStatut(StatutEncoursTiers.REJETE);
							suiviEncoursDB.setCodeRejet(msgReponseEncours.getCodeRejet());
							suiviEncoursDB.setMsgRejet(msgReponseEncours.getMessageRejet());
						} else {
							suiviEncoursDB.setStatut(StatutEncoursTiers.NON_REJETE);
						}
						// construction des entités de la table ENCOURS_TIERS à stocker
						encoursTiersList.add(new EncoursTiers(msgReponseKafka.getDateArreteMensuelle(),
								suiviEncoursDB.getTiers().getId(), new Date(),
								!Boolean.TRUE.equals(estClientRejete) ? msgReponseEncours.getMntEngBrutBil()
										: BigDecimal.ZERO));
						// envoi du tiers sur la file KAFKA pour calcul de l'AS
						listIdTiersArecalculer.add(suiviEncoursDB.getTiers().getId());

					}

				}
				repSuiviDemandeEncours.saveAndFlush(suiviDemande);

				repEncoursTiers.saveAll(encoursTiersList);
				repEncoursTiers.flush();

				if (LOG.isDebugEnabled()) {
					LOG.debug("insertion de {} lignes dans la table ENCOURS_TIERS", encoursTiersList.size());

				}

				if (!listIdTiersArecalculer.isEmpty() && recalculApresRepEncours) {
					LocalDate dateCalculBase = parametresNdodSrvc.getDateCalculCourante();
					// date calcul trt-evt égale date calcul compteur + 1
					envoyerIdsTiersParPaquet(listIdTiersArecalculer, dateCalculBase.plusDays(1),
							Integer.parseInt(nbTiersLot));
				}

			}

		} else {
			LOG.warn("La Demande d'encours avec msgId = {} et dateEncours {} est introuvable", msgId,
					msgReponseKafka.getDateEncours());

		}

	}

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void initDemandeEncoursLotIdTiers(LocalDate datedemande, List<Long> idTiers) {
		if (idTiers == null || idTiers.isEmpty()) {
			return;
		}
		String msgId = UUID.randomUUID().toString();
		SuiviDemandeEncours suiviDemandeEncours = new SuiviDemandeEncours(msgId, new Date(), datedemande);
		repSuiviDemandeEncours.saveAndFlush(suiviDemandeEncours);
		DemandeEncours msgDemandeEncours = new DemandeEncours(datedemande);
		List<SuiviEncoursTiers> listSuiviEncours = new ArrayList<>();
		List<DemandeEncoursTiers> listMsgSuiviEncours = new ArrayList<>();
		List<Long> lidTiersSansDoublons = idTiers.stream().distinct().collect(Collectors.toList());

		List<InfoTiers> infosTiers = identiteTiersRepo.rechercheIdentitesActives(lidTiersSansDoublons);

		Map<Long, List<InfoTiers>> mapParIdTiers = infosTiers.stream()
				.collect(Collectors.groupingBy(InfoTiers::getIdTiers));

		for (Long tiersId : lidTiersSansDoublons) {

			if (mapParIdTiers.get(tiersId).isEmpty()) {
				continue;
			}

			InfoTiers infoTiers = mapParIdTiers.get(tiersId).get(0);
			Tiers tiers = new Tiers(infoTiers.getIdTiers(), infoTiers.getIdFederal());

			if (infoTiers.getIdFederal() != null) {
				SuiviEncoursTiers suiviEncoursDb = new SuiviEncoursTiers(TypeAgregat.N, suiviDemandeEncours, tiers,
						infoTiers.getIdFederal(), null, null, StatutEncoursTiers.ATTENTE);
				listSuiviEncours.add(suiviEncoursDb);
				listMsgSuiviEncours.add(new DemandeEncoursTiers(TypeAgregat.N, infoTiers.getIdFederal(), null, null));

			} else {

				if (infoTiers.getCodeBanque() != null && infoTiers.getIdLocal() != null) {
					TypeAgregat typeAgreg = calculateTypeAgregat(infoTiers.getCodeBanque(), datedemande);
					SuiviEncoursTiers suiviEncoursDb = new SuiviEncoursTiers(typeAgreg, suiviDemandeEncours, tiers,
							null, infoTiers.getCodeBanque(), infoTiers.getIdLocal(), StatutEncoursTiers.ATTENTE);
					listSuiviEncours.add(suiviEncoursDb);
					listMsgSuiviEncours.add(new DemandeEncoursTiers(typeAgreg, null, infoTiers.getCodeBanque(),
							infoTiers.getIdLocal()));
				}
			}

		}

		repSuiviEncoursTiers.saveAll(listSuiviEncours);
		repSuiviEncoursTiers.flush();
		LOG.info("insertion de {} lignes dans la table SUIVI_ENCOURS_TIERS", listSuiviEncours.size());

		if (producerDemandeEncours != null) {
			msgDemandeEncours.setListTiers(listMsgSuiviEncours);
			producerDemandeEncours.send(msgDemandeEncours, msgId);
		}

	}

	private void envoyerIdsTiersParPaquet(List<Long> listIdTiersArecalculer, LocalDate dateEncours, int nbsParPaquet) {
		LotIdTiersDTO lotIdsTiers = new LotIdTiersDTO();
		lotIdsTiers.setDateCalcul(dateEncours);
		int i = 0;
		for (Long idTiers : listIdTiersArecalculer) {
			lotIdsTiers.addIdTiers(idTiers);
			if (++i % nbsParPaquet == 0) {
				envoieLotIds(lotIdsTiers);
			}
		}
		envoieLotIds(lotIdsTiers);
	}

	private void envoieLotIds(LotIdTiersDTO lotIds) {
		if (!lotIds.getIdsTiers().isEmpty()) {
			kafkaLotTiers.send(lotIds);
			// Réinitialisation
			lotIds.getIdsTiers().clear();
		}
	}

	private Map<String, ReponseEncoursTiers> getMapMsgRepEncours(List<ReponseEncoursTiers> lEncoursTiers) {

		Map<String, ReponseEncoursTiers> returnMap = new HashMap<>();
		for (ReponseEncoursTiers msgEncours : lEncoursTiers) {
			returnMap.put(
					msgEncours.getIdRft() + "#" + msgEncours.getCodeFournisseur() + "#" + msgEncours.getClientId(),
					msgEncours);
		}

		return returnMap;
	}

	@Override
	public LocalDate rechercheDateEncoursTiersADate(Long idTiers, LocalDate dateCalcul) {
		return repEncoursTiers.searchDateEncours(idTiers, dateCalcul);
	}

	public void setRepNotificationEncours(NotificationEncoursRepository repNotificationEncours) {
		this.repNotificationEncours = repNotificationEncours;
	}

	public void setRepSuiviDemandeEncours(SuiviDemandeEncoursRepository repSuiviDemandeEncours) {
		this.repSuiviDemandeEncours = repSuiviDemandeEncours;
	}

	public void setProducerDemandeEncours(KafkaDemandeEncours producerDemandeEncours) {
		this.producerDemandeEncours = producerDemandeEncours;
	}

	public void setIdentTiersService(IdentiteTiersService identTiersService) {
		this.identTiersService = identTiersService;
	}

	public void setRefCliSegService(RefCliSegService refCliSegService) {
		this.refCliSegService = refCliSegService;
	}

	public void setRecalculApresRepEncours(boolean recalculApresRepEncours) {
		this.recalculApresRepEncours = recalculApresRepEncours;
	}

	public void setEchangeMocked(boolean echangeMocked) {
		this.echangeMocked = echangeMocked;
	}

	public void setRepEncoursTiers(EncoursTiersRepository repEncoursTiers) {
		this.repEncoursTiers = repEncoursTiers;
	}

	public void setTiersRepository(TiersRepository tiersRepository) {
		this.tiersRepository = tiersRepository;
	}

	public void setParametresNdodSrvc(ParametresNDoD parametresNdodSrvc) {
		this.parametresNdodSrvc = parametresNdodSrvc;
	}
}
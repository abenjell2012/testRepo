package fr.bpce.yyd.service.traitement.evenements.web.utils;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

import org.apache.commons.lang3.StringUtils;

public final class WebUtility {

	public static final DateTimeFormatter datePattern = DateTimeFormatter.ofPattern("dd/MM/yyyy");

	private WebUtility() {
	}

	public static String dateToString(LocalDate date) {

		if (date == null) {
			return StringUtils.EMPTY;
		}
		return date.format(datePattern);
	}

	public static String dateToString(LocalDateTime date) {
		if (date == null) {
			return StringUtils.EMPTY;
		}
		return date.format(datePattern);
	}

	public static String booleanToString(boolean bool) {
		return bool ? "OUI" : "NON";
	}

	public static boolean toBoolean(BigDecimal decimal) {
		return (decimal != null && decimal.signum() > 0);
	}

	public static String booleanToString(BigDecimal decimal) {
		return toBoolean(decimal) ? "OUI" : "NON";
	}

	public static LocalDate convertToLocalDate(java.util.Date dateToConvert) {
		if (dateToConvert == null) {
			return null;
		}
		return new java.sql.Date(dateToConvert.getTime()).toLocalDate();
	}

	public static String formatToString(java.util.Date dateToConvert) {

		return dateToString(convertToLocalDate(dateToConvert));
	}

	public static int longToInt(Long numb) {
		if (numb == null) {
			return 0;
		}
		return numb.intValue();
	}

	public static BigDecimal toBigDecimal(BigDecimal nombre) {

		if (nombre == null) {
			return new BigDecimal(0);
		}
		return nombre;
	}

	public static BigDecimal longToBigDecimal(Long nombre) {

		if (nombre == null) {
			return new BigDecimal(0);
		}
		return new BigDecimal(nombre);
	}

	public static String longToString(Long nombre) {

		if (nombre == null) {
			return "0";
		}
		return nombre.toString();
	}

	public static int getDurationInDays(LocalDate date) {

		if (date == null) {
			return 0;
		}
		LocalDate today = LocalDate.now();
		if (today.isBefore(date)) {
			return 0;
		}
		return (int) ChronoUnit.DAYS.between(date, today);
	}

	public static int getCompteurAtRuntime(Long compteur, LocalDate today, boolean top) {

		if (top) {
			return WebUtility.longToInt(compteur) + getDurationInDays(today);
		}
		return 0;
	}

	public static String mapStatus(String status) {

		if (status == null) {
			return StringUtils.EMPTY;
		}
		if ("ND".equals(status)) {
			return "Sain";
		}

		return "Défaut";
	}

	public static String mapOriginStatus(String originStatus) {

		if (originStatus == null) {
			return StringUtils.EMPTY;
		}
		if ("BV".equals(originStatus)) {
			return "Forcé"; // Forcé
		}

		return originStatus;
	}

}

package fr.bpce.yyd.service.traitement.evenements.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class EvenementMdcDto {

	private String idEvenement;
	private String codeEvenement;
	private String dateMetier;
	private String statut;
	private String dateMajStatut;

}

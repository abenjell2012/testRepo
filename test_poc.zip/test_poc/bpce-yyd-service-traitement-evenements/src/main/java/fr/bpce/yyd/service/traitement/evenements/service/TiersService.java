package fr.bpce.yyd.service.traitement.evenements.service;

import java.time.LocalDate;

import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.service.traitement.evenements.service.dto.Etat360TiersDTO;

/**
 * Service autour du tiers.
 *
 * @author zgud
 *
 */
public interface TiersService {

	/**
	 * Retourne un état complet (360) du tiers à date donnée.
	 *
	 * @param id
	 * @param dateEtat
	 * @return
	 */
	Etat360TiersDTO donneEtat360TiersADate(Long id, LocalDate dateEtat);

	/**
	 * Retourne l'id du tiers recherché par son code banque et id tiers local.
	 *
	 * @param codeBanque
	 * @param idLocal
	 * @return
	 */
	Long chercheIdTiersParCodeBanqueEtIdLocal(String codeBanque, String idLocal);

	/**
	 * cloture statusTiers d'un Tiers
	 *
	 * @param idTiers
	 * @param dateCalcul
	 * @return void
	 */
	void clotureStatusTiers(Long idTiers, LocalDate dateCalcul);

	/**
	 * Retourne l'id du tiers recherché par son ID.
	 *
	 * @param idTiers
	 * @return
	 */
	Tiers chercheTiersParId(Long idTiers);

}

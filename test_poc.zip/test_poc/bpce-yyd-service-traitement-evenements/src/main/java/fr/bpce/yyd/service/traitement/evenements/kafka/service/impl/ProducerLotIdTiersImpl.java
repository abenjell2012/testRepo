package fr.bpce.yyd.service.traitement.evenements.kafka.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;

import fr.bpce.yyd.commun.messages.dto.LotIdTiersDTO;
import fr.bpce.yyd.service.traitement.evenements.kafka.service.ProducerLotIdTiers;

@Service("kafkaLotTiers")
@ConditionalOnProperty(value = "kafka.actif", havingValue = "true", matchIfMissing = false)
public class ProducerLotIdTiersImpl implements ProducerLotIdTiers {

	private static final Logger LOG = LoggerFactory.getLogger(ProducerLotIdTiersImpl.class);

	@Autowired
	private KafkaTemplate<String, LotIdTiersDTO> lotIdTiersTemplate;

	@Value("${kafka.producerLotIdTiers.topic}")
	private String topic;

	@Override
	public void send(LotIdTiersDTO data) {
		Long guid = java.util.UUID.randomUUID().getMostSignificantBits();
		data.setGuid(guid);
		Message<LotIdTiersDTO> message = MessageBuilder.withPayload(data).setHeader(KafkaHeaders.TOPIC, topic).build();
		lotIdTiersTemplate.send(message);
		LOG.info("sended lotIdTiers [nbTiers={}]", data.getIdsTiers().size());

	}
}
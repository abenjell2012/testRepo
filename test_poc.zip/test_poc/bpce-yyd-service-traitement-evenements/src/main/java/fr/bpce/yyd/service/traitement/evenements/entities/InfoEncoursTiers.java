package fr.bpce.yyd.service.traitement.evenements.entities;

import java.math.BigDecimal;
import java.time.LocalDate;

public class InfoEncoursTiers {

	private Long idTiers;
	private LocalDate dateCalcul;
	private boolean demandeEncoursAEnvoyer;
	private BigDecimal montantEncours;
	private LocalDate datePhoto;

	public InfoEncoursTiers(Long idTiers, LocalDate dateCalcul) {
		this.idTiers = idTiers;
		this.dateCalcul = dateCalcul;
	}

	public Long getIdTiers() {
		return idTiers;
	}

	public void setIdTiers(Long idTiers) {
		this.idTiers = idTiers;
	}

	public LocalDate getDateCalcul() {
		return dateCalcul;
	}

	public void setDateCalcul(LocalDate dateCalcul) {
		this.dateCalcul = dateCalcul;
	}

	public BigDecimal getMontantEncours() {
		return montantEncours;
	}

	public void setMontantEncours(BigDecimal montantEncours) {
		this.montantEncours = montantEncours;
	}

	public boolean isDemandeEncoursAEnvoyer() {
		return demandeEncoursAEnvoyer;
	}

	public void setDemandeEncoursAEnvoyer(boolean demandeEncoursAEnvoyer) {
		this.demandeEncoursAEnvoyer = demandeEncoursAEnvoyer;
	}

	public LocalDate getDatePhoto() {
		return datePhoto;
	}

	public void setDatePhoto(LocalDate datePhoto) {
		this.datePhoto = datePhoto;
	}

}

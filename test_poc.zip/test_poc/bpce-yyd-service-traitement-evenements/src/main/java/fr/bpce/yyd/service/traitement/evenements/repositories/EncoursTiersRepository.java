package fr.bpce.yyd.service.traitement.evenements.repositories;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import fr.bpce.yyd.commun.model.EncoursTiers;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.TypeAgregat;

@Repository
public interface EncoursTiersRepository extends JpaRepository<EncoursTiers, Long> {

	@Query(value = "select e from EncoursTiers e where idTiers = :idTiers and datePhoto = :datePhoto order by dateImport desc")
	List<EncoursTiers> searchIdTiersAndDatePhoto(@Param("idTiers") Long idTiers,
			@Param("datePhoto") LocalDate datePhoto);

	@Query(value = "select max(datePhoto) from EncoursTiers e where datePhoto <= :datePhoto")
	LocalDate searchDatePhoto(@Param("datePhoto") LocalDate coveredDate);

	@Query(value = "select max(suiviDem.dateEncours) from SuiviDemandeEncours suiviDem join fetch SuiviEncoursTiers suiviEnc on suiviDem.id = suiviEnc.suiviDemandeEncours.id WHERE suiviEnc.tiers.id = :idTiers and suiviDem.dateEncours <= :dateCalcul and suiviEnc.statut = 'NON_REJETE'")
	LocalDate searchDateEncours(@Param("idTiers") Long idTiers, @Param("dateCalcul") LocalDate dateCalcul);

	@Query(value = "select suiviEnc.typeAgregat from SuiviEncoursTiers suiviEnc join fetch SuiviDemandeEncours suiviDem on suiviDem.id = suiviEnc.suiviDemandeEncours.id WHERE suiviEnc.tiers.id = :idTiers and suiviDem.dateArreteMensuelle = :datePhoto order by suiviDem.dateDemande desc")
	List<TypeAgregat> searchListTypeAgregaDemandeEncours(@Param("idTiers") Long idTiers,
			@Param("datePhoto") LocalDate datePhoto);

	@Query(value = "select suiviEnc.typeAgregat from SuiviEncoursTiers suiviEnc join fetch SuiviDemandeEncours suiviDem on suiviDem.id = suiviEnc.suiviDemandeEncours.id WHERE suiviEnc.idFederal = :idFederal and suiviEnc.tiers.id = :idTiers and suiviDem.dateArreteMensuelle = :datePhoto order by suiviDem.dateDemande desc")
	List<TypeAgregat> searchListTypeAgregaFederaleDemandeEncours(@Param("idTiers") Long idTiers,
			@Param("datePhoto") LocalDate datePhoto, @Param("idFederal") String idFederal);
}
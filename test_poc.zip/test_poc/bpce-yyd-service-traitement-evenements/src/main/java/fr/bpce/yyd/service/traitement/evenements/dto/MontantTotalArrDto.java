package fr.bpce.yyd.service.traitement.evenements.dto;

import java.math.BigDecimal;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MontantTotalArrDto {

	private String codeBanque;
	private BigDecimal mttTotalImx;
	private BigDecimal mttTotalDax;
	private BigDecimal mttTotalArr;

}

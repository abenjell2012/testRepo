package fr.bpce.yyd.service.traitement.evenements.service;

import fr.bpce.yyd.commun.messages.dto.LotIdTiersDTO;

/**
 * Service Interface for managing computation.
 */
public interface CalculService {

	/**
	 * Traitement d'un message de lot d'ids Tiers à traiter.
	 *
	 * @param message Le message reçu
	 */
	void traiteMessage(LotIdTiersDTO message);

	void traiteMessageCloture(LotIdTiersDTO message);
}

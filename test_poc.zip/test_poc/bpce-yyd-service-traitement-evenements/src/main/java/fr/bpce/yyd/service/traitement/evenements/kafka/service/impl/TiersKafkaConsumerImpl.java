package fr.bpce.yyd.service.traitement.evenements.kafka.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import fr.bpce.yyd.commun.messages.dto.LotIdTiersDTO;
import fr.bpce.yyd.service.traitement.evenements.kafka.service.TiersKafkaConsumer;
import fr.bpce.yyd.service.traitement.evenements.service.CalculService;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service("consumerLotIdTiers")
@ConditionalOnProperty(value = "kafka.actif", havingValue = "true", matchIfMissing = false)
public class TiersKafkaConsumerImpl implements TiersKafkaConsumer {

	@Autowired
	private CalculService calculService;

	@KafkaListener(topics = "${kafka.consumerListTiers.topic}", groupId = "${kafka.consumerListTiers.groupId}", containerFactory = "listTiersKafkaListenerFactory")
	@Override
	public void receive(@Payload LotIdTiersDTO data) {
		if (data != null && !CollectionUtils.isEmpty(data.getIdsTiers())) {
			if (log.isDebugEnabled()) {
				log.debug("received data='{}'", data);
			}
			calculService.traiteMessage(data);
		}
	}

	@KafkaListener(topics = "${kafka.consumerListTiersCloture.topic}", groupId = "${kafka.consumerListTiersCloture.groupId}", containerFactory = "listTiersClotureKafkaListenerFactory")
	@Override
	public void receiveCloture(LotIdTiersDTO data) {
		if (data != null && !CollectionUtils.isEmpty(data.getIdsTiers())) {
			if (log.isDebugEnabled()) {
				log.debug("received data='{}'", data);
			}
			calculService.traiteMessageCloture(data);
		}
	}
}
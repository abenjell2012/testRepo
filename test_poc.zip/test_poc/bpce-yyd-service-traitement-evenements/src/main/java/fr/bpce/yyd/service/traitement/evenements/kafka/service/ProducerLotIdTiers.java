package fr.bpce.yyd.service.traitement.evenements.kafka.service;

import fr.bpce.yyd.commun.messages.dto.LotIdTiersDTO;

public interface ProducerLotIdTiers {

	void send(LotIdTiersDTO data);

}

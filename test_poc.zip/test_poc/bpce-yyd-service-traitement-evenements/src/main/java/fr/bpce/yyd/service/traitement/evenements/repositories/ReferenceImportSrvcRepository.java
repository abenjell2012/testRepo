package fr.bpce.yyd.service.traitement.evenements.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import fr.bpce.yyd.commun.model.reference.RefBqBfbp;

public interface ReferenceImportSrvcRepository  extends JpaRepository<RefBqBfbp, Long>{

	@Query(value = "select refBqBfbp "
			+ "from RefBqBfbp refBqBfbp ")
    List<RefBqBfbp> getAll();
}

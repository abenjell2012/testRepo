package fr.bpce.yyd.service.traitement.evenements.kafka.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import fr.bpce.yyd.service.commun.yyc.constant.KafkaConstant;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.NotifEncours;
import fr.bpce.yyd.service.traitement.evenements.kafka.service.KafkaNotifEncours;
import fr.bpce.yyd.service.traitement.evenements.service.EncoursService;

@Service("consumerNotifEncours")
@ConditionalOnProperty(value = "kafka.actif", havingValue = "true", matchIfMissing = false)
@EnableScheduling
public class KafkaNotificationEncoursImpl implements KafkaNotifEncours {

	private static final Logger LOG = LoggerFactory.getLogger(KafkaNotificationEncoursImpl.class);

	@Autowired
	private EncoursService serviceEncours;

	@Autowired
	private KafkaListenerEndpointRegistry registry;

	@KafkaListener(id = "notifKafkaListener", autoStartup = "false", topics = "${kafka.consumerNotifEncours.topic}", groupId = "${kafka.consumerNotifEncours.groupId}", containerFactory = "consumerNotificationEncours")
	@Override
	public void receive(@Payload NotifEncours data, @Header(KafkaHeaders.RECEIVED_MESSAGE_KEY) String key,
			@Header(KafkaConstant.MSGID_HEADER) String msgId, @Header(KafkaConstant.PROVIDER_HEADER) String provider) {
		LOG.info("Reception NotificationEncours avec {msgId={}, dateArreteMensuelle={} ,provider={}}", msgId,
				data.getDateArreteMensuelle(), provider);

		serviceEncours.saveEncoursNotification(data, msgId);
	}

	@Scheduled(cron = "0 0/5 20-21 * * *")
	public void scheduledMethod() throws InterruptedException {
		System.out.println("consommation notif");
		this.registry.getListenerContainer("notifKafkaListener").start();
		// Attendre 10 secondes
		Thread.sleep(10_000);
		this.registry.getListenerContainer("notifKafkaListener").stop();
	}

}

package fr.bpce.yyd.service.traitement.evenements.service.impl;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fr.bpce.yyd.commun.enums.StatutTiers;
import fr.bpce.yyd.commun.model.ArriereSignificatif;
import fr.bpce.yyd.commun.model.ComplementEvenement;
import fr.bpce.yyd.commun.model.ElementsDeCalcul;
import fr.bpce.yyd.commun.model.EvenementCalcule;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.ImpayeSurForbearance;
import fr.bpce.yyd.commun.model.PeriodeProbatoire;
import fr.bpce.yyd.commun.model.StatutHistorise;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.service.commun.beans.EvenementsATraiter;
import fr.bpce.yyd.service.commun.beans.EvenementsCalculesTiers;
import fr.bpce.yyd.service.commun.repository.IdentiteTiersRepository;
import fr.bpce.yyd.service.commun.repository.StatutTiersRepository;
import fr.bpce.yyd.service.commun.repository.TiersRepository;
import fr.bpce.yyd.service.commun.service.EvenementCalculeService;
import fr.bpce.yyd.service.commun.service.EvenementRecuService;
import fr.bpce.yyd.service.traitement.evenements.repositories.ElementsDeCalculRepository;
import fr.bpce.yyd.service.traitement.evenements.service.TiersService;
import fr.bpce.yyd.service.traitement.evenements.service.dto.CalculArriereDTO;
import fr.bpce.yyd.service.traitement.evenements.service.dto.Etat360TiersDTO;
import fr.bpce.yyd.service.traitement.evenements.service.dto.EvenementCalculeDTO;
import fr.bpce.yyd.service.traitement.evenements.service.dto.EvenementRecuDTO;
import fr.bpce.yyd.service.traitement.evenements.service.dto.IdentiteTiersDTO;
import fr.bpce.yyd.service.traitement.evenements.service.dto.MotifDefautDTO;
import fr.bpce.yyd.service.traitement.evenements.service.dto.StatutTiersDTO;

@Service
public class TiersServiceImpl implements TiersService {

	@Autowired
	private TiersRepository tiersRepository;

	@Autowired
	private IdentiteTiersRepository identiteTiersRepository;

	@Autowired
	private StatutTiersRepository statutTiersRepository;

	@Autowired
	private EvenementCalculeService evtCalculeService;

	@Autowired
	private EvenementRecuService evtRecuService;

	@Autowired
	private ElementsDeCalculRepository elementsDeCalculRepository;

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Etat360TiersDTO donneEtat360TiersADate(Long idTiers, LocalDate dateEtat) {
		Etat360TiersDTO ret = null;

		Optional<Tiers> tiers = tiersRepository.findById(idTiers);
		if (tiers.isPresent()) {

			ret = new Etat360TiersDTO();
			ret.setDateEtat(date2String(dateEtat));

			ret.setIdInterne(tiers.get().getId());
			ret.setIdRFT(tiers.get().getIdFederal());

			ret.setStatut(buildStatutTiers(idTiers, dateEtat));

			List<IdentiteTiers> identites = identiteTiersRepository.rechercheIdentitesActivesADate(idTiers);
			if (!identites.isEmpty()) {
				for (IdentiteTiers ident : identites) {
					IdentiteTiersDTO identDto = new IdentiteTiersDTO();
					identDto.setCodeBanque(ident.getCodeBanque());
					identDto.setIdTiersLocal(ident.getIdLocal());
					identDto.setSegment(ident.getCodeSegment());
					identDto.setSiren(ident.getSiren());
					ret.addIdentiteActive(identDto);
				}

				EvenementsCalculesTiers evtsCalc = evtCalculeService.rechercheEvenementsCalculesActifsADate(idTiers,
						dateEtat);
				for (EvenementCalcule ec : evtsCalc.getEvenementsCalcules()) {
					ret.addEvenementCalcule(makeEvenementCalculeDTO(idTiers, ec, dateEtat));
				}
			}

			EvenementsATraiter evtsADate = evtRecuService.rechercheEvenementsATraiterADate(idTiers, dateEtat);
			for (ComplementEvenement ce : evtsADate.getTousEvenementsActifs()) {
				EvenementRecuDTO evtRecuDto = new EvenementRecuDTO();
				evtRecuDto.setCode(ce.getEvenement().getCode());
				evtRecuDto.setIdEvtLocal(ce.getEvenement().getIdLocal());
				evtRecuDto.setIdContrat(ce.getEvenement().getIdContrat());
				evtRecuDto.setDateDebut(date2String(ce.getEvenement().getDateDebut()));
				evtRecuDto.setDatePhoto(date2String(ce.getDatePhoto()));
				evtRecuDto.setMontant("" + ce.getMontantArriere());
				ret.addEvenementRecu(evtRecuDto);
			}
		}

		Optional<ElementsDeCalcul> elmtsCalc = elementsDeCalculRepository.findElementsDeCalculADate(idTiers, dateEtat);
		if (elmtsCalc.isPresent()) {
			ret.setDernierCalculADate(elementsDeCalcul2CalculArriere(elmtsCalc.get()));
		}

		return ret;
	}

	private StatutTiersDTO buildStatutTiers(Long idTiers, LocalDate dateEtat) {
		List<StatutHistorise> statuts = statutTiersRepository.getStatutADate(idTiers, dateEtat);
		StatutTiersDTO statutDto = new StatutTiersDTO();
		LocalDate dateDebut = null;
		for (StatutHistorise statut : statuts) {
			statutDto.setStatut(statut.getStatut().name());
			if (dateDebut == null || dateDebut.isAfter(statut.getDateDebut())) {
				dateDebut = statut.getDateDebut();
			}
			if (statut.getStatut() == StatutTiers.DEFAUT) {
				MotifDefautDTO motif = new MotifDefautDTO(statut.getMotif().getMotif(),
						date2String(statut.getDateDebut()));
				motif.setAnnule(statut.getAnnule());
				statutDto.addMotif(motif);
			}
		}
		statutDto.setDateDebut(date2String(dateDebut));
		return statutDto;
	}

	private CalculArriereDTO elementsDeCalcul2CalculArriere(ElementsDeCalcul elementsDeCalcul) {
		CalculArriereDTO ret = new CalculArriereDTO();
		ret.setDateCalcul(date2String(elementsDeCalcul.getDateCalcul()));
		if (elementsDeCalcul.getMontantAbsolu() != null) {
			ret.setMontantAbsolu("" + elementsDeCalcul.getMontantAbsolu());
		}
		if (elementsDeCalcul.getMontantRelatif() != null) {
			ret.setMontantRelatif("" + elementsDeCalcul.getMontantRelatif());
		}
		if (elementsDeCalcul.getEncours() != null) {
			ret.setMontantEncours("" + elementsDeCalcul.getEncours());
		}
		ret.setSignificatif(elementsDeCalcul.isSignificatif());
		return ret;
	}

	private EvenementCalculeDTO makeEvenementCalculeDTO(Long idTiers, EvenementCalcule ec, LocalDate dateEtat) {

		String code = null;
		if (ec instanceof ImpayeSurForbearance) {
			code = "IF";
		} else if (ec instanceof PeriodeProbatoire) {
			code = "PP";
		} else if (ec instanceof ArriereSignificatif) {
			code = "ARX / "
					+ evtCalculeService.categoriseArriereSignificatif(idTiers, (ArriereSignificatif) ec, dateEtat);
			long nbJours = ChronoUnit.DAYS.between(ec.getDateDebut(), dateEtat);
			code += " (" + nbJours + " jour";
			if (nbJours > 1) {
				code += "s";
			}
			code += ")";
		}

		return new EvenementCalculeDTO(code, date2String(ec.getDateDebut()));
	}

	private String date2String(LocalDate date) {
		return date == null ? "" : DateTimeFormatter.ISO_DATE.format(date);
	}

	@Override
	public Long chercheIdTiersParCodeBanqueEtIdLocal(String codeBanque, String idLocal) {
		Tiers tiers = tiersRepository.chercheTiersParCodeBanqueEtIdLocal(codeBanque, idLocal);
		return tiers == null ? null : tiers.getId();
	}

	@Override
	public void clotureStatusTiers(Long idTiers, LocalDate dateCalcul) {
		List<StatutHistorise> statusTiers = statutTiersRepository.findStatusTiersActive(idTiers);
		statusTiers.forEach(status -> status.setDateFin(dateCalcul));
		statutTiersRepository.saveAll(statusTiers);
	}

	public void setStatutTiersRepository(StatutTiersRepository statutTiersRepository) {
		this.statutTiersRepository = statutTiersRepository;
	}

	@Override
	public Tiers chercheTiersParId(Long idTiers) {
		Optional<Tiers> tiers = tiersRepository.findById(idTiers);
		return tiers.orElse(null);
	}

}
package fr.bpce.yyd.service.traitement.evenements.dto;

import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class SyntheseTiersDto {

	private String datePhoto;
	private String dateDerniereMaj;
	// info bloc 1
	private String idFederal;
	private String codeBqRef;
	private String siren;
	private String libelleBqRef;
	private String raisonSociale;
	private String codeSegment;
	private String libelleCdSegment;
	private String idLocal;
	private String codeBanque;
	private String dateImportRft;

	// info bloc 2
	private String statutEff;
	private String statutCalc;
	private String palierDefaut;
	private String dateStc;
	private String dateSte;
	private String evtEntreeDefaut;
	private String libelleEvtEntreeDefaut;
	private String origineSte;
	private String dateEvt;

	private List<RelationTiersDto> relationTiersList;

	private DetailStatutArriereEtEngDto detailStatutArriereEtEng;

	private List<EvenementMdcDto> evenementMdcList;

	private List<MontantTotalArrDto> montantTotalArrList;

	private List<EvenementLocalDto> evenementLocalList;

}

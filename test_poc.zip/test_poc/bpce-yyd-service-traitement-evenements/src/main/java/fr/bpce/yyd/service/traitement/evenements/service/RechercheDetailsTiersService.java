package fr.bpce.yyd.service.traitement.evenements.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Sort.Direction;

import fr.bpce.yyd.service.traitement.evenements.dto.TiersSearchDto;
import fr.bpce.yyd.service.traitement.evenements.enums.CritereRechercheTiers;
import fr.bpce.yyd.service.traitement.evenements.enums.TypeRecherche;

import java.util.List;

public interface RechercheDetailsTiersService {

	Page<TiersSearchDto> findByIdentifiant(CritereRechercheTiers critere, TypeRecherche typeRecherche,
										   String identifiant, String codBanque, List<String> permimetre,
										   int page, int size, String orderBy, Direction direction);

}

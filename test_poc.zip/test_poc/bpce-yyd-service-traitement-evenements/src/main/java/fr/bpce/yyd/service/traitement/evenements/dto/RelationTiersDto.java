package fr.bpce.yyd.service.traitement.evenements.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class RelationTiersDto {

	private String idLocal;
	private String codeBanque;
	private String libelleBanque;
	private String banqueReferente;

}

package fr.bpce.yyd.service.traitement.evenements.kafka.service;

import fr.bpce.yyd.service.commun.yyc.kafka.dto.ReponseEncours;

public interface KafkaEncoursTiers {

	void receive(ReponseEncours data, String key, String msgId, String issuer, String provider);

}

package fr.bpce.yyd.service.traitement.evenements.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import fr.bpce.yyd.commun.model.restitution.RestSynthEvtMDCStatus;
import fr.bpce.yyd.service.traitement.evenements.entities.InfoEvtMdc;

public interface SynthEvtMdcRepository extends JpaRepository<RestSynthEvtMDCStatus, Long> {

	@Query(value = "with TIERS_ID as ( "
			+ "select tiers_id  from identite_tiers where  code_bq = :codeBq and id_local = :idLocal and date_fin is null and rownum=1 "
			+ ") SELECT  case when ac.CODE in ('AR0','AR1','AR2','AR3') "
			+ "then concat(trim(ac.CODE),to_char(e.id)) else to_char(e.id) end as idMdcEvent, "
			+ "ac.CODE as codeMdc , ac.statut as statutEvt, "
			+ "case when e.code = 'AS' then (case when ac.statut = 'ACT' then ac.date_effet else eact_dclo.date_effet end)  "
			+ "                        else e.date_debut end as creationDateEvt, "
			+ "ac.date_effet as dateMiseAJourStatut from evenement_calcule e "
			+ "inner join audit_calcul ac on ac.evenement_calcul_id = e.id and ac.tiers_id = e.tiers_id "
			+ "left join audit_calcul eact_dclo on eact_dclo.evenement_calcul_id = e.id and e.code = 'AS' and eact_dclo.statut = 'ACT' and ac.code = eact_dclo.code and ac.tiers_id = eact_dclo.tiers_id "
			+ "inner join (select  max(date_generation) as max_date_gen , code ,tiers_id , evenement_calcul_id "
			+ "			from audit_calcul where tiers_id = (select tiers_id from TIERS_ID) "
			+ "			group by  tiers_id , code, evenement_calcul_id) ac_max  "
			+ "on (ac.date_generation = ac_max.max_date_gen  and ac.tiers_id = ac_max.tiers_id and ac.code = ac_max.code and ac.evenement_calcul_id = ac_max.evenement_calcul_id ) "
			+ "where ac.tiers_id = (select tiers_id from TIERS_ID) and (ac.statut in ('ACT','SUS') or (ac.statut = 'CLO' and ac.date_effet >= (trunc(sysdate) - :profHistorique))) "
			, nativeQuery = true)
	List<InfoEvtMdc> findByIdLocalAndCodBq(@Param("idLocal") String idLocal, @Param("codeBq") String codeBq,
			@Param("profHistorique") int profondeur);

	@Query(value = "with TIERS_ID as ( select id as tiers_id from tiers where id_rft = :idRft and rownum=1 ) "
			+ "SELECT  case when ac.CODE in ('AR0','AR1','AR2','AR3') "
			+ "then concat(trim(ac.CODE),to_char(e.id)) else to_char(e.id) end as idMdcEvent, "
			+ "ac.CODE as codeMdc , ac.statut as statutEvt, "
			+ "case when e.code = 'AS' then (case when ac.statut = 'ACT' then ac.date_effet else eact_dclo.date_effet end)  "
			+ "                        else e.date_debut end as creationDateEvt, "
			+ "ac.date_effet as dateMiseAJourStatut from evenement_calcule e "
			+ "inner join audit_calcul ac on ac.evenement_calcul_id = e.id and ac.tiers_id = e.tiers_id "
			+ "left join audit_calcul eact_dclo on eact_dclo.evenement_calcul_id = e.id and e.code = 'AS' and eact_dclo.statut = 'ACT' and ac.code = eact_dclo.code and ac.tiers_id = eact_dclo.tiers_id "
			+ "inner join (select  max(date_generation) as max_date_gen , code ,tiers_id , evenement_calcul_id "
			+ "			from audit_calcul where tiers_id = (select tiers_id from TIERS_ID) "
			+ "			group by  tiers_id , code, evenement_calcul_id) ac_max  "
			+ "on (ac.date_generation = ac_max.max_date_gen  and ac.tiers_id = ac_max.tiers_id and ac.code = ac_max.code and ac.evenement_calcul_id = ac_max.evenement_calcul_id ) "
			+ "where ac.tiers_id = (select tiers_id from TIERS_ID) and (ac.statut in ('ACT','SUS') or (ac.statut = 'CLO' and ac.date_effet >= (trunc(sysdate) - :profHistorique))) "
			, nativeQuery = true)
	List<InfoEvtMdc> findByIdRft(@Param("idRft") String idRft, @Param("profHistorique") int profondeurHisto);

}

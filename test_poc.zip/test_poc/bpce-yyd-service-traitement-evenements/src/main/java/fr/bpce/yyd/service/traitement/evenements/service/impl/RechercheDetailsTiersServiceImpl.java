package fr.bpce.yyd.service.traitement.evenements.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import fr.bpce.yyd.service.traitement.evenements.dto.TiersSearchDto;
import fr.bpce.yyd.service.traitement.evenements.enums.CritereRechercheTiers;
import fr.bpce.yyd.service.traitement.evenements.enums.TypeRecherche;
import fr.bpce.yyd.service.traitement.evenements.repositories.RechercheTiersRepository;
import fr.bpce.yyd.service.traitement.evenements.service.RechercheDetailsTiersService;

@Service
public class RechercheDetailsTiersServiceImpl implements RechercheDetailsTiersService {

	@Autowired
	private RechercheTiersRepository rechercheTiersRepository;

	@Override
	public Page<TiersSearchDto> findByIdentifiant(CritereRechercheTiers critere, TypeRecherche typeRecherche,
			String identifiant, String codBanque, List<String> permimetre, int page, int size, String orderBy, Direction direction) {

		PageRequest pageRequest = PageRequest.of(page, size, new Sort(direction, orderBy));

		if (CritereRechercheTiers.ID_LOCAL.equals(critere)) {

			return rechercheAvecIdLocal(typeRecherche, identifiant, codBanque, permimetre, pageRequest);

		} else if (CritereRechercheTiers.SIREN.equals(critere)) {

			return rechercheAvecSiren(typeRecherche, identifiant, codBanque, permimetre, pageRequest);

		} else if (CritereRechercheTiers.ID_RFT.equals(critere)) {

			return rechercheAvecIdRft(typeRecherche, identifiant, codBanque, permimetre, pageRequest);
		}
		return new PageImpl<>(new ArrayList<>());
	}

	private Page<TiersSearchDto> rechercheAvecIdRft(TypeRecherche typeRecherche, String idRft, String codBanque, List<String> permimetre,
			PageRequest pageRequest) {
		if (StringUtils.isBlank(codBanque)) {
			if (TypeRecherche.EQUAL.equals(typeRecherche)) {
				return rechercheTiersRepository.findByIdRftEqual(idRft, pageRequest);
			} else if (TypeRecherche.LIKE.equals(typeRecherche)) {
				return rechercheTiersRepository.findByIdRftLike(idRft, pageRequest);
			}
		} else {
			if (TypeRecherche.EQUAL.equals(typeRecherche)) {
				if(permimetre != null && !permimetre.isEmpty()){
					if(!permimetre.contains(codBanque)){
						permimetre.add(codBanque);
					}
					return rechercheTiersRepository.findByIdRftEqualAndPerimetre(idRft, permimetre, pageRequest);
				}
				return rechercheTiersRepository.findByIdRftEqualAndCodBq(idRft, codBanque, pageRequest);
			} else if (TypeRecherche.LIKE.equals(typeRecherche)) {
				if(permimetre != null && !permimetre.isEmpty()){
					if(!permimetre.contains(codBanque)){
						permimetre.add(codBanque);
					}
					return rechercheTiersRepository.findByidRftLikeAndPerimetre(idRft, permimetre, pageRequest);
				}
				return rechercheTiersRepository.findByidRftLikeAndCodBq(idRft, codBanque, pageRequest);
			}
		}
		return new PageImpl<>(new ArrayList<>());

	}

	private Page<TiersSearchDto> rechercheAvecSiren(TypeRecherche typeRecherche, String siren, String codBanque, List<String> permimetre,
			PageRequest pageRequest) {
		if (StringUtils.isBlank(codBanque)) {
			if (TypeRecherche.EQUAL.equals(typeRecherche)) {
				return rechercheTiersRepository.findBySirenEqual(siren, pageRequest);
			} else if (TypeRecherche.LIKE.equals(typeRecherche)) {
				return rechercheTiersRepository.findBySirenLike(siren, pageRequest);
			}
		} else {
			if (TypeRecherche.EQUAL.equals(typeRecherche)) {
				if(permimetre != null && !permimetre.isEmpty()){
					if(!permimetre.contains(codBanque)){
						permimetre.add(codBanque);
					}
					return rechercheTiersRepository.findBySirenEqualAndPerimetre(siren, permimetre, pageRequest);
				}
				return rechercheTiersRepository.findBySirenEqualAndCodBq(siren, codBanque, pageRequest);
			} else if (TypeRecherche.LIKE.equals(typeRecherche)) {
				if(permimetre != null && !permimetre.isEmpty()){
					if(!permimetre.contains(codBanque)){
						permimetre.add(codBanque);
					}
					return rechercheTiersRepository.findBySirenLikeAndPerimetre(siren, permimetre, pageRequest);
				}
				return rechercheTiersRepository.findBySirenLikeAndCodBq(siren, codBanque, pageRequest);
			}
		}
		return new PageImpl<>(new ArrayList<>());
	}

	private Page<TiersSearchDto> rechercheAvecIdLocal(TypeRecherche typeRecherche, String idLocal, String codBanque, List<String> permimetre,
			PageRequest pageRequest) {

		if (StringUtils.isBlank(codBanque)) {
			if (TypeRecherche.EQUAL.equals(typeRecherche)) {
				return rechercheTiersRepository.findByIdLocalEqual(idLocal, pageRequest);
			} else if (TypeRecherche.LIKE.equals(typeRecherche)) {
				return rechercheTiersRepository.findByIdLocalLike(idLocal, pageRequest);
			}
		} else {
			if (TypeRecherche.EQUAL.equals(typeRecherche)) {
				if(permimetre != null && !permimetre.isEmpty()){
					if(!permimetre.contains(codBanque)){
						permimetre.add(codBanque);
					}
					return rechercheTiersRepository.findByIdLocalEqualAndPerimetre(idLocal, permimetre, pageRequest);
				}
				return rechercheTiersRepository.findByIdLocalEqualAndCodBq(idLocal, codBanque, pageRequest);
			} else if (TypeRecherche.LIKE.equals(typeRecherche)) {
				if(permimetre != null && !permimetre.isEmpty()){
					if(!permimetre.contains(codBanque)){
						permimetre.add(codBanque);
					}
					return rechercheTiersRepository.findByIdLocalLikeAndPerimetre(idLocal, permimetre, pageRequest);
				}
				return rechercheTiersRepository.findByIdLocalLikeAndCodBq(idLocal, codBanque, pageRequest);
			}
		}
		return new PageImpl<>(new ArrayList<>());
	}

}

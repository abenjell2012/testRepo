package fr.bpce.yyd.service.traitement.evenements.service.dto;

import java.io.Serializable;

public class EvenementRecuDTO implements Serializable {

	private static final long serialVersionUID = -3282784386619502611L;

	private String code;
	private String idEvtLocal;
	private String idContrat;
	private String dateDebut;
	private String datePhoto;
	private String montant;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getIdEvtLocal() {
		return idEvtLocal;
	}

	public void setIdEvtLocal(String idEvtLocal) {
		this.idEvtLocal = idEvtLocal;
	}

	public String getDateDebut() {
		return dateDebut;
	}

	public void setDateDebut(String dateDebut) {
		this.dateDebut = dateDebut;
	}

	public String getDatePhoto() {
		return datePhoto;
	}

	public void setDatePhoto(String datePhoto) {
		this.datePhoto = datePhoto;
	}

	public String getMontant() {
		return montant;
	}

	public void setMontant(String montant) {
		this.montant = montant;
	}

	public String getIdContrat() {
		return idContrat;
	}

	public void setIdContrat(String idContrat) {
		this.idContrat = idContrat;
	}
}

package fr.bpce.yyd.service.traitement.evenements.repositories;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import fr.bpce.yyd.commun.model.TiersRFT;

@Repository
public interface TiersRftRepository extends JpaRepository<TiersRFT, Long> {

    @Query(value="select max(t.date) from TiersRFT t where date <= :dateAppel")
    LocalDate findMaxDateArreteMensuelle(@Param("dateAppel") LocalDate dateAppel);

    @Query(value="select t from TiersRFT t where date = :dateAppel and concat(codeBanque, '#', idLocal) in :listCodesId")
    List<TiersRFT> findByListCodeIdAndDate(@Param("dateAppel") LocalDate dateAppel, @Param("listCodesId") List<String> listCodesId);

 // ************ Recherche Date Import avec l'id RFT
    @Query(value="select max(t.date) from TiersRFT t where idFederal = :idRft")
    LocalDate findDateArreteMensuelle(@Param("idRft") String idRft);

}

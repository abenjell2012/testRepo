package fr.bpce.yyd.service.traitement.evenements.web.rest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import fr.bpce.yyd.service.commun.yyc.model.DemandeLotTiersRft;
import fr.bpce.yyd.service.commun.yyc.model.ReponseLotTiersRft;
import fr.bpce.yyd.service.traitement.evenements.service.impl.TiersRftServiceImpl;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@Api(tags = "API RFT pour le projet RMN")
@RestController
@RequestMapping("/api/v1")
public class DemandeRftController {

	@Autowired
	private TiersRftServiceImpl tiersRftServiceImpl;

	private static final Logger LOG = LoggerFactory.getLogger(DemandeRftController.class);

	@ApiOperation(value = "récupére les ids fédéraux (id_rft) d'une liste de tiers / couples (code_banque/id_local)")
	@PostMapping("/tiersRft")
	public ResponseEntity<ReponseLotTiersRft> getIdFederal(
			@ApiParam(required = true, value = "Objet constitué d'une date d'appel et d'une liste de couples (code_banque/id_local)") @RequestBody DemandeLotTiersRft tiers) {
		if (tiers.getDateAppel() == null) {
			throw new IllegalArgumentException("La date d'appel doit etre renseigné");
		}
		LOG.info("Appel api rft avec la date {}", tiers.getDateAppel());
		ReponseLotTiersRft reponse = tiersRftServiceImpl.processRequest(tiers);
		return new ResponseEntity<>(reponse, HttpStatus.OK);
	}

}

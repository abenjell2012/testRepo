package fr.bpce.yyd.service.traitement.evenements.web.rest;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import fr.bpce.yyd.service.traitement.evenements.service.TiersService;
import fr.bpce.yyd.service.traitement.evenements.service.dto.Etat360TiersDTO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * REST controller for managing Tiers.
 */
@Api(tags = "API ZGUD - Etat 360° d'un tiers")
@RestController
@RequestMapping("/api")
public class TiersResource {

	private final Logger log = LoggerFactory.getLogger(TiersResource.class);

	private final TiersService tiersService;

	public TiersResource(TiersService bilanService) {
		this.tiersService = bilanService;
	}

	/**
	 * GET /tiers/:id/:dateEtat : un état 360° du Tiers "id" à la date "dateEtat"
	 *
	 * @param id       the id of the Tiers to retrieve
	 * @param dateEtat
	 * @return the ResponseEntity with status 200 (OK) and with body the
	 *         Etat360TiersDTO, or with status 404 (Not Found)
	 */
	@GetMapping("/tiers/{id}/{dateEtat}")
	@ApiOperation(value = "récupére les données (id_local, statut, évènements recus/calculés..) d'un tiers à partir de son id technique pour une date donnée")
	public ResponseEntity<Etat360TiersDTO> getEtat360Tiers(@PathVariable Long id, @PathVariable String dateEtat) {
		log.debug("REST request to get Bilan : {}", id);
		Etat360TiersDTO etat360 = tiersService.donneEtat360TiersADate(id,
				DateTimeFormatter.BASIC_ISO_DATE.parse(dateEtat, LocalDate::from));
		if (etat360 != null) {
			return ResponseEntity.ok().body(etat360);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	/**
	 * GET /tiers/:codeBanque/:idTiersLocal : retourne l'id interne d'un tiers
	 *
	 * @param codeBanque   code banque du tiers
	 * @param idTiersLocal id tiers local du tiers
	 * @return the ResponseEntity with status 200 (OK) and with body the id, or with
	 *         status 404 (Not Found)
	 */
	@ApiOperation(value = "récupére l'id technique d'un tiers à partir de son code banque et idLocal")
	@GetMapping("/tiers/search/{codeBanque}/{idTiersLocal}")
	public ResponseEntity<Long> getIdTiers(@PathVariable String codeBanque, @PathVariable String idTiersLocal) {
		Long idTiers = tiersService.chercheIdTiersParCodeBanqueEtIdLocal(codeBanque, idTiersLocal);
		if (idTiers != null) {
			return ResponseEntity.ok().body(idTiers);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
}

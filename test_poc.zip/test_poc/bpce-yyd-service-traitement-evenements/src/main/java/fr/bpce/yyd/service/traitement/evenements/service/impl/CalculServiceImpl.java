package fr.bpce.yyd.service.traitement.evenements.service.impl;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.tuple.MutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import fr.bpce.yyd.commun.constantes.Constant;
import fr.bpce.yyd.commun.enums.EvenementArriereSignificatif;
import fr.bpce.yyd.commun.enums.StatutEvenement;
import fr.bpce.yyd.commun.enums.StatutTiers;
import fr.bpce.yyd.commun.messages.dto.LotIdTiersDTO;
import fr.bpce.yyd.commun.model.ArriereSignificatif;
import fr.bpce.yyd.commun.model.ComplementEvenement;
import fr.bpce.yyd.commun.model.ElementsDeCalcul;
import fr.bpce.yyd.commun.model.Evenement;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.MotifStatutTiers;
import fr.bpce.yyd.commun.model.StatutHistorise;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.service.commun.beans.EvenementsATraiter;
import fr.bpce.yyd.service.commun.beans.EvenementsCalculesTiers;
import fr.bpce.yyd.service.commun.contexte.ContexteCalculTiers;
import fr.bpce.yyd.service.commun.service.AuditCalculService;
import fr.bpce.yyd.service.commun.service.DefautService;
import fr.bpce.yyd.service.commun.service.EvenementCalculeService;
import fr.bpce.yyd.service.commun.service.EvenementRecuService;
import fr.bpce.yyd.service.commun.service.IdentiteTiersService;
import fr.bpce.yyd.service.commun.service.ParametresNDoD;
import fr.bpce.yyd.service.traitement.evenements.entities.InfoEncoursTiers;
import fr.bpce.yyd.service.traitement.evenements.repositories.ElementsDeCalculRepository;
import fr.bpce.yyd.service.traitement.evenements.repositories.EncoursTiersRepository;
import fr.bpce.yyd.service.traitement.evenements.service.CalculService;
import fr.bpce.yyd.service.traitement.evenements.service.EncoursService;
import fr.bpce.yyd.service.traitement.evenements.service.TiersService;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CalculServiceImpl implements CalculService {

	@Autowired
	private TiersService tiersService;

	@Autowired
	private EncoursService serviceEncours;

	@Autowired
	private ElementsDeCalculRepository elemCalcRepository;

	@Autowired
	private EvenementCalculeService evtCalculeService;

	@Autowired
	private DefautService defautService;

	@Autowired
	private EvenementRecuService evtRecuService;

	@Autowired
	private ParametresNDoD parametresNDoDService;

	@Autowired
	private AuditCalculService auditCalculService;

	@Autowired
	private IdentiteTiersService identiteTiersService;

	@Autowired
	private EncoursTiersRepository repEncoursTiers;

	@Override
	@Transactional
	public void traiteMessage(LotIdTiersDTO message) {
		log.info("*********************** Traitement du message {} *****************************", " date de calcul : "
				+ message.getDateCalcul() + " , " + Arrays.toString(message.getIdsTiers().toArray()));
		LocalDate dateCalcul = message.getDateCalcul();
		Long guid = message.getGuid();

		if (dateCalcul == null) {
			dateCalcul = LocalDate.now();
			message.setDateCalcul(dateCalcul);
		}

		try {
			Map<Long, List<IdentiteTiers>> identiteTiers = identiteTiersService.rechercheIdentitesActivesADate(message);
			Map<Long, EvenementsATraiter> evenementsATraiter = evtRecuService.rechercheEvenementsATraiterADate(message,
					identiteTiers);
			Map<Long, List<StatutHistorise>> statutsCourants = defautService.getStatutsADate(message);
			Map<Long, EvenementsCalculesTiers> evtCalculesTiers = evtCalculeService
					.rechercheEvenementsCalculesActifsADate(message);

			Map<Long, Tiers> tiersMap = identiteTiersService.rechercheAllTiers(message.getIdsTiers());

			ContexteCalculTiers.init(evenementsATraiter, statutsCourants, identiteTiers, evtCalculesTiers);

			LocalDate datePhoto = repEncoursTiers.searchDatePhoto(dateCalcul);
			List<Long> listIdTiersPourDemande = new ArrayList<>();
			for (Long idTiers : message.getIdsTiers()) {
				try {
					Long id = traiteTiersADate(idTiers, dateCalcul, guid, datePhoto, tiersMap.get(idTiers));
					if (id != null) {
						listIdTiersPourDemande.add(id);
					}
				} catch (Exception exp) {
					log.error("Erreur lors de traitement du tiers " + idTiers, exp);
				}
			}
			if (!listIdTiersPourDemande.isEmpty()) {
				serviceEncours.initDemandeEncoursLotIdTiers(dateCalcul, listIdTiersPourDemande);
			}
		} finally {
			ContexteCalculTiers.clear();
		}
	}

	@Override
	@Transactional
	public void traiteMessageCloture(LotIdTiersDTO message) {
		log.info("*********************** Traitement du message Cloture {} *****************************",
				" date de calcul : " + message.getDateCalcul() + " , "
						+ Arrays.toString(message.getIdsTiers().toArray()));
		LocalDate dateCalcul = message.getDateCalcul();

		if (dateCalcul == null) {
			dateCalcul = LocalDate.now();
		}

		for (Long idTiers : message.getIdsTiers()) {
			try {
				evtCalculeService.clotureEvenementCalcul(idTiers, dateCalcul);
				auditCalculService.clotureAuditCalcul(idTiers, dateCalcul);
				tiersService.clotureStatusTiers(idTiers, dateCalcul);
			} catch (Exception exp) {
				String complMessage = "";
				if (exp.getMessage() != null) {
					complMessage = exp.getMessage();
				} else if (exp.getCause() != null) {
					complMessage = exp.getCause().getMessage();
				} else {
					complMessage = exp.toString();
				}
				log.error("Erreur lors de traitement du tiers " + idTiers + " : " + complMessage);

				Arrays.asList(exp.getStackTrace()).stream().forEach(x -> log.error(x.toString()));
			}
		}
	}

	public Long traiteTiersADate(Long idTiers, LocalDate dateCalcul, Long guid, LocalDate datePhoto, Tiers tiers) {

		EvenementsATraiter evtsATraiter = evtRecuService.rechercheEvenementsATraiterADate(idTiers, dateCalcul);
		if (log.isDebugEnabled()) {
			log.debug("Nb evenement defaut trouvés : {} ", evtsATraiter.getEvenementsDefaut().size());
			log.debug("Nb ARR trouvés : {}", evtsATraiter.getArrieres().size());
		}
		Long idenTiers = traiteAS(evtsATraiter, idTiers, dateCalcul, guid, datePhoto);
		traiteEvenementDefaut(evtsATraiter, tiers, dateCalcul);

		List<StatutHistorise> statutsCourants = defautService.getAllStatuts(idTiers);
		if (statutsCourants.isEmpty()) {

			boolean chgtTiersId = false;

			if (!evtsATraiter.getArrieres().isEmpty()) {
				Tiers tiersInitial = evtsATraiter.getArrieres().get(0).getEvenement().getIdentiteInitiale()
						.getTiersInitial();
				// detection de changement de tiers id (changement de segement)
				chgtTiersId = !(idTiers.equals(tiersInitial.getId()));
			}

			EvenementsCalculesTiers evtsCalc = evtCalculeService.rechercheEvenementsCalculesActifsADate(idTiers,
					dateCalcul);
			ArriereSignificatif as = evtsCalc.getArriereSignigicatif();
			if (!chgtTiersId || as == null) {
				// initialiser un statut SAIN avec la dateCalcul
				defautService.initStatutTiersASain(idTiers, dateCalcul);
			} else {
				log.info(
						"Statut tiers {} non initialise en bdd car identite tiers est absente a la date {} ou nous avons un changement de categorie pour le tiers ",
						idTiers, dateCalcul);
			}
		}
		return idenTiers;
	}

	protected Optional<LocalDate> dateLaPlusRecente(Optional<LocalDate> date1, Optional<LocalDate> date2) {
		if (date1.isPresent() && (!date2.isPresent() || date1.get().compareTo(date2.get()) > 0)) {
			return date1;
		}
		return date2;
	}

	/**
	 * Traitement des evenements defaut présents à date pour un tiers pour
	 * déclencher son passage en défaut ou, si cloture, son passage en période
	 * probatoire.
	 *
	 * @param evtsATraiter événements collectés du tiers à date donnée.
	 * @param tiersId
	 * @param dateCalcul
	 */
	protected void traiteEvenementDefaut(EvenementsATraiter evtsATraiter, Tiers tiers, LocalDate dateCalcul) {
		List<MotifStatutTiers> evtsDefaut = new ArrayList<>();
		for (ComplementEvenement evtDefaut : evtsATraiter.getEvenementsDefaut()) {
			boolean annulation = evtDefaut.isArriereTech() || evtDefaut.isArriereLitige()
					|| StatutEvenement.ANN == evtDefaut.getStatutEvt();
			boolean termine = annulation || StatutEvenement.CLO == evtDefaut.getStatutEvt();
			MotifStatutTiers motif = new MotifStatutTiers(evtDefaut);
			StatutHistorise statutDefaut = defautService.trouveStatutDefautByMotif(tiers.getId(), dateCalcul, motif);

			evtsDefaut.add(motif);

			if (statutDefaut == null && !termine) {
				// Il faut créer un nouveau statut de défaut
				defautService.entreeEnDefaut(tiers, evtDefaut.getDateDebut(), motif, dateCalcul);
			}
			if (statutDefaut != null && termine) {
				// Il faut clore le statut de défaut
				// on recoit une evenement DEFAUT annulé; le tiers est en DEFAUT (il n'est pas
				// en PP)

				// choix MOA dans le cadre de l'annulation la date de sortie est la date de
				// calcul
				LocalDate datesortie = evtDefaut.getDateDebut();
				if (annulation) {
					datesortie = dateCalcul;
				}

				defautService.sortieDUnEvenementDeDefaut(tiers.getId(), datesortie, motif, annulation, dateCalcul);
			}
			if (statutDefaut == null && annulation) {
				// le tiers est en PP et on recoit une evenement DEFAUT annulé
				defautService.annulerDefautEventClos(tiers, evtDefaut, dateCalcul);
			}
		}

		// tous les statut SAIN et DEFAUT sans date_fin
		List<StatutHistorise> listStatutADate = defautService.getStatutsActif(tiers.getId(), dateCalcul);
		cloDefautNonJustifies(tiers, dateCalcul, listStatutADate, evtsDefaut);
	}

	/**
	 * Traitement des événements IMX et DAX pour déterminer si une période
	 * d'arriérés significatifs doit débuter ou se clore.
	 *
	 * @param arrieres
	 * @param dateCalcul
	 */
	protected Long traiteAS(EvenementsATraiter evtsATraiter, Long idTiers, LocalDate dateCalcul, Long guid,
			LocalDate datePhoto) {
		// test si le tiers courant à un AS actif
		ArriereSignificatif asExistantActif = evtCalculeService.rechercheArriereSignificatifADate(idTiers, dateCalcul);

		if (asExistantActif != null && evtsATraiter.getArrieres().isEmpty()) {
			List<ComplementEvenement> arrieresActifs = evtsATraiter.getArrieres(StatutEvenement.ACT);
			Pair<ElementsDeCalcul, InfoEncoursTiers> infosCalculAs = calculeElementsAS(arrieresActifs, idTiers,
					dateCalcul, guid, datePhoto);
			ElementsDeCalcul elementscalcul = infosCalculAs.getLeft();

			if (elementscalcul == null) {
				elementscalcul = new ElementsDeCalcul(dateCalcul);
				elementscalcul.setDateGeneration(LocalDateTime.now());
				elementscalcul.setGuid(guid);
			}

			Tiers tiers = asExistantActif.getTiers();
			elementscalcul.setTiers(tiers);

			elemCalcRepository.save(elementscalcul);

			// Il faut le clore.
			cloArriereSignificatif(asExistantActif, dateCalcul, elementscalcul, dateCalcul, idTiers, evtsATraiter);
		}

		if (!evtsATraiter.getArrieres().isEmpty()) {
			List<ComplementEvenement> arrieresActifs = evtsATraiter.getArrieres(StatutEvenement.ACT);
			Pair<ElementsDeCalcul, InfoEncoursTiers> infosCalculAs = calculeElementsAS(arrieresActifs, idTiers,
					dateCalcul, guid, datePhoto);
			ElementsDeCalcul elementscalcul = infosCalculAs.getLeft();
			InfoEncoursTiers infoEncoursTiers = infosCalculAs.getRight();
			if (elementscalcul != null && (infoEncoursTiers == null || !infoEncoursTiers.isDemandeEncoursAEnvoyer())) {
				Tiers tiers = evtsATraiter.getArrieres().get(0).getEvenement().getIdentiteInitiale().getTiers();
				Tiers tiersInitial = evtsATraiter.getArrieres().get(0).getEvenement().getIdentiteInitiale()
						.getTiersInitial();

				elementscalcul.setTiers(tiers);
				elemCalcRepository.save(elementscalcul);
				traiteChangementSegmentAvecAS(tiers, tiersInitial, dateCalcul, elementscalcul);

				ArriereSignificatif asExistant = evtCalculeService.rechercheArriereSignificatifADate(idTiers,
						dateCalcul);
				creerCloturerArriereSignificatif(tiers, dateCalcul, elementscalcul, asExistant, evtsATraiter);
			} else {
				if (infoEncoursTiers != null && infoEncoursTiers.isDemandeEncoursAEnvoyer()) {

					return infoEncoursTiers.getIdTiers();
				}
			}
		}
		return null;
	}

	private void creerCloturerArriereSignificatif(Tiers tiers, LocalDate dateCalcul, ElementsDeCalcul elementscalcul,
			ArriereSignificatif asExistant, EvenementsATraiter evtsATraiter) {
		if (elementscalcul.isSignificatif()) {
			if (log.isDebugEnabled()) {
				log.debug("Test d'arriérés significatifs positif");
			}
			if (asExistant == null) {
				evtCalculeService.creeArriereSignificatif(tiers, elementscalcul.getDateSignificatif(), dateCalcul,
						elementscalcul, false);
			}
		} else {
			if (log.isDebugEnabled()) {
				log.debug("Test d'arriérés significatifs non positif");
			}
			if (asExistant != null) {
				// Il faut le clore.

				LocalDate dateClotureAS = trouveDateClotureArriere(evtsATraiter.getArrieres(), dateCalcul);
				dateClotureAS = trouveDateClotureASAvecNouvelEncours(tiers.getId(), dateCalcul, dateClotureAS);
				dateClotureAS = trouveDateClotureASAvecChgtSegment(tiers.getId(), dateCalcul, dateClotureAS);
				cloArriereSignificatif(asExistant, dateClotureAS, elementscalcul, dateCalcul, tiers.getId(),
						evtsATraiter);
			}
		}
	}

	private void traiteChangementSegmentAvecAS(Tiers tiers, Tiers tiersInitial, LocalDate dateCalcul,
			ElementsDeCalcul elementscalcul) {

		boolean chgtTiersId = !(tiers.getId().equals(tiersInitial.getId()));
		if (chgtTiersId) {
			LocalDate dateFinDernierASTiersInitial = evtCalculeService
					.rechercheDateFinDernierArriereSignificatif(tiersInitial.getId());

			// test si le tiers courant à un AS actif
			ArriereSignificatif asExistant = evtCalculeService.rechercheArriereSignificatifADate(tiers.getId(),
					dateCalcul);

			if (asExistant == null
					&& (dateFinDernierASTiersInitial == null || dateFinDernierASTiersInitial.equals(dateCalcul))) {

				LocalDate dateDebutLastASTiersInitial = evtCalculeService
						.rechercheDateDebutArriereSignificatif(tiersInitial.getId());

				if (dateDebutLastASTiersInitial != null) {
					// il ne faut pas appliquer la rege des -15 jours donc chgtTiersId = true
					evtCalculeService.creeArriereSignificatif(tiers, dateDebutLastASTiersInitial, dateCalcul,
							elementscalcul, chgtTiersId);
				}
			}
		}
	}

	private LocalDate trouveDateClotureASAvecNouvelEncours(Long idTiers, LocalDate dateCalcul,
			LocalDate dateDernierArriere) {
		LocalDate dateClotureAS = null;
		LocalDate dateEncours = serviceEncours.rechercheDateEncoursTiersADate(idTiers, dateCalcul);
		if (dateDernierArriere != null && dateEncours != null) {
			if (dateDernierArriere.isAfter(dateEncours)) {
				dateClotureAS = dateDernierArriere;
			} else {
				dateClotureAS = dateEncours;
			}
		} else {
			if (dateDernierArriere == null) {
				dateClotureAS = dateEncours;
			} else {
				dateClotureAS = dateDernierArriere;
			}
		}
		return dateClotureAS;
	}

	private LocalDate trouveDateClotureASAvecChgtSegment(Long idTiers, LocalDate dateCalcul, LocalDate dateClotureAs) {
		List<IdentiteTiers> identitesTiers = identiteTiersService.rechercheIdentitesActivesADate(idTiers, dateCalcul);
		if (identitesTiers != null && !identitesTiers.isEmpty()) {
			LocalDate dateIdentitePlusRecente = identitesTiers.get(0).getDateDebut();
			if (dateClotureAs != null && dateIdentitePlusRecente != null) {
				if (dateClotureAs.isAfter(dateIdentitePlusRecente)) {
					return dateClotureAs;
				} else {
					return dateCalcul;
				}
			} else {
				if (dateClotureAs == null) {
					return dateCalcul;
				} else {
					return dateClotureAs;
				}
			}
		} else {
			return dateClotureAs;
		}
	}

	private void cloArriereSignificatif(ArriereSignificatif asExistant, LocalDate dateClotureAS,
			ElementsDeCalcul elementscalcul, LocalDate dateCalcul, Long idTiers, EvenementsATraiter evtsATraiter) {

		EvenementArriereSignificatif statutAS = evtCalculeService.categoriseArriereSignificatif(idTiers, asExistant,
				dateCalcul);

		Map<EvenementArriereSignificatif, LocalDate> calendrierAS = evtCalculeService
				.calculeCalendrierArriereSignificatif(idTiers, asExistant, dateCalcul);

		EvenementArriereSignificatif dernierPalierAS = asExistant.getComplement().getDernierEvenementEnvoye();

		if (dernierPalierAS != null && dateClotureAS.isBefore(calendrierAS.get(statutAS))) {
			dateClotureAS = dateCalcul;
		}

		evtCalculeService.closArriereSignificatif(asExistant, dateClotureAS, elementscalcul, dateCalcul);

		if (EvenementArriereSignificatif.AR3 == statutAS) {
			boolean annulationAR = isAnnulation(evtsATraiter, asExistant);
			defautService.sortieDUnEvenementDeDefaut(idTiers, dateClotureAS, new MotifStatutTiers(asExistant),
					annulationAR, dateCalcul);
		}
	}

	private boolean isAnnulation(EvenementsATraiter evtsATraiter, ArriereSignificatif asACloturer) {
		List<ComplementEvenement> arrieres = new ArrayList<>(evtsATraiter.getArrieres());
		arrieres.removeAll(evtsATraiter.getArrieres(StatutEvenement.CLO).stream()
				.filter(x -> x.getDateDebut().isBefore(asACloturer.getDateDebut())).collect(Collectors.toList()));
		if (arrieres.isEmpty()) {
			return false;
		}
		for (ComplementEvenement ce : arrieres) {
			if (!Boolean.TRUE.equals(ce.isArriereTech()) && !Boolean.TRUE.equals(ce.isArriereLitige())
					&& StatutEvenement.ANN != ce.getStatutEvt()) {
				// Il existe un impayé non clos et non annulé, technique ou litige.
				return false;
			}
		}
		return true;
	}

	/**
	 * Retourne une date qui devrait être celle correspondant à la sortie d'arriéré
	 * significatif.
	 *
	 * La liste paramètre est classée par odre croissant.
	 *
	 * @param arrieres
	 * @return
	 */
	protected LocalDate trouveDateClotureArriere(List<ComplementEvenement> arrieres, LocalDate dateCalcul) {
		int i = arrieres.size();
		LocalDate dateParDefaut = null;
		while (--i >= 0) {
			ComplementEvenement ce = arrieres.get(i);
			if (ce.getStatutEvt() == StatutEvenement.CLO) {
				return ce.getDateMaj();
			}
			if (ce.getStatutEvt() == StatutEvenement.ANN) {
				return dateCalcul;
			}
			if (ce.isArriereTech() || ce.isArriereLitige()) {
				return dateCalcul;
			}
			if (ce.isMiseAJour()) {
				return ce.getDatePhoto();
			}
			// Pour ne pas sortir sans date
			if (dateParDefaut == null) {
				dateParDefaut = ce.getDatePhoto();
			}
		}

		return dateParDefaut;
	}

	/**
	 * Calcul d'arriérés significatifs pour tests de seuil.
	 *
	 * @param arrieres
	 * @param dateCalcul
	 * @return les éléments de calcul servant à prendre la décision
	 */
	protected Pair<ElementsDeCalcul, InfoEncoursTiers> calculeElementsAS(List<ComplementEvenement> arrieres,
			Long idTiers, LocalDate dateCalcul, Long guid, LocalDate datePhoto) {
		if (arrieres == null) {
			return null;
		}

		InfoEncoursTiers infoEncours = null;
		BigDecimal sommeArrieres = BigDecimal.ZERO;
		Integer seuilAbsolu = null;
		BigDecimal seuilRelatif = null;

		ElementsDeCalcul calc = new ElementsDeCalcul(dateCalcul);
		calc.setDateGeneration(LocalDateTime.now());
		calc.setGuid(guid);

		List<IdentiteTiers> identitesTiers = identiteTiersService.rechercheIdentitesActivesADate(idTiers, dateCalcul);

		if (identitesTiers.isEmpty()) {
			if (log.isDebugEnabled()) {
				log.debug("Le tiers {} n'a pas d'identité", idTiers);
			}
			return new MutablePair<>(null, null);
		}
		IdentiteTiers identTiers = identitesTiers.get(0);
		int seuilAbsoluPourEvt = parametresNDoDService.getSeuilAbsolu(identTiers.getCodeBanque(),
				identTiers.getCodeSegment(), dateCalcul);
		if (log.isDebugEnabled()) {
			log.debug("valeur du seuil absolu: {}", seuilAbsoluPourEvt);
		}

		if (seuilAbsolu == null || seuilAbsolu < seuilAbsoluPourEvt) {
			seuilAbsolu = seuilAbsoluPourEvt;
			calc.setSeuilAbsolu(seuilAbsolu);
		}

		BigDecimal seuilRelatifPourEvt = parametresNDoDService.getSeuilRelatif(identTiers.getCodeSegment(), dateCalcul);
		if (log.isDebugEnabled()) {
			log.debug("valeur du seuil relatif: {}", seuilRelatifPourEvt);
		}
		if (seuilRelatif == null || seuilRelatif.compareTo(seuilRelatifPourEvt) < 0) {
			seuilRelatif = seuilRelatifPourEvt;
			calc.setSeuilRelatif(seuilRelatif);
		}

		for (ComplementEvenement complEvt : arrieres) {
			if (StatutEvenement.ACT == complEvt.getStatutEvt()) {
				sommeArrieres = sommeArrieres.add(complEvt.getMontantArriere());
				calc.setMontantAbsolu(sommeArrieres);

				if (infoEncours != null && infoEncours.getMontantEncours() != null
						&& infoEncours.getMontantEncours().compareTo(BigDecimal.ZERO) != 0) {
					calc.setMontantRelatif(
							sommeArrieres.divide(infoEncours.getMontantEncours(), 5, RoundingMode.HALF_UP));
					calc.setEncours(infoEncours.getMontantEncours());
				}

				if (calc.isSignificatif()) {
					if (infoEncours == null) {
						infoEncours = serviceEncours.rechercheEncoursTiersADate(idTiers, dateCalcul, datePhoto);
						if (log.isDebugEnabled()) {
							log.debug("Recuperation de l'encours du tiers [{}]: {}", idTiers,
									infoEncours.getMontantEncours());
						}

						if (infoEncours.isDemandeEncoursAEnvoyer()) {
							// faut faire une demande pour les encours, on envoi un element de calcul null
							return new MutablePair<>(null, infoEncours);
						}
					}

					if (infoEncours.getMontantEncours() != null
							&& infoEncours.getMontantEncours().compareTo(BigDecimal.ZERO) != 0) {
						calc.setMontantRelatif(
								sommeArrieres.divide(infoEncours.getMontantEncours(), 5, RoundingMode.HALF_UP));
						calc.setEncours(infoEncours.getMontantEncours());
					}
					if (calc.getDateSignificatif() == null && calc.isSignificatif()) {
						calc.setDateSignificatif(complEvt.getDateDebut());
					}
				}
			}
		}

		return new MutablePair<>(calc, infoEncours);
	}

	protected IdentiteTiers donneIdentiteTiersPourDate(Evenement evt, LocalDate dateCalcul) {

		IdentiteTiers ret = evt.getIdentiteInitiale();
		if (dateCalcul.isBefore(ret.getDateDebut())) {
			return null;
		}
		while (ret.getDateFin() != null && ret.getDateFin().isBefore(dateCalcul)) {
			ret = ret.getSuivante();
		}
		return ret;
	}

	private MotifStatutTiers trouveStatutDefautByMotif(List<MotifStatutTiers> motifs, MotifStatutTiers motif) {
		for (MotifStatutTiers m : motifs) {
			if (motif.equals(m)) {
				return m;
			}
		}
		return null;
	}

	private void cloDefautNonJustifies(Tiers tiers, LocalDate dateCalcul, List<StatutHistorise> listDefautExitants,
			List<MotifStatutTiers> listDefautJustifies) {
		if (listDefautExitants != null && !listDefautExitants.isEmpty()) {
			for (StatutHistorise statut : listDefautExitants) {
				// Si DEFAUT UTP actif et est non justifié
				if (StatutTiers.DEFAUT.equals(statut.getStatut())
						&& !Constant.EVENEMENT_AR3.equals(statut.getMotif().getMotif())
						&& !Constant.EVENEMENT_IF.equals(statut.getMotif().getMotif())
						&& !Constant.EVENEMENT_PP.equals(statut.getMotif().getMotif())
						&& trouveStatutDefautByMotif(listDefautJustifies, statut.getMotif()) == null) {
					defautService.sortieDUnEvenementDeDefaut(tiers.getId(), dateCalcul, statut.getMotif(), false,
							dateCalcul);
				}
			}
		}
	}

	public void setServiceEncours(EncoursService serviceEncours) {
		this.serviceEncours = serviceEncours;
	}

	public void setParametresNDoD(ParametresNDoD parametresNDoD) {
		this.parametresNDoDService = parametresNDoD;
	}

	public void setEvtCalculeService(EvenementCalculeService evtCalculeService) {
		this.evtCalculeService = evtCalculeService;
	}

	public void setElemCalcRepository(ElementsDeCalculRepository elemCalcRepository) {
		this.elemCalcRepository = elemCalcRepository;
	}

	public void setEvtRecuService(EvenementRecuService evtRecuService) {
		this.evtRecuService = evtRecuService;
	}

	public void setDefautService(DefautService defautService) {
		this.defautService = defautService;
	}

	public void setAuditCalculService(AuditCalculService auditCalculService) {
		this.auditCalculService = auditCalculService;
	}

	public void setIdentiteTiersService(IdentiteTiersService identiteTiersService) {
		this.identiteTiersService = identiteTiersService;
	}

	public void setTiersService(TiersService tiersService) {
		this.tiersService = tiersService;
	}

	public void setRepEncoursTiers(EncoursTiersRepository repEncoursTiers) {
		this.repEncoursTiers = repEncoursTiers;
	}
}

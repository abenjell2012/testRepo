package fr.bpce.yyd.service.traitement.evenements.repositories;

import java.time.LocalDate;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import fr.bpce.yyd.service.traitement.evenements.entities.SuiviEncoursTiers;

@Repository
public interface SuiviEncoursTiersRepository extends JpaRepository<SuiviEncoursTiers, Long> {

    @Query(value = "select max(suiviDem.dateArreteMensuelle)  from SuiviEncoursTiers suiviEnc join fetch SuiviDemandeEncours suiviDem on suiviDem.id = suiviEnc.suiviDemandeEncours.id WHERE suiviEnc.tiers.id = :idTiers and suiviDem.dateArreteMensuelle <= :dateArrete and suiviDem.codeErreur is not null")
    LocalDate searchLastRespWithCodeErreur(@Param("idTiers") Long idTiers, @Param("dateArrete") LocalDate dateArrete);
}
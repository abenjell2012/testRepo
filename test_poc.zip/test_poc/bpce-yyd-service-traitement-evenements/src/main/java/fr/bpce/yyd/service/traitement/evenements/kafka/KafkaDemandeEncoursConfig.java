package fr.bpce.yyd.service.traitement.evenements.kafka;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;

import fr.bpce.yyd.commun.util.KafkaUtil;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.DemandeEncours;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.DemandeEncoursDtoSerializer;

@Configuration
@ConditionalOnProperty(value = "kafka.actif", havingValue = "true", matchIfMissing = false)
@EnableKafka
public class KafkaDemandeEncoursConfig {

	@Value(value = "${kafka.bootstrapAddress}")
	private List<String> bootstrapAddress;

	@Value(value = "${kafka.security-actif}")
	private boolean isSecurityActif;

	@Value(value = "${kafka.ssl-truststore-location}")
	private String sslTrustStoreLocation;

	@Value(value = "${kafka.ssl-truststore-password}")
	private String sslTrustStorePass;

	@Value(value = "${kafka.sasl-producer-user}")
	private String saslUser;

	@Value(value = "${kafka.sasl-producer-password}")
	private String saslPass;

	public Map<String, Object> baseFactory(Map<String, Object> props) {
		props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapAddress);
		return props;
	}

	@Bean
	public ProducerFactory<String, DemandeEncours> demandeEncoursProducerFactory() {
		Map<String, Object> props = new HashMap<>();
		props = baseFactory(props);
		props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
		props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, DemandeEncoursDtoSerializer.class);
		if (isSecurityActif) {
			KafkaUtil.addSecurityConfig(props, sslTrustStoreLocation, sslTrustStorePass, saslUser, saslPass);
		}
		return new DefaultKafkaProducerFactory<>(props);
	}

	@Bean
	public KafkaTemplate<String, DemandeEncours> demandeEncoursTemplate() {
		return new KafkaTemplate<>(demandeEncoursProducerFactory());
	}
}

package fr.bpce.yyd.service.traitement.evenements.repositories;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import fr.bpce.yyd.commun.model.restitution.RestTiersLocal;
import fr.bpce.yyd.service.traitement.evenements.dto.TiersSearchDto;

/**
 *
 *
 * @author benjelloun
 *
 */
@Repository
public interface RechercheTiersRepository extends JpaRepository<RestTiersLocal, Long> {

	// ************ Recherche sur ID_LOCAL

	@Query(value = "select new fr.bpce.yyd.service.traitement.evenements.dto.TiersSearchDto(tiers.id,rft.idRft,siren.siren, tiers.idLocal,tiers.codeBanque, "
			+ "rft.raisonSociale, tiers.codeSegment, seg.libSegCli) from RestTiersLocal tiers "
			+ "left join tiers.restAssoRftSiren assoc left join assoc.restIdRFT rft "
			+ "left join assoc.restIdSiren siren left join RefCliSeg seg on seg.codSegCli = tiers.codeSegment "
			+ "where tiers.dateFin is null "
			+ "and tiers.idLocal like concat('%',:idLocal,'%') and tiers.codeBanque = :codeBq")
	Page<TiersSearchDto> findByIdLocalLikeAndCodBq(@Param("idLocal") String idLocal, @Param("codeBq") String codeBq,
			Pageable pageable);

	@Query(value = "select new fr.bpce.yyd.service.traitement.evenements.dto.TiersSearchDto(tiers.id,rft.idRft,siren.siren, tiers.idLocal,tiers.codeBanque, "
			+ "rft.raisonSociale, tiers.codeSegment, seg.libSegCli) from RestTiersLocal tiers "
			+ "left join tiers.restAssoRftSiren assoc left join assoc.restIdRFT rft "
			+ "left join assoc.restIdSiren siren left join RefCliSeg seg on seg.codSegCli = tiers.codeSegment "
			+ "where tiers.dateFin is null "
			+ "and tiers.idLocal like concat('%',:idLocal,'%') and tiers.codeBanque IN (:perimetre)")
	Page<TiersSearchDto> findByIdLocalLikeAndPerimetre(@Param("idLocal") String idLocal, @Param("perimetre") List<String> perimetre,
												   Pageable pageable);

	@Query(value = "select new fr.bpce.yyd.service.traitement.evenements.dto.TiersSearchDto(tiers.id,rft.idRft,siren.siren, tiers.idLocal,tiers.codeBanque, "
			+ "rft.raisonSociale, tiers.codeSegment, seg.libSegCli) from RestTiersLocal tiers "
			+ "left join tiers.restAssoRftSiren assoc left join assoc.restIdRFT rft "
			+ "left join assoc.restIdSiren siren left join RefCliSeg seg on seg.codSegCli = tiers.codeSegment "
			+ "where tiers.dateFin is null and tiers.idLocal like concat('%',:idLocal,'%') ")
	Page<TiersSearchDto> findByIdLocalLike(@Param("idLocal") String idLocal, Pageable pageable);

	@Query(value = "select new fr.bpce.yyd.service.traitement.evenements.dto.TiersSearchDto(tiers.id,rft.idRft,siren.siren, tiers.idLocal,tiers.codeBanque, "
			+ "rft.raisonSociale, tiers.codeSegment, seg.libSegCli) from RestTiersLocal tiers "
			+ "left join tiers.restAssoRftSiren assoc left join assoc.restIdRFT rft "
			+ "left join assoc.restIdSiren siren left join RefCliSeg seg on seg.codSegCli = tiers.codeSegment "
			+ "where tiers.dateFin is null and tiers.idLocal =:idLocal and tiers.codeBanque = :codeBq")
	Page<TiersSearchDto> findByIdLocalEqualAndCodBq(@Param("idLocal") String idLocal, @Param("codeBq") String codeBq,
			Pageable pageable);

	@Query(value = "select new fr.bpce.yyd.service.traitement.evenements.dto.TiersSearchDto(tiers.id,rft.idRft,siren.siren, tiers.idLocal,tiers.codeBanque, "
			+ "rft.raisonSociale, tiers.codeSegment, seg.libSegCli) from RestTiersLocal tiers "
			+ "left join tiers.restAssoRftSiren assoc left join assoc.restIdRFT rft "
			+ "left join assoc.restIdSiren siren left join RefCliSeg seg on seg.codSegCli = tiers.codeSegment "
			+ "where tiers.dateFin is null and tiers.idLocal =:idLocal and tiers.codeBanque IN (:perimetre)")
	Page<TiersSearchDto> findByIdLocalEqualAndPerimetre(@Param("idLocal") String idLocal, @Param("perimetre") List<String> perimetre,
													Pageable pageable);

	@Query(value = "select new fr.bpce.yyd.service.traitement.evenements.dto.TiersSearchDto(tiers.id,rft.idRft,siren.siren, tiers.idLocal,tiers.codeBanque, "
			+ "rft.raisonSociale, tiers.codeSegment, seg.libSegCli) from RestTiersLocal tiers "
			+ "left join tiers.restAssoRftSiren assoc left join assoc.restIdRFT rft "
			+ "left join assoc.restIdSiren siren left join RefCliSeg seg on seg.codSegCli = tiers.codeSegment "
			+ "where tiers.dateFin is null and tiers.idLocal =:idLocal ")
	Page<TiersSearchDto> findByIdLocalEqual(@Param("idLocal") String idLocal, Pageable pageable);

	// ******************************* Recherche sur SIREN
	@Query(value = "select new fr.bpce.yyd.service.traitement.evenements.dto.TiersSearchDto(tiers.id,rft.idRft,siren.siren, tiers.idLocal,tiers.codeBanque, "
			+ "rft.raisonSociale, tiers.codeSegment, seg.libSegCli) from RestTiersLocal tiers "
			+ "left join tiers.restAssoRftSiren assoc left join assoc.restIdRFT rft "
			+ "left join assoc.restIdSiren siren left join RefCliSeg seg on seg.codSegCli = tiers.codeSegment "
			+ "where tiers.dateFin is null and siren.siren =:siren ")
	Page<TiersSearchDto> findBySirenEqual(@Param("siren") String siren, Pageable pageable);

	@Query(value = "select new fr.bpce.yyd.service.traitement.evenements.dto.TiersSearchDto(tiers.id,rft.idRft,siren.siren, tiers.idLocal,tiers.codeBanque, "
			+ "rft.raisonSociale, tiers.codeSegment, seg.libSegCli) from RestTiersLocal tiers "
			+ "left join tiers.restAssoRftSiren assoc left join assoc.restIdRFT rft "
			+ "left join assoc.restIdSiren siren left join RefCliSeg seg on seg.codSegCli = tiers.codeSegment "
			+ "where tiers.dateFin is null and siren.siren like concat('%',:siren,'%') ")
	Page<TiersSearchDto> findBySirenLike(@Param("siren") String siren, Pageable pageable);

	@Query(value = "select new fr.bpce.yyd.service.traitement.evenements.dto.TiersSearchDto(tiers.id,rft.idRft,siren.siren, tiers.idLocal,tiers.codeBanque, "
			+ "rft.raisonSociale, tiers.codeSegment, seg.libSegCli) from RestTiersLocal tiers "
			+ "left join tiers.restAssoRftSiren assoc left join assoc.restIdRFT rft "
			+ "left join assoc.restIdSiren siren left join RefCliSeg seg on seg.codSegCli = tiers.codeSegment "
			+ "where tiers.dateFin is null and siren.siren = :siren and tiers.codeBanque = :codeBq")
	Page<TiersSearchDto> findBySirenEqualAndCodBq(@Param("siren") String siren, @Param("codeBq") String codeBq,
			Pageable pageable);

	@Query(value = "select new fr.bpce.yyd.service.traitement.evenements.dto.TiersSearchDto(tiers.id,rft.idRft,siren.siren, tiers.idLocal,tiers.codeBanque, "
			+ "rft.raisonSociale, tiers.codeSegment, seg.libSegCli) from RestTiersLocal tiers "
			+ "left join tiers.restAssoRftSiren assoc left join assoc.restIdRFT rft "
			+ "left join assoc.restIdSiren siren left join RefCliSeg seg on seg.codSegCli = tiers.codeSegment "
			+ "where tiers.dateFin is null and siren.siren = :siren and tiers.codeBanque IN (:perimetre)")
	Page<TiersSearchDto> findBySirenEqualAndPerimetre(@Param("siren") String siren, @Param("perimetre") List<String> perimetre,
												  Pageable pageable);

	@Query(value = "select new fr.bpce.yyd.service.traitement.evenements.dto.TiersSearchDto(tiers.id,rft.idRft,siren.siren, tiers.idLocal,tiers.codeBanque, "
			+ "rft.raisonSociale, tiers.codeSegment, seg.libSegCli) from RestTiersLocal tiers "
			+ "left join tiers.restAssoRftSiren assoc left join assoc.restIdRFT rft "
			+ "left join assoc.restIdSiren siren left join RefCliSeg seg on seg.codSegCli = tiers.codeSegment "
			+ "where tiers.dateFin is null "
			+ "and siren.siren like concat('%',:siren,'%') and tiers.codeBanque = :codeBq")
	Page<TiersSearchDto> findBySirenLikeAndCodBq(@Param("siren") String siren, @Param("codeBq") String codeBq,
			Pageable pageable);

	@Query(value = "select new fr.bpce.yyd.service.traitement.evenements.dto.TiersSearchDto(tiers.id,rft.idRft,siren.siren, tiers.idLocal,tiers.codeBanque, "
			+ "rft.raisonSociale, tiers.codeSegment, seg.libSegCli) from RestTiersLocal tiers "
			+ "left join tiers.restAssoRftSiren assoc left join assoc.restIdRFT rft "
			+ "left join assoc.restIdSiren siren left join RefCliSeg seg on seg.codSegCli = tiers.codeSegment "
			+ "where tiers.dateFin is null "
			+ "and siren.siren like concat('%',:siren,'%') and tiers.codeBanque IN (:perimetre)")
	Page<TiersSearchDto> findBySirenLikeAndPerimetre(@Param("siren") String siren, @Param("perimetre") List<String> perimetre,
												 Pageable pageable);

//	// ******************************* Recherche sur ID_RFT

	@Query(value = "select tiers from RestTiersLocal tiers inner join tiers.restAssoRftSiren assoc "
			+ "inner join assoc.restIdRFT rft where tiers.dateFin is null and rft.idRft = :idRft ")
	List<RestTiersLocal> getRelationCommerciales(@Param("idRft") String idRft);

	@Query(value = "select new fr.bpce.yyd.service.traitement.evenements.dto.TiersSearchDto(tiers.id,rft.idRft,siren.siren, tiers.idLocal,tiers.codeBanque, "
			+ "rft.raisonSociale, tiers.codeSegment, seg.libSegCli) from RestTiersLocal tiers "
			+ "left join tiers.restAssoRftSiren assoc left join assoc.restIdRFT rft "
			+ "left join assoc.restIdSiren siren left join RefCliSeg seg on seg.codSegCli = tiers.codeSegment "
			+ "where tiers.dateFin is null and rft.idRft = :idRft ")
	Page<TiersSearchDto> findByIdRftEqual(@Param("idRft") String idRft, Pageable pageable);

	@Query(value = "select new fr.bpce.yyd.service.traitement.evenements.dto.TiersSearchDto(tiers.id,rft.idRft,siren.siren, tiers.idLocal,tiers.codeBanque, "
			+ "rft.raisonSociale, tiers.codeSegment, seg.libSegCli) from RestTiersLocal tiers "
			+ "left join tiers.restAssoRftSiren assoc left join assoc.restIdRFT rft "
			+ "left join assoc.restIdSiren siren left join RefCliSeg seg on seg.codSegCli = tiers.codeSegment "
			+ "where tiers.dateFin is null and rft.idRft like concat('%',:idRft,'%') ")
	Page<TiersSearchDto> findByIdRftLike(@Param("idRft") String idRft, Pageable pageable);

	@Query(value = "select new fr.bpce.yyd.service.traitement.evenements.dto.TiersSearchDto(tiers.id,rft.idRft,siren.siren, tiers.idLocal,tiers.codeBanque, "
			+ "rft.raisonSociale, tiers.codeSegment, seg.libSegCli) from RestTiersLocal tiers "
			+ "left join tiers.restAssoRftSiren assoc left join assoc.restIdRFT rft "
			+ "left join assoc.restIdSiren siren left join RefCliSeg seg on seg.codSegCli = tiers.codeSegment "
			+ "where tiers.dateFin is null "
			+ "and rft.idRft = :idRft and tiers.codeBanque = :codeBq ")
	Page<TiersSearchDto> findByIdRftEqualAndCodBq(@Param("idRft") String idRft, @Param("codeBq") String codBanque,
			Pageable pageable);

	@Query(value = "select new fr.bpce.yyd.service.traitement.evenements.dto.TiersSearchDto(tiers.id,rft.idRft,siren.siren, tiers.idLocal,tiers.codeBanque, "
			+ "rft.raisonSociale, tiers.codeSegment, seg.libSegCli) from RestTiersLocal tiers "
			+ "left join tiers.restAssoRftSiren assoc left join assoc.restIdRFT rft "
			+ "left join assoc.restIdSiren siren left join RefCliSeg seg on seg.codSegCli = tiers.codeSegment "
			+ "where tiers.dateFin is null "
			+ "and rft.idRft = :idRft and tiers.codeBanque IN (:perimetre)")
	Page<TiersSearchDto> findByIdRftEqualAndPerimetre(@Param("idRft") String idRft, @Param("perimetre") List<String> perimetre,
												  Pageable pageable);

	@Query(value = "select new fr.bpce.yyd.service.traitement.evenements.dto.TiersSearchDto(tiers.id,rft.idRft,siren.siren, tiers.idLocal,tiers.codeBanque, "
			+ "rft.raisonSociale, tiers.codeSegment, seg.libSegCli) from RestTiersLocal tiers "
			+ "left join tiers.restAssoRftSiren assoc left join assoc.restIdRFT rft "
			+ "left join assoc.restIdSiren siren left join RefCliSeg seg on seg.codSegCli = tiers.codeSegment "
			+ "where tiers.dateFin is null "
			+ "and rft.idRft like concat('%',:idRft,'%') and tiers.codeBanque = :codeBq ")
	Page<TiersSearchDto> findByidRftLikeAndCodBq(@Param("idRft") String idRft, @Param("codeBq") String codBanque,
			Pageable pageable);

	@Query(value = "select new fr.bpce.yyd.service.traitement.evenements.dto.TiersSearchDto(tiers.id,rft.idRft,siren.siren, tiers.idLocal,tiers.codeBanque, "
			+ "rft.raisonSociale, tiers.codeSegment, seg.libSegCli) from RestTiersLocal tiers "
			+ "left join tiers.restAssoRftSiren assoc left join assoc.restIdRFT rft "
			+ "left join assoc.restIdSiren siren left join RefCliSeg seg on seg.codSegCli = tiers.codeSegment "
			+ "where tiers.dateFin is null "
			+ "and rft.idRft like concat('%',:idRft,'%') and tiers.codeBanque IN (:perimetre)")
	Page<TiersSearchDto> findByidRftLikeAndPerimetre(@Param("idRft") String idRft, @Param("perimetre") List<String> perimetre,
												 Pageable pageable);

}

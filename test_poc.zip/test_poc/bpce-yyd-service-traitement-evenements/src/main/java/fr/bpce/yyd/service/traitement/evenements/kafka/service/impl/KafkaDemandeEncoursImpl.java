package fr.bpce.yyd.service.traitement.evenements.kafka.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;

import fr.bpce.yyd.service.commun.yyc.constant.KafkaConstant;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.DemandeEncours;
import fr.bpce.yyd.service.traitement.evenements.kafka.service.KafkaDemandeEncours;

@Service("producerDemandeEncours")
@ConditionalOnProperty(value = "kafka.actif", havingValue = "true", matchIfMissing = false)
public class KafkaDemandeEncoursImpl implements KafkaDemandeEncours {

	private static final Logger LOG = LoggerFactory.getLogger(KafkaDemandeEncoursImpl.class);

	@Autowired
	private KafkaTemplate<String, DemandeEncours> demandeEncoursTemplate;

	@Value("${kafka.producerEncours.topic}")
	private String topic;

	@Override
	public void send(DemandeEncours data, String msgId) {
		Message<DemandeEncours> message = MessageBuilder.withPayload(data) //
				.setHeader(KafkaConstant.MSGID_HEADER, msgId).setHeader(KafkaHeaders.MESSAGE_KEY, msgId)//
				.setHeader(KafkaConstant.ISSUER_HEADER, KafkaConstant.APPLI_YYD) //
				.setHeader(KafkaHeaders.TOPIC, topic).build();
		demandeEncoursTemplate.send(message);
		LOG.info("sended DemandeEncours {msgId={}, dateEncours={}, nbTiers={}}", msgId, data.getDateEncours(),
				data.getListTiers().size());

	}
}
package fr.bpce.yyd.service.traitement.evenements.enums;

public enum TypeRecherche {

	EQUAL, LIKE;

}

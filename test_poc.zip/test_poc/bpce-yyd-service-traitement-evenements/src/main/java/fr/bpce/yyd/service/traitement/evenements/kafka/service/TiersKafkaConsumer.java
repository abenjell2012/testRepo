package fr.bpce.yyd.service.traitement.evenements.kafka.service;

import fr.bpce.yyd.commun.messages.dto.LotIdTiersDTO;

public interface TiersKafkaConsumer {

	void receive(LotIdTiersDTO data);

	void receiveCloture(LotIdTiersDTO data);

}

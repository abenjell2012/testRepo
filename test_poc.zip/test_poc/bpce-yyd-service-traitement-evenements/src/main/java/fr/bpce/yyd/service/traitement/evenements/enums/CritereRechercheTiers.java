package fr.bpce.yyd.service.traitement.evenements.enums;

public enum CritereRechercheTiers {

	ID_RFT("tiers.idFederal"), SIREN("identite.siren"), ID_LOCAL("identite.idLocal");

	String column;

	CritereRechercheTiers(String column) {
		this.column = column;
	}

	public String getColumn() {
		return column;
	}

}

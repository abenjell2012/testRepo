package fr.bpce.yyd.service.traitement.evenements;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@ComponentScan(basePackages = { "fr.bpce.yyd.service.commun", "fr.bpce.yyd.service.traitement.evenements",
		"fr.bpce.yyd.commun" })
@EntityScan(basePackages = { "fr.bpce.yyd.service.traitement.evenements.entities",
		"fr.bpce.yyd.service.traitement.evenements.domain", "fr.bpce.yyd.commun.model",
		"fr.bpce.yyd.service.commun.model" })
@EnableJpaRepositories(basePackages = { "fr.bpce.yyd.service.commun.repository",
		"fr.bpce.yyd.service.traitement.evenements.repositories", "fr.bpce.yyd.commun.repository" })
@EnableCaching
public class CalculApplication {

	public static void main(String[] args) {
		SpringApplication.run(CalculApplication.class, args);
	}

	@Bean
	public CacheManager cacheManager() {
		return new ConcurrentMapCacheManager("ref_segment");
	}

}

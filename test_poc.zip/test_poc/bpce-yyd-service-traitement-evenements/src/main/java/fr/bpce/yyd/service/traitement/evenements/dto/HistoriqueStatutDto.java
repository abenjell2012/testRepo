package fr.bpce.yyd.service.traitement.evenements.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class HistoriqueStatutDto {

	// idSituation donnée utile pour le back-end mais non affiché à l'ecran
	private Long idSituation;

	private String statutEff;
	private String palier;
	private String date;
	private String origine;

}

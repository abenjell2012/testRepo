package fr.bpce.yyd.service.traitement.evenements.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import fr.bpce.yyd.commun.model.restitution.RestSynthTierLocalStatus;

/**
 *
 * @author chouichi
 *
 */

@Repository
public interface SyntheseTiersRepository extends JpaRepository<RestSynthTierLocalStatus, Long> {

	@Query(value = "select synth from RestSynthTierLocalStatus synth where id = :idSituation")
	RestSynthTierLocalStatus rechercherDetailStatutArrEtEng(@Param("idSituation") Long idSituation);

	@Query(value = "select synth from RestSynthTierLocalStatus synth inner join synth.restRechTiersLocal tiers "
			+ "where tiers.id = :idTiers order by synth.datePhoto desc")
	List<RestSynthTierLocalStatus> findAllPhotosByTiersId(@Param("idTiers") Long idTiers);

}

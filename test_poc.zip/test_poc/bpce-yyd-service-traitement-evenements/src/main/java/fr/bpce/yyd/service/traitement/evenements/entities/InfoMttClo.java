package fr.bpce.yyd.service.traitement.evenements.entities;

import java.math.BigDecimal;

public interface InfoMttClo {

	Long getEvtId();

	BigDecimal getMttArr();

}

package fr.bpce.yyd.service.traitement.evenements.repositories;

import java.time.LocalDate;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import fr.bpce.yyd.commun.model.ElementsDeCalcul;

@Repository
public interface ElementsDeCalculRepository extends CrudRepository<ElementsDeCalcul, Long> {

	@Query("select calcul from ElementsDeCalcul calcul where calcul.id = "
			+ "(select max(calc.id) from ElementsDeCalcul calc where "
			+ "calc.tiers.id = :idTiers and calc.dateCalcul <= :dateCalcul)")
	Optional<ElementsDeCalcul> findElementsDeCalculADate(@Param("idTiers") Long idTiers,
			@Param("dateCalcul") LocalDate date);
}
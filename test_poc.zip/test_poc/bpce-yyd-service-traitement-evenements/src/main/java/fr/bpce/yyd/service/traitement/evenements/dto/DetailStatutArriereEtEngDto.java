package fr.bpce.yyd.service.traitement.evenements.dto;

import java.math.BigDecimal;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DetailStatutArriereEtEngDto {

	private String statutCalc;
	private String palierDefautCalc;
	private String datePalierDefautCalc;
	private String dateStatutCalc;
	private String dateMetierEvtEntreeDefaut;
	private String idEvtEntreeDefaut;
	private String codeEvtEntreeDefaut;

	private String statutForce;
	private String dateDebut;
	private String dateFin;
	private String palierDefautForceBV;
	private String etablissement;
	private String codificationMotif;
	private String commentaireForcage;
	private String utilisateur;

	private String topPP;
	private String dateTopPP;
	private Integer compteurPP;
	private String datePrevFinPP;

	private String topF;
	private String dateTopF;

	private BigDecimal mttTotalArrieres;
	private BigDecimal mttEngagements;
	private String darDonneesEngagements;
	private Integer seuilAbsoluApp;
	private String dateSituation;

	private String topA;
	private Integer compteurA;
	private String dateTopA;

	private String topAS;
	private Integer compteurAS;
	private String dateTopAS;
	private String palierAS;

}

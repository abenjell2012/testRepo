package fr.bpce.yyd.service.traitement.evenements.service.dto;

import java.io.Serializable;

public class EvenementCalculeDTO implements Serializable {

	private static final long serialVersionUID = -5230441199486131199L;

	private String code;
	private String dateDebut;

	public EvenementCalculeDTO() {
	}

	public EvenementCalculeDTO(String code, String dateDebut) {
		this.code = code;
		this.dateDebut = dateDebut;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDateDebut() {
		return dateDebut;
	}

	public void setDateDebut(String dateDebut) {
		this.dateDebut = dateDebut;
	}
}

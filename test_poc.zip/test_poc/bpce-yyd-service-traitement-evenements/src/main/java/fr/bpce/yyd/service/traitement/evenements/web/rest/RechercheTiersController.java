package fr.bpce.yyd.service.traitement.evenements.web.rest;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import fr.bpce.yyd.service.traitement.evenements.dto.TiersSearchDto;
import fr.bpce.yyd.service.traitement.evenements.enums.CritereRechercheTiers;
import fr.bpce.yyd.service.traitement.evenements.enums.OrderBy;
import fr.bpce.yyd.service.traitement.evenements.exception.InvalidRequestParamException;
import fr.bpce.yyd.service.traitement.evenements.service.RechercheDetailsTiersService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Api(tags = "API pour l'IHM ANGULAR")
@RestController
@RequestMapping("api/tiers")
public class RechercheTiersController {

	@Autowired
	private RechercheDetailsTiersService rechercheDetailsTiersService;

	@ApiOperation(value = "recherche un tiers à partir de son identifiant (id_local, id_rft ou siren)")
	@PostMapping(value = "/search")
	public Map<String, Object> rechercherTiers(@RequestBody TiersSearchDto.SearchQuery searchQuery,
			@RequestParam("sortField") String sortField, @RequestParam("sortOrder") String sortOrder,
			@RequestParam("pageNumber") Integer pageNumber, @RequestParam("pageSize") Integer pageSize)
			throws InvalidRequestParamException {

		if (!CritereRechercheTiers.ID_LOCAL.name().equals(searchQuery.getCritere())
				&& !CritereRechercheTiers.ID_RFT.name().equals(searchQuery.getCritere())
				&& !CritereRechercheTiers.SIREN.name().equals(searchQuery.getCritere())) {
			throw new InvalidRequestParamException("paramètre critere invalide, valeurs attendues = "
					+ concatEnumValuesToString(CritereRechercheTiers.class));
		}

		if (searchQuery.getValeur() == null || searchQuery.getValeur().trim().isEmpty()) {
			throw new InvalidRequestParamException("Le paramètre identifiant ne peut pas être nulle");
		}
		if (!OrderBy.ID_RFT.getValue().equals(sortField) && !OrderBy.RAISON_SOC.getValue().equals(sortField)
				&& !OrderBy.SIREN.getValue().equals(sortField) && !OrderBy.SEGMENT.getValue().equals(sortField)) {
			throw new InvalidRequestParamException("paramètre orderBy invalide ");
		}

		if (!Direction.ASC.name().equalsIgnoreCase(sortOrder) && !Direction.DESC.name().equalsIgnoreCase(sortOrder)) {
			throw new InvalidRequestParamException(
					"paramètre direction invalide, valeurs attendues = " + concatEnumValuesToString(Direction.class));
		}

		Page<TiersSearchDto> pageResultat = rechercheDetailsTiersService.findByIdentifiant(
				CritereRechercheTiers.valueOf(searchQuery.getCritere()), searchQuery.getType(), searchQuery.getValeur(),
				searchQuery.getCodeBanque(), searchQuery.getPerimetre() ,pageNumber, pageSize, OrderBy.getColmunFromvalue(sortField),
				Direction.valueOf(sortOrder.toUpperCase()));

		Map<String, Object> result = new HashMap<>();
		result.put("items", pageResultat.getContent());
		result.put("totalCount", pageResultat.getTotalElements());

		return result;
	}

	public <E extends Enum<?>> String concatEnumValuesToString(Class<E> enumClass) {
		return Stream.of(enumClass.getEnumConstants()).map(Enum::name).collect(Collectors.joining(", "));
	}

}

package fr.bpce.yyd.service.traitement.evenements.exception;

public class InvalidRequestParamException extends Exception {

	private static final long serialVersionUID = 1290251455905761021L;

	public InvalidRequestParamException(String message) {
		super(message);
	}
}

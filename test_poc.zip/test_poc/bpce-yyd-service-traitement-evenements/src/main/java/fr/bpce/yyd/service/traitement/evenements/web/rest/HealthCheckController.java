package fr.bpce.yyd.service.traitement.evenements.web.rest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 *
 * @author chouichi
 *
 */

@Api(tags = "API Controle de vie")
@RestController
public class HealthCheckController {

	private static final String ALIVE = "Alive";

	@GetMapping(value = "/api/healthcheck")
	@ApiOperation(value = "permet de vérifier que le service est Alive")
	public String healthcheck() {
		return ALIVE;
	}
}

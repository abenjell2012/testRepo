package fr.bpce.yyd.service.traitement.evenements.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.TypeAgregat;

@Entity
@Table(name = "SUIVI_ENCOURS_TIERS")
public class SuiviEncoursTiers implements Serializable {

	private static final long serialVersionUID = 5952709627521960344L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "suivi_encours_tiers_seq_generator")
	@SequenceGenerator(name = "suivi_encours_tiers_seq_generator", sequenceName = "SUIVI_ENCOURS_TIERS_seq", allocationSize = 1000)
	private Long id;

	@ManyToOne
	@JoinColumn(name = "DEMANDE_ID", unique = false, nullable = false, updatable = false)
	private SuiviDemandeEncours suiviDemandeEncours;

	@ManyToOne
	@JoinColumn(name = "TIERS_ID", unique = false, nullable = false, updatable = false)
	private Tiers tiers;

	@Enumerated(EnumType.STRING)
	@Column(name = "TYPE_AGREGAT", length = 1)
	private TypeAgregat typeAgregat;

	@Column(name = "ID_FEDERAL", length = 10)
	private String idFederal;

	@Column(name = "CODE_BANQUE", length = 5)
	private String codeBanque;

	@Column(name = "ID_LOCAL", length = 50)
	private String idLocal;

	@Enumerated(EnumType.STRING)
	@Column(name = "STATUT", length = 10)
	private StatutEncoursTiers statut;

	@Column(name = "CODE_REJET", length = 10)
	private String codeRejet;

	@Column(name = "MSG_REJET", length = 250)
	private String msgRejet;

	public SuiviEncoursTiers(TypeAgregat typeAg, SuiviDemandeEncours suiviDemandeEncours, Tiers tiers, String idFederal,
			String codeBanque, String idLocal, StatutEncoursTiers statut) {
		this.typeAgregat = typeAg;
		this.suiviDemandeEncours = suiviDemandeEncours;
		this.tiers = tiers;
		this.idFederal = idFederal;
		this.codeBanque = codeBanque;
		this.idLocal = idLocal;
		this.statut = statut;
	}

	public SuiviEncoursTiers() {

	}

	public SuiviDemandeEncours getSuiviDemandeEncours() {
		return suiviDemandeEncours;
	}

	public void setSuiviDemandeEncours(SuiviDemandeEncours suiviDemandeEncours) {
		this.suiviDemandeEncours = suiviDemandeEncours;
	}

	public Tiers getTiers() {
		return tiers;
	}

	public void setTiers(Tiers tiers) {
		this.tiers = tiers;
	}

	public String getIdFederal() {
		return idFederal;
	}

	public void setIdFederal(String idFederal) {
		this.idFederal = idFederal;
	}

	public String getCodeBanque() {
		return codeBanque;
	}

	public void setCodeBanque(String codeBanque) {
		this.codeBanque = codeBanque;
	}

	public String getIdLocal() {
		return idLocal;
	}

	public void setIdLocal(String idLocal) {
		this.idLocal = idLocal;
	}

	public StatutEncoursTiers getStatut() {
		return statut;
	}

	public void setStatut(StatutEncoursTiers statut) {
		this.statut = statut;
	}

	public TypeAgregat getTypeAgregat() {
		return typeAgregat;
	}

	public void setTypeAgregat(TypeAgregat typeAgregat) {
		this.typeAgregat = typeAgregat;
	}

	public String getCodeRejet() {
		return codeRejet;
	}

	public void setCodeRejet(String codeRejet) {
		this.codeRejet = codeRejet;
	}

	public String getMsgRejet() {
		return msgRejet;
	}

	public void setMsgRejet(String msgRejet) {
		this.msgRejet = msgRejet;
	}

}

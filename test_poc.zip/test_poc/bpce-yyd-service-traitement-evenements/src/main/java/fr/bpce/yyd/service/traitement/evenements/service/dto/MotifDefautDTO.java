package fr.bpce.yyd.service.traitement.evenements.service.dto;

import java.io.Serializable;

public class MotifDefautDTO implements Serializable {

	private static final long serialVersionUID = -6131195241199483049L;

	private String motif;
	private String dateDebut;
	private boolean annule = false;

	public MotifDefautDTO() {
	}

	public MotifDefautDTO(String motif, String dateDebut) {
		this.motif = motif;
		this.dateDebut = dateDebut;
	}

	public String getMotif() {
		return motif;
	}

	public void setMotif(String motif) {
		this.motif = motif;
	}

	public String getDateDebut() {
		return dateDebut;
	}

	public void setDateDebut(String dateDebut) {
		this.dateDebut = dateDebut;
	}

	public boolean isAnnule() {
		return annule;
	}

	public void setAnnule(boolean annule) {
		this.annule = annule;
	}
}

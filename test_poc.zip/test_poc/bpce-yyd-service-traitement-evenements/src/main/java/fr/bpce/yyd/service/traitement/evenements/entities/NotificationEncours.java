package fr.bpce.yyd.service.traitement.evenements.entities;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import fr.bpce.yyd.commun.converters.LocalDatePersistenceConverter;

@Entity
@Table(name = "NOTIF_ENCOURS")
public class NotificationEncours implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "MSGID", length = 36)
	private String msgId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "DATE_NOTIFICATION")
	private Date dateNotif;

	@Convert(converter = LocalDatePersistenceConverter.class)
	@Column(name = "DATE_ARRETE_MENSUELLE")
	private LocalDate dateArrete;

	public String getMsgId() {
		return msgId;
	}

	public void setMsgId(String msgId) {
		this.msgId = msgId;
	}

	public Date getDateNotif() {
		return dateNotif;
	}

	public void setDateNotif(Date dateNotif) {
		this.dateNotif = dateNotif;
	}

	public LocalDate getDateArrete() {
		return dateArrete;
	}

	public void setDateArrete(LocalDate dateArrete) {
		this.dateArrete = dateArrete;
	}

	private static final long serialVersionUID = 1L;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}


	public NotificationEncours(Long id, String msgId, Date dateNotif, LocalDate dateArrete) {
		this.id = id;
		this.msgId = msgId;
		this.dateNotif = dateNotif;
		this.dateArrete = dateArrete;
	}

	public NotificationEncours(String msgId, Date dateNotif, LocalDate dateArrete) {
		this.msgId = msgId;
		this.dateNotif = dateNotif;
		this.dateArrete = dateArrete;
	}

	public NotificationEncours() {
	}
}

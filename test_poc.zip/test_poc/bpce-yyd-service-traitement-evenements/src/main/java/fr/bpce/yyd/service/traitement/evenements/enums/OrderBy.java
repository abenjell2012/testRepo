package fr.bpce.yyd.service.traitement.evenements.enums;

public enum OrderBy {

	ID_RFT("idRft", "rft.idRft"), SIREN("siren", "siren.siren"),
	RAISON_SOC("raisonSociale", "rft.raisonSociale"), SEGMENT("segment", "codeSegment");

	String value;
	String column;

	OrderBy(String value, String column) {
		this.value = value;
		this.column = column;
	}

	public String getColumn() {
		return column;
	}

	public String getValue() {
		return value;
	}

	public static String getColmunFromvalue(String value) {
		for (OrderBy order : OrderBy.values()) {
			if (order.getValue().equals(value)) {
				return order.getColumn();
			}
		}
		return null;

	}

}

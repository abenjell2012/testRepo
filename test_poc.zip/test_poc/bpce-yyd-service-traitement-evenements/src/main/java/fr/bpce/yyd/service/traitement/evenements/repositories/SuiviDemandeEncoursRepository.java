package fr.bpce.yyd.service.traitement.evenements.repositories;

import java.time.LocalDate;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import fr.bpce.yyd.service.traitement.evenements.entities.SuiviDemandeEncours;

@Repository
public interface SuiviDemandeEncoursRepository extends JpaRepository<SuiviDemandeEncours, Long> {
	SuiviDemandeEncours findByMsgIdAndDateEncours(String msgId, LocalDate dateEncours);

}
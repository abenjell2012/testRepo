package fr.bpce.yyd.service.traitement.evenements.kafka.service;

import fr.bpce.yyd.service.commun.yyc.kafka.dto.NotifEncours;

public interface KafkaNotifEncours {

	void receive(NotifEncours data, String key, String msgId, String provider);

}

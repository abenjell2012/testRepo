package fr.bpce.yyd.service.traitement.evenements.service;

import fr.bpce.yyd.commun.model.restitution.RestSynthTierLocalStatus;
import fr.bpce.yyd.service.traitement.evenements.dto.SyntheseTiersDto;
import fr.bpce.yyd.service.traitement.evenements.dto.TiersSearchDto;

public interface RechercheSyntheseTiersService {

	RestSynthTierLocalStatus rechercherDetailStatutArrEtEng(Long idSituation);

	/*
	 * renvoie une synthese tier avec:
	 * son histoque des status, ses relations commerciales
	 * les details et evenements locaux et Mdc du status le plus recent
	 *
	 */
	SyntheseTiersDto findByTier(TiersSearchDto tierDto) ;
}

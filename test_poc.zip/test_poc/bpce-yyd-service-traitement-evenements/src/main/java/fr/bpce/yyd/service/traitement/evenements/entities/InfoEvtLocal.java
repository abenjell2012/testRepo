package fr.bpce.yyd.service.traitement.evenements.entities;

import java.math.BigDecimal;
import java.util.Date;

public interface InfoEvtLocal {

	Long getIdEvt();

	String getIdLocalTiers();

	String getCodeBanqueEmetrice();

	String getIdEvtLocal();

	String getCode();

	String getSousCode();

	Date getDateDebut();

	Date getDatePhoto();

	Date getDateCloture();

	Date getDateMajStatut();

	String getStatut();

	String getCommentaire();

	BigDecimal getTopLitige();

	BigDecimal getTopTechnique();

	BigDecimal getMontant();

	String getContrat();

}

package fr.bpce.yyd.service.traitement.evenements.kafka.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import fr.bpce.yyd.service.commun.yyc.constant.KafkaConstant;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.ReponseEncours;
import fr.bpce.yyd.service.traitement.evenements.kafka.service.KafkaEncoursTiers;
import fr.bpce.yyd.service.traitement.evenements.service.EncoursService;

@Service("consumerReponseEncours")
@ConditionalOnProperty(value = "kafka.actif", havingValue = "true", matchIfMissing = false)
public class KafkaEncoursTiersImpl implements KafkaEncoursTiers {

	private static final Logger LOG = LoggerFactory.getLogger(KafkaEncoursTiersImpl.class);

	@Autowired
	private EncoursService serviceEncours;

	@KafkaListener(topics = "${kafka.consumerEncoursTiers.topic}", groupId = "${kafka.consumerEncoursTiers.groupId}", containerFactory = "consumerEncoursTiers")
	@Override
	public void receive(@Payload ReponseEncours data, @Header(KafkaHeaders.RECEIVED_MESSAGE_KEY) String key,
			@Header(KafkaConstant.MSGID_HEADER) String msgId, @Header(KafkaConstant.ISSUER_HEADER) String issuer,
			@Header(KafkaConstant.PROVIDER_HEADER) String provider) {
		LOG.info("Reception EncoursTiers avec {msgId={}, dateArreteMensuelle={}, nbTiers={}, issuer={}, provider={}}",
				msgId, data.getDateArreteMensuelle(), data.getEncoursTiers().size(), issuer, provider);
		serviceEncours.traiterReponseEncours(data, msgId);
	}

}

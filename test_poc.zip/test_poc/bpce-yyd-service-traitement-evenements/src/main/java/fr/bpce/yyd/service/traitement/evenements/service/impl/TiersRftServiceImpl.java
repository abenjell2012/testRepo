package fr.bpce.yyd.service.traitement.evenements.service.impl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fr.bpce.yyd.commun.model.TiersRFT;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.Statut;
import fr.bpce.yyd.service.commun.yyc.model.DemandeLotTiersRft;
import fr.bpce.yyd.service.commun.yyc.model.DemandeTiersRFT;
import fr.bpce.yyd.service.commun.yyc.model.ReponseLotTiersRft;
import fr.bpce.yyd.service.commun.yyc.model.ReponseTiersRFT;
import fr.bpce.yyd.service.traitement.evenements.repositories.TiersRftRepository;
import fr.bpce.yyd.service.traitement.evenements.service.TiersRftService;

@Service
public class TiersRftServiceImpl implements TiersRftService {

    @Autowired
    private TiersRftRepository tiersRftRepository;

    @Override
    public ReponseLotTiersRft processRequest(DemandeLotTiersRft request) {
        LocalDate dateAppel = request.getDateAppel();
        ReponseLotTiersRft response;
        LocalDate dateArreteMensuelle = tiersRftRepository.findMaxDateArreteMensuelle(dateAppel);
        if (dateArreteMensuelle == null) {
            response = getResponseWithoutDateArreteDB(dateAppel, request);
        } else {
            response = new ReponseLotTiersRft(dateAppel, dateArreteMensuelle);
            Map<String, ReponseTiersRFT> map = new HashMap<>();
            getResponseIdRFTDB(dateArreteMensuelle, 0, 500, request, response, map);
        }
        return response;
    }

    private ReponseLotTiersRft getResponseWithoutDateArreteDB(LocalDate dateAppel, DemandeLotTiersRft request) {
        ReponseLotTiersRft response = new ReponseLotTiersRft(dateAppel, null);
        for (int i = 0; i < request.getTiers().size(); i++) {
            DemandeTiersRFT tiersR = request.getTiers().get(i);
            String codeBanque = tiersR.getCodeBanque();
            String idLocal = tiersR.getIdLocal();
            response.getTiers().add(new ReponseTiersRFT(codeBanque, idLocal, null, Statut.NON_TROUVE));
        }
        return response;
    }

    private void getResponseIdRFTDB(LocalDate dateArrete, int cursor, int max, DemandeLotTiersRft request,
            ReponseLotTiersRft response, Map<String, ReponseTiersRFT> map) {
        List<String> codeBanqueIdLocal = new ArrayList<>();
        int nbTiers = request.getTiers().size();

        for (int i = cursor; i < max && i < nbTiers; i++) {
            DemandeTiersRFT tiersR = request.getTiers().get(i);
            String key = tiersR.getCodeBanque() + "#" + tiersR.getIdLocal();
            codeBanqueIdLocal.add(key);
            map.put(key, new ReponseTiersRFT(tiersR.getCodeBanque(), tiersR.getIdLocal(), null, Statut.NON_TROUVE));
            cursor = i;
        }
        if (!codeBanqueIdLocal.isEmpty()) {
            List<TiersRFT> tiersRRft = tiersRftRepository.findByListCodeIdAndDate(dateArrete, codeBanqueIdLocal);
            for (int j = 0; j < tiersRRft.size(); j++) {
                map.put(tiersRRft.get(j).getCodeBanque() + "#" + tiersRRft.get(j).getIdLocal(),
                        new ReponseTiersRFT(tiersRRft.get(j).getCodeBanque(), tiersRRft.get(j).getIdLocal(),
                                tiersRRft.get(j).getIdFederal(), Statut.TROUVE));
            }
        }

        if (cursor >= nbTiers - 1) {
            for (ReponseTiersRFT value : map.values()) {
                response.getTiers().add(value);
            }
            return;
        }
        getResponseIdRFTDB(dateArrete, max, max + 500, request, response, map);
    }

    @Override
    public LocalDate getDateArrete(LocalDate dateAppel) {
        return tiersRftRepository.findMaxDateArreteMensuelle(dateAppel);

    }

}

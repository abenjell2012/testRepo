package fr.bpce.yyd.service.traitement.evenements.entities;

import java.util.Date;

public interface InfoEvtMdc {

	String getIdMdcEvent();

	String getCodeMdc();

	Date getCreationDateEvt();

	String getStatutEvt();

	Date getDateMiseAJourStatut();

}

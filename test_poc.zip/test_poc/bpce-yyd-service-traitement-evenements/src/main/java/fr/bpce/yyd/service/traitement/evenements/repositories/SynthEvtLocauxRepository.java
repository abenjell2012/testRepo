package fr.bpce.yyd.service.traitement.evenements.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import fr.bpce.yyd.commun.model.restitution.RestSynthEvtLocauxStatus;
import fr.bpce.yyd.service.traitement.evenements.entities.InfoEvtLocal;
import fr.bpce.yyd.service.traitement.evenements.entities.InfoMttClo;

@Repository
public interface SynthEvtLocauxRepository extends JpaRepository<RestSynthEvtLocauxStatus, Long> {

	@Query(value = "with TIERS_IDENTITE as (select i.id , i.id_local, i.code_bq from  identite_tiers i"
			+ "	inner join identite_tiers i2 on i.id_local = i2.id_local and i.code_bq = i2.code_bq  and i2.date_fin is null"
			+ "	where i.id_local = :idLocal and i.code_bq = :codeBq)"
			+ "	select e.id as idEvt, ident.id_local as idLocalTiers ,ident.code_bq as codeBanqueEmetrice, e.id_local as idEvtLocal, "
			+ " e.code as code ,e.type as sousCode, e.date_debut as dateDebut,ce.DATE_PHOTO as datePhoto, null as dateCloture, ce.DATE_MAJ as dateMajStatut,"
			+ " ce.STATUT_EVENEMENT as statut , ce.commentaire as commentaire, ce.ARRIERE_TECH as topTechnique, ce.ARRIERE_LITIGE as topLitige, "
			+ " ce.MONTANT_ARRIERE as montant, e.id_contrat as contrat from complement_evenement ce"
			+ "	inner join evenement e on e.id = ce.evenement_id"
			+ "	inner join TIERS_IDENTITE ident on ident.id = e.identite_initiale_id"
			+ "	where ce.statut_evenement = 'ACT' and ce.date_fin is null and  ce.identite_initiale_id = ident.id"
			+ "	union all " // union all
			+ "	select e.id as idEvt, ident.id_local as idLocalTiers,ident.code_bq as codeBanqueEmetrice, e.id_local as idEvtLocal,"
			+ " e.code as code,e.type as sousCode, e.date_debut as dateDebut,ce.DATE_PHOTO as datePhoto, "
			+ " case when ce.STATUT_EVENEMENT = 'CLO' then ce.DATE_MAJ else null end as dateCloture, ce.DATE_MAJ as dateMajStatut,"
			+ " ce.STATUT_EVENEMENT as statut , ce.commentaire as commentaire, ce.ARRIERE_TECH as topTechnique, ce.ARRIERE_LITIGE as topLitige, "
			+ " ce.MONTANT_ARRIERE as montant, e.id_contrat as contrat from complement_evenement ce"
			+ "	inner join evenement e on e.id = ce.evenement_id"
			+ "	inner join TIERS_IDENTITE ident on ident.id = e.identite_initiale_id"
			+ "	where statut_evenement in ('CLO','ANN') and date_maj >= (trunc(sysdate) - :profHistorique)  and  ce.identite_initiale_id = ident.id", nativeQuery = true)
	List<InfoEvtLocal> findByIdLocalAndCodBq(@Param("idLocal") String idLocal, @Param("codeBq") String codeBq,
			@Param("profHistorique") int profondeur);

	@Query(value = "with TIERS_IDENTITE as ( select i.id , i.id_local, i.code_bq from identite_tiers i  "
			+ " inner join tiers t on t.id = i.tiers_id where t.id_rft = :idRft ) "
			+ " select e.id as idEvt ,ident.id_local as idLocalTiers ,ident.code_bq as codeBanqueEmetrice, e.id_local as idEvtLocal,  "
			+ " e.code as code ,e.type as sousCode, e.date_debut as dateDebut,ce.DATE_PHOTO as datePhoto, null as dateCloture, ce.DATE_MAJ as dateMajStatut, "
			+ " ce.STATUT_EVENEMENT as statut , ce.commentaire as commentaire, ce.ARRIERE_TECH as topTechnique, ce.ARRIERE_LITIGE as topLitige,  "
			+ "	ce.MONTANT_ARRIERE as montant, e.id_contrat as contrat from complement_evenement ce "
			+ " inner join evenement e on e.id = ce.evenement_id "
			+ "	inner join TIERS_IDENTITE ident on ident.id = e.identite_initiale_id "
			+ "	where ce.statut_evenement = 'ACT' and ce.date_fin is null and  ce.identite_initiale_id = ident.id "
			+ "	union all " // union all
			+ "	select  e.id as idEvt, ident.id_local as idLocalTiers,ident.code_bq as codeBanqueEmetrice, e.id_local as idEvtLocal, "
			+ "	e.code as code,e.type as sousCode, e.date_debut as dateDebut,ce.DATE_PHOTO as datePhoto,"
			+ " case when ce.STATUT_EVENEMENT = 'CLO' then ce.DATE_MAJ else null end as dateCloture, ce.DATE_MAJ as dateMajStatut, "
			+ "	ce.STATUT_EVENEMENT as statut , ce.commentaire as commentaire, ce.ARRIERE_TECH as topTechnique, ce.ARRIERE_LITIGE as topLitige,  "
			+ "	ce.MONTANT_ARRIERE as montant, e.id_contrat as contrat from complement_evenement ce "
			+ " inner join evenement e on e.id = ce.evenement_id "
			+ "	inner join TIERS_IDENTITE ident on ident.id = e.identite_initiale_id "
			+ "	where statut_evenement in ('CLO','ANN') and date_maj >= (trunc(sysdate) - :profHistorique)  and  ce.identite_initiale_id = ident.id ", nativeQuery = true)
	List<InfoEvtLocal> findByIdRft(@Param("idRft") String idRft, @Param("profHistorique") int profondeurHisto);

	@Query(value = "select C_ACT.EVENEMENT_ID AS evtId, C_ACT.MONTANT_ARRIERE as mttArr from COMPLEMENT_EVENEMENT C_ACT "
			+ "INNER JOIN ("
			+ "SELECT MAX(id) AS id_compl, evenement_id AS id_evt FROM COMPLEMENT_EVENEMENT WHERE evenement_id in (:arrsCloIds) AND STATUT_EVENEMENT = 'ACT' AND DATE_FIN IS NOT NULL "
			+ "group by EVENEMENT_ID ) MAX_ID_EVT "
			+ "ON MAX_ID_EVT.id_compl = C_ACT.ID AND MAX_ID_EVT.ID_EVT = C_ACT.EVENEMENT_ID", nativeQuery = true)
	List<InfoMttClo> findMontantArrClo(@Param("arrsCloIds") List<Long> arrsCloIds);
}

package fr.bpce.yyd.service.traitement.evenements.dto;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class EvenementLocalDto {

	private String idLocalTiers;
	private String codeBqEmett;
	private String idLocalEvt;
	private String code;
	private String libelleCode;
	private String sousCode;
	private String libelleSsCode;
	private String dateDebut;
	private String dateCloture;
	private String datePhoto;

	private String statut;
	private String dateMajStatut;
	private String commentaire;
	private String topTechnique;
	private String topLitige;

	private BigDecimal montant;
	private String idContrat;
	private Long idEvtTech;

}

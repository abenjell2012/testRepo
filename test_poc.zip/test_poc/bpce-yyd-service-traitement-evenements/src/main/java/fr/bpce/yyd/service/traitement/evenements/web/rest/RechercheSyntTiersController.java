package fr.bpce.yyd.service.traitement.evenements.web.rest;

import java.time.format.DateTimeFormatter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import fr.bpce.yyd.commun.model.restitution.RestSynthTierLocalStatus;
import fr.bpce.yyd.service.traitement.evenements.dto.DetailStatutArriereEtEngDto;
import fr.bpce.yyd.service.traitement.evenements.dto.SyntheseTiersDto;
import fr.bpce.yyd.service.traitement.evenements.dto.TiersSearchDto;
import fr.bpce.yyd.service.traitement.evenements.exception.InvalidRequestParamException;
import fr.bpce.yyd.service.traitement.evenements.service.RechercheSyntheseTiersService;
import fr.bpce.yyd.service.traitement.evenements.web.utils.WebUtility;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Api(tags = "API pour l'IHM ANGULAR")
@RestController
@RequestMapping("api/syntheseTiers")
public class RechercheSyntTiersController {

	private static final String MSG_TIERS_NULL = "le tiers est null";
	private static final String MSG_CODE_BANQUE_NULL = "pas de code banque";
	private static final String MSG_DETAIL_NULL = "Detail de status tiers introuvable";
	private static final String MSG_ID_LOCAL_NULL = "pas d identifiant local";
	private static final String MSG_SYNTHESE_NULL = "Le tiers sélectionné n'a pas de synthèse";

	@Autowired
	private RechercheSyntheseTiersService rechercheSyntheseTiersService;

	DateTimeFormatter datePattern = DateTimeFormatter.ofPattern("dd/MM/yyyy");

	@GetMapping(value = "/detailStatutArrEtEng")
	@ApiOperation(value = "renvoi les détails de statut pour un idSituation")
	public DetailStatutArriereEtEngDto rechercherDetailStatutArrEtEng(
			@RequestParam(value = "idSituation") Long idSituation) throws InvalidRequestParamException {

		RestSynthTierLocalStatus synth = rechercheSyntheseTiersService.rechercherDetailStatutArrEtEng(idSituation);
		if (synth == null) {
			throw new InvalidRequestParamException(MSG_DETAIL_NULL);
		}

		return mapToDetailStatus(synth);

	}

	private DetailStatutArriereEtEngDto mapToDetailStatus(RestSynthTierLocalStatus synth) {

		DetailStatutArriereEtEngDto dto = new DetailStatutArriereEtEngDto();

		dto.setStatutCalc(WebUtility.mapStatus(synth.getStatutCalcule()));
		dto.setPalierDefautCalc(synth.getPalierCalcule());
		dto.setDatePalierDefautCalc(WebUtility.dateToString(synth.getDatePalierCalcule()));
		dto.setDateStatutCalc(WebUtility.dateToString(synth.getDateStatutCalcule()));
		dto.setDateMetierEvtEntreeDefaut(WebUtility.dateToString(synth.getDateMetierEntreeDefaut()));
		dto.setIdEvtEntreeDefaut(synth.getIdEvtEntreeDefaut());
		dto.setCodeEvtEntreeDefaut(synth.getCodeEvtEntreeDefaut());

		dto.setStatutForce(WebUtility.mapStatus(synth.getStatutBV()));
		dto.setDateDebut(WebUtility.dateToString(synth.getDateDebutForcageBV()));
		dto.setDateFin(WebUtility.dateToString(synth.getDateFinForcageBV()));
		dto.setPalierDefautForceBV(synth.getPalierBV());
		dto.setEtablissement(synth.getEtablissementBV());
		dto.setCodificationMotif(synth.getCodeMotifBV());
		dto.setCommentaireForcage(synth.getCommentaireBV());
		dto.setUtilisateur(synth.getUtilisateurBV());

		dto.setTopPP(WebUtility.booleanToString(synth.isTopPP()));
		dto.setDateTopPP(WebUtility.dateToString(synth.getDateTopPP()));
		dto.setCompteurPP(
				WebUtility.getCompteurAtRuntime(synth.getCompteurPP(), synth.getDatePhoto(), synth.isTopPP()));
		dto.setDatePrevFinPP(WebUtility.dateToString(synth.getDatePrevisionnelleFinPP()));

		dto.setTopF(WebUtility.booleanToString(synth.isTopF()));
		dto.setDateTopF(WebUtility.dateToString(synth.getDateTopF()));

		dto.setMttTotalArrieres(WebUtility.toBigDecimal(synth.getMontantTotalArriere()));
		dto.setMttEngagements(WebUtility.toBigDecimal(synth.getMontantEnCours()));

		dto.setDarDonneesEngagements(WebUtility.dateToString(synth.getDarEncours()));
		dto.setSeuilAbsoluApp(WebUtility.longToInt(synth.getSeuilAbsolu()));
		dto.setDateSituation(WebUtility.dateToString(synth.getDatePhoto()));

		dto.setTopA(WebUtility.booleanToString(synth.isTopA()));
		dto.setCompteurA(WebUtility.getCompteurAtRuntime(synth.getCompteurA(), synth.getDatePhoto(), synth.isTopA()));
		dto.setDateTopA(WebUtility.dateToString(synth.getDateTopA()));

		dto.setTopAS(WebUtility.booleanToString(synth.isTopAS()));
		dto.setCompteurAS(
				WebUtility.getCompteurAtRuntime(synth.getCompteurAS(), synth.getDatePhoto(), synth.isTopAS()));
		dto.setDateTopAS(WebUtility.dateToString(synth.getDateTopAS()));
		dto.setPalierAS(synth.getPalierAS());
		return dto;
	}

	/*
	 * renvoie une synthese tier avec: son histoque des status, ses relations
	 * commerciales les details et evenements locaux et Mdc du status le plus recent
	 */

	@ApiOperation(value = "renvoi la dernière synthese (quotidienne) d'un tiers, avec ses événements locaux et MDC")
	@PostMapping(value = "/synthese")
	public SyntheseTiersDto rechercheSyntheseTiers(@RequestBody TiersSearchDto tiers)
			throws InvalidRequestParamException {

		if (tiers == null) {
			throw new InvalidRequestParamException(MSG_TIERS_NULL);
		}

		if (tiers.getCodeBanque() == null || tiers.getCodeBanque().isEmpty()) {
			throw new InvalidRequestParamException(MSG_CODE_BANQUE_NULL);
		}

		if (tiers.getIdLocal() == null || tiers.getIdLocal().isEmpty()) {
			throw new InvalidRequestParamException(MSG_ID_LOCAL_NULL);
		}

		SyntheseTiersDto syntheseTiersDto = rechercheSyntheseTiersService.findByTier(tiers);

		if (syntheseTiersDto == null) {
			throw new InvalidRequestParamException(MSG_SYNTHESE_NULL);
		}

		return syntheseTiersDto;

	}

}

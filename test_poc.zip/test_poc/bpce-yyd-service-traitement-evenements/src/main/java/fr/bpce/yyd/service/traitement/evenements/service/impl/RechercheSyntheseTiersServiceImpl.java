package fr.bpce.yyd.service.traitement.evenements.service.impl;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fr.bpce.yyd.commun.enums.CodeEvenement;
import fr.bpce.yyd.commun.enums.StatutEvenement;
import fr.bpce.yyd.commun.model.reference.RefBqBfbp;
import fr.bpce.yyd.commun.model.reference.RefCliSeg;
import fr.bpce.yyd.commun.model.reference.RefEvtNdod;
import fr.bpce.yyd.commun.model.reference.RefSsCodEvt;
import fr.bpce.yyd.commun.model.restitution.RestAssociateRftSiren;
import fr.bpce.yyd.commun.model.restitution.RestSynthTierLocalStatus;
import fr.bpce.yyd.commun.model.restitution.RestTiersLocal;
import fr.bpce.yyd.commun.repository.RefEvtNdodRepository;
import fr.bpce.yyd.commun.repository.RefMdcnSegmentRepository;
import fr.bpce.yyd.commun.repository.RefSsEvtNdodRepository;
import fr.bpce.yyd.service.commun.service.ParametresNDoD;
import fr.bpce.yyd.service.traitement.evenements.dto.DetailStatutArriereEtEngDto;
import fr.bpce.yyd.service.traitement.evenements.dto.EvenementLocalDto;
import fr.bpce.yyd.service.traitement.evenements.dto.EvenementMdcDto;
import fr.bpce.yyd.service.traitement.evenements.dto.MontantTotalArrDto;
import fr.bpce.yyd.service.traitement.evenements.dto.RelationTiersDto;
import fr.bpce.yyd.service.traitement.evenements.dto.SyntheseTiersDto;
import fr.bpce.yyd.service.traitement.evenements.dto.TiersSearchDto;
import fr.bpce.yyd.service.traitement.evenements.entities.InfoEvtLocal;
import fr.bpce.yyd.service.traitement.evenements.entities.InfoEvtMdc;
import fr.bpce.yyd.service.traitement.evenements.entities.InfoMttClo;
import fr.bpce.yyd.service.traitement.evenements.repositories.RechercheTiersRepository;
import fr.bpce.yyd.service.traitement.evenements.repositories.ReferenceImportSrvcRepository;
import fr.bpce.yyd.service.traitement.evenements.repositories.SynthEvtLocauxRepository;
import fr.bpce.yyd.service.traitement.evenements.repositories.SynthEvtMdcRepository;
import fr.bpce.yyd.service.traitement.evenements.repositories.SyntheseTiersRepository;
import fr.bpce.yyd.service.traitement.evenements.service.RechercheSyntheseTiersService;
import fr.bpce.yyd.service.traitement.evenements.web.utils.WebUtility;
import fr.bpce.yyd.service.traitement.evenements.repositories.TiersRftRepository;

@Service
public class RechercheSyntheseTiersServiceImpl implements RechercheSyntheseTiersService {

	@Autowired
	private SyntheseTiersRepository syntheseTiersRepository;

	@Autowired
	private RechercheTiersRepository rechercheTiersRepository;

	@Autowired
	private SynthEvtLocauxRepository synthEvtLocauxRepository;

	@Autowired
	private SynthEvtMdcRepository synthEvtMdcRepository;

	@Autowired
	private ReferenceImportSrvcRepository referenceImportSrvcRepository;

	@Autowired
	private RefMdcnSegmentRepository refMdcnSegmentRepository;

	@Autowired
	private RefEvtNdodRepository refEvtNdodRepository;

	@Autowired
	private RefSsEvtNdodRepository refSsEvtNdodRepository;
	
	@Autowired
	private TiersRftRepository tiersRftRepository;

	@Autowired
	private ParametresNDoD parametresNdodSrvc;

	private Map<String, String> libellesBanq;

	private Map<String, String> libellesCdSeg;

	private Map<String, String> libellesCdEvt;

	private Map<String, String> libellesSsCdEvt;

	@Override
	public RestSynthTierLocalStatus rechercherDetailStatutArrEtEng(Long idSituation) {

		return syntheseTiersRepository.rechercherDetailStatutArrEtEng(idSituation);
	}

	@Override
	public SyntheseTiersDto findByTier(TiersSearchDto tierDto) {

		// recuperation des syntheses d'un tier
		List<RestSynthTierLocalStatus> restSynthTierLocalStatus = syntheseTiersRepository
				.findAllPhotosByTiersId(tierDto.getId());
		
		if (restSynthTierLocalStatus == null || restSynthTierLocalStatus.isEmpty()) {
			return null;
		}

		RestSynthTierLocalStatus synthRecente = restSynthTierLocalStatus.get(0);
		RestTiersLocal tierRef = synthRecente.getRestRechTiersLocal();
		RestAssociateRftSiren associateRftSirenRef = tierRef.getRestAssoRftSiren();

		SyntheseTiersDto syntheseTiers = new SyntheseTiersDto();
        
		syntheseTiers.setDatePhoto(WebUtility.dateToString(synthRecente.getDatePhoto()));

		if (associateRftSirenRef != null && associateRftSirenRef.getRestIdRFT() != null) {

			syntheseTiers.setIdFederal(associateRftSirenRef.getRestIdRFT().getIdRft());
			syntheseTiers.setCodeBqRef(associateRftSirenRef.getRestIdRFT().getCodeBanqueReferente());
			syntheseTiers
					.setLibelleBqRef(getLibelleByCodeBq(associateRftSirenRef.getRestIdRFT().getCodeBanqueReferente()));
			syntheseTiers.setRaisonSociale(associateRftSirenRef.getRestIdRFT().getRaisonSociale());
			
			//recuperation de la date import rft pour le tiers
			LocalDate dateArreteMensuelle = tiersRftRepository.findDateArreteMensuelle(associateRftSirenRef.getRestIdRFT().getIdRft());
			syntheseTiers.setDateImportRft(WebUtility.dateToString(dateArreteMensuelle));
		}

		if (associateRftSirenRef != null && associateRftSirenRef.getRestIdSiren() != null) {
			syntheseTiers.setSiren(associateRftSirenRef.getRestIdSiren().getSiren());
		}

		syntheseTiers.setCodeSegment(tierRef.getCodeSegment());
		syntheseTiers.setLibelleCdSegment(getLibelleByCodeSeg(tierRef.getCodeSegment()));
		syntheseTiers.setIdLocal(tierRef.getIdLocal());
		syntheseTiers.setCodeBanque(tierRef.getCodeBanque());
		
		syntheseTiers.setStatutEff(WebUtility.mapStatus(synthRecente.getStatutEffectif()));
		syntheseTiers.setStatutCalc(WebUtility.mapStatus(synthRecente.getStatutCalcule()));
		syntheseTiers.setPalierDefaut(synthRecente.getPalierEffectif());
		syntheseTiers.setDateStc(WebUtility.dateToString(synthRecente.getDateStatutCalcule()));
		syntheseTiers.setDateSte(WebUtility.dateToString(synthRecente.getDateMAJStatutEffectif()));
		syntheseTiers.setOrigineSte(WebUtility.mapOriginStatus(synthRecente.getOrigineStatutEffectif()));
		syntheseTiers.setEvtEntreeDefaut(synthRecente.getCodeEvtEntreeDefaut());
		syntheseTiers.setDateEvt(WebUtility.dateToString(synthRecente.getDateMetierEntreeDefaut()));
		syntheseTiers.setLibelleEvtEntreeDefaut(getLibelleByCodeEvt(synthRecente.getCodeEvtEntreeDefaut()));
		
		// RELATIONS COMMERCIALES
		String idRft = null;
		if (associateRftSirenRef != null && associateRftSirenRef.getRestIdRFT() != null) {
			idRft = associateRftSirenRef.getRestIdRFT().getIdRft();
		}
		syntheseTiers.setRelationTiersList(getRelationsComFromIdRFT(idRft));

		// EVENEMENTS
		int profondeurHisto = parametresNdodSrvc.getProfondeurHistoEvts(LocalDate.now());
		List<EvenementMdcDto> historiqueEvenementMdcList = new ArrayList<>();

		// recuperation des evenements MDC
		List<InfoEvtMdc> evenementsMdc;
		if (tierDto.getIdRft() != null && StringUtils.isNotBlank(tierDto.getIdRft())) {
			evenementsMdc = synthEvtMdcRepository.findByIdRft(tierDto.getIdRft(), profondeurHisto);
		} else {
			evenementsMdc = synthEvtMdcRepository.findByIdLocalAndCodBq(tierDto.getIdLocal(), tierDto.getCodeBanque(),
					profondeurHisto);
		}
		for (InfoEvtMdc evntMdc : evenementsMdc) {
			historiqueEvenementMdcList.add(getEvntMdcToDto(evntMdc));
		}

		syntheseTiers.setEvenementMdcList(historiqueEvenementMdcList);

		// recuperation des evenements locaux
		List<InfoEvtLocal> evenementsLocauxI;
		if (tierDto.getIdRft() != null && StringUtils.isNotBlank(tierDto.getIdRft())) {
			evenementsLocauxI = synthEvtLocauxRepository.findByIdRft(tierDto.getIdRft(), profondeurHisto);
		} else {
			evenementsLocauxI = synthEvtLocauxRepository.findByIdLocalAndCodBq(tierDto.getIdLocal(),
					tierDto.getCodeBanque(), profondeurHisto);
		}
		List<EvenementLocalDto> historiqueEvenementLocauxList = new ArrayList<>();

		Map<String, MontantTotalArrDto> amounts = new HashMap<>();
		LocalDate derniereMaj = synthRecente.getDatePhoto();
		for (InfoEvtLocal evntLocal : evenementsLocauxI) {

			if (derniereMaj.isBefore(WebUtility.convertToLocalDate(evntLocal.getDatePhoto()))) {
				derniereMaj = WebUtility.convertToLocalDate(evntLocal.getDatePhoto());
			}

			if (!WebUtility.toBoolean(evntLocal.getTopLitige()) && !WebUtility.toBoolean(evntLocal.getTopTechnique())
					&& StatutEvenement.ACT.toString().equals(evntLocal.getStatut())
					&& (CodeEvenement.IMX.toString().equals(evntLocal.getCode())
							|| CodeEvenement.DAX.toString().equals(evntLocal.getCode()))) {
				MontantTotalArrDto mtt = amounts.get(evntLocal.getCodeBanqueEmetrice());
				BigDecimal newMtt = evntLocal.getMontant();
				BigDecimal imxMtt;
				BigDecimal daxMtt;

				if (mtt == null) {
					mtt = new MontantTotalArrDto();
					mtt.setCodeBanque(evntLocal.getCodeBanqueEmetrice());
					amounts.put(evntLocal.getCodeBanqueEmetrice(), mtt);
					imxMtt = new BigDecimal(0);
					daxMtt = new BigDecimal(0);
					mtt.setMttTotalImx(imxMtt);
					mtt.setMttTotalDax(daxMtt);
				} else {
					imxMtt = mtt.getMttTotalImx();
					daxMtt = mtt.getMttTotalDax();
				}

				if (evntLocal.getCode().equals(CodeEvenement.IMX.toString())) {
					mtt.setMttTotalImx(imxMtt.add(newMtt));
				} else if (evntLocal.getCode().equals(CodeEvenement.DAX.toString())) {
					mtt.setMttTotalDax(daxMtt.add(newMtt));
				}
				mtt.setMttTotalArr(mtt.getMttTotalImx().add(mtt.getMttTotalDax()));
			}
			historiqueEvenementLocauxList.add(getEvntLocalToDto(evntLocal));
		}
		syntheseTiers.setDateDerniereMaj(WebUtility.dateToString(derniereMaj));

		// rechercher les DAX/IMX CLO pour mettre à jour les montants des arrières
		List<Long> idsArrsClo = historiqueEvenementLocauxList.stream()
				.filter(e -> ((CodeEvenement.IMX.toString().equals(e.getCode())
						|| CodeEvenement.DAX.toString().equals(e.getCode()))
						&& (StatutEvenement.CLO.toString().equals(e.getStatut())
								|| StatutEvenement.ANN.toString().equals(e.getStatut()))))
				.map(EvenementLocalDto::getIdEvtTech).collect(Collectors.toList());

		if (!idsArrsClo.isEmpty()) {
			majMontantEvtClo(historiqueEvenementLocauxList, idsArrsClo);
		}

		syntheseTiers.setEvenementLocalList(historiqueEvenementLocauxList);

		// MONTANT
		syntheseTiers.setMontantTotalArrList(new ArrayList<>(amounts.values()));

		// DETAIL STATUS
		DetailStatutArriereEtEngDto arrEtEng = syntheseToDetailStatus(synthRecente);
		if (!syntheseTiers.getMontantTotalArrList().isEmpty()) {
			arrEtEng.setMttTotalArrieres(new BigDecimal(0));
			for (MontantTotalArrDto mnt : syntheseTiers.getMontantTotalArrList()) {
				arrEtEng.setMttTotalArrieres(arrEtEng.getMttTotalArrieres().add(mnt.getMttTotalArr()));
			}
		}
		syntheseTiers.setDetailStatutArriereEtEng(arrEtEng);

		return syntheseTiers;

	}

	private void majMontantEvtClo(List<EvenementLocalDto> historiqueEvenementLocauxList, List<Long> idsArrsClo) {
		List<InfoMttClo> listMontant = synthEvtLocauxRepository.findMontantArrClo(idsArrsClo);
		if (listMontant != null && !listMontant.isEmpty()) {
			Map<Long, BigDecimal> map = new HashMap<>();
			for (InfoMttClo info : listMontant) {
				map.put(info.getEvtId(), info.getMttArr());
			}
			for (EvenementLocalDto evtLocalDto : historiqueEvenementLocauxList) {
				if (idsArrsClo.contains(evtLocalDto.getIdEvtTech()) && map.get(evtLocalDto.getIdEvtTech()) != null) {
					evtLocalDto.setMontant(map.get(evtLocalDto.getIdEvtTech()));
				}
			}
		}
	}

	/*
	 * recupere les relation commercieles d un tier a partir de son idrft idlocal
	 * sert a le retirer de la liste.
	 *
	 */
	private List<RelationTiersDto> getRelationsComFromIdRFT(String idRFT) {

		List<RelationTiersDto> relationsComm = new ArrayList<>();
		if (idRFT == null) {
			return relationsComm;
		}

		List<RestTiersLocal> tiers = rechercheTiersRepository.getRelationCommerciales(idRFT);

		for (RestTiersLocal restTiersLocal : tiers) {
			relationsComm.add(getRelationTierFromSynthese(restTiersLocal));
		}

		return relationsComm;
	}

	/*
	 * transforme un evenmentMdc entite en dto
	 *
	 */
	private EvenementMdcDto getEvntMdcToDto(InfoEvtMdc evntMdc) {

		return new EvenementMdcDto(evntMdc.getIdMdcEvent(), evntMdc.getCodeMdc(),
				WebUtility.formatToString(evntMdc.getCreationDateEvt()), evntMdc.getStatutEvt(),
				WebUtility.formatToString(evntMdc.getDateMiseAJourStatut())

		);

	}

	/*
	 * transforme un evenment local en dto
	 *
	 */

	private EvenementLocalDto getEvntLocalToDto(InfoEvtLocal evntLocal) {
		return new EvenementLocalDto(evntLocal.getIdLocalTiers(), evntLocal.getCodeBanqueEmetrice(),
				evntLocal.getIdEvtLocal(), evntLocal.getCode(), getLibelleByCodeEvt(evntLocal.getCode()),
				evntLocal.getSousCode(), getLibelleBySsCodeEvt(evntLocal.getSousCode()),
				WebUtility.formatToString(evntLocal.getDateDebut()),
				WebUtility.formatToString(evntLocal.getDateCloture()),
				WebUtility.formatToString(evntLocal.getDatePhoto()), evntLocal.getStatut(),
				WebUtility.formatToString(evntLocal.getDateMajStatut()), evntLocal.getCommentaire(),
				WebUtility.booleanToString(evntLocal.getTopTechnique()),
				WebUtility.booleanToString(evntLocal.getTopLitige()), evntLocal.getMontant(), evntLocal.getContrat(),
				evntLocal.getIdEvt());

	}

	/*
	 * genere une relation tier à partir d une synthese entite
	 *
	 */
	private RelationTiersDto getRelationTierFromSynthese(RestTiersLocal tier) {

		RestAssociateRftSiren associateRftSiren = tier.getRestAssoRftSiren();

		return new RelationTiersDto(tier.getIdLocal(), tier.getCodeBanque(), getLibelleByCodeBq(tier.getCodeBanque()),
				WebUtility.booleanToString(
						tier.getCodeBanque().equals(associateRftSiren.getRestIdRFT().getCodeBanqueReferente())));

	}

	/*
	 * genere un detail status dto a partir d une sunthese entite
	 *
	 */
	private DetailStatutArriereEtEngDto syntheseToDetailStatus(RestSynthTierLocalStatus synthese) {

		DetailStatutArriereEtEngDto detailDernierStatutArrEng = new DetailStatutArriereEtEngDto();
		detailDernierStatutArrEng.setStatutCalc(WebUtility.mapStatus(synthese.getStatutCalcule()));
		detailDernierStatutArrEng.setPalierDefautCalc(synthese.getPalierCalcule());

		detailDernierStatutArrEng.setDatePalierDefautCalc(WebUtility.dateToString(synthese.getDatePalierCalcule()));

		detailDernierStatutArrEng.setDateStatutCalc(WebUtility.dateToString(synthese.getDateStatutCalcule()));

		detailDernierStatutArrEng
				.setDateMetierEvtEntreeDefaut(WebUtility.dateToString(synthese.getDateMetierEntreeDefaut()));

		detailDernierStatutArrEng.setCodeEvtEntreeDefaut(synthese.getCodeEvtEntreeDefaut());
		if ("AR3".equals(synthese.getCodeEvtEntreeDefaut())) {
			detailDernierStatutArrEng.setIdEvtEntreeDefaut("AR3" + synthese.getIdEvtEntreeDefaut());
		} else {
			detailDernierStatutArrEng.setIdEvtEntreeDefaut(synthese.getIdEvtEntreeDefaut());
		}

		detailDernierStatutArrEng.setStatutForce(WebUtility.mapStatus(synthese.getStatutBV()));

		detailDernierStatutArrEng.setDateDebut(WebUtility.dateToString(synthese.getDateDebutForcageBV()));

		detailDernierStatutArrEng.setDateFin(WebUtility.dateToString(synthese.getDateFinForcageBV()));

		detailDernierStatutArrEng.setPalierDefautForceBV(synthese.getPalierBV());
		detailDernierStatutArrEng.setEtablissement(synthese.getEtablissementBV());
		detailDernierStatutArrEng.setCodificationMotif(synthese.getCodeMotifBV());
		detailDernierStatutArrEng.setCommentaireForcage(synthese.getCommentaireBV());
		detailDernierStatutArrEng.setUtilisateur(synthese.getUtilisateurBV());

		detailDernierStatutArrEng.setTopPP(WebUtility.booleanToString(synthese.isTopPP()));

		detailDernierStatutArrEng.setDateTopPP(WebUtility.dateToString(synthese.getDateTopPP()));

		detailDernierStatutArrEng.setCompteurPP(
				WebUtility.getCompteurAtRuntime(synthese.getCompteurPP(), synthese.getDatePhoto(), synthese.isTopPP()));

		detailDernierStatutArrEng.setDatePrevFinPP(WebUtility.dateToString(synthese.getDatePrevisionnelleFinPP()));

		detailDernierStatutArrEng.setTopF(WebUtility.booleanToString(synthese.isTopF()));

		detailDernierStatutArrEng.setDateTopF(WebUtility.dateToString(synthese.getDateTopF()));

		detailDernierStatutArrEng.setMttTotalArrieres(WebUtility.toBigDecimal(synthese.getMontantTotalArriere()));
		detailDernierStatutArrEng.setMttEngagements(WebUtility.toBigDecimal(synthese.getMontantEnCours()));

		detailDernierStatutArrEng.setDarDonneesEngagements(WebUtility.dateToString(synthese.getDarEncours()));

		detailDernierStatutArrEng.setSeuilAbsoluApp(WebUtility.longToInt(synthese.getSeuilAbsolu()));

		detailDernierStatutArrEng.setDateSituation(WebUtility.dateToString(synthese.getDatePhoto()));

		detailDernierStatutArrEng.setTopA(WebUtility.booleanToString(synthese.isTopA()));
		detailDernierStatutArrEng.setCompteurA(
				WebUtility.getCompteurAtRuntime(synthese.getCompteurA(), synthese.getDatePhoto(), synthese.isTopA()));

		detailDernierStatutArrEng.setDateTopA(WebUtility.dateToString(synthese.getDateTopA()));

		detailDernierStatutArrEng.setTopAS(WebUtility.booleanToString(synthese.isTopAS()));
		detailDernierStatutArrEng.setCompteurAS(
				WebUtility.getCompteurAtRuntime(synthese.getCompteurAS(), synthese.getDatePhoto(), synthese.isTopAS()));

		detailDernierStatutArrEng.setDateTopAS(WebUtility.dateToString(synthese.getDateTopAS()));
		detailDernierStatutArrEng.setPalierAS(synthese.getPalierAS());

		return detailDernierStatutArrEng;
	}

	/*
	 * renvoie le libele banquaire a partir de son code banque
	 *
	 */
	private String getLibelleByCodeBq(String codeBanque) {

		if (libellesBanq == null) {
			libellesBanq = new HashMap<>();

			for (RefBqBfbp refBqBfbps : referenceImportSrvcRepository.getAll()) {
				libellesBanq.put(refBqBfbps.getCodBq(), refBqBfbps.getLibBqAbrege());
			}
		}

		return codeBanque == null ? StringUtils.EMPTY : libellesBanq.get(codeBanque);

	}

	private String getLibelleByCodeSeg(String codeSeg) {

		if (libellesCdSeg == null) {
			libellesCdSeg = new HashMap<>();

			for (RefCliSeg ref : refMdcnSegmentRepository.getAll()) {
				libellesCdSeg.put(ref.getCodSegCli(), ref.getLibSegCli());
			}
		}

		return codeSeg == null ? StringUtils.EMPTY : libellesCdSeg.get(codeSeg);

	}

	private String getLibelleByCodeEvt(String codeEvt) {

		if (libellesCdEvt == null) {
			libellesCdEvt = new HashMap<>();

			for (RefEvtNdod ref : refEvtNdodRepository.getAll()) {
				libellesCdEvt.put(ref.getCodEvt(), ref.getLibEvt());
			}
		}

		return codeEvt == null ? StringUtils.EMPTY : libellesCdEvt.get(codeEvt.trim());

	}

	private String getLibelleBySsCodeEvt(String ssCodeEvt) {

		if (libellesSsCdEvt == null) {
			libellesSsCdEvt = new HashMap<>();

			for (RefSsCodEvt ref : refSsEvtNdodRepository.getAll()) {
				libellesSsCdEvt.put(ref.getSsCodeEvt(), ref.getLibSsCodeEvt());
			}
		}

		return ssCodeEvt == null ? StringUtils.EMPTY : libellesSsCdEvt.get(ssCodeEvt);

	}

}

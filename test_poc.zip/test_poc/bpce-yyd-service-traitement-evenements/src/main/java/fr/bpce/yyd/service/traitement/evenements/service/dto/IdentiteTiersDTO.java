package fr.bpce.yyd.service.traitement.evenements.service.dto;

import java.io.Serializable;

public class IdentiteTiersDTO implements Serializable {

	private static final long serialVersionUID = 455822948819812482L;

	private String codeBanque;
	private String idTiersLocal;
	private String segment;
	private String siren;

	public String getCodeBanque() {
		return codeBanque;
	}

	public void setCodeBanque(String codeBanque) {
		this.codeBanque = codeBanque;
	}

	public String getIdTiersLocal() {
		return idTiersLocal;
	}

	public void setIdTiersLocal(String idTiersLocal) {
		this.idTiersLocal = idTiersLocal;
	}

	public String getSiren() {
		return siren;
	}

	public void setSiren(String siren) {
		this.siren = siren;
	}

	public String getSegment() {
		return segment;
	}

	public void setSegment(String segment) {
		this.segment = segment;
	}

}

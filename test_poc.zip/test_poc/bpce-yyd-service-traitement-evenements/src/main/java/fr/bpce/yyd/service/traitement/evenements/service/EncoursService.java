package fr.bpce.yyd.service.traitement.evenements.service;

import java.time.LocalDate;
import java.util.List;

import fr.bpce.yyd.service.commun.yyc.kafka.dto.NotifEncours;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.ReponseEncours;
import fr.bpce.yyd.service.traitement.evenements.entities.InfoEncoursTiers;

/**
 * Interface du service pour l'obtention des encours d'un tiers.
 */
public interface EncoursService {

	/**
	 * Recherche les encours consolidés d'un tiers (consolidé) à une date donnée.
	 *
	 * @param idTiers
	 * @param date
	 * @return
	 */
	InfoEncoursTiers rechercheEncoursTiersADate(Long idTiers, LocalDate date, LocalDate datePhoto);

	void saveEncoursNotification(NotifEncours message, String msgId);

	void traiterReponseEncours(ReponseEncours msg, String msgId);

	void initDemandeEncoursApresNotif(LocalDate datedemande);

	void initDemandeEncoursLotIdTiers(LocalDate dateCalcul, List<Long> listIdTiersPourDemande);

	LocalDate rechercheDateEncoursTiersADate(Long idTiers, LocalDate dateCalcul);

	InfoEncoursTiers rechercheEncoursTiers(Long idTiers, LocalDate dateDemande, LocalDate datePhoto,
			InfoEncoursTiers infoEncoursTiers, boolean mocked);

}
package fr.bpce.yyd.service.traitement.evenements.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import fr.bpce.yyd.service.traitement.evenements.entities.NotificationEncours;


@Repository
public interface NotificationEncoursRepository extends CrudRepository<NotificationEncours, Long> {

}
package fr.bpce.yyd.service.calcul.compteur.service;

import fr.bpce.yyd.commun.messages.dto.LotIdTiersDTO;

/**
 * Service Interface for managing computation.
 */
public interface CalculCompteurService {

	/**
	 * Traitement d'un message de lot d'ids Tiers à traiter.
	 *
	 * @param message Le message reçu
	 */
	void traiteMessage(LotIdTiersDTO message);
}

package fr.bpce.yyd.service.calcul.compteur;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

/**
 * 
 * @author Ndod team
 *
 */

@SpringBootApplication
@ComponentScan(basePackages = { "fr.bpce.yyd.service.commun", "fr.bpce.yyd.service.calcul.compteur",
		"fr.bpce.yyd.commun" })
@EntityScan(basePackages = { "fr.bpce.yyd.commun.model", "fr.bpce.yyd.service.commun.model" })
@EnableJpaRepositories(basePackages = { "fr.bpce.yyd.service.commun.repository", "fr.bpce.yyd.commun.repository" })
@EnableCaching
public class CalculCompteurApplication {

	public static void main(String[] args) {
		SpringApplication.run(CalculCompteurApplication.class, args);
	}

	@Bean
	public CacheManager cacheManager() {
		return new ConcurrentMapCacheManager("ref_segment");
	}

}

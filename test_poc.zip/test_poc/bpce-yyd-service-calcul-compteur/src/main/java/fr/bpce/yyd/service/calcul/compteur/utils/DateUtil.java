package fr.bpce.yyd.service.calcul.compteur.utils;

import java.time.LocalDate;
import java.time.Period;
import java.time.temporal.ChronoUnit;

public class DateUtil {

	private DateUtil() {
		// Méthodes statiques seulement.
	}

	public static long getNbDaysBetween(LocalDate dateDebut, LocalDate dateFin) {
		return ChronoUnit.DAYS.between(dateDebut, dateFin);

	}

	public static Period getPeriodBetween(LocalDate dateDebut, LocalDate dateFin) {
		return Period.between(dateDebut, dateFin);

	}

}

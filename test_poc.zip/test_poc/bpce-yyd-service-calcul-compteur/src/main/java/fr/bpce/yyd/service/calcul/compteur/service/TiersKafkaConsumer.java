package fr.bpce.yyd.service.calcul.compteur.service;

import fr.bpce.yyd.commun.messages.dto.LotIdTiersDTO;

public interface TiersKafkaConsumer {

	void receive(LotIdTiersDTO data);

}

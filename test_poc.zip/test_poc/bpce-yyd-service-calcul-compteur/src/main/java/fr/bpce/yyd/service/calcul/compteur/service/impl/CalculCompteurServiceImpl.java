package fr.bpce.yyd.service.calcul.compteur.service.impl;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import fr.bpce.yyd.commun.enums.CodeEvenement;
import fr.bpce.yyd.commun.enums.EvenementArriereSignificatif;
import fr.bpce.yyd.commun.enums.StatutAuditEvenement;
import fr.bpce.yyd.commun.enums.StatutEvenement;
import fr.bpce.yyd.commun.messages.dto.LotIdTiersDTO;
import fr.bpce.yyd.commun.model.ArriereSignificatif;
import fr.bpce.yyd.commun.model.AuditCalcul;
import fr.bpce.yyd.commun.model.ComplementArriere;
import fr.bpce.yyd.commun.model.ComplementEvenement;
import fr.bpce.yyd.commun.model.ComplementImpaye;
import fr.bpce.yyd.commun.model.Evenement;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.ImpayeSurForbearance;
import fr.bpce.yyd.commun.model.MotifStatutTiers;
import fr.bpce.yyd.commun.model.PeriodeProbatoire;
import fr.bpce.yyd.commun.model.StatutHistorise;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.service.calcul.compteur.service.CalculCompteurService;
import fr.bpce.yyd.service.calcul.compteur.utils.DateUtil;
import fr.bpce.yyd.service.calcul.compteur.utils.EnumIterator;
import fr.bpce.yyd.service.commun.beans.EvenementsATraiter;
import fr.bpce.yyd.service.commun.beans.EvenementsCalculesTiers;
import fr.bpce.yyd.service.commun.contexte.ContexteCalculTiers;
import fr.bpce.yyd.service.commun.service.AuditCalculService;
import fr.bpce.yyd.service.commun.service.DefautService;
import fr.bpce.yyd.service.commun.service.EvenementCalculeService;
import fr.bpce.yyd.service.commun.service.EvenementRecuService;
import fr.bpce.yyd.service.commun.service.IdentiteTiersService;
import fr.bpce.yyd.service.commun.service.RechercheTiersService;
import fr.bpce.yyd.service.commun.service.impl.ParametresNDoDImpl;

@Service
public class CalculCompteurServiceImpl implements CalculCompteurService {

	private static final Logger LOG = LoggerFactory.getLogger(CalculCompteurServiceImpl.class);

	@Autowired
	private EvenementCalculeService evenementCalculeService;

	@Autowired
	private EvenementRecuService evenementRecuService;

	@Autowired
	private RechercheTiersService rechercheTiersService;

	@Autowired
	private DefautService defautService;

	@Autowired
	private AuditCalculService auditCalculService;

	@Autowired
	private ParametresNDoDImpl paramNDoDService;

	@Autowired
	private IdentiteTiersService identiteTiersService;

	@Override
	@Transactional
	public void traiteMessage(LotIdTiersDTO message) {

		if (LOG.isInfoEnabled()) {
			LOG.info(
					"*********************** Traitement du message ***************************** date de calcul : {} , {}",
					message.getDateCalcul(), Arrays.toString(message.getIdsTiers().toArray()));
		}
		LocalDate dateCalcul = message.getDateCalcul();

		if (dateCalcul == null) {
			dateCalcul = LocalDate.now();
			message.setDateCalcul(dateCalcul);
		}

		Map<Long, List<IdentiteTiers>> identiteTiers;
		Map<Long, EvenementsATraiter> evenementsATraiter;
		Map<Long, List<StatutHistorise>> statutsCourants;
		Map<Long, EvenementsCalculesTiers> evtCalculesTiers;
		Map<Long, ComplementArriere> complArriereTiers;

		try {
			identiteTiers = identiteTiersService.rechercheIdentitesActivesADate(message);
			evenementsATraiter = evenementRecuService.rechercheEvenementsATraiterADate(message, identiteTiers);
			statutsCourants = defautService.getStatutsADate(message);
			evtCalculesTiers = evenementCalculeService.rechercheEvenementsCalculesActifsADate(message);
			complArriereTiers = evenementCalculeService.rechercheComplementArriere(message);
		} catch (Exception exp) {
			LOG.error("Erreur lors de chargement des Maps", exp);
			return;
		}

		try {
			ContexteCalculTiers.init(evenementsATraiter, statutsCourants, identiteTiers, evtCalculesTiers);

			for (Long idTiers : message.getIdsTiers()) {
				try {
					if (LOG.isDebugEnabled()) {
						LOG.debug("traitement tiers {}", idTiers);
					}
					traiteTiersAvecEvenementCalcule(idTiers, dateCalcul, complArriereTiers);
				} catch (Exception exp) {

					LOG.error("Erreur lors de traitement du tiers " + idTiers, exp);
				}
			}
			updateDateCalculCourante(dateCalcul);
		} finally {
			ContexteCalculTiers.clear();
		}
	}

	public void traiteTiersAvecEvenementCalcule(Long idTiers, LocalDate dateCalcul,
			Map<Long, ComplementArriere> complArriereTiers) {

		EvenementsCalculesTiers evtsCalc = evenementCalculeService.rechercheEvenementsCalculesActifsADate(idTiers,
				dateCalcul);
		traiteArriereSignificatif(idTiers, evtsCalc, dateCalcul, complArriereTiers);
		traiteImpayesSurForbearance(idTiers, evtsCalc, dateCalcul);
		traiteSortiePeriodeProbatoire(idTiers, evtsCalc, dateCalcul);

		// gestion pour créer un staut SAIN au tiers dans le cas où il n'est pas en
		// Défaut (et il a eu un changement de catégorie)
		List<StatutHistorise> statutsCourants = defautService.getAllStatuts(idTiers);
		if (statutsCourants.isEmpty()) {
			// initialiser un statut SAIN avec la dateCalcul
			defautService.initStatutTiersASain(idTiers, dateCalcul);
		}

	}

	/**
	 * Traitement des arriérés significatifs
	 *
	 * @param idTiers
	 * @param as
	 * @param dateCalcul
	 */
	protected void traiteArriereSignificatif(Long idTiers, EvenementsCalculesTiers evtsCalc, LocalDate dateCalcul,
			Map<Long, ComplementArriere> complArriereTiers) {
		ArriereSignificatif as = evtsCalc.getArriereSignigicatif();
		if (as == null) {
			return;
		}

		ComplementArriere compl = complArriereTiers.get(as.getId());

		EvenementArriereSignificatif dernierEtatEnvoye = compl.getDernierEvenementEnvoye();

		EvenementArriereSignificatif etatCourant = evenementCalculeService.categoriseArriereSignificatif(idTiers, as,
				dateCalcul);

		if (dernierEtatEnvoye == null || dernierEtatEnvoye.compareTo(etatCourant) < 0) {
			Map<EvenementArriereSignificatif, LocalDate> calendrierAS = evenementCalculeService
					.calculeCalendrierArriereSignificatif(idTiers, as, dateCalcul);
			EnumIterator<EvenementArriereSignificatif> it = new EnumIterator<>(dernierEtatEnvoye, etatCourant);
			while (it.hasNext()) {
				EvenementArriereSignificatif etatSuivant = it.next();
				LocalDate dateChangement = calendrierAS.get(etatSuivant);
				if (dernierEtatEnvoye != null) {
					auditCalculService.creeAuditCalcul(as, dernierEtatEnvoye.name(), StatutAuditEvenement.CLO,
							dateChangement, dateCalcul);
				}
				auditCalculService.creeAuditCalcul(as, etatSuivant.name(), StatutAuditEvenement.ACT, dateChangement,
						dateCalcul);
				dernierEtatEnvoye = etatSuivant;
				compl.setDernierEvenementEnvoye(dernierEtatEnvoye);

				if (dernierEtatEnvoye == EvenementArriereSignificatif.AR3) {
					defautService.entreeEnDefaut(as.getTiers(), dateChangement, new MotifStatutTiers(as), dateCalcul);
				}
			}
		}
	}

	/**
	 * Traitement des impayés sur forbearance, génération et clôture.
	 *
	 * @param evtsCalc
	 * @param dateCalcul
	 */
	protected void traiteImpayesSurForbearance(Long idTiers, EvenementsCalculesTiers evtsCalc, LocalDate dateCalcul) {
		if (evtsCalc.getArriereSignigicatif() == null && evtsCalc.getImpayesSurForbearance().isEmpty()) {
			return;
		}

		Map<String, ComplementImpaye> impayesExistant = construitMapImpayesExistant(
				evtsCalc.getImpayesSurForbearance());
		Map<String, ComplementImpaye> impayesNecessaires = construitMapImpayesNecessaires(idTiers,
				evtsCalc.getArriereSignigicatif(), dateCalcul);

		// Traitement des clôtures
		for (String cleExistantIF : impayesExistant.keySet()) {
			if (!impayesNecessaires.containsKey(cleExistantIF)) {
				PeriodeProbatoire pp = clotImpayeSurForbearance(impayesExistant.get(cleExistantIF), dateCalcul);
				if (pp != null && evtsCalc.getPeriodeProbatoire() == null) {
					evtsCalc.setPeriodeProbatoire(pp);
				}
			}
		}

		// Traitement des créations
		for (String cleNecesitantIF : impayesNecessaires.keySet()) {
			if (!impayesExistant.containsKey(cleNecesitantIF)) {
				creeImpayeSurForbearance(idTiers, impayesNecessaires.get(cleNecesitantIF), dateCalcul);
			}
		}
	}

	/**
	 * Rassemblement des impayés sur forbearance existant sous forma d'une map ayant
	 * le contrat pour clé.
	 *
	 * @param impayesSurForbearance
	 * @return
	 */
	protected Map<String, ComplementImpaye> construitMapImpayesExistant(
			List<ImpayeSurForbearance> impayesSurForbearance) {
		Map<String, ComplementImpaye> ret = new HashMap<>();
		for (ImpayeSurForbearance isf : impayesSurForbearance) {
			ComplementImpaye complImpaye = isf.getComplement();

			String cleForb;

			if (complImpaye != null) {
				cleForb = complImpaye.getEvenementForbearance().getIdContrat() + "."
						+ complImpaye.getEvenementForbearance().getIdentiteInitiale().getCodeBanque() + "."
						+ complImpaye.getEvenementForbearance().getIdentiteInitiale().getIdLocal();
				ret.put(cleForb, complImpaye);
			}
		}
		return ret;
	}

	/**
	 * Constitution des triplets (arriere, evt forbearance, evt IMX) valides pour
	 * déclencher un impayé sur forbearance.
	 *
	 * @param idTiers
	 * @param arriereSignigicatif
	 * @param dateCalcul
	 * @return
	 */
	protected Map<String, ComplementImpaye> construitMapImpayesNecessaires(Long idTiers,
			ArriereSignificatif arriereSignigicatif, LocalDate dateCalcul) {
		Map<String, ComplementImpaye> ret = new HashMap<>();
		if (arriereSignigicatif != null) {
			Map<String, ComplementImpaye> forbearances = new HashMap<>();
			EvenementsATraiter evtsATraiter = evenementRecuService.rechercheEvenementsATraiterADate(idTiers,
					dateCalcul);
			String codeSegment = identiteTiersService.donneSegmentDuTiers(idTiers, dateCalcul);
			int nbJourImpayePourIF = paramNDoDService.getNbJoursPourIFSurCtrtForbearance(codeSegment, dateCalcul);
			// Les événements de forbearance
			for (ComplementEvenement complEvtForb : evtsATraiter.getForbearancesActifs()) {
				ComplementImpaye ci = new ComplementImpaye();
				ci.setArriere(arriereSignigicatif);
				ci.setEvenementForbearance(complEvtForb.getEvenement());
				String cleForb = complEvtForb.getEvenement().getIdContrat() + "."
						+ complEvtForb.getIdentiteInitiale().getCodeBanque() + "."
						+ complEvtForb.getIdentiteInitiale().getIdLocal();
				ComplementImpaye complImpaye = forbearances.get(cleForb);
				if (complImpaye != null) {
					Evenement evtF = complImpaye.getEvenementForbearance();
					if (evtF != null && complEvtForb.getDateDebut().isAfter(evtF.getDateDebut())) {
						continue;
					}
				}
				forbearances.put(cleForb, ci);
			}

			// Complétion avec les événements d'impayé
			for (ComplementEvenement complEvtArr : evtsATraiter.getArrieresActifs()) {
				Evenement evtArr = complEvtArr.getEvenement();
				// Evénement IMX ?
				if (!CodeEvenement.IMX.name().equals(evtArr.getCode())) {
					continue;
				}
				// Sur un contrat en forbearance + sur le meme code banque et le meme id_local
				// EVOL CLE JIRA 785 le 29/06/2020
				String cleForb = evtArr.getIdContrat() + "." + complEvtArr.getIdentiteInitiale().getCodeBanque() + "."
						+ complEvtArr.getIdentiteInitiale().getIdLocal();
				ComplementImpaye ci = forbearances.get(cleForb);
				if (ci == null) {
					continue;
				}
				// 30 jours ou plus d'IMX ?
				long nbJours = DateUtil.getNbDaysBetween(evtArr.getDateDebut(), dateCalcul);
				if (nbJours < nbJourImpayePourIF) {
					continue;
				}
				ComplementImpaye complImpaye = ret.get(cleForb);
				if (complImpaye != null) {
					Evenement evtIMX = complImpaye.getEvenementImpaye();
					if (evtIMX != null && evtArr.getDateDebut().isAfter(evtIMX.getDateDebut())) {
						continue;
					}
				}
				// L'IMX a eu lieu après le début de la forbearance ?
				Evenement evtForb = ci.getEvenementForbearance();
				if (evtArr.getDateDebut().isAfter(evtForb.getDateDebut())) {
					// Toutes les conditions sont réunies
					ci.setEvenementImpaye(evtArr);
					ret.put(cleForb, ci);
				}
			}

			forbearances.clear();
		}
		return ret;
	}

	/**
	 * Création d'un impayé sur forbearance. Il débute 30 jours après l'événement
	 * d'impayé.
	 *
	 * @param complementImpaye
	 * @param enDateDe
	 */
	protected void creeImpayeSurForbearance(Long idTiers, ComplementImpaye complementImpaye, LocalDate dateCalcul) {
		Tiers tiers = rechercheTiersService.getTiers(idTiers);
		LocalDate enDateDe = complementImpaye.getEvenementImpaye().getDateDebut().plusDays(30);
		if (enDateDe.isBefore(complementImpaye.getArriere().getDateDebut())) {
			enDateDe = complementImpaye.getArriere().getDateDebut();
		}
		ImpayeSurForbearance iF = evenementCalculeService.creeImpayeSurForbearance(tiers, enDateDe,
				complementImpaye.getArriere(), complementImpaye.getEvenementForbearance(),
				complementImpaye.getEvenementImpaye());
		auditCalculService.creeAuditCalcul(iF, CodeEvenement.IF.name(), StatutAuditEvenement.ACT, iF.getDateDebut(),
				dateCalcul);

		// Mise en defaut
		defautService.entreeEnDefaut(tiers, enDateDe, new MotifStatutTiers(iF), dateCalcul);
	}

	/**
	 * Clôture d'un impayé sur forbearance.
	 *
	 * @param complementImpaye
	 * @param dateCalcul
	 */
	protected PeriodeProbatoire clotImpayeSurForbearance(ComplementImpaye complementImpaye, LocalDate dateCalcul) {
		// Détermination de la date de fin de cet événement IF
		LocalDate dateFinIF = null;
		ArriereSignificatif as = complementImpaye.getArriere();
		if (as.getDateFin() != null && !as.getDateFin().isAfter(dateCalcul)) {
			// Candidat possible
			dateFinIF = as.getDateFin();
		}
		// Recherche d'autres candidats possibles
		dateFinIF = rechercheDateFinIF(complementImpaye, dateCalcul, dateFinIF);

		boolean annulation = false;
		ComplementEvenement impayeF = complementImpaye.getEvenementImpaye().getComplements().stream()
				.filter(s -> s.getDateFin() == null).collect(Collectors.toList()).get(0);
		ComplementEvenement forbearance = complementImpaye.getEvenementForbearance().getComplements().stream()
				.filter(s -> s.getDateFin() == null).collect(Collectors.toList()).get(0);
		annulation = StatutEvenement.ANN.equals(impayeF.getStatutEvt()) || impayeF.isArriereLitige()
				|| impayeF.isArriereTech() || StatutEvenement.ANN.equals(forbearance.getStatutEvt());

		if (annulation || dateFinIF.isBefore(complementImpaye.getImpaye().getDateDebut())) {
			dateFinIF = dateCalcul;
		}

		// Mise à jour de l'IF
		complementImpaye.getImpaye().setDateFin(dateFinIF);
		// création de l'audit
		auditCalculService.creeAuditCalcul(complementImpaye.getImpaye(), CodeEvenement.IF.name(),
				StatutAuditEvenement.CLO, dateFinIF, dateCalcul);

		// Mise à jour des statuts de défaut
		return defautService.sortieDUnEvenementDeDefaut(complementImpaye.getIdTiers(), dateFinIF,
				new MotifStatutTiers(complementImpaye.getImpaye()), annulation, dateCalcul);
	}

	private LocalDate rechercheDateFinIF(ComplementImpaye complementImpaye, LocalDate dateCalcul, LocalDate dateFinIF) {

		LocalDate dateFinIFCand = dateFinIF;
		EvenementsATraiter evtsATraiter = evenementRecuService
				.rechercheEvenementsATraiterADate(complementImpaye.getIdTiers(), dateCalcul);

		for (ComplementEvenement complForb : evtsATraiter.getForbearances()) {
			if (complForb.getEvenement().equals(complementImpaye.getEvenementForbearance())) {
				if (!StatutEvenement.ACT.equals(complForb.getStatutEvt()) && isDateFinAfter(dateFinIFCand, complForb)) {
					// Candidat possible
					dateFinIFCand = complForb.getDateDebut();
				}
				break;
			}
		}

		for (ComplementEvenement complArr : evtsATraiter.getArrieres()) {
			if (complArr.getEvenement().equals(complementImpaye.getEvenementImpaye())) {
				if (isNotActif(complArr) && isDateFinAfter(dateFinIFCand, complArr)) {
					// Candidat possible
					dateFinIFCand = complArr.getDateDebut();

				}
				break;
			}
		}
		// Pour ne pas sortir avec une date fin IF null
		if (dateFinIFCand == null) {
			dateFinIFCand = dateCalcul;
		}
		return dateFinIFCand;
	}

	private boolean isNotActif(ComplementEvenement compl) {
		return StatutEvenement.ACT != compl.getStatutEvt() || Boolean.TRUE.equals(compl.isArriereLitige())
				|| Boolean.TRUE.equals(compl.isArriereTech());
	}

	private boolean isDateFinAfter(LocalDate dateFin, ComplementEvenement compl) {
		return dateFin == null || dateFin.isAfter(compl.getDateDebut());
	}

	/**
	 * Traitement de la sortie de période probatoire.
	 *
	 * @param idTiers
	 * @param evenementsCalcules
	 * @param dateCalcul
	 */
	protected void traiteSortiePeriodeProbatoire(Long idTiers, EvenementsCalculesTiers evts, LocalDate dateCalcul) {
		PeriodeProbatoire pp = evts.getPeriodeProbatoire();
		ArriereSignificatif as = evts.getArriereSignigicatif();

		long depassement = 0;
		if (pp != null && pp.getDateFin() == null) {
			if (LOG.isDebugEnabled()) {
				LOG.debug("Traitment Periode Probatoire [idPP={}]", pp.getId());
			}
			AuditCalcul auditPeriodeProbatoire = auditCalculService.recupererAuditPeriodeProbatoire(pp.getId(), idTiers,
					dateCalcul);
			if (as != null && as.getDateFin() == null) {
				if (LOG.isDebugEnabled()) {
					LOG.debug("Arriere significatif actif trouve [idAS={}]", as.getId());
				}
				if (StatutAuditEvenement.ACT.equals(auditPeriodeProbatoire.getStatut())) {
					if (LOG.isDebugEnabled()) {
						LOG.debug("Suspension de la periode probatoire [idAudit={}]", auditPeriodeProbatoire.getId());
					}
					LocalDate dateSuspension = as.getDateDebut();
					// Si la date de debut de l'AS est inférieure à la date de debut de la PP, alors
					// la date de suspension de PP est égale à sa date de création
					if (dateSuspension.isBefore(pp.getDateDebut())) {
						dateSuspension = pp.getDateDebut();
					}
					auditCalculService.creeAuditCalcul(pp, CodeEvenement.PP.name(), StatutAuditEvenement.SUS,
							dateSuspension, dateCalcul);
				}
			} else {
				List<ArriereSignificatif> listAS = evenementCalculeService
						.rechercheArriereSignificatifEntreDeuxDate(idTiers, pp.getDateDebut(), dateCalcul);

				if (!StatutAuditEvenement.ACT.equals(auditPeriodeProbatoire.getStatut())) {
					if (LOG.isDebugEnabled()) {
						LOG.debug("Reprise de la Periode Probatoire [idAudit={}]", auditPeriodeProbatoire.getId());
					}
					if (listAS != null && !listAS.isEmpty()) {
						ArriereSignificatif dernierAsCloADate = listAS.get(listAS.size() - 1);
						auditCalculService.creeAuditCalcul(pp, CodeEvenement.PP.name(), StatutAuditEvenement.ACT,
								dernierAsCloADate.getDateFin(), dateCalcul);
					} else {
						auditCalculService.creeAuditCalcul(pp, CodeEvenement.PP.name(), StatutAuditEvenement.ACT,
								dateCalcul, dateCalcul);
					}
				}
				String codeSegment = identiteTiersService.donneSegmentDuTiers(idTiers, dateCalcul);

				long compteurPeriodeProbatoire = calculerCompteurPP(listAS, codeSegment, pp.getDateDebut(), dateCalcul);

				if (LOG.isDebugEnabled()) {
					LOG.debug("Compteur de la Periode Probatoire [idAudit={}, compteurPP={}]",
							auditPeriodeProbatoire.getId(), compteurPeriodeProbatoire);
				}

				EvenementsATraiter evtsATraiter = evenementRecuService.rechercheEvenementsATraiterADate(idTiers,
						dateCalcul);
				boolean hasEvenementForbearance = !evtsATraiter.getForbearancesActifs().isEmpty();

				if (hasEvenementForbearance) {
					depassement = compteurPeriodeProbatoire
							- paramNDoDService.getNbJoursPPForbearance(codeSegment, dateCalcul);
				} else {
					depassement = compteurPeriodeProbatoire
							- paramNDoDService.getNbJoursPPStandard(codeSegment, dateCalcul);
				}

				if (depassement >= 0) {
					LocalDate dateCloturePP = dateCalcul.minusDays(depassement);
					if (!hasEvenementForbearance) {
						// existe-t-il un evenement forbearence cloturé depuis le delai des 90 jours
						List<ComplementEvenement> evenementsForbearenceCloture = evenementRecuService
								.rechercheForbearenceClotureEntreDeuxDate(idTiers, dateCloturePP, dateCalcul);
						if (evenementsForbearenceCloture != null && !evenementsForbearenceCloture.isEmpty()) {
							dateCloturePP = evenementsForbearenceCloture.get(0).getDateFin();
						}
					}

					if (LOG.isDebugEnabled()) {
						LOG.debug("Delai de la Periode Probatoire atteint, cloture [idAudit={}, idPP={}]",
								auditPeriodeProbatoire.getId(), pp.getId());
					}
					evenementCalculeService.closPeriodeProbatoire(pp, dateCloturePP, dateCalcul);
					// Retour à SAIN
					defautService.sortieDeDefaut(pp.getTiers(), dateCloturePP, null);
				}
			}
		}
	}

	private long calculerCompteurPP(List<ArriereSignificatif> listAS, String codeSegment, LocalDate dateDebutPP,
			LocalDate dateCalcul) {

		long delaiRemiseAZeroCompteurPP = paramNDoDService.getNbJoursASRazDecomptePP(codeSegment, dateCalcul);

		long compteurPP = DateUtil.getNbDaysBetween(dateDebutPP, dateCalcul) + 1;

		for (ArriereSignificatif as : listAS) {
			LocalDate dateFin = as.getDateFin();
			LocalDate dateDeb = as.getDateDebut();
			if (dateFin == null || dateFin.isAfter(dateCalcul)) {
				dateFin = dateCalcul;
			}

			if (dateDeb.isBefore(dateDebutPP)) {
				dateDeb = dateDebutPP;
			}

			long duree = DateUtil.getNbDaysBetween(dateDeb, dateFin) + 1;

			if (duree <= delaiRemiseAZeroCompteurPP) {
				compteurPP -= duree;
			} else {
				compteurPP = DateUtil.getNbDaysBetween(dateFin, dateCalcul) + 1;
			}
		}
		return compteurPP;
	}

	private void updateDateCalculCourante(LocalDate dateCalcul) {
		LocalDate dateCalculBase = paramNDoDService.getDateCalculCourante();
		if (dateCalculBase != null) {
			paramNDoDService.updateDateCalculCourante(dateCalcul);
		}
	}

	/*
	 * Setters
	 */
	public void setEvenementCalculeService(EvenementCalculeService evenementCalculeService) {
		this.evenementCalculeService = evenementCalculeService;
	}

	public void setRechercheTiersService(RechercheTiersService rechercheTiersService) {
		this.rechercheTiersService = rechercheTiersService;
	}

	public void setEvenementRecuService(EvenementRecuService evenementRecuService) {
		this.evenementRecuService = evenementRecuService;
	}

	public void setDefautService(DefautService defautService) {
		this.defautService = defautService;
	}

	public void setAuditCalculService(AuditCalculService auditCalculService) {
		this.auditCalculService = auditCalculService;
	}

	public void setParamNDoD(ParametresNDoDImpl paramNDoD) {
		this.paramNDoDService = paramNDoD;
	}

	public void setIdentiteTiersService(IdentiteTiersService identiteTiersService) {
		this.identiteTiersService = identiteTiersService;
	}

}

package fr.bpce.yyd.service.calcul.compteur.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import fr.bpce.yyd.commun.messages.dto.LotIdTiersDTO;
import fr.bpce.yyd.service.calcul.compteur.service.CalculCompteurService;
import fr.bpce.yyd.service.calcul.compteur.service.TiersKafkaConsumer;

@Service
@ConditionalOnProperty(value = "kafka.actif", havingValue = "true", matchIfMissing = false)
public class TiersKafkaConsumerImpl implements TiersKafkaConsumer {

	private static final Logger LOG = LoggerFactory.getLogger(TiersKafkaConsumerImpl.class);

	@Autowired
	private CalculCompteurService calculCompteurService;

	@KafkaListener(topics = "${kafka.consumerListTiers.topic}", groupId = "${kafka.consumerListTiers.groupId}", containerFactory = "listTiersKafkaListenerFactory")
	@Override
	public void receive(@Payload LotIdTiersDTO data) {
		if (LOG.isDebugEnabled()) {
			LOG.debug("received data='{}'", data);
		}
		calculCompteurService.traiteMessage(data);

	}
}

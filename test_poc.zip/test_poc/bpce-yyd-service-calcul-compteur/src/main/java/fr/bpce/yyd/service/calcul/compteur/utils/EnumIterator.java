package fr.bpce.yyd.service.calcul.compteur.utils;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class EnumIterator<E extends Enum<E>> implements Iterator<E> {

	private E current;
	private final E lastVal;

	public EnumIterator(E start) {
		this(start, null);
	}

	@SuppressWarnings("unchecked")
	public EnumIterator(E first, E last) {
		if (first == null && last == null) {
			throw new IllegalArgumentException("les deux arguments first et last ne peuvent pas être nuls");
		}
		Class<E> enumClass = null;
		if (first != null) {
			enumClass = (Class<E>) first.getClass();
		}
		if (enumClass == null && last != null) {
			enumClass = (Class<E>) last.getClass();
		}
		lastVal = (last == null && enumClass != null)
				? enumClass.getEnumConstants()[enumClass.getEnumConstants().length - 1]
				: last;
		current = first == null ? enumClass.getEnumConstants()[0] : findNext(first);
		if (current != null) {
			assert current.compareTo(lastVal) <= 0;
		}
	}

	@Override
	public boolean hasNext() {
		return (current != null);
	}

	@Override
	public E next() {
		if (current == null) {
			throw new NoSuchElementException();
		}
		E next = current;
		current = findNext(next);
		return next;
	}

	@SuppressWarnings("unchecked")
	private E findNext(E currVal) {
		E nextVal = null;
		if (currVal != lastVal) {
			boolean currentFound = false;
			for (Enum<E> enVal : lastVal.getClass().getEnumConstants()) {
				if (!currentFound) {
					currentFound = enVal == currVal;
				} else {
					nextVal = (E) enVal;
					break;
				}
			}
		}
		return nextVal;
	}
}

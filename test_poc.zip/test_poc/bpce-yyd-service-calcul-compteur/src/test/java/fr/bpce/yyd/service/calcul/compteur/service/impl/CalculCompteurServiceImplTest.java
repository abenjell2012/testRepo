package fr.bpce.yyd.service.calcul.compteur.service.impl;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import fr.bpce.yyd.commun.constantes.Constant;
import fr.bpce.yyd.commun.enums.CodeParamMdc;
import fr.bpce.yyd.commun.enums.EvenementArriereSignificatif;
import fr.bpce.yyd.commun.enums.StatutAuditEvenement;
import fr.bpce.yyd.commun.enums.StatutTiers;
import fr.bpce.yyd.commun.messages.dto.LotIdTiersDTO;
import fr.bpce.yyd.commun.model.ArriereSignificatif;
import fr.bpce.yyd.commun.model.AuditCalcul;
import fr.bpce.yyd.commun.model.ComplementArriere;
import fr.bpce.yyd.commun.model.ElementsDeCalcul;
import fr.bpce.yyd.commun.model.EvenementCalcule;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.ParMdcSeg;
import fr.bpce.yyd.commun.model.StatutHistorise;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.commun.repository.RefCliSsClassRepository;
import fr.bpce.yyd.commun.service.impl.RefCliSegServiceImpl;
import fr.bpce.yyd.service.commun.beans.EvenementsCalculesTiers;
import fr.bpce.yyd.service.commun.repository.AuditCalculRepository;
import fr.bpce.yyd.service.commun.repository.EvenementCalculeRepository;
import fr.bpce.yyd.service.commun.repository.EvenementImpactRepository;
import fr.bpce.yyd.service.commun.repository.EvenementRecuRepository;
import fr.bpce.yyd.service.commun.repository.IdentiteTiersRepository;
import fr.bpce.yyd.service.commun.repository.ParMdcBqSegRepository;
import fr.bpce.yyd.service.commun.repository.ParMdcSegRepository;
import fr.bpce.yyd.service.commun.repository.StatutTiersRepository;
import fr.bpce.yyd.service.commun.repository.TiersRepository;
import fr.bpce.yyd.service.commun.service.impl.AuditCalculServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.DefautServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.EvenementCalculeServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.EvenementImpactServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.EvenementRecuServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.IdentiteTiersServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.ParamMdcServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.ParametresNDoDImpl;
import fr.bpce.yyd.service.commun.service.impl.RechercheTiersServiceImpl;

@RunWith(SpringRunner.class)
@DataJpaTest
@ActiveProfiles(profiles = "ti")
public class CalculCompteurServiceImplTest {

	@Autowired
	TestEntityManager entityManager;

	@Autowired
	TiersRepository tiersRepository;

	@Autowired
	IdentiteTiersRepository identiteTiersRepository;

	@Autowired
	EvenementCalculeRepository evtCalcRepository;

	@Autowired
	AuditCalculRepository auditCalculRepository;

	@Autowired
	ParMdcSegRepository parMdcSegRepository;

	@Autowired
	ParMdcBqSegRepository parMdcBqSegRepository;

	@Autowired
	EvenementRecuRepository evtRecuRepository;

	@Autowired
	StatutTiersRepository statutTiersRepository;

	@Autowired
	private EvenementImpactRepository evenementImpactRepository;

	@Autowired
	private RefCliSsClassRepository cliSsClassRepository;

	CalculCompteurServiceImpl ccService;

	@Before
	public void assembleService() {
		ccService = new CalculCompteurServiceImpl();

		ParamMdcServiceImpl paramService = new ParamMdcServiceImpl();
		paramService.setParMdcBqSegRepository(parMdcBqSegRepository);
		paramService.setParMdcSegRepository(parMdcSegRepository);
		ParametresNDoDImpl parametresNDoD = new ParametresNDoDImpl();
		parametresNDoD.setParamService(paramService);
		ccService.setParamNDoD(parametresNDoD);
		RechercheTiersServiceImpl rtService = new RechercheTiersServiceImpl();
		rtService.setTiersRepository(tiersRepository);
		ccService.setRechercheTiersService(rtService);

		AuditCalculServiceImpl acService = new AuditCalculServiceImpl();
		acService.setAuditCalculRepository(auditCalculRepository);
		ccService.setAuditCalculService(acService);

		IdentiteTiersServiceImpl itService = new IdentiteTiersServiceImpl();
		itService.setIdentTiersRepository(identiteTiersRepository);

		EvenementCalculeServiceImpl ecService = new EvenementCalculeServiceImpl();
		ecService.setEvtCalculeRepository(evtCalcRepository);
		ecService.setIdentiteTiersService(itService);
		ecService.setAuditCalculService(acService);
		ecService.setParamsNDoD(parametresNDoD);
		ccService.setEvenementCalculeService(ecService);

		EvenementRecuServiceImpl erService = new EvenementRecuServiceImpl();
		erService.setEvtRecuRepository(evtRecuRepository);
		ccService.setEvenementRecuService(erService);

		EvenementImpactServiceImpl impactService = new EvenementImpactServiceImpl();
		impactService.setEvenementImpactRepository(evenementImpactRepository);

		RefCliSegServiceImpl cliSegService = new RefCliSegServiceImpl();
		cliSegService.setCliSsClassRepository(cliSsClassRepository);

		DefautServiceImpl defautService = new DefautServiceImpl();
		defautService.setEvtCalculeService(ecService);
		defautService.setRechercheTiersService(rtService);
		defautService.setStatutTiersRepository(statutTiersRepository);
		defautService.setImpactService(impactService);
		defautService.setIdentiteTiersService(itService);
		defautService.setRefCliSegService(cliSegService);
		ccService.setDefautService(defautService);
		ccService.setIdentiteTiersService(itService);
	}

	@Test
	public void initialisationAR0() {
		// Arrange
		Tiers tiers = new Tiers();
		IdentiteTiers ident = new IdentiteTiers();
		ident.setCodeSegment("3200");
		ident.setDateDebut(LocalDate.now());
		tiers.addIdentite(ident);
		entityManager.persist(tiers);

		ElementsDeCalcul edc = new ElementsDeCalcul();
		edc.setTiers(tiers);
		entityManager.persist(edc);

		ArriereSignificatif as = new ArriereSignificatif();
		as.setTiers(tiers);
		as.setDateDebut(LocalDate.now());
		ComplementArriere complAS = new ComplementArriere();
		complAS.setEntree(edc);
		as.setComplement(complAS);
		entityManager.persistAndFlush(as);

		List<EvenementCalcule> listEvtCalc = new ArrayList<>();
		listEvtCalc.add(as);
		EvenementsCalculesTiers evtsCalc = new EvenementsCalculesTiers(listEvtCalc);
		Map<Long, ComplementArriere> complArriereTiers = new HashMap<>();
		complArriereTiers.put(as.getId(), complAS);

		// Act
		ccService.traiteArriereSignificatif(tiers.getId(), evtsCalc, LocalDate.now(), complArriereTiers);

		// On assure de repasser par la persistence qui doit être à jour.
		entityManager.flush();
		entityManager.detach(as);

		// Assert
		Optional<EvenementCalcule> optAS = evtCalcRepository.findById(as.getId());
		ArriereSignificatif asRelu = (ArriereSignificatif) optAS.get();
		ComplementArriere complRelu = asRelu.getComplement();
		Assert.assertEquals(EvenementArriereSignificatif.AR0, complRelu.getDernierEvenementEnvoye());
		Set<AuditCalcul> audits = asRelu.getAuditCalcul();
		Assert.assertEquals(1, audits.size());
		AuditCalcul audit = audits.iterator().next();
		Assert.assertEquals(EvenementArriereSignificatif.AR0.name(), audit.getCode());
		Assert.assertEquals(StatutAuditEvenement.ACT, audit.getStatut());
	}

	@Test
	public void passageALAR1() {
		// Arrange
		Tiers tiers = new Tiers();
		IdentiteTiers ident = new IdentiteTiers();
		ident.setCodeSegment("3200");
		ident.setDateDebut(LocalDate.now().minusDays(30));
		tiers.addIdentite(ident);
		entityManager.persist(tiers);

		ElementsDeCalcul edc = new ElementsDeCalcul();
		edc.setTiers(tiers);
		entityManager.persist(edc);

		ArriereSignificatif as = new ArriereSignificatif();
		as.setTiers(tiers);
		as.setDateDebut(LocalDate.now().minusDays(30));
		ComplementArriere complAS = new ComplementArriere();
		complAS.setEntree(edc);
		complAS.setDernierEvenementEnvoye(EvenementArriereSignificatif.AR0);
		as.setComplement(complAS);
		entityManager.persistAndFlush(as);

		List<EvenementCalcule> listEvtCalc = new ArrayList<>();
		listEvtCalc.add(as);
		EvenementsCalculesTiers evtsCalc = new EvenementsCalculesTiers(listEvtCalc);
		Map<Long, ComplementArriere> complArriereTiers = new HashMap<>();
		complArriereTiers.put(as.getId(), complAS);

		// Act avant
		ccService.traiteArriereSignificatif(tiers.getId(), evtsCalc, LocalDate.now().minusDays(1), complArriereTiers);

		// On assure de repasser par la persistence qui doit être à jour.
		entityManager.flush();
		entityManager.detach(as);

		// Assert avant
		Optional<EvenementCalcule> optAS1 = evtCalcRepository.findById(as.getId());
		ArriereSignificatif asRelu1 = (ArriereSignificatif) optAS1.get();
		ComplementArriere complRelu1 = asRelu1.getComplement();
		Assert.assertEquals(EvenementArriereSignificatif.AR0, complRelu1.getDernierEvenementEnvoye());

		// On avait dit que l'AR0 avait été envoyé => pas de nouvelle ligne créée
		Set<AuditCalcul> audits1 = asRelu1.getAuditCalcul();
		Assert.assertEquals(0, audits1.size());

		List<EvenementCalcule> listEvtCalcRelu1 = new ArrayList<>();
		listEvtCalcRelu1.add(asRelu1);
		EvenementsCalculesTiers evtsCalcRelu1 = new EvenementsCalculesTiers(listEvtCalcRelu1);

		Map<Long, ComplementArriere> complArriereTiers1 = new HashMap<>();
		complArriereTiers1.put(asRelu1.getId(), complRelu1);

		// Act après
		ccService.traiteArriereSignificatif(tiers.getId(), evtsCalcRelu1, LocalDate.now(), complArriereTiers1);

		// On assure de repasser par la persistence qui doit être à jour.
		entityManager.flush();
		entityManager.detach(asRelu1);

		// Assert après
		Optional<EvenementCalcule> optAS2 = evtCalcRepository.findById(as.getId());
		ArriereSignificatif asRelu2 = (ArriereSignificatif) optAS2.get();
		ComplementArriere complRelu2 = asRelu2.getComplement();
		Assert.assertEquals(EvenementArriereSignificatif.AR1, complRelu2.getDernierEvenementEnvoye());

		Set<AuditCalcul> audits2 = asRelu2.getAuditCalcul();
		Assert.assertEquals(2, audits2.size());
		List<AuditCalcul> audits2Tries = new ArrayList<>(audits2);
		Collections.sort(audits2Tries, new Comparator<AuditCalcul>() {
			@Override
			public int compare(AuditCalcul ac1, AuditCalcul ac2) {
				return ac1.getId().compareTo(ac2.getId());
			}
		});
		Assert.assertEquals(EvenementArriereSignificatif.AR0.name(), audits2Tries.get(0).getCode());
		Assert.assertEquals(StatutAuditEvenement.CLO, audits2Tries.get(0).getStatut());
		Assert.assertEquals(EvenementArriereSignificatif.AR1.name(), audits2Tries.get(1).getCode());
		Assert.assertEquals(StatutAuditEvenement.ACT, audits2Tries.get(1).getStatut());
	}

	@Test
	public void passageALAR2() {
		// Arrange
		Tiers tiers = new Tiers();
		IdentiteTiers ident = new IdentiteTiers();
		ident.setCodeSegment("3200");
		ident.setDateDebut(LocalDate.now().minusDays(60));
		tiers.addIdentite(ident);
		entityManager.persist(tiers);

		ElementsDeCalcul edc = new ElementsDeCalcul();
		edc.setTiers(tiers);
		entityManager.persist(edc);

		ArriereSignificatif as = new ArriereSignificatif();
		as.setTiers(tiers);
		as.setDateDebut(LocalDate.now().minusDays(60));
		ComplementArriere complAS = new ComplementArriere();
		complAS.setEntree(edc);
		complAS.setDernierEvenementEnvoye(EvenementArriereSignificatif.AR1);
		as.setComplement(complAS);
		entityManager.persistAndFlush(as);

		List<EvenementCalcule> listEvtCalc = new ArrayList<>();
		listEvtCalc.add(as);
		EvenementsCalculesTiers evtsCalc = new EvenementsCalculesTiers(listEvtCalc);

		Map<Long, ComplementArriere> complArriereTiers = new HashMap<>();
		complArriereTiers.put(as.getId(), complAS);

		// Act avant
		ccService.traiteArriereSignificatif(tiers.getId(), evtsCalc, LocalDate.now().minusDays(1), complArriereTiers);

		// On assure de repasser par la persistence qui doit être à jour.
		entityManager.flush();
		entityManager.detach(as);

		// Assert avant
		Optional<EvenementCalcule> optAS1 = evtCalcRepository.findById(as.getId());
		ArriereSignificatif asRelu1 = (ArriereSignificatif) optAS1.get();
		ComplementArriere complRelu1 = asRelu1.getComplement();
		Assert.assertEquals(EvenementArriereSignificatif.AR1, complRelu1.getDernierEvenementEnvoye());

		// On avait dit que l'AR1 avait été envoyé => pas de nouvelle ligne créée
		Set<AuditCalcul> audits1 = asRelu1.getAuditCalcul();
		Assert.assertEquals(0, audits1.size());

		List<EvenementCalcule> listEvtCalcRelu1 = new ArrayList<>();
		listEvtCalcRelu1.add(asRelu1);
		EvenementsCalculesTiers evtsCalcRelu1 = new EvenementsCalculesTiers(listEvtCalcRelu1);

		Map<Long, ComplementArriere> complArriereTiers1 = new HashMap<>();
		complArriereTiers1.put(asRelu1.getId(), complRelu1);

		// Act après
		ccService.traiteArriereSignificatif(tiers.getId(), evtsCalcRelu1, LocalDate.now(), complArriereTiers1);

		// On assure de repasser par la persistence qui doit être à jour.
		entityManager.flush();
		entityManager.detach(asRelu1);

		// Assert après
		Optional<EvenementCalcule> optAS2 = evtCalcRepository.findById(as.getId());
		ArriereSignificatif asRelu2 = (ArriereSignificatif) optAS2.get();
		ComplementArriere complRelu2 = asRelu2.getComplement();
		Assert.assertEquals(EvenementArriereSignificatif.AR2, complRelu2.getDernierEvenementEnvoye());

		Set<AuditCalcul> audits2 = asRelu2.getAuditCalcul();
		Assert.assertEquals(2, audits2.size());
		List<AuditCalcul> audits2Tries = new ArrayList<>(audits2);
		Collections.sort(audits2Tries, new Comparator<AuditCalcul>() {
			@Override
			public int compare(AuditCalcul ac1, AuditCalcul ac2) {
				return ac1.getId().compareTo(ac2.getId());
			}
		});
		Assert.assertEquals(EvenementArriereSignificatif.AR1.name(), audits2Tries.get(0).getCode());
		Assert.assertEquals(StatutAuditEvenement.CLO, audits2Tries.get(0).getStatut());
		Assert.assertEquals(EvenementArriereSignificatif.AR2.name(), audits2Tries.get(1).getCode());
		Assert.assertEquals(StatutAuditEvenement.ACT, audits2Tries.get(1).getStatut());
	}

	@Test
	public void passageDeLAR1ALAR3() {
		// Arrange
		Tiers tiers = new Tiers();
		IdentiteTiers ident = new IdentiteTiers();
		ident.setCodeSegment("3200");
		ident.setDateDebut(LocalDate.now().minusDays(91));
		tiers.addIdentite(ident);
		entityManager.persist(tiers);

		ElementsDeCalcul edc = new ElementsDeCalcul();
		edc.setTiers(tiers);
		entityManager.persist(edc);

		ArriereSignificatif as = new ArriereSignificatif();
		as.setTiers(tiers);
		as.setDateDebut(LocalDate.now().minusDays(91));
		ComplementArriere complAS = new ComplementArriere();
		complAS.setEntree(edc);
		complAS.setDernierEvenementEnvoye(EvenementArriereSignificatif.AR1);
		as.setComplement(complAS);
		entityManager.persistAndFlush(as);

		// Act
		LotIdTiersDTO lot = new LotIdTiersDTO(LocalDate.now());
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// On assure de repasser par la persistence qui doit être à jour.
		entityManager.flush();
		entityManager.detach(as);

		// Assert
		Optional<EvenementCalcule> optAS2 = evtCalcRepository.findById(as.getId());
		ArriereSignificatif asRelu2 = (ArriereSignificatif) optAS2.get();
		ComplementArriere complRelu2 = asRelu2.getComplement();
		Assert.assertEquals(EvenementArriereSignificatif.AR3, complRelu2.getDernierEvenementEnvoye());

		Set<AuditCalcul> audits2 = asRelu2.getAuditCalcul();
		Assert.assertEquals(4, audits2.size());
		List<AuditCalcul> audits2Tries = new ArrayList<>(audits2);
		Collections.sort(audits2Tries, new Comparator<AuditCalcul>() {
			@Override
			public int compare(AuditCalcul ac1, AuditCalcul ac2) {
				return ac1.getId().compareTo(ac2.getId());
			}
		});
		Assert.assertEquals(EvenementArriereSignificatif.AR1.name(), audits2Tries.get(0).getCode());
		Assert.assertEquals(StatutAuditEvenement.CLO, audits2Tries.get(0).getStatut());
		Assert.assertEquals(EvenementArriereSignificatif.AR2.name(), audits2Tries.get(1).getCode());
		Assert.assertEquals(StatutAuditEvenement.ACT, audits2Tries.get(1).getStatut());
		Assert.assertEquals(EvenementArriereSignificatif.AR2.name(), audits2Tries.get(2).getCode());
		Assert.assertEquals(StatutAuditEvenement.CLO, audits2Tries.get(2).getStatut());
		Assert.assertEquals(EvenementArriereSignificatif.AR3.name(), audits2Tries.get(3).getCode());
		Assert.assertEquals(StatutAuditEvenement.ACT, audits2Tries.get(3).getStatut());

		List<StatutHistorise> statutsCourants = statutTiersRepository.getStatutADate(tiers.getId(), LocalDate.now());
		Assert.assertTrue(statutsCourants.size() == 1);
		StatutHistorise statutCourant = statutsCourants.get(0);
		Assert.assertEquals(StatutTiers.DEFAUT, statutCourant.getStatut());
		Assert.assertEquals(Constant.EVENEMENT_AR3, statutCourant.getMotif().getMotif());
		Assert.assertEquals(asRelu2, statutCourant.getMotif().getAR3());
	}

	@Test
	public void changementDateCalculCourante() {
		// Arrange
		Tiers tiers = new Tiers();
		IdentiteTiers ident = new IdentiteTiers();
		ident.setCodeSegment("3200");
		ident.setDateDebut(LocalDate.now().minusDays(91));
		tiers.addIdentite(ident);
		entityManager.persist(tiers);

		ParMdcSeg parMdcSeg = new ParMdcSeg();
		parMdcSeg.setCodeParam(CodeParamMdc.DATE_CALCUL_COURANTE);
		parMdcSeg.setCodeSegment(Constant.ANY);
		parMdcSeg.setDateDebut(LocalDate.of(2019, 01, 01));
		parMdcSeg.setValeurParam("20190101");
		entityManager.persist(parMdcSeg);

		ElementsDeCalcul edc = new ElementsDeCalcul();
		edc.setTiers(tiers);
		entityManager.persist(edc);

		ArriereSignificatif as = new ArriereSignificatif();
		as.setTiers(tiers);
		as.setDateDebut(LocalDate.now().minusDays(91));
		ComplementArriere complAS = new ComplementArriere();
		complAS.setEntree(edc);
		complAS.setDernierEvenementEnvoye(EvenementArriereSignificatif.AR1);
		as.setComplement(complAS);
		entityManager.persistAndFlush(as);

		// Act
		LotIdTiersDTO lot = new LotIdTiersDTO(LocalDate.now());
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// On assure de repasser par la persistence qui doit être à jour.
		entityManager.flush();
		entityManager.detach(parMdcSeg);

		// Assert
		ParMdcSeg param = parMdcSegRepository.rechercherParamMdcADate(CodeParamMdc.DATE_CALCUL_COURANTE);
		Assert.assertEquals(LocalDate.now(), LocalDate.parse(param.getValeurParam(), DateTimeFormatter.BASIC_ISO_DATE));
	}
}

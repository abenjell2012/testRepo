package fr.bpce.yyd.service.calcul.compteur.utils;

import java.util.NoSuchElementException;

import org.junit.Assert;
import org.junit.Test;

import fr.bpce.yyd.commun.enums.EvenementArriereSignificatif;

public class EnumIteratorTest {

	@Test
	public void premiereValeurDebutPasDeFin() {
		// Arrange
		EnumIterator<EvenementArriereSignificatif> it = new EnumIterator<EvenementArriereSignificatif>(
				EvenementArriereSignificatif.AR0);

		// Assert
		Assert.assertTrue(it.hasNext());
		Assert.assertEquals(EvenementArriereSignificatif.AR1, it.next());
		Assert.assertTrue(it.hasNext());
		Assert.assertEquals(EvenementArriereSignificatif.AR2, it.next());
		Assert.assertTrue(it.hasNext());
		Assert.assertEquals(EvenementArriereSignificatif.AR3, it.next());
		Assert.assertFalse(it.hasNext());
		try {
			it.next();
			throw new RuntimeException("L'appel précédent aurait dû lancer une exception...");
		} catch (NoSuchElementException nsee) {
			// Comportement attendu
		}
	}

	@Test
	public void valeurDebutCentralePasDeFin() {
		// Arrange
		EnumIterator<EvenementArriereSignificatif> it = new EnumIterator<EvenementArriereSignificatif>(
				EvenementArriereSignificatif.AR2);

		// Assert
		Assert.assertTrue(it.hasNext());
		Assert.assertEquals(EvenementArriereSignificatif.AR3, it.next());
		Assert.assertFalse(it.hasNext());
		try {
			it.next();
			throw new RuntimeException("L'appel précédent aurait dû lancer une exception...");
		} catch (NoSuchElementException nsee) {
			// Comportement attendu
		}
	}

	@Test
	public void derniereValeurDebutPasDeFin() {
		// Arrange
		EnumIterator<EvenementArriereSignificatif> it = new EnumIterator<EvenementArriereSignificatif>(
				EvenementArriereSignificatif.AR3);

		// Assert
		Assert.assertFalse(it.hasNext());
		try {
			it.next();
			throw new RuntimeException("L'appel précédent aurait dû lancer une exception...");
		} catch (NoSuchElementException nsee) {
			// Comportement attendu
		}
	}

	@Test
	public void valeursDebutMilieuEtFinDerniere() {
		// Arrange
		EnumIterator<EvenementArriereSignificatif> it = new EnumIterator<EvenementArriereSignificatif>(
				EvenementArriereSignificatif.AR1, EvenementArriereSignificatif.AR3);

		// Assert
		Assert.assertTrue(it.hasNext());
		Assert.assertEquals(EvenementArriereSignificatif.AR2, it.next());
		Assert.assertTrue(it.hasNext());
		Assert.assertEquals(EvenementArriereSignificatif.AR3, it.next());
		Assert.assertFalse(it.hasNext());
		try {
			it.next();
			throw new RuntimeException("L'appel précédent aurait dû lancer une exception...");
		} catch (NoSuchElementException nsee) {
			// Comportement attendu
		}
	}

	@Test
	public void valeursDebutMilieuEtFinMilieu() {
		// Arrange
		EnumIterator<EvenementArriereSignificatif> it = new EnumIterator<EvenementArriereSignificatif>(
				EvenementArriereSignificatif.AR1, EvenementArriereSignificatif.AR2);

		// Assert
		Assert.assertTrue(it.hasNext());
		Assert.assertEquals(EvenementArriereSignificatif.AR2, it.next());
		Assert.assertFalse(it.hasNext());
		try {
			it.next();
			throw new RuntimeException("L'appel précédent aurait dû lancer une exception...");
		} catch (NoSuchElementException nsee) {
			// Comportement attendu
		}
	}

	@Test
	public void valeursIdentiquesDebutEtFin() {
		// Arrange
		EnumIterator<EvenementArriereSignificatif> it = new EnumIterator<EvenementArriereSignificatif>(
				EvenementArriereSignificatif.AR2, EvenementArriereSignificatif.AR2);

		// Assert
		Assert.assertFalse(it.hasNext());
		try {
			it.next();
			throw new RuntimeException("L'appel précédent aurait dû lancer une exception...");
		} catch (NoSuchElementException nsee) {
			// Comportement attendu
		}
	}

	@Test(expected = AssertionError.class)
	public void valeurFinIncorrecte() {
		new EnumIterator<EvenementArriereSignificatif>(EvenementArriereSignificatif.AR2,
				EvenementArriereSignificatif.AR1);
	}

	@Test(expected = IllegalArgumentException.class)
	public void valeurDebutEtFinNulle() {
		// Arrange
		new EnumIterator<EvenementArriereSignificatif>(null, null);
	}

	@Test
	public void valeurDebutNulleEtFinMilieu() {
		// Arrange
		EnumIterator<EvenementArriereSignificatif> it = new EnumIterator<EvenementArriereSignificatif>(null,
				EvenementArriereSignificatif.AR2);

		// Assert
		Assert.assertTrue(it.hasNext());
		Assert.assertEquals(EvenementArriereSignificatif.AR0, it.next());
		Assert.assertTrue(it.hasNext());
		Assert.assertEquals(EvenementArriereSignificatif.AR1, it.next());
		Assert.assertTrue(it.hasNext());
		Assert.assertEquals(EvenementArriereSignificatif.AR2, it.next());
		Assert.assertFalse(it.hasNext());
		try {
			it.next();
			throw new RuntimeException("L'appel précédent aurait dû lancer une exception...");
		} catch (NoSuchElementException nsee) {
			// Comportement attendu
		}
	}
}

package fr.bpce.yyd.service.calcul.compteur.service.impl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import org.apache.commons.collections4.IterableUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import fr.bpce.yyd.commun.constantes.Constant;
import fr.bpce.yyd.commun.enums.StatutAuditEvenement;
import fr.bpce.yyd.commun.enums.StatutEvenement;
import fr.bpce.yyd.commun.enums.StatutTiers;
import fr.bpce.yyd.commun.messages.dto.LotIdTiersDTO;
import fr.bpce.yyd.commun.model.ArriereSignificatif;
import fr.bpce.yyd.commun.model.AuditCalcul;
import fr.bpce.yyd.commun.model.AuditFichiers;
import fr.bpce.yyd.commun.model.ComplementArriere;
import fr.bpce.yyd.commun.model.ComplementEvenement;
import fr.bpce.yyd.commun.model.ElementsDeCalcul;
import fr.bpce.yyd.commun.model.Evenement;
import fr.bpce.yyd.commun.model.EvenementCalcule;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.MotifStatutTiers;
import fr.bpce.yyd.commun.model.PeriodeProbatoire;
import fr.bpce.yyd.commun.model.StatutHistorise;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.commun.repository.RefCliSsClassRepository;
import fr.bpce.yyd.commun.service.impl.RefCliSegServiceImpl;
import fr.bpce.yyd.service.commun.repository.AuditCalculRepository;
import fr.bpce.yyd.service.commun.repository.EvenementCalculeRepository;
import fr.bpce.yyd.service.commun.repository.EvenementImpactRepository;
import fr.bpce.yyd.service.commun.repository.EvenementRecuRepository;
import fr.bpce.yyd.service.commun.repository.IdentiteTiersRepository;
import fr.bpce.yyd.service.commun.repository.ParMdcBqSegRepository;
import fr.bpce.yyd.service.commun.repository.ParMdcSegRepository;
import fr.bpce.yyd.service.commun.repository.StatutTiersRepository;
import fr.bpce.yyd.service.commun.repository.TiersRepository;
import fr.bpce.yyd.service.commun.service.impl.AuditCalculServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.DefautServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.EvenementCalculeServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.EvenementImpactServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.EvenementRecuServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.IdentiteTiersServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.ParamMdcServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.ParametresNDoDImpl;
import fr.bpce.yyd.service.commun.service.impl.RechercheTiersServiceImpl;

@RunWith(SpringRunner.class)
@DataJpaTest
@ActiveProfiles(profiles = "ti")
public class PeriodeProbatoireTest {

	@Autowired
	TestEntityManager entityManager;

	@Autowired
	TiersRepository tiersRepository;

	@Autowired
	IdentiteTiersRepository identiteTiersRepository;

	@Autowired
	EvenementCalculeRepository evtCalcRepository;

	@Autowired
	AuditCalculRepository auditCalculRepository;

	@Autowired
	ParMdcSegRepository parMdcSegRepository;

	@Autowired
	ParMdcBqSegRepository parMdcBqSegRepository;

	@Autowired
	EvenementRecuRepository evenementRecuRepository;

	@Autowired
	StatutTiersRepository statutTiersRepository;

	@Autowired
	private EvenementImpactRepository evenementImpactRepository;

	@Autowired
	private RefCliSsClassRepository cliSsClassRepository;

	CalculCompteurServiceImpl ccService;

	@Before
	public void assembleService() {
		ccService = new CalculCompteurServiceImpl();

		ParamMdcServiceImpl paramService = new ParamMdcServiceImpl();
		paramService.setParMdcBqSegRepository(parMdcBqSegRepository);
		paramService.setParMdcSegRepository(parMdcSegRepository);
		ParametresNDoDImpl parametresNDoD = new ParametresNDoDImpl();
		parametresNDoD.setParamService(paramService);

		RechercheTiersServiceImpl rtService = new RechercheTiersServiceImpl();
		rtService.setTiersRepository(tiersRepository);
		ccService.setRechercheTiersService(rtService);

		AuditCalculServiceImpl acService = new AuditCalculServiceImpl();
		acService.setAuditCalculRepository(auditCalculRepository);
		ccService.setAuditCalculService(acService);

		IdentiteTiersServiceImpl itService = new IdentiteTiersServiceImpl();
		itService.setIdentTiersRepository(identiteTiersRepository);

		EvenementCalculeServiceImpl ecService = new EvenementCalculeServiceImpl();
		ecService.setEvtCalculeRepository(evtCalcRepository);
		ecService.setIdentiteTiersService(itService);
		ecService.setAuditCalculService(acService);
		ecService.setParamsNDoD(parametresNDoD);
		ccService.setEvenementCalculeService(ecService);

		EvenementImpactServiceImpl impactService = new EvenementImpactServiceImpl();
		impactService.setEvenementImpactRepository(evenementImpactRepository);

		RefCliSegServiceImpl cliSegService = new RefCliSegServiceImpl();
		cliSegService.setCliSsClassRepository(cliSsClassRepository);

		EvenementRecuServiceImpl evenementRecuService = new EvenementRecuServiceImpl();
		evenementRecuService.setEvtRecuRepository(evenementRecuRepository);
		evenementRecuService.setCliSegService(cliSegService);
		evenementRecuService.setImpactService(impactService);
		ccService.setEvenementRecuService(evenementRecuService);

		DefautServiceImpl defautService = new DefautServiceImpl();
		defautService.setStatutTiersRepository(statutTiersRepository);
		defautService.setEvtCalculeService(ecService);
		defautService.setRechercheTiersService(rtService);
		defautService.setImpactService(impactService);
		defautService.setIdentiteTiersService(itService);
		defautService.setRefCliSegService(cliSegService);
		ccService.setDefautService(defautService);

		ccService.setParamNDoD(parametresNDoD);
		ccService.setIdentiteTiersService(itService);
	}

	@Test
	public void passageDePpAct2PpClo() {
		// Arrange
		Tiers tiers = new Tiers();
		IdentiteTiers ident = new IdentiteTiers();
		ident.setIdLocal("11111111");
		ident.setCodeSegment("3200");
		ident.setDateDebut(LocalDate.now().minusDays(91));
		tiers.addIdentite(ident);
		entityManager.persist(tiers);

		PeriodeProbatoire pp = new PeriodeProbatoire();
		pp.setTiers(tiers);
		pp.setDateDebut(LocalDate.now().minusDays(91));
		entityManager.persist(pp);

		AuditCalcul ac = new AuditCalcul();
		ac.setCode("PP");
		ac.setIdTiers(tiers.getId());
		ac.setDateEffet(LocalDate.now().minusDays(91));
		ac.setDateGeneration(LocalDateTime.now());
		ac.setEvenementCalcule(pp);
		ac.setStatut(StatutAuditEvenement.ACT);
		entityManager.persist(ac);

		entityManager.flush();

		// Act
		LotIdTiersDTO lot = new LotIdTiersDTO(LocalDate.now());
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Assert
		AuditCalcul optPP = auditCalculRepository
				.rechercheAuditCalculePPActifOuSuspenduADate(pp.getId(), tiers.getId(), LocalDate.now()).get(0);
		Assert.assertEquals(StatutAuditEvenement.CLO, optPP.getStatut());
		Assert.assertEquals(LocalDate.now().minusDays(2), optPP.getDateEffet());

		StatutHistorise statut = statutTiersRepository.getStatutADate(tiers.getId(), LocalDate.now()).get(0);
		Assert.assertEquals(StatutTiers.SAIN, statut.getStatut());
		Assert.assertEquals(LocalDate.now().minusDays(2), statut.getDateDebut());
	}

	@Test
	public void ppActAvecForbCasDelaiNonAtteint() {
		// Arrange
		Tiers tiers = new Tiers();
		IdentiteTiers ident = new IdentiteTiers();
		ident.setIdLocal("11111112");
		ident.setCodeSegment("3200");
		ident.setCodeBanque("10107");
		ident.setDateDebut(LocalDate.now().minusDays(91));
		tiers.addIdentite(ident);
		entityManager.persist(tiers);

		Evenement forb = new Evenement();
		forb.setCode("F");
		forb.setDateDebut(LocalDate.now().minusDays(45));
		forb.setIdContrat("contrat111");
//		forb.setTiers(tiers);
		forb.setIdentiteInitiale(ident);

		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persist(fic);

		ComplementEvenement compForb = new ComplementEvenement();
		compForb.setEvenement(forb);
		compForb.setAuditFichier(fic);
		compForb.setDateMaj(forb.getDateDebut());
		compForb.setDatePhoto(forb.getDateDebut().plusDays(1));
		compForb.setStatutEvt(StatutEvenement.ACT);
		compForb.setArriereLitige(false);
		compForb.setArriereTech(false);
		compForb.setMiseAJour(true);
		compForb.setIdentiteInitiale(ident);
		forb.addComplement(compForb);
		entityManager.persist(forb);

		PeriodeProbatoire pp = new PeriodeProbatoire();
		pp.setTiers(tiers);
		pp.setDateDebut(LocalDate.now().minusDays(120));
		entityManager.persist(pp);

		AuditCalcul ac = new AuditCalcul();
		ac.setCode("PP");
		ac.setIdTiers(tiers.getId());
		ac.setDateEffet(LocalDate.now().minusDays(120));
		ac.setDateGeneration(LocalDateTime.now());
		ac.setEvenementCalcule(pp);
		ac.setStatut(StatutAuditEvenement.ACT);
		entityManager.persist(ac);

		entityManager.flush();

		// Act
		LotIdTiersDTO lot = new LotIdTiersDTO(LocalDate.now());
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Assert
		AuditCalcul optPP = auditCalculRepository
				.rechercheAuditCalculePPActifOuSuspenduADate(pp.getId(), tiers.getId(), LocalDate.now()).get(0);
		Assert.assertEquals(StatutAuditEvenement.ACT, optPP.getStatut());
	}

	@Test
	public void passageDePpAct2PpCloAvecForbCasDelaiAtteint() {
		// Arrange
		Tiers tiers = new Tiers();
		IdentiteTiers ident = new IdentiteTiers();
		ident.setIdLocal("11111113");
		ident.setCodeBanque("10107");
		ident.setCodeSegment("3200");
		ident.setDateDebut(LocalDate.now().minusDays(91));
		tiers.addIdentite(ident);
		entityManager.persist(tiers);

		Evenement forb = new Evenement();
		forb.setCode("F");
		forb.setDateDebut(LocalDate.now().minusDays(45));
		forb.setIdContrat("contrat111");
//		forb.setTiers(tiers);
		forb.setIdentiteInitiale(ident);

		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persist(fic);

		ComplementEvenement compForb = new ComplementEvenement();
		compForb.setEvenement(forb);
		compForb.setAuditFichier(fic);
		compForb.setDateMaj(forb.getDateDebut());
		compForb.setDatePhoto(forb.getDateDebut().plusDays(1));
		compForb.setStatutEvt(StatutEvenement.ACT);
		compForb.setArriereLitige(false);
		compForb.setArriereTech(false);
		compForb.setMiseAJour(true);
		compForb.setIdentiteInitiale(ident);
		forb.addComplement(compForb);
		entityManager.persist(forb);

		PeriodeProbatoire pp = new PeriodeProbatoire();
		pp.setTiers(tiers);
		pp.setDateDebut(LocalDate.now().minusDays(370));
		entityManager.persist(pp);

		AuditCalcul ac = new AuditCalcul();
		ac.setCode("PP");
		ac.setIdTiers(tiers.getId());
		ac.setDateEffet(LocalDate.now().minusDays(370));
		ac.setDateGeneration(LocalDateTime.now());
		ac.setEvenementCalcule(pp);
		ac.setStatut(StatutAuditEvenement.ACT);
		entityManager.persist(ac);

		entityManager.flush();

		// Act
		LotIdTiersDTO lot = new LotIdTiersDTO(LocalDate.now());
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Assert
		AuditCalcul optPP = auditCalculRepository
				.rechercheAuditCalculePPActifOuSuspenduADate(pp.getId(), tiers.getId(), LocalDate.now()).get(0);
		Assert.assertEquals(StatutAuditEvenement.CLO, optPP.getStatut());
		Assert.assertEquals(LocalDate.now().minusDays(6), optPP.getDateEffet());

		StatutHistorise statut = statutTiersRepository.getStatutADate(tiers.getId(), LocalDate.now()).get(0);
		Assert.assertEquals(StatutTiers.SAIN, statut.getStatut());
		Assert.assertEquals(LocalDate.now().minusDays(6), statut.getDateDebut());
	}

	@Test
	public void passageDePpAct2PpSus() {
		// Arrange
		Tiers tiers = new Tiers();
		IdentiteTiers ident = new IdentiteTiers();
		ident.setIdLocal("22222222");
		ident.setCodeSegment("3200");
		ident.setDateDebut(LocalDate.now().minusDays(91));
		tiers.addIdentite(ident);
		entityManager.persist(tiers);

		PeriodeProbatoire pp = new PeriodeProbatoire();
		pp.setTiers(tiers);
		pp.setDateDebut(LocalDate.now().minusDays(50));
		entityManager.persist(pp);

		AuditCalcul ac = new AuditCalcul();
		ac.setCode("PP");
		ac.setIdTiers(tiers.getId());
		ac.setDateEffet(LocalDate.now().minusDays(50));
		ac.setDateGeneration(LocalDateTime.now());
		ac.setEvenementCalcule(pp);
		ac.setStatut(StatutAuditEvenement.ACT);
		entityManager.persist(ac);

		ElementsDeCalcul edc = new ElementsDeCalcul();
		edc.setTiers(tiers);
		entityManager.persist(edc);

		ArriereSignificatif as = new ArriereSignificatif();
		as.setTiers(tiers);
		as.setDateDebut(LocalDate.now());
		ComplementArriere complAS = new ComplementArriere();
		complAS.setEntree(edc);
		as.setComplement(complAS);
		entityManager.persist(as);

		entityManager.flush();

		// Act
		LotIdTiersDTO lot = new LotIdTiersDTO(LocalDate.now());
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Assert
		AuditCalcul optPP = auditCalculRepository
				.rechercheAuditCalculePPActifOuSuspenduADate(pp.getId(), tiers.getId(), LocalDate.now()).get(0);
		Assert.assertEquals(StatutAuditEvenement.SUS, optPP.getStatut());
		Assert.assertEquals(LocalDate.now(), optPP.getDateEffet());
	}

	@Test
	public void passageDePpSus2PpAct() {
		// Arrange
		Tiers tiers = new Tiers();
		IdentiteTiers ident = new IdentiteTiers();
		ident.setIdLocal("33333333");
		ident.setCodeSegment("3200");
		ident.setDateDebut(LocalDate.now().minusDays(91));
		tiers.addIdentite(ident);
		entityManager.persist(tiers);

		PeriodeProbatoire pp = new PeriodeProbatoire();
		pp.setTiers(tiers);
		pp.setDateDebut(LocalDate.now().minusDays(50));
		entityManager.persist(pp);

		AuditCalcul ac = new AuditCalcul();
		ac.setCode("PP");
		ac.setIdTiers(tiers.getId());
		ac.setDateEffet(LocalDate.now().minusDays(50));
		ac.setDateGeneration(LocalDateTime.now());
		ac.setEvenementCalcule(pp);
		ac.setStatut(StatutAuditEvenement.SUS);
		entityManager.persist(ac);

		ElementsDeCalcul edc = new ElementsDeCalcul();
		edc.setTiers(tiers);
		entityManager.persist(edc);

		ArriereSignificatif as = new ArriereSignificatif();
		as.setTiers(tiers);
		as.setDateDebut(LocalDate.now().minusDays(10));
		as.setDateFin(LocalDate.now().minusDays(5));
		ComplementArriere complAS = new ComplementArriere();
		complAS.setEntree(edc);
		as.setComplement(complAS);
		entityManager.persist(as);

		entityManager.flush();

		// Act
		LotIdTiersDTO lot = new LotIdTiersDTO(LocalDate.now());
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Assert
		AuditCalcul optPP = auditCalculRepository
				.rechercheAuditCalculePPActifOuSuspenduADate(pp.getId(), tiers.getId(), LocalDate.now()).get(0);
		Assert.assertEquals(StatutAuditEvenement.ACT, optPP.getStatut());
		Assert.assertEquals(LocalDate.now().minusDays(5), optPP.getDateEffet());
	}

	@Test
	public void passageDePpAct2PpCloAvecAR3() {
		// Arrange
		Tiers tiers = new Tiers();
		IdentiteTiers ident = new IdentiteTiers();
		ident.setIdLocal("22222222");
		ident.setCodeSegment("3200");
		ident.setDateDebut(LocalDate.now().minusDays(91));
		tiers.addIdentite(ident);
		entityManager.persist(tiers);

		PeriodeProbatoire pp = new PeriodeProbatoire();
		pp.setTiers(tiers);
		pp.setDateDebut(LocalDate.now().minusDays(50));
		entityManager.persist(pp);

		AuditCalcul ac = new AuditCalcul();
		ac.setCode("PP");
		ac.setIdTiers(tiers.getId());
		ac.setDateEffet(LocalDate.now().minusDays(50));
		ac.setDateGeneration(LocalDateTime.now());
		ac.setEvenementCalcule(pp);
		ac.setStatut(StatutAuditEvenement.ACT);
		entityManager.persist(ac);

		ElementsDeCalcul edc = new ElementsDeCalcul();
		edc.setTiers(tiers);
		entityManager.persist(edc);

		ArriereSignificatif as = new ArriereSignificatif();
		as.setTiers(tiers);
		as.setDateDebut(LocalDate.now());
		ComplementArriere complAS = new ComplementArriere();
		complAS.setEntree(edc);
		as.setComplement(complAS);
		entityManager.persist(as);

		entityManager.flush();

		// Act
		LotIdTiersDTO lot = new LotIdTiersDTO(LocalDate.now());
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Assert
		AuditCalcul optPP = auditCalculRepository
				.rechercheAuditCalculePPActifOuSuspenduADate(pp.getId(), tiers.getId(), LocalDate.now()).get(0);
		Assert.assertEquals(StatutAuditEvenement.SUS, optPP.getStatut());
		Assert.assertEquals(LocalDate.now(), optPP.getDateEffet());

		lot.setDateCalcul(LocalDate.now().plusDays(90));
		ccService.traiteMessage(lot);

		StatutHistorise statut = statutTiersRepository.getStatutADate(tiers.getId(), LocalDate.now().plusDays(90))
				.get(0);
		Assert.assertEquals(Constant.EVENEMENT_AR3, statut.getMotif().getMotif());
		Assert.assertEquals(StatutTiers.DEFAUT, statut.getStatut());
		Assert.assertEquals(LocalDate.now().plusDays(90), statut.getDateDebut());
	}

	@Test
	public void passageDePpAct2PpCloAvec2ForbsCloturesApres90J() {

		LocalDate dateDebutF1 = LocalDate.of(2020, 03, 05);
		LocalDate dateDebutF2 = LocalDate.of(2020, 03, 07);
		LocalDate dateFinF = LocalDate.of(2020, 06, 16); // + que 90;

		// Arrange
		Tiers tiers = new Tiers();
		IdentiteTiers ident = new IdentiteTiers();
		ident.setIdLocal("123655454");
		ident.setCodeBanque("10107");
		ident.setCodeSegment("3200");
		ident.setDateDebut(LocalDate.of(2020, 02, 07));
		tiers.addIdentite(ident);
		entityManager.persist(tiers);

		// Forbearance 1
		Evenement forb1 = new Evenement();
		forb1.setCode("F");
		forb1.setDateDebut(dateDebutF1);
		forb1.setIdContrat("contrat111");
		forb1.setIdentiteInitiale(ident);
		// Forbearance 2
		Evenement forb2 = new Evenement();
		forb2.setCode("F");
		forb2.setDateDebut(dateDebutF2);
		forb2.setIdContrat("contrat112");
		forb2.setIdentiteInitiale(ident);

		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persist(fic);
		// Complement ACT
		ComplementEvenement compForb1 = new ComplementEvenement();
		compForb1.setEvenement(forb1);
		compForb1.setAuditFichier(fic);
		compForb1.setDateMaj(forb1.getDateDebut());
		compForb1.setDatePhoto(forb1.getDateDebut().minusDays(3));
		compForb1.setStatutEvt(StatutEvenement.ACT);
		compForb1.setArriereLitige(false);
		compForb1.setArriereTech(false);
		compForb1.setMiseAJour(false);
		compForb1.setIdentiteInitiale(ident);
		compForb1.setDateFin(dateFinF);
		// complement CLO
		ComplementEvenement compForb1CLO = new ComplementEvenement();
		compForb1CLO.setEvenement(forb1);
		compForb1CLO.setAuditFichier(fic);
		compForb1CLO.setDateMaj(dateFinF);
		compForb1CLO.setDatePhoto(dateFinF);
		compForb1CLO.setStatutEvt(StatutEvenement.CLO);
		compForb1CLO.setArriereLitige(false);
		compForb1CLO.setArriereTech(false);
		compForb1CLO.setMiseAJour(true);
		compForb1CLO.setIdentiteInitiale(ident);
		compForb1CLO.setDateFin(null);
		forb1.addComplement(compForb1);
		forb1.addComplement(compForb1CLO);
		entityManager.persist(forb1);

		// Forbearance 2
		// Complement ACT
		ComplementEvenement compForb2 = new ComplementEvenement();
		compForb2.setEvenement(forb2);
		compForb2.setAuditFichier(fic);
		compForb2.setDateMaj(forb2.getDateDebut());
		compForb2.setDatePhoto(forb2.getDateDebut().minusDays(3));
		compForb2.setStatutEvt(StatutEvenement.ACT);
		compForb2.setArriereLitige(false);
		compForb2.setArriereTech(false);
		compForb2.setMiseAJour(true);
		compForb2.setIdentiteInitiale(ident);
		compForb2.setDateFin(dateFinF);
		// Complement CLO
		ComplementEvenement compForb2CLO = new ComplementEvenement();
		compForb2CLO.setEvenement(forb2);
		compForb2CLO.setAuditFichier(fic);
		compForb2CLO.setDateMaj(dateFinF);
		compForb2CLO.setDatePhoto(dateFinF);
		compForb2CLO.setStatutEvt(StatutEvenement.CLO);
		compForb2CLO.setArriereLitige(false);
		compForb2CLO.setArriereTech(false);
		compForb2CLO.setMiseAJour(true);
		compForb2CLO.setIdentiteInitiale(ident);
		compForb2CLO.setDateFin(null);
		forb2.addComplement(compForb2);
		forb2.addComplement(compForb2CLO);
		entityManager.persist(forb2);
		// PP
		PeriodeProbatoire pp = new PeriodeProbatoire();
		pp.setTiers(tiers);
		pp.setDateDebut(LocalDate.of(2020, 3, 10));
		entityManager.persist(pp);

		AuditCalcul ac = new AuditCalcul();
		ac.setCode("PP");
		ac.setIdTiers(tiers.getId());
		ac.setDateEffet(LocalDate.of(2020, 3, 10));
		ac.setDateGeneration(LocalDateTime.now());
		ac.setEvenementCalcule(pp);
		ac.setStatut(StatutAuditEvenement.ACT);
		entityManager.persist(ac);
		// statut Defaut PP
		StatutHistorise stDefaut = new StatutHistorise();
		stDefaut.setAnnule(false);
		stDefaut.setDateDeb(LocalDate.of(2020, 3, 10));
		stDefaut.setGravite("RX");
		stDefaut.setTiers(tiers);
		stDefaut.setStatut(StatutTiers.DEFAUT);
		stDefaut.setMotif(new MotifStatutTiers(pp));
		entityManager.persist(stDefaut);

		entityManager.flush();

		// Act
		LotIdTiersDTO lot = new LotIdTiersDTO(LocalDate.now());
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Vérifier que la PP est bien cloturée avec date_effet = dateFinF
		AuditCalcul optPP = auditCalculRepository
				.rechercheAuditCalculePPActifOuSuspenduADate(pp.getId(), tiers.getId(), LocalDate.now()).get(0);
		Assert.assertEquals(StatutAuditEvenement.CLO, optPP.getStatut());
		Assert.assertEquals(dateFinF, optPP.getDateEffet());
		// Vérifier le retour en sain avec date_debut = dateFinF
		StatutHistorise statut = statutTiersRepository.getStatutADate(tiers.getId(), LocalDate.now()).get(0);
		Assert.assertEquals(StatutTiers.SAIN, statut.getStatut());
		Assert.assertEquals(dateFinF, statut.getDateDebut());
	}

	@Test
	public void passageDePpAnnEtPPAct2PpCloRetourSain() {

		// DM ACT le 08/10, entrée en défaut le 08/10
		// RAD ACT le 15/10,
		// DM CLO le 16/10,
		// RAD CLO le 28/10,
		// PP ACT le 28/10,
		// RAD ANN le 10/12
		// DANS STE, nous avons à la réception du RAD ANN :
		// Intégrer la mise à jour au niveau de l'évènement RAD
		// Flagger le statut tiers RAD correspondant à annulé (1)
		// Recalculer la PP par rapport au DM CLO au 16/10 (le dernier UTP lié à la
		// période de défaut)
		// Passer le tiers en statut SAIN à date de clôture de PP (le 13/01) - 90 jours
		// a partir du 16/10

		// Arrange
		LocalDate date_08_10_2020 = LocalDate.of(2020, 10, 8);
		LocalDate date_15_10_2020 = LocalDate.of(2020, 10, 15);
		LocalDate date_16_10_2020 = LocalDate.of(2020, 10, 16);
		LocalDate date_28_10_2020 = LocalDate.of(2020, 10, 28);
		LocalDate date_10_12_2020 = LocalDate.of(2020, 12, 10);

		Tiers tiers = new Tiers();
		IdentiteTiers ident = new IdentiteTiers();
		ident.setIdLocal("11111111");
		ident.setCodeSegment("3200");
		ident.setDateDebut(LocalDate.now().minusDays(91));
		tiers.addIdentite(ident);
		entityManager.persist(tiers);

		// * EVENEMENT_CALCULE - création de 2 lignes en BDD
		PeriodeProbatoire evtCalculePpANN = new PeriodeProbatoire();
		evtCalculePpANN.setTiers(tiers);
		evtCalculePpANN.setDateDebut(date_28_10_2020);
		evtCalculePpANN.setDateFin(date_10_12_2020);
		entityManager.persist(evtCalculePpANN);

		PeriodeProbatoire evtCalculePpACT = new PeriodeProbatoire();
		evtCalculePpACT.setTiers(tiers);
		evtCalculePpACT.setDateDebut(date_16_10_2020);
		entityManager.persist(evtCalculePpACT);

		// * AUDIT_CALCUL - création de 3 lignes
		AuditCalcul acACTPpAnn = new AuditCalcul();
		acACTPpAnn.setCode("PP");
		acACTPpAnn.setIdTiers(tiers.getId());
		acACTPpAnn.setDateEffet(date_28_10_2020);
		acACTPpAnn.setDateGeneration(LocalDateTime.now());
		acACTPpAnn.setEvenementCalcule(evtCalculePpANN);
		acACTPpAnn.setStatut(StatutAuditEvenement.ACT);
		entityManager.persist(acACTPpAnn);

		AuditCalcul acCLOPpAnn = new AuditCalcul();
		acCLOPpAnn.setCode("PP");
		acCLOPpAnn.setIdTiers(tiers.getId());
		acCLOPpAnn.setDateEffet(date_10_12_2020);
		acCLOPpAnn.setDateGeneration(LocalDateTime.now());
		acCLOPpAnn.setEvenementCalcule(evtCalculePpANN);
		acCLOPpAnn.setStatut(StatutAuditEvenement.CLO);
		entityManager.persist(acCLOPpAnn);

		AuditCalcul acACTPpACT = new AuditCalcul();
		acACTPpACT.setCode("PP");
		acACTPpACT.setIdTiers(tiers.getId());
		acACTPpACT.setDateEffet(date_16_10_2020);
		acACTPpACT.setDateGeneration(LocalDateTime.now());
		acACTPpACT.setEvenementCalcule(evtCalculePpACT);
		acACTPpACT.setStatut(StatutAuditEvenement.ACT);
		entityManager.persist(acACTPpACT);

		entityManager.flush();

		// * STATUT_TIERS - 4 lignes

		// statut DEFAUT DX sur evt DM
		StatutHistorise statutDXDm = new StatutHistorise();
		statutDXDm.setAnnule(false);
		statutDXDm.setDateDeb(date_08_10_2020);
		statutDXDm.setDateFin(date_16_10_2020);
		statutDXDm.setGravite("DX");

		Evenement evtDM = new Evenement();
		evtDM.setCode("DM");
		evtDM.setDateDebut(date_08_10_2020);
		evtDM.setIdentiteInitiale(ident);
		entityManager.persist(evtDM);
		ComplementEvenement complEvtDM = new ComplementEvenement();
		complEvtDM.setEvenement(evtDM);
		complEvtDM.setDatePhoto(LocalDate.now());
		complEvtDM.setDateMaj(date_28_10_2020);
		complEvtDM.setStatutEvt(StatutEvenement.CLO);
		complEvtDM.setIdentiteInitiale(ident);
		AuditFichiers a1 = new AuditFichiers();
		entityManager.persist(a1);
		complEvtDM.setAuditFichier(a1);
		entityManager.persist(complEvtDM);
		statutDXDm.setMotif(new MotifStatutTiers(complEvtDM));

		statutDXDm.setStatut(StatutTiers.DEFAUT);
		statutDXDm.setTiers(tiers);
		entityManager.persist(statutDXDm);

		// statut DEFAUT RX sur evt RAD
		StatutHistorise statutRXRad = new StatutHistorise();
		statutRXRad.setAnnule(true);
		statutRXRad.setDateDeb(date_15_10_2020);
		statutRXRad.setDateFin(date_28_10_2020);
		statutRXRad.setGravite("RX");

		Evenement evtRAD = new Evenement();
		evtRAD.setCode("RAD");
		evtRAD.setDateDebut(date_15_10_2020);
		evtRAD.setIdentiteInitiale(ident);
		entityManager.persist(evtRAD);
		ComplementEvenement complEvtRAD = new ComplementEvenement();
		complEvtRAD.setEvenement(evtRAD);
		complEvtDM.setDatePhoto(LocalDate.now());
		complEvtRAD.setDateMaj(date_10_12_2020);
		complEvtRAD.setStatutEvt(StatutEvenement.ANN);
		complEvtRAD.setIdentiteInitiale(ident);
		AuditFichiers a2 = new AuditFichiers();
		entityManager.persist(a2);
		complEvtRAD.setAuditFichier(a2);
		entityManager.persist(complEvtRAD);
		statutRXRad.setMotif(new MotifStatutTiers(complEvtRAD));

		statutRXRad.setStatut(StatutTiers.DEFAUT);
		statutRXRad.setTiers(tiers);
		entityManager.persist(statutRXRad);

		// statut DEFAUT RX sur evt PP annulée
		StatutHistorise statutPPAnn = new StatutHistorise();
		statutPPAnn.setAnnule(true);
		statutPPAnn.setDateDeb(date_28_10_2020);
		statutPPAnn.setDateFin(date_10_12_2020);
		statutPPAnn.setGravite("RX");
		statutPPAnn.setMotif(new MotifStatutTiers(evtCalculePpANN));
		statutPPAnn.setStatut(StatutTiers.DEFAUT);
		statutPPAnn.setTiers(tiers);
		entityManager.persist(statutPPAnn);

		// statut DEFAUT DX sur evt PP actif
		StatutHistorise statutPPAct = new StatutHistorise();
		statutPPAct.setAnnule(true);
		statutPPAct.setDateDeb(date_16_10_2020);
		statutPPAct.setGravite("DX");
		statutPPAct.setMotif(new MotifStatutTiers(evtCalculePpACT));
		statutPPAct.setStatut(StatutTiers.DEFAUT);
		statutPPAct.setTiers(tiers);
		entityManager.persist(statutPPAct);

		// Act
		LotIdTiersDTO lot = new LotIdTiersDTO(LocalDate.now());
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Assert - Ties passe en SAIN à date de clôture de PP (le 13/01) - 90 jours a
		// partir du 16/10
		List<StatutHistorise> allStatutsCourants = statutTiersRepository.findAll();
		Assert.assertEquals(5, allStatutsCourants.size());

		Iterable<AuditCalcul> allAuditCalcul = auditCalculRepository.findAll();
		Assert.assertEquals(4, IterableUtils.size(allAuditCalcul));

		Iterable<EvenementCalcule> allevtCalcules = evtCalcRepository.findAll();
		Assert.assertEquals(2, IterableUtils.size(allevtCalcules));

		AuditCalcul optPP = auditCalculRepository
				.rechercheAuditCalculePPActifOuSuspenduADate(evtCalculePpACT.getId(), tiers.getId(), LocalDate.now())
				.get(0);

		// PP qui se cloture le 13/01
		LocalDate date_13_01_2021 = LocalDate.of(2021, 01, 13);

		Assert.assertEquals(StatutAuditEvenement.CLO, optPP.getStatut());
		Assert.assertEquals(date_13_01_2021, optPP.getDateEffet());

		StatutHistorise statut = statutTiersRepository.getStatutADate(tiers.getId(), LocalDate.now()).get(0);
		Assert.assertEquals(StatutTiers.SAIN, statut.getStatut());
		Assert.assertEquals(date_13_01_2021, statut.getDateDebut());
	}
}

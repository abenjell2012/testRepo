package fr.bpce.yyd.service.calcul.compteur.service.impl;

import java.time.LocalDate;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import fr.bpce.yyd.commun.constantes.Constant;
import fr.bpce.yyd.commun.enums.StatutEvenement;
import fr.bpce.yyd.commun.enums.StatutTiers;
import fr.bpce.yyd.commun.messages.dto.LotIdTiersDTO;
import fr.bpce.yyd.commun.model.ArriereSignificatif;
import fr.bpce.yyd.commun.model.AuditFichiers;
import fr.bpce.yyd.commun.model.ComplementArriere;
import fr.bpce.yyd.commun.model.ComplementEvenement;
import fr.bpce.yyd.commun.model.ElementsDeCalcul;
import fr.bpce.yyd.commun.model.Evenement;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.StatutHistorise;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.commun.model.reference.RefCliSeg;
import fr.bpce.yyd.commun.model.reference.RefCliSsClass;
import fr.bpce.yyd.commun.model.reference.RefImpactEvtMdc;
import fr.bpce.yyd.commun.repository.RefCliSsClassRepository;
import fr.bpce.yyd.commun.service.impl.RefCliSegServiceImpl;
import fr.bpce.yyd.service.commun.repository.AuditCalculRepository;
import fr.bpce.yyd.service.commun.repository.EvenementCalculeRepository;
import fr.bpce.yyd.service.commun.repository.EvenementImpactRepository;
import fr.bpce.yyd.service.commun.repository.EvenementRecuRepository;
import fr.bpce.yyd.service.commun.repository.IdentiteTiersRepository;
import fr.bpce.yyd.service.commun.repository.ParMdcBqSegRepository;
import fr.bpce.yyd.service.commun.repository.ParMdcSegRepository;
import fr.bpce.yyd.service.commun.repository.StatutTiersRepository;
import fr.bpce.yyd.service.commun.repository.TiersRepository;
import fr.bpce.yyd.service.commun.service.impl.AuditCalculServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.DefautServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.EvenementCalculeServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.EvenementImpactServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.EvenementRecuServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.IdentiteTiersServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.ParamMdcServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.ParametresNDoDImpl;
import fr.bpce.yyd.service.commun.service.impl.RechercheTiersServiceImpl;

@RunWith(SpringRunner.class)
@DataJpaTest
@ActiveProfiles(profiles = "ti")
public class ImpactEtGraviteTest {

	@Autowired
	TestEntityManager entityManager;

	@Autowired
	TiersRepository tiersRepository;

	@Autowired
	IdentiteTiersRepository identiteTiersRepository;

	@Autowired
	EvenementCalculeRepository evtCalcRepository;

	@Autowired
	AuditCalculRepository auditCalculRepository;

	@Autowired
	ParMdcSegRepository parMdcSegRepository;

	@Autowired
	ParMdcBqSegRepository parMdcBqSegRepository;

	@Autowired
	EvenementRecuRepository evenementRecuRepository;

	@Autowired
	StatutTiersRepository statutTiersRepository;

	@Autowired
	private EvenementImpactRepository evenementImpactRepository;

	@Autowired
	private RefCliSsClassRepository cliSsClassRepository;

	CalculCompteurServiceImpl ccService;

	@Before
	public void assembleService() {
		ccService = new CalculCompteurServiceImpl();

		ParamMdcServiceImpl paramService = new ParamMdcServiceImpl();
		paramService.setParMdcBqSegRepository(parMdcBqSegRepository);
		paramService.setParMdcSegRepository(parMdcSegRepository);
		ParametresNDoDImpl parametresNDoD = new ParametresNDoDImpl();
		parametresNDoD.setParamService(paramService);

		RechercheTiersServiceImpl rtService = new RechercheTiersServiceImpl();
		rtService.setTiersRepository(tiersRepository);
		ccService.setRechercheTiersService(rtService);

		AuditCalculServiceImpl acService = new AuditCalculServiceImpl();
		acService.setAuditCalculRepository(auditCalculRepository);
		ccService.setAuditCalculService(acService);

		IdentiteTiersServiceImpl itService = new IdentiteTiersServiceImpl();
		itService.setIdentTiersRepository(identiteTiersRepository);

		EvenementCalculeServiceImpl ecService = new EvenementCalculeServiceImpl();
		ecService.setEvtCalculeRepository(evtCalcRepository);
		ecService.setIdentiteTiersService(itService);
		ecService.setAuditCalculService(acService);
		ecService.setParamsNDoD(parametresNDoD);
		ccService.setEvenementCalculeService(ecService);

		EvenementImpactServiceImpl impactService = new EvenementImpactServiceImpl();
		impactService.setEvenementImpactRepository(evenementImpactRepository);

		RefCliSegServiceImpl cliSegService = new RefCliSegServiceImpl();
		cliSegService.setCliSsClassRepository(cliSsClassRepository);

		EvenementRecuServiceImpl evenementRecuService = new EvenementRecuServiceImpl();
		evenementRecuService.setEvtRecuRepository(evenementRecuRepository);
		evenementRecuService.setCliSegService(cliSegService);
		evenementRecuService.setImpactService(impactService);
		ccService.setEvenementRecuService(evenementRecuService);

		DefautServiceImpl defautService = new DefautServiceImpl();
		defautService.setStatutTiersRepository(statutTiersRepository);
		defautService.setEvtCalculeService(ecService);
		defautService.setRechercheTiersService(rtService);
		defautService.setImpactService(impactService);
		defautService.setIdentiteTiersService(itService);
		defautService.setRefCliSegService(cliSegService);
		ccService.setDefautService(defautService);

		ccService.setParamNDoD(parametresNDoD);
		ccService.setIdentiteTiersService(itService);
	}

	@Test
	public void impactDefautAR3() {
		// Arrange
		Tiers tiers = new Tiers();
		IdentiteTiers ident = new IdentiteTiers();
		ident.setIdLocal("11111113");
		ident.setCodeSegment("3200");
		ident.setDateDebut(LocalDate.now().minusDays(100));
		tiers.addIdentite(ident);
		entityManager.persist(tiers);

		ElementsDeCalcul edc = new ElementsDeCalcul();
		edc.setTiers(tiers);
		entityManager.persist(edc);

		ArriereSignificatif as = new ArriereSignificatif();
		as.setTiers(tiers);
		as.setDateDebut(LocalDate.now().minusDays(92));
		ComplementArriere complAS = new ComplementArriere();
		complAS.setEntree(edc);
		as.setComplement(complAS);
		entityManager.persist(as);

		// REF IMPACTEVT MDC
		RefImpactEvtMdc refImpact = new RefImpactEvtMdc();
		refImpact.setCodEvt("AR3");
		refImpact.setCategorieSegment(Constant.TOUS_AUTRES);
		refImpact.setImpact("D");
		refImpact.setGraviteImpact("DX");
		refImpact.setDateDebut(LocalDate.now().minusDays(100));
		entityManager.persist(refImpact);

		// REF_CLI_SEG
		RefCliSeg refCliSeg = new RefCliSeg();
		refCliSeg.setCodSegCli("3200");
		refCliSeg.setLibSegCli("PARTICULIERS");
		refCliSeg.setCodSsClassCli("RETPAR");
		refCliSeg.setTopSuppr("N");
		entityManager.persist(refCliSeg);

		// REF_CLI_SS_CLASS
		RefCliSsClass refClassSsClass = new RefCliSsClass();
		refClassSsClass.setCodSsClassCli("RETPAR");
		refClassSsClass.setLibSsClassCli("PARTICULIERS");
		refClassSsClass.setCodClassCli("RET");
		refClassSsClass.setTopSuppr("N");
		refClassSsClass.setCodTypNot("PART");
		entityManager.persist(refClassSsClass);

		entityManager.flush();

		// Act
		LotIdTiersDTO lot = new LotIdTiersDTO(LocalDate.now());
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		StatutHistorise statut = statutTiersRepository.getStatutADate(tiers.getId(), LocalDate.now()).get(0);
		Assert.assertEquals(StatutTiers.DEFAUT, statut.getStatut());
		Assert.assertEquals("AR3", statut.getMotif().getMotif());
		Assert.assertEquals("DX", statut.getGravite());
		Assert.assertEquals(LocalDate.now().minusDays(2), statut.getDateDebut());
	}

	@Test
	public void impactDefautIFAvecDateDebutARX() {
		// Arrange
		Tiers tiers = new Tiers();
		IdentiteTiers ident = new IdentiteTiers();
		ident.setIdLocal("11111113");
		ident.setCodeBanque("10107");
		ident.setCodeSegment("3200");
		ident.setDateDebut(LocalDate.now().minusDays(91));
		tiers.addIdentite(ident);
		entityManager.persist(tiers);

		Evenement forb = new Evenement();
		forb.setCode("F");
		forb.setDateDebut(LocalDate.now().minusDays(45));
		forb.setIdContrat("contrat111");
//		forb.setTiers(tiers);
		forb.setIdentiteInitiale(ident);

		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persist(fic);

		ComplementEvenement compForb = new ComplementEvenement();
		compForb.setEvenement(forb);
		compForb.setAuditFichier(fic);
		compForb.setDateMaj(forb.getDateDebut());
		compForb.setDatePhoto(forb.getDateDebut().plusDays(1));
		compForb.setStatutEvt(StatutEvenement.ACT);
		compForb.setArriereLitige(false);
		compForb.setArriereTech(false);
		compForb.setMiseAJour(false);
		compForb.setIdentiteInitiale(ident);
		forb.addComplement(compForb);
		entityManager.persist(forb);

		Evenement imx = new Evenement();
		imx.setCode("IMX");
		imx.setDateDebut(LocalDate.now().minusDays(35));
		imx.setIdContrat("contrat111");
//		imx.setTiers(tiers);
		imx.setIdentiteInitiale(ident);

		ComplementEvenement compImx = new ComplementEvenement();
		compImx.setEvenement(imx);
		compImx.setAuditFichier(fic);
		compImx.setDateMaj(imx.getDateDebut());
		compImx.setDatePhoto(imx.getDateDebut());
		compImx.setStatutEvt(StatutEvenement.ACT);
		compImx.setArriereLitige(false);
		compImx.setArriereTech(false);
		compImx.setMiseAJour(false);
		compImx.setIdentiteInitiale(ident);
		imx.addComplement(compImx);
		entityManager.persist(imx);

		ElementsDeCalcul edc = new ElementsDeCalcul();
		edc.setTiers(tiers);
		entityManager.persist(edc);

		ArriereSignificatif as = new ArriereSignificatif();
		as.setTiers(tiers);
		as.setDateDebut(LocalDate.now());
		ComplementArriere complAS = new ComplementArriere();
		complAS.setEntree(edc);
		as.setComplement(complAS);
		entityManager.persist(as);

		// REF IMPACTEVT MDC
		RefImpactEvtMdc refImpact = new RefImpactEvtMdc();
		refImpact.setCodEvt("IF");
		refImpact.setCategorieSegment(Constant.TOUS_AUTRES);
		refImpact.setImpact("D");
		refImpact.setGraviteImpact("RX");
		refImpact.setDateDebut(LocalDate.now().minusDays(100));
		entityManager.persist(refImpact);

		// REF_CLI_SEG
		RefCliSeg refCliSeg = new RefCliSeg();
		refCliSeg.setCodSegCli("3200");
		refCliSeg.setLibSegCli("PARTICULIERS");
		refCliSeg.setCodSsClassCli("RETPAR");
		refCliSeg.setTopSuppr("N");
		entityManager.persist(refCliSeg);

		// REF_CLI_SS_CLASS
		RefCliSsClass refClassSsClass = new RefCliSsClass();
		refClassSsClass.setCodSsClassCli("RETPAR");
		refClassSsClass.setLibSsClassCli("PARTICULIERS");
		refClassSsClass.setCodClassCli("RET");
		refClassSsClass.setTopSuppr("N");
		refClassSsClass.setCodTypNot("PART");
		entityManager.persist(refClassSsClass);

		entityManager.flush();

		// Act
		LotIdTiersDTO lot = new LotIdTiersDTO(LocalDate.now());
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Assert
		StatutHistorise statut = statutTiersRepository.getStatutADate(tiers.getId(), LocalDate.now()).get(0);
		Assert.assertEquals(StatutTiers.DEFAUT, statut.getStatut());
		Assert.assertEquals("IF", statut.getMotif().getMotif());
		Assert.assertEquals("RX", statut.getGravite());
		Assert.assertEquals(LocalDate.now(), statut.getDateDebut());
	}

	@Test
	public void impactDefautIFAvecDateDebutIMX30j() {
		// Arrange
		Tiers tiers = new Tiers();
		IdentiteTiers ident = new IdentiteTiers();
		ident.setIdLocal("11111113");
		ident.setCodeBanque("10107");
		ident.setCodeSegment("3200");
		ident.setDateDebut(LocalDate.now().minusDays(91));
		tiers.addIdentite(ident);
		entityManager.persist(tiers);

		Evenement forb = new Evenement();
		forb.setCode("F");
		forb.setDateDebut(LocalDate.now().minusDays(45));
		forb.setIdContrat("contrat111");
//		forb.setTiers(tiers);
		forb.setIdentiteInitiale(ident);

		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persist(fic);

		ComplementEvenement compForb = new ComplementEvenement();
		compForb.setEvenement(forb);
		compForb.setAuditFichier(fic);
		compForb.setDateMaj(forb.getDateDebut());
		compForb.setDatePhoto(forb.getDateDebut().plusDays(1));
		compForb.setStatutEvt(StatutEvenement.ACT);
		compForb.setArriereLitige(false);
		compForb.setArriereTech(false);
		compForb.setMiseAJour(false);
		compForb.setIdentiteInitiale(ident);
		forb.addComplement(compForb);
		entityManager.persist(forb);

		Evenement imx = new Evenement();
		imx.setCode("IMX");
		imx.setDateDebut(LocalDate.now().minusDays(35));
		imx.setIdContrat("contrat111");
//		imx.setTiers(tiers);
		imx.setIdentiteInitiale(ident);

		ComplementEvenement compImx = new ComplementEvenement();
		compImx.setEvenement(imx);
		compImx.setAuditFichier(fic);
		compImx.setDateMaj(imx.getDateDebut());
		compImx.setDatePhoto(imx.getDateDebut());
		compImx.setStatutEvt(StatutEvenement.ACT);
		compImx.setArriereLitige(false);
		compImx.setArriereTech(false);
		compImx.setMiseAJour(false);
		compImx.setIdentiteInitiale(ident);
		imx.addComplement(compImx);
		entityManager.persist(imx);

		ElementsDeCalcul edc = new ElementsDeCalcul();
		edc.setTiers(tiers);
		entityManager.persist(edc);

		ArriereSignificatif as = new ArriereSignificatif();
		as.setTiers(tiers);
		as.setDateDebut(LocalDate.now().minusDays(10));
		ComplementArriere complAS = new ComplementArriere();
		complAS.setEntree(edc);
		as.setComplement(complAS);
		entityManager.persist(as);

		// REF IMPACTEVT MDC
		RefImpactEvtMdc refImpact = new RefImpactEvtMdc();
		refImpact.setCodEvt("IF");
		refImpact.setCategorieSegment(Constant.TOUS_AUTRES);
		refImpact.setImpact("D");
		refImpact.setGraviteImpact("RX");
		refImpact.setDateDebut(LocalDate.now().minusDays(100));
		entityManager.persist(refImpact);

		// REF_CLI_SEG
		RefCliSeg refCliSeg = new RefCliSeg();
		refCliSeg.setCodSegCli("3200");
		refCliSeg.setLibSegCli("PARTICULIERS");
		refCliSeg.setCodSsClassCli("RETPAR");
		refCliSeg.setTopSuppr("N");
		entityManager.persist(refCliSeg);

		// REF_CLI_SS_CLASS
		RefCliSsClass refClassSsClass = new RefCliSsClass();
		refClassSsClass.setCodSsClassCli("RETPAR");
		refClassSsClass.setLibSsClassCli("PARTICULIERS");
		refClassSsClass.setCodClassCli("RET");
		refClassSsClass.setTopSuppr("N");
		refClassSsClass.setCodTypNot("PART");
		entityManager.persist(refClassSsClass);

		entityManager.flush();

		// Act
		LotIdTiersDTO lot = new LotIdTiersDTO(LocalDate.now());
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Assert
		StatutHistorise statut = statutTiersRepository.getStatutADate(tiers.getId(), LocalDate.now()).get(0);
		Assert.assertEquals(StatutTiers.DEFAUT, statut.getStatut());
		Assert.assertEquals("IF", statut.getMotif().getMotif());
		Assert.assertEquals("RX", statut.getGravite());
		Assert.assertEquals(LocalDate.now().minusDays(5), statut.getDateDebut());
	}
}

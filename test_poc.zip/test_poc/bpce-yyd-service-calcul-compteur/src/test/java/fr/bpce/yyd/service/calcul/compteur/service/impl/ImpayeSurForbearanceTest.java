package fr.bpce.yyd.service.calcul.compteur.service.impl;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import fr.bpce.yyd.commun.constantes.Constant;
import fr.bpce.yyd.commun.enums.StatutAuditEvenement;
import fr.bpce.yyd.commun.enums.StatutEvenement;
import fr.bpce.yyd.commun.enums.StatutTiers;
import fr.bpce.yyd.commun.messages.dto.LotIdTiersDTO;
import fr.bpce.yyd.commun.model.ArriereSignificatif;
import fr.bpce.yyd.commun.model.AuditCalcul;
import fr.bpce.yyd.commun.model.AuditFichiers;
import fr.bpce.yyd.commun.model.ComplementArriere;
import fr.bpce.yyd.commun.model.ComplementEvenement;
import fr.bpce.yyd.commun.model.ElementsDeCalcul;
import fr.bpce.yyd.commun.model.Evenement;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.ImpayeSurForbearance;
import fr.bpce.yyd.commun.model.MotifStatutTiers;
import fr.bpce.yyd.commun.model.PeriodeProbatoire;
import fr.bpce.yyd.commun.model.StatutHistorise;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.commun.model.reference.RefCliSeg;
import fr.bpce.yyd.commun.model.reference.RefCliSsClass;
import fr.bpce.yyd.commun.model.reference.RefImpactEvtMdc;
import fr.bpce.yyd.commun.repository.RefCliSsClassRepository;
import fr.bpce.yyd.commun.service.impl.RefCliSegServiceImpl;
import fr.bpce.yyd.service.commun.beans.EvenementsCalculesTiers;
import fr.bpce.yyd.service.commun.repository.AuditCalculRepository;
import fr.bpce.yyd.service.commun.repository.EvenementCalculeRepository;
import fr.bpce.yyd.service.commun.repository.EvenementImpactRepository;
import fr.bpce.yyd.service.commun.repository.EvenementRecuRepository;
import fr.bpce.yyd.service.commun.repository.IdentiteTiersRepository;
import fr.bpce.yyd.service.commun.repository.ParMdcBqSegRepository;
import fr.bpce.yyd.service.commun.repository.ParMdcSegRepository;
import fr.bpce.yyd.service.commun.repository.StatutTiersRepository;
import fr.bpce.yyd.service.commun.repository.TiersRepository;
import fr.bpce.yyd.service.commun.service.impl.AuditCalculServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.DefautServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.EvenementCalculeServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.EvenementImpactServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.EvenementRecuServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.IdentiteTiersServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.ParamMdcServiceImpl;
import fr.bpce.yyd.service.commun.service.impl.ParametresNDoDImpl;
import fr.bpce.yyd.service.commun.service.impl.RechercheTiersServiceImpl;

@RunWith(SpringRunner.class)
@DataJpaTest
@ActiveProfiles(profiles = "ti")
public class ImpayeSurForbearanceTest {

	@Autowired
	TestEntityManager entityManager;

	@Autowired
	TiersRepository tiersRepository;

	@Autowired
	IdentiteTiersRepository identiteTiersRepository;

	@Autowired
	EvenementCalculeRepository evtCalcRepository;

	@Autowired
	EvenementRecuRepository evtRecuRepository;

	@Autowired
	AuditCalculRepository auditCalculRepository;

	@Autowired
	StatutTiersRepository statutTiersRepository;

	@Autowired
	ParMdcSegRepository parMdcSegRepository;

	@Autowired
	ParMdcBqSegRepository parMdcBqSegRepository;

	@Autowired
	private EvenementImpactRepository evenementImpactRepository;

	@Autowired
	private RefCliSsClassRepository cliSsClassRepository;

	CalculCompteurServiceImpl ccService;

	EvenementCalculeServiceImpl ecService;

	AuditFichiers auditFichier;

	@Before
	public void assembleService() {
		ccService = new CalculCompteurServiceImpl();

		ParamMdcServiceImpl paramService = new ParamMdcServiceImpl();
		paramService.setParMdcBqSegRepository(parMdcBqSegRepository);
		paramService.setParMdcSegRepository(parMdcSegRepository);
		ParametresNDoDImpl parametresNDoD = new ParametresNDoDImpl();
		parametresNDoD.setParamService(paramService);

		RechercheTiersServiceImpl rtService = new RechercheTiersServiceImpl();
		rtService.setTiersRepository(tiersRepository);
		ccService.setRechercheTiersService(rtService);

		IdentiteTiersServiceImpl itService = new IdentiteTiersServiceImpl();
		itService.setIdentTiersRepository(identiteTiersRepository);

		AuditCalculServiceImpl acService = new AuditCalculServiceImpl();
		acService.setAuditCalculRepository(auditCalculRepository);
		ccService.setAuditCalculService(acService);
		ccService.setIdentiteTiersService(itService);
		ccService.setParamNDoD(parametresNDoD);

		ecService = new EvenementCalculeServiceImpl();
		ecService.setEvtCalculeRepository(evtCalcRepository);
		ecService.setIdentiteTiersService(itService);
		ecService.setAuditCalculService(acService);
		ecService.setParamsNDoD(parametresNDoD);
		ccService.setEvenementCalculeService(ecService);

		EvenementImpactServiceImpl impactService = new EvenementImpactServiceImpl();
		impactService.setEvenementImpactRepository(evenementImpactRepository);

		RefCliSegServiceImpl cliSegService = new RefCliSegServiceImpl();
		cliSegService.setCliSsClassRepository(cliSsClassRepository);

		EvenementRecuServiceImpl erService = new EvenementRecuServiceImpl();
		erService.setEvtRecuRepository(evtRecuRepository);
		erService.setCliSegService(cliSegService);
		erService.setImpactService(impactService);
		ccService.setEvenementRecuService(erService);

		DefautServiceImpl defautService = new DefautServiceImpl();
		defautService.setEvtCalculeService(ecService);
		defautService.setRechercheTiersService(rtService);
		defautService.setStatutTiersRepository(statutTiersRepository);
		defautService.setImpactService(impactService);
		defautService.setIdentiteTiersService(itService);
		defautService.setRefCliSegService(cliSegService);
		ccService.setDefautService(defautService);
	}

	@Test
	public void creationForbearance() {
		// Arrange
		String idContrat = "contratForbearance";
		Tiers tiers = initDonnees(idContrat, idContrat, LocalDate.now().minusDays(35), LocalDate.now().minusDays(32),
				LocalDate.now().minusDays(2));

		// Act
		LocalDate dateCalcul = LocalDate.now();
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalcul);
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Assert
		assertHasForbearance(tiers, dateCalcul, LocalDate.now().minusDays(2));
	}

	@Test
	public void sansArriereSignificatif() {
		// Arrange
		String idContrat = "contratForbearance";
		Tiers tiers = initDonnees(idContrat, idContrat, LocalDate.now().minusDays(35), LocalDate.now().minusDays(32),
				null);

		// Act
		LocalDate dateCalcul = LocalDate.now();
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalcul);
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Assert
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc = mapEvtsCalc.get(tiers.getId());
		Assert.assertNull(evtsCalc);
	}

	@Test
	public void surContratsDifferents() {
		// Arrange
		String idContratFor = "contratForbearance";
		String idContratImp = "contratImpaye";
		Tiers tiers = initDonnees(idContratFor, idContratImp, LocalDate.now().minusDays(35),
				LocalDate.now().minusDays(32), LocalDate.now().minusDays(2));

		// Act
		LocalDate dateCalcul = LocalDate.now();
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalcul);
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Assert
		assertHasNoForbearance(tiers, dateCalcul);
	}

	@Test
	public void impayeDe30Jours() {
		// Arrange
		String idContrat = "contratForbearance";
		Tiers tiers = initDonnees(idContrat, idContrat, LocalDate.now().minusDays(35), LocalDate.now().minusDays(30),
				LocalDate.now().minusDays(2));

		// Act
		LocalDate dateCalcul = LocalDate.now();
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalcul);
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Assert
		assertHasForbearance(tiers, dateCalcul, dateCalcul);
	}

	@Test
	public void impayeDeMoinsDe30Jours() {
		// Arrange
		String idContrat = "contratForbearance";
		Tiers tiers = initDonnees(idContrat, idContrat, LocalDate.now().minusDays(35), LocalDate.now().minusDays(20),
				LocalDate.now().minusDays(2));

		// Act
		LocalDate dateCalcul = LocalDate.now();
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalcul);
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);
		// Assert
		assertHasNoForbearance(tiers, dateCalcul);
	}

	@Test
	public void impayePrecedantLaForbearance() {
		// Arrange
		String idContrat = "contratForbearance";
		Tiers tiers = initDonnees(idContrat, idContrat, LocalDate.now().minusDays(35), LocalDate.now().minusDays(37),
				LocalDate.now().minusDays(2));

		// Act
		LocalDate dateCalcul = LocalDate.now();
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalcul);
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Assert
		assertHasNoForbearance(tiers, dateCalcul);
	}

	@Test
	public void impayeMemeDateQueForbearance() {
		// Arrange
		String idContrat = "contratForbearance";
		Tiers tiers = initDonnees(idContrat, idContrat, LocalDate.now().minusDays(35), LocalDate.now().minusDays(35),
				LocalDate.now().minusDays(2));

		// Act
		LocalDate dateCalcul = LocalDate.now();
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalcul);
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Assert
		assertHasNoForbearance(tiers, dateCalcul);
	}

	@Test
	public void sansForbearance() {
		// Arrange
		String idContrat = "contratImpaye";
		Tiers tiers = initDonnees(null, idContrat, null, LocalDate.now().minusDays(35), LocalDate.now().minusDays(2));

		// Act
		LocalDate dateCalcul = LocalDate.now();
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalcul);
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Assert
		assertHasNoForbearance(tiers, dateCalcul);
	}

	@Test
	public void sansImpaye() {
		// Arrange
		String idContrat = "contratForbearance";
		Tiers tiers = initDonnees(idContrat, null, LocalDate.now().minusDays(35), null, LocalDate.now().minusDays(2));

		// Act
		LocalDate dateCalcul = LocalDate.now();
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalcul);
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Assert
		assertHasNoForbearance(tiers, dateCalcul);
	}

	@Test
	public void plusieursImpayesSurForbearance() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);

		Tiers tiers = new Tiers();
		IdentiteTiers ident = new IdentiteTiers();
		ident.setCodeSegment("3200");
		ident.setIdLocal("abcd");
		ident.setCodeBanque("10107");
		ident.setDateDebut(LocalDate.now());
		tiers.addIdentite(ident);
		entityManager.persist(tiers);

		// Arriéré significatif
		ElementsDeCalcul edc = new ElementsDeCalcul();
		edc.setTiers(tiers);
		entityManager.persist(edc);

		ArriereSignificatif as = new ArriereSignificatif();
		as.setTiers(tiers);
		as.setDateDebut(LocalDate.now().minusDays(2));
		ComplementArriere complAS = new ComplementArriere();
		complAS.setEntree(edc);
		as.setComplement(complAS);
		entityManager.persist(as);

		// Deux événements de forbearance
		Evenement forbearance = new Evenement();
		forbearance.setCode("F");
		forbearance.setDateDebut(LocalDate.now().minusDays(35));
		forbearance.setIdContrat("contratForb1");
//		forbearance.setTiers(tiers);
		forbearance.setIdentiteInitiale(ident);

		ComplementEvenement compForb = new ComplementEvenement();
		compForb.setAuditFichier(fic);
		compForb.setDateMaj(forbearance.getDateDebut());
		compForb.setDatePhoto(forbearance.getDateDebut().plusDays(1));
		compForb.setStatutEvt(StatutEvenement.ACT);
		compForb.setArriereLitige(false);
		compForb.setArriereTech(false);
		compForb.setIdentiteInitiale(ident);
		forbearance.addComplement(compForb);
		entityManager.persist(forbearance);

		Evenement forbearance2 = new Evenement();
		forbearance2.setCode("F");
		forbearance2.setDateDebut(LocalDate.now().minusDays(45));
		forbearance2.setIdContrat("contratForb2");
//		forbearance2.setTiers(tiers);
		forbearance2.setIdentiteInitiale(ident);

		ComplementEvenement compForb2 = new ComplementEvenement();
		compForb2.setAuditFichier(fic);
		compForb2.setDateMaj(forbearance2.getDateDebut());
		compForb2.setDatePhoto(forbearance2.getDateDebut().plusDays(1));
		compForb2.setStatutEvt(StatutEvenement.ACT);
		compForb2.setArriereLitige(false);
		compForb2.setArriereTech(false);
		compForb2.setIdentiteInitiale(ident);
		forbearance2.addComplement(compForb2);
		entityManager.persist(forbearance2);

		// 3 événements d'impayé
		Evenement impaye = new Evenement();
		impaye.setCode("IMX");
		impaye.setDateDebut(forbearance.getDateDebut().plusDays(2));
		impaye.setIdContrat(forbearance.getIdContrat());
//		impaye.setTiers(tiers);
		impaye.setIdentiteInitiale(ident);

		ComplementEvenement compImp = new ComplementEvenement();
		compImp.setAuditFichier(fic);
		compImp.setDateMaj(impaye.getDateDebut());
		compImp.setDatePhoto(impaye.getDateDebut().plusDays(1));
		compImp.setStatutEvt(StatutEvenement.ACT);
		compImp.setArriereLitige(false);
		compImp.setArriereTech(false);
		compImp.setIdentiteInitiale(ident);
		impaye.addComplement(compImp);
		entityManager.persist(impaye);

		Evenement impaye2 = new Evenement();
		impaye2.setCode("IMX");
		impaye2.setDateDebut(forbearance2.getDateDebut().plusDays(4));
		impaye2.setIdContrat(forbearance2.getIdContrat());
//		impaye2.setTiers(tiers);
		impaye2.setIdentiteInitiale(ident);

		ComplementEvenement compImp2 = new ComplementEvenement();
		compImp2.setAuditFichier(fic);
		compImp2.setDateMaj(impaye2.getDateDebut());
		compImp2.setDatePhoto(impaye2.getDateDebut().plusDays(1));
		compImp2.setStatutEvt(StatutEvenement.ACT);
		compImp2.setArriereLitige(false);
		compImp2.setArriereTech(false);
		compImp2.setIdentiteInitiale(ident);
		impaye2.addComplement(compImp2);
		entityManager.persist(impaye2);

		Evenement impaye3 = new Evenement();
		impaye3.setCode("DAX");
		impaye3.setDateDebut(forbearance2.getDateDebut().plusDays(1));
		impaye3.setIdContrat(forbearance2.getIdContrat());
//		impaye3.setTiers(tiers);
		impaye3.setIdentiteInitiale(ident);

		ComplementEvenement compImp3 = new ComplementEvenement();
		compImp3.setAuditFichier(fic);
		compImp3.setDateMaj(impaye3.getDateDebut());
		compImp3.setDatePhoto(impaye3.getDateDebut().plusDays(1));
		compImp3.setStatutEvt(StatutEvenement.ACT);
		compImp3.setArriereLitige(false);
		compImp3.setArriereTech(false);
		compImp3.setIdentiteInitiale(ident);
		impaye3.addComplement(compImp3);
		entityManager.persist(impaye3);

		entityManager.flush();

		// Act
		LocalDate dateCalcul = LocalDate.now();
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalcul);
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Assert
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc = mapEvtsCalc.get(tiers.getId());
		Assert.assertNotNull(evtsCalc);
		Assert.assertEquals(2, evtsCalc.getImpayesSurForbearance().size());
	}

	@Test
	public void clotureForbearanceFinASCasLimite() {
		// Arrange
		// Création de l'impayé sur forbearance
		String idContrat = "contratForbearance";
		Tiers tiers = initDonnees(idContrat, idContrat, LocalDate.now().minusDays(45), LocalDate.now().minusDays(42),
				LocalDate.now().minusDays(20));

		LocalDate dateCalculForb = LocalDate.now().minusDays(10);
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalculForb);
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Changement des conditions - fin d'AS
		LocalDate dateSortieAS = LocalDate.now().minusDays(5);
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc = mapEvtsCalc.get(tiers.getId());
		evtsCalc.getArriereSignigicatif().setDateFin(dateSortieAS);
		ImpayeSurForbearance isf = evtsCalc.getImpayesSurForbearance().get(0);

		entityManager.flush();

		// Act
		LocalDate dateCalcul = dateSortieAS; // Cas limite
		lot.setDateCalcul(dateCalcul);
		ccService.traiteMessage(lot);

		// Assert
		Assert.assertEquals(dateSortieAS, isf.getDateFin());
	}

	@Test
	public void clotureForbearanceFinAS() {
		// Arrange
		// Création de l'impayé sur forbearance
		String idContrat = "contratForbearance";
		Tiers tiers = initDonnees(idContrat, idContrat, LocalDate.now().minusDays(45), LocalDate.now().minusDays(42),
				LocalDate.now().minusDays(20));

		LocalDate dateCalculForb = LocalDate.now().minusDays(10);
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalculForb);
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Changement des conditions - fin d'AS
		LocalDate dateSortieAS = LocalDate.now().minusDays(5);
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc = mapEvtsCalc.get(tiers.getId());
		evtsCalc.getArriereSignigicatif().setDateFin(dateSortieAS);
		ImpayeSurForbearance isf = evtsCalc.getImpayesSurForbearance().get(0);

		entityManager.flush();

		// Act
		LocalDate dateCalcul = dateSortieAS.plusDays(1);
		lot.setDateCalcul(dateCalcul);
		ccService.traiteMessage(lot);

		// Assert
		Assert.assertEquals(dateSortieAS, isf.getDateFin());
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc2 = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc2 = mapEvtsCalc2.get(tiers.getId());
		Assert.assertNotNull(evtsCalc2.getPeriodeProbatoire());
		Assert.assertEquals(dateSortieAS, evtsCalc2.getPeriodeProbatoire().getDateDebut());
	}

	@Test
	public void clotureForbearanceFinForbearanceCLO() {
		// Arrange
		// Création de l'impayé sur forbearance
		String idContrat = "contratForbearance";
		Tiers tiers = initDonnees(idContrat, idContrat, LocalDate.now().minusDays(45), LocalDate.now().minusDays(42),
				LocalDate.now().minusDays(20));

		LocalDate dateCalculForb = LocalDate.now().minusDays(10);
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalculForb);
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Changement des conditions - Sortie de forbearance - événement clos
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc = mapEvtsCalc.get(tiers.getId());
		ImpayeSurForbearance isf = evtsCalc.getImpayesSurForbearance().get(0);

		LocalDate dateSortieForb = LocalDate.now().minusDays(5);
		Evenement forbearance = isf.getComplement().getEvenementForbearance();
		ComplementEvenement premComplF = forbearance.getComplements().iterator().next();
		ComplementEvenement compForb = new ComplementEvenement();
		compForb.setAuditFichier(auditFichier);
		compForb.setDateMaj(dateSortieForb);
		compForb.setDatePhoto(dateSortieForb.plusDays(1));
		compForb.setStatutEvt(StatutEvenement.CLO);
		compForb.setMiseAJour(true);
		compForb.setArriereLitige(false);
		compForb.setArriereTech(false);
		compForb.setIdentiteInitiale(forbearance.getIdentiteInitiale());
		forbearance.addComplement(compForb);
		entityManager.persist(compForb);
		premComplF.setDateFin(compForb.getDateDebut());

		entityManager.flush();

		// Act
		LocalDate dateCalcul = compForb.getDateDebut().minusDays(1); // Cas limite - le jour avant
		lot.setDateCalcul(dateCalcul);
		ccService.traiteMessage(lot);

		// Assert
		Assert.assertNull(isf.getDateFin()); // Pas encore sortie

		// Act
		dateCalcul = compForb.getDateDebut(); // Cas limite - le jour même
		lot.setDateCalcul(dateCalcul);
		ccService.traiteMessage(lot);

		// Assert
		Assert.assertEquals(compForb.getDateDebut(), isf.getDateFin());
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc2 = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc2 = mapEvtsCalc2.get(tiers.getId());
		Assert.assertNotNull(evtsCalc2.getPeriodeProbatoire());
		Assert.assertEquals(compForb.getDateDebut(), evtsCalc2.getPeriodeProbatoire().getDateDebut());
	}

	@Test
	public void clotureForbearanceFinForbearanceFlagTechnique() {
		// Arrange
		// Création de l'impayé sur forbearance
		String idContrat = "contratForbearance";
		Tiers tiers = initDonnees(idContrat, idContrat, LocalDate.now().minusDays(45), LocalDate.now().minusDays(42),
				LocalDate.now().minusDays(20));

		LocalDate dateCalculForb = LocalDate.now().minusDays(10);
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalculForb);
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Changement des conditions - Sortie de forbearance - flag technique
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc = mapEvtsCalc.get(tiers.getId());
		ImpayeSurForbearance isf = evtsCalc.getImpayesSurForbearance().get(0);

		LocalDate dateSortieForb = LocalDate.now().minusDays(5);
		Evenement forbearance = isf.getComplement().getEvenementForbearance();
		ComplementEvenement premComplF = forbearance.getComplements().iterator().next();
		ComplementEvenement compForb = new ComplementEvenement();
		compForb.setAuditFichier(auditFichier);
		compForb.setDateMaj(dateSortieForb);
		compForb.setDatePhoto(dateSortieForb.plusDays(1));
		compForb.setStatutEvt(StatutEvenement.ACT);
		compForb.setMiseAJour(true);
		compForb.setArriereLitige(false);
		compForb.setArriereTech(true);
		compForb.setIdentiteInitiale(forbearance.getIdentiteInitiale());
		forbearance.addComplement(compForb);
		entityManager.persist(compForb);
		premComplF.setDateFin(compForb.getDateDebut());

		entityManager.flush();

		// Act
		LocalDate dateCalcul = compForb.getDateDebut().minusDays(1); // Cas limite - le jour avant
		lot.setDateCalcul(dateCalcul);
		ccService.traiteMessage(lot);

		// Assert
		Assert.assertNull(isf.getDateFin()); // Pas encore sortie

		// Act
		dateCalcul = compForb.getDateDebut(); // Cas limite - le jour même
		lot.setDateCalcul(dateCalcul);
		ccService.traiteMessage(lot);

		// Assert
		Assert.assertNull(isf.getDateFin());
	}

	@Test
	public void clotureForbearanceFinImpayeCLO() {
		// Arrange
		// Création de l'impayé sur forbearance
		String idContrat = "contratForbearance";
		Tiers tiers = initDonnees(idContrat, idContrat, LocalDate.now().minusDays(45), LocalDate.now().minusDays(42),
				LocalDate.now().minusDays(20));

		LocalDate dateCalculForb = LocalDate.now().minusDays(10);
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalculForb);
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Changement des conditions - Sortie de forbearance - événement clos
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc = mapEvtsCalc.get(tiers.getId());

		ImpayeSurForbearance isf = evtsCalc.getImpayesSurForbearance().get(0);
		LocalDate dateFinImp = LocalDate.now().minusDays(5);
		Evenement impaye = isf.getComplement().getEvenementImpaye();
		ComplementEvenement premComplI = impaye.getComplements().iterator().next();
		ComplementEvenement compFinImp = new ComplementEvenement();
		compFinImp.setAuditFichier(auditFichier);
		compFinImp.setDateMaj(dateFinImp);
		compFinImp.setDatePhoto(dateFinImp.plusDays(1));
		compFinImp.setStatutEvt(StatutEvenement.CLO);
		compFinImp.setMontantArriere(BigDecimal.ZERO);
		compFinImp.setMiseAJour(true);
		compFinImp.setArriereLitige(false);
		compFinImp.setArriereTech(false);
		compFinImp.setIdentiteInitiale(impaye.getIdentiteInitiale());
		impaye.addComplement(compFinImp);
		entityManager.persist(compFinImp);
		premComplI.setDateFin(compFinImp.getDateDebut());

		entityManager.flush();

		// Act
		LocalDate dateCalcul = compFinImp.getDateDebut().minusDays(1); // Cas limite - le jour avant
		lot.setDateCalcul(dateCalcul);
		ccService.traiteMessage(lot);

		// Assert
		Assert.assertNull(isf.getDateFin()); // Pas encore sortie

		// Act
		dateCalcul = compFinImp.getDateDebut(); // Cas limite - le jour même
		lot.setDateCalcul(dateCalcul);
		ccService.traiteMessage(lot);

		// Assert
		Assert.assertEquals(compFinImp.getDateDebut(), isf.getDateFin());

		lot.setDateCalcul(dateCalcul);
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc2 = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc2 = mapEvtsCalc2.get(tiers.getId());

		Assert.assertNotNull(evtsCalc2.getPeriodeProbatoire());
		Assert.assertEquals(compFinImp.getDateDebut(), evtsCalc2.getPeriodeProbatoire().getDateDebut());
	}

	@Test
	public void clotureForbearanceFinImpayeFlagLitige() {
		// Arrange
		// Création de l'impayé sur forbearance
		String idContrat = "contratForbearance";
		Tiers tiers = initDonnees(idContrat, idContrat, LocalDate.now().minusDays(45), LocalDate.now().minusDays(42),
				LocalDate.now().minusDays(20));

		LocalDate dateCalculForb = LocalDate.now().minusDays(10);
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalculForb);
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Changement des conditions - Sortie de forbearance - événement clos
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc = mapEvtsCalc.get(tiers.getId());
		ImpayeSurForbearance isf = evtsCalc.getImpayesSurForbearance().get(0);

		LocalDate dateFinImp = LocalDate.now().minusDays(5);
		Evenement impaye = isf.getComplement().getEvenementImpaye();
		ComplementEvenement premComplI = impaye.getComplements().iterator().next();
		ComplementEvenement compFinImp = new ComplementEvenement();
		compFinImp.setAuditFichier(auditFichier);
		compFinImp.setDateMaj(dateFinImp);
		compFinImp.setDatePhoto(dateFinImp.plusDays(1));
		compFinImp.setStatutEvt(StatutEvenement.ACT);
		compFinImp.setMiseAJour(true);
		compFinImp.setArriereLitige(true);
		compFinImp.setArriereTech(false);
		compFinImp.setIdentiteInitiale(impaye.getIdentiteInitiale());
		impaye.addComplement(compFinImp);
		entityManager.persist(compFinImp);
		premComplI.setDateFin(compFinImp.getDateDebut());

		entityManager.flush();

		// Act
		LocalDate dateCalcul = compFinImp.getDateDebut().minusDays(1); // Cas limite - le jour avant
		lot.setDateCalcul(dateCalcul);
		ccService.traiteMessage(lot);

		// Assert
		Assert.assertNull(isf.getDateFin()); // Pas encore sortie

		// Act
		dateCalcul = compFinImp.getDateDebut(); // Cas limite - le jour même
		lot.setDateCalcul(dateCalcul);
		ccService.traiteMessage(lot);

		// Assert
		Assert.assertEquals(compFinImp.getDateDebut(), isf.getDateFin());
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc2 = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc2 = mapEvtsCalc2.get(tiers.getId());
		Assert.assertNull(evtsCalc2.getPeriodeProbatoire());
		List<StatutHistorise> listStatutsActifs = statutTiersRepository.findAll().stream()
				.filter(s -> s.getDateFin() == null).collect(Collectors.toList());
		Assert.assertEquals(1, listStatutsActifs.size());
		Assert.assertEquals(StatutTiers.SAIN, listStatutsActifs.get(0).getStatut());
	}

	@Test
	public void clotureDUnSurPlusieursImpayesSurForbearance() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);

		Tiers tiers = new Tiers();
		IdentiteTiers ident = new IdentiteTiers();
		ident.setCodeSegment("3200");
		ident.setIdLocal("abcd");
		ident.setCodeBanque("10107");
		ident.setDateDebut(LocalDate.now());
		tiers.addIdentite(ident);
		entityManager.persist(tiers);

		// Arriéré significatif
		ElementsDeCalcul edc = new ElementsDeCalcul();
		edc.setTiers(tiers);
		entityManager.persist(edc);

		ArriereSignificatif as = new ArriereSignificatif();
		as.setTiers(tiers);
		as.setDateDebut(LocalDate.now().minusDays(2));
		ComplementArriere complAS = new ComplementArriere();
		complAS.setEntree(edc);
		as.setComplement(complAS);
		entityManager.persist(as);

		// Deux événements de forbearance
		Evenement forbearance = new Evenement();
		forbearance.setCode("F");
		forbearance.setDateDebut(LocalDate.now().minusDays(35));
		forbearance.setIdContrat("contratForb1");
//		forbearance.setTiers(tiers);
		forbearance.setIdentiteInitiale(ident);

		ComplementEvenement compForb = new ComplementEvenement();
		compForb.setAuditFichier(fic);
		compForb.setDateMaj(forbearance.getDateDebut());
		compForb.setDatePhoto(forbearance.getDateDebut().plusDays(1));
		compForb.setStatutEvt(StatutEvenement.ACT);
		compForb.setArriereLitige(false);
		compForb.setArriereTech(false);
		compForb.setIdentiteInitiale(ident);
		forbearance.addComplement(compForb);
		entityManager.persist(forbearance);

		Evenement forbearance2 = new Evenement();
		forbearance2.setCode("F");
		forbearance2.setDateDebut(LocalDate.now().minusDays(45));
		forbearance2.setIdContrat("contratForb2");
//		forbearance2.setTiers(tiers);
		forbearance2.setIdentiteInitiale(ident);

		ComplementEvenement compForb2 = new ComplementEvenement();
		compForb2.setAuditFichier(fic);
		compForb2.setDateMaj(forbearance2.getDateDebut());
		compForb2.setDatePhoto(forbearance2.getDateDebut().plusDays(1));
		compForb2.setStatutEvt(StatutEvenement.ACT);
		compForb2.setArriereLitige(false);
		compForb2.setArriereTech(false);
		compForb2.setIdentiteInitiale(ident);
		forbearance2.addComplement(compForb2);
		entityManager.persist(forbearance2);

		// 2 événements d'impayé
		Evenement impaye = new Evenement();
		impaye.setCode("IMX");
		impaye.setDateDebut(forbearance.getDateDebut().plusDays(2));
		impaye.setIdContrat(forbearance.getIdContrat());
//		impaye.setTiers(tiers);
		impaye.setIdentiteInitiale(ident);

		ComplementEvenement compImp = new ComplementEvenement();
		compImp.setAuditFichier(fic);
		compImp.setDateMaj(impaye.getDateDebut());
		compImp.setDatePhoto(impaye.getDateDebut().plusDays(1));
		compImp.setStatutEvt(StatutEvenement.ACT);
		compImp.setArriereLitige(false);
		compImp.setArriereTech(false);
		compImp.setIdentiteInitiale(ident);
		impaye.addComplement(compImp);
		entityManager.persist(impaye);

		Evenement impaye2 = new Evenement();
		impaye2.setCode("IMX");
		impaye2.setDateDebut(forbearance2.getDateDebut().plusDays(4));
		impaye2.setIdContrat(forbearance2.getIdContrat());
//		impaye2.setTiers(tiers);
		impaye2.setIdentiteInitiale(ident);

		ComplementEvenement compImp2 = new ComplementEvenement();
		compImp2.setAuditFichier(fic);
		compImp2.setDateMaj(impaye2.getDateDebut());
		compImp2.setDatePhoto(impaye2.getDateDebut().plusDays(1));
		compImp2.setStatutEvt(StatutEvenement.ACT);
		compImp2.setArriereLitige(false);
		compImp2.setArriereTech(false);
		compImp2.setIdentiteInitiale(ident);
		impaye2.addComplement(compImp2);
		entityManager.persist(impaye2);

		entityManager.flush();

		// Création des deux ISF
		LocalDate dateCalcul = LocalDate.now();
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalcul);
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Changement des conditions d'un des événements F
		LocalDate dateFinForb = LocalDate.now().plusDays(5);
		ComplementEvenement compForbFin = new ComplementEvenement();
		compForbFin.setAuditFichier(fic);
		compForbFin.setDateMaj(dateFinForb);
		compForbFin.setDatePhoto(dateFinForb.plusDays(1));
		compForbFin.setStatutEvt(StatutEvenement.CLO);
		compForbFin.setArriereLitige(false);
		compForbFin.setArriereTech(false);
		compForbFin.setIdentiteInitiale(ident);
		forbearance.addComplement(compForbFin);
		compForb.setDateFin(compForbFin.getDateDebut());
		entityManager.persist(compForbFin);

		entityManager.flush();

		// Clôture d'une des deux ISF
		dateCalcul = dateFinForb;
		lot.setDateCalcul(dateCalcul);
		ccService.traiteMessage(lot);

		// Assert
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc = mapEvtsCalc.get(tiers.getId());
		Assert.assertNotNull(evtsCalc);
		Assert.assertEquals(1, evtsCalc.getImpayesSurForbearance().size());
		Assert.assertNull(evtsCalc.getPeriodeProbatoire());
	}

	@Test
	public void clotureDePlusieursImpayesSurForbearance() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);

		Tiers tiers = new Tiers();
		IdentiteTiers ident = new IdentiteTiers();
		ident.setCodeSegment("3200");
		ident.setIdLocal("abcd");
		ident.setCodeBanque("10107");
		ident.setDateDebut(LocalDate.now());
		tiers.addIdentite(ident);
		entityManager.persist(tiers);

		// Arriéré significatif
		ElementsDeCalcul edc = new ElementsDeCalcul();
		edc.setTiers(tiers);
		entityManager.persist(edc);

		ArriereSignificatif as = new ArriereSignificatif();
		as.setTiers(tiers);
		as.setDateDebut(LocalDate.now().minusDays(2));
		ComplementArriere complAS = new ComplementArriere();
		complAS.setEntree(edc);
		as.setComplement(complAS);
		entityManager.persist(as);

		// Deux événements de forbearance
		Evenement forbearance = new Evenement();
		forbearance.setCode("F");
		forbearance.setDateDebut(LocalDate.now().minusDays(35));
		forbearance.setIdContrat("contratForb1");
		forbearance.setIdentiteInitiale(ident);

		ComplementEvenement compForb = new ComplementEvenement();
		compForb.setAuditFichier(fic);
		compForb.setDateMaj(forbearance.getDateDebut());
		compForb.setDatePhoto(forbearance.getDateDebut().plusDays(1));
		compForb.setStatutEvt(StatutEvenement.ACT);
		compForb.setArriereLitige(false);
		compForb.setArriereTech(false);
		compForb.setIdentiteInitiale(ident);
		forbearance.addComplement(compForb);
		entityManager.persist(forbearance);

		Evenement forbearance2 = new Evenement();
		forbearance2.setCode("F");
		forbearance2.setDateDebut(LocalDate.now().minusDays(45));
		forbearance2.setIdContrat("contratForb2");
		forbearance2.setIdentiteInitiale(ident);

		ComplementEvenement compForb2 = new ComplementEvenement();
		compForb2.setAuditFichier(fic);
		compForb2.setDateMaj(forbearance2.getDateDebut());
		compForb2.setDatePhoto(forbearance2.getDateDebut().plusDays(1));
		compForb2.setStatutEvt(StatutEvenement.ACT);
		compForb2.setArriereLitige(false);
		compForb2.setArriereTech(false);
		compForb2.setIdentiteInitiale(ident);
		forbearance2.addComplement(compForb2);
		entityManager.persist(forbearance2);

		// 2 événements d'impayé
		Evenement impaye = new Evenement();
		impaye.setCode("IMX");
		impaye.setDateDebut(forbearance.getDateDebut().plusDays(2));
		impaye.setIdContrat(forbearance.getIdContrat());
		impaye.setIdentiteInitiale(ident);

		ComplementEvenement compImp = new ComplementEvenement();
		compImp.setAuditFichier(fic);
		compImp.setDateMaj(impaye.getDateDebut());
		compImp.setDatePhoto(impaye.getDateDebut().plusDays(1));
		compImp.setStatutEvt(StatutEvenement.ACT);
		compImp.setArriereLitige(false);
		compImp.setArriereTech(false);
		compImp.setIdentiteInitiale(ident);
		impaye.addComplement(compImp);
		entityManager.persist(impaye);

		Evenement impaye2 = new Evenement();
		impaye2.setCode("IMX");
		impaye2.setDateDebut(forbearance2.getDateDebut().plusDays(4));
		impaye2.setIdContrat(forbearance2.getIdContrat());
		impaye2.setIdentiteInitiale(ident);

		ComplementEvenement compImp2 = new ComplementEvenement();
		compImp2.setAuditFichier(fic);
		compImp2.setDateMaj(impaye2.getDateDebut());
		compImp2.setDatePhoto(impaye2.getDateDebut().plusDays(1));
		compImp2.setStatutEvt(StatutEvenement.ACT);
		compImp2.setArriereLitige(false);
		compImp2.setArriereTech(false);
		compImp2.setIdentiteInitiale(ident);
		impaye2.addComplement(compImp2);
		entityManager.persist(impaye2);

		entityManager.flush();

		// Création des deux ISF
		LocalDate dateCalcul = LocalDate.now();
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalcul);
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Changement des conditions sur un événement F et un événement IMX
		LocalDate dateFinForb = LocalDate.now().plusDays(5);
		ComplementEvenement compForbFin = new ComplementEvenement();
		compForbFin.setAuditFichier(fic);
		compForbFin.setDateMaj(dateFinForb);
		compForbFin.setDatePhoto(dateFinForb.plusDays(1));
		compForbFin.setStatutEvt(StatutEvenement.CLO);
		compForbFin.setArriereLitige(false);
		compForbFin.setArriereTech(false);
		compForbFin.setIdentiteInitiale(ident);
		forbearance.addComplement(compForbFin);
		compForb.setDateFin(compForbFin.getDateDebut());
		entityManager.persist(compForbFin);
		entityManager.flush();

		// Clôture des du premier IF : J +5
		dateCalcul = dateFinForb.plusDays(1);
		lot.setDateCalcul(dateCalcul);
		ccService.traiteMessage(lot);

		LocalDate dateFinImp = dateFinForb.plusDays(2);
		ComplementEvenement compFinImp2 = new ComplementEvenement();
		compFinImp2.setAuditFichier(fic);
		compFinImp2.setDateMaj(dateFinImp);
		compFinImp2.setDatePhoto(dateFinImp.plusDays(1));
		compFinImp2.setStatutEvt(StatutEvenement.CLO);
		compFinImp2.setMontantArriere(BigDecimal.ZERO);
		compFinImp2.setMiseAJour(true);
		compFinImp2.setArriereLitige(false);
		compFinImp2.setArriereTech(false);
		compFinImp2.setIdentiteInitiale(ident);
		impaye2.addComplement(compFinImp2);
		compImp2.setDateFin(compFinImp2.getDateDebut());
		entityManager.persist(compFinImp2);

		entityManager.flush();

		// Clôture du deuxieme IF : J + 8 (impportant l'ordre). si traitement dans le
		// mauvais ordre, par de creation PP
		dateCalcul = compFinImp2.getDateDebut().plusDays(1);
		lot.setDateCalcul(dateCalcul);
		ccService.traiteMessage(lot);

		// Assert
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc = mapEvtsCalc.get(tiers.getId());
		Assert.assertNotNull(evtsCalc);
		Assert.assertTrue(evtsCalc.getImpayesSurForbearance().isEmpty());
		Assert.assertNotNull(evtsCalc.getPeriodeProbatoire());
		Assert.assertEquals(compFinImp2.getDateDebut(), evtsCalc.getPeriodeProbatoire().getDateDebut());
	}

	@Test
	public void creationIFSurPresencePPPosterieure() {
		// Arrange
		Tiers tiers = new Tiers();
		IdentiteTiers ident = new IdentiteTiers();
		ident.setIdLocal("11111113");
		ident.setCodeBanque("10107");
		ident.setCodeSegment("3200");
		ident.setDateDebut(LocalDate.now().minusDays(91));
		tiers.addIdentite(ident);
		entityManager.persist(tiers);

		Evenement forb = new Evenement();
		forb.setCode("F");
		forb.setDateDebut(LocalDate.now().minusDays(45));
		forb.setIdContrat("contrat111");
		forb.setIdentiteInitiale(ident);

		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persist(fic);

		ComplementEvenement compForb = new ComplementEvenement();
		compForb.setEvenement(forb);
		compForb.setAuditFichier(fic);
		compForb.setDateMaj(forb.getDateDebut());
		compForb.setDatePhoto(forb.getDateDebut().plusDays(1));
		compForb.setStatutEvt(StatutEvenement.ACT);
		compForb.setArriereLitige(false);
		compForb.setArriereTech(false);
		compForb.setMiseAJour(false);
		compForb.setIdentiteInitiale(ident);
		forb.addComplement(compForb);
		entityManager.persist(forb);

		Evenement imx = new Evenement();
		imx.setCode("IMX");
		imx.setDateDebut(LocalDate.now().minusDays(35));
		imx.setIdContrat("contrat111");
		imx.setIdentiteInitiale(ident);

		ComplementEvenement compImx = new ComplementEvenement();
		compImx.setEvenement(imx);
		compImx.setAuditFichier(fic);
		compImx.setDateMaj(imx.getDateDebut());
		compImx.setDatePhoto(imx.getDateDebut());
		compImx.setStatutEvt(StatutEvenement.ACT);
		compImx.setArriereLitige(false);
		compImx.setArriereTech(false);
		compImx.setMiseAJour(false);
		compImx.setIdentiteInitiale(ident);
		imx.addComplement(compImx);
		entityManager.persist(imx);

		ElementsDeCalcul edc = new ElementsDeCalcul();
		edc.setTiers(tiers);
		entityManager.persist(edc);

		ArriereSignificatif as = new ArriereSignificatif();
		as.setTiers(tiers);
		as.setDateDebut(LocalDate.now().minusDays(3));
		ComplementArriere complAS = new ComplementArriere();
		complAS.setEntree(edc);
		as.setComplement(complAS);
		entityManager.persist(as);

		PeriodeProbatoire pp = new PeriodeProbatoire();
		pp.setTiers(tiers);
		pp.setDateDebut(LocalDate.now());
		entityManager.persist(pp);

		AuditCalcul ac = new AuditCalcul();
		ac.setCode("PP");
		ac.setDateEffet(LocalDate.now());
		ac.setEvenementCalcule(pp);
		ac.setIdTiers(tiers.getId());
		ac.setStatut(StatutAuditEvenement.ACT);
		entityManager.persist(ac);

		StatutHistorise statutPP = new StatutHistorise();
		statutPP.setDateDeb(LocalDate.now());
		statutPP.setMotif(new MotifStatutTiers(pp));
		statutPP.setStatut(StatutTiers.DEFAUT);
		statutPP.setTiers(tiers);
		entityManager.persist(statutPP);

		entityManager.flush();

		// Act
		LocalDate dateCalcul = LocalDate.now();
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalcul);
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Assert
		StatutHistorise statutISF = statutTiersRepository.getStatutADate(tiers.getId(), LocalDate.now()).get(0);
		StatutHistorise statutPeriodeProbatoire = statutTiersRepository.findById(statutPP.getId()).get();
		Assert.assertEquals(StatutTiers.DEFAUT, statutISF.getStatut());
		Assert.assertEquals("IF", statutISF.getMotif().getMotif());
		Assert.assertEquals(LocalDate.now().minusDays(3), statutISF.getDateDebut());
		Assert.assertEquals("PP", statutPeriodeProbatoire.getMotif().getMotif());
		Assert.assertEquals(LocalDate.now(), statutPeriodeProbatoire.getDateDebut());
		Assert.assertEquals(LocalDate.now(), statutPeriodeProbatoire.getDateFin());
		Assert.assertEquals(LocalDate.now(), statutPeriodeProbatoire.getMotif().getPeriodeProbatoire().getDateDebut());
		Assert.assertEquals(LocalDate.now(), statutPeriodeProbatoire.getMotif().getPeriodeProbatoire().getDateFin());
	}

	@Test
	public void creationIFSurPresencePPAnterieure() {
		// Arrange
		Tiers tiers = new Tiers();
		IdentiteTiers ident = new IdentiteTiers();
		ident.setIdLocal("11111113");
		ident.setCodeBanque("10107");
		ident.setCodeSegment("3200");
		ident.setDateDebut(LocalDate.now().minusDays(91));
		tiers.addIdentite(ident);
		entityManager.persist(tiers);

		Evenement forb = new Evenement();
		forb.setCode("F");
		forb.setDateDebut(LocalDate.now().minusDays(45));
		forb.setIdContrat("contrat111");
		forb.setIdentiteInitiale(ident);

		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persist(fic);

		ComplementEvenement compForb = new ComplementEvenement();
		compForb.setEvenement(forb);
		compForb.setAuditFichier(fic);
		compForb.setDateMaj(forb.getDateDebut());
		compForb.setDatePhoto(forb.getDateDebut().plusDays(1));
		compForb.setStatutEvt(StatutEvenement.ACT);
		compForb.setArriereLitige(false);
		compForb.setArriereTech(false);
		compForb.setMiseAJour(false);
		compForb.setIdentiteInitiale(ident);
		forb.addComplement(compForb);
		entityManager.persist(forb);

		Evenement imx = new Evenement();
		imx.setCode("IMX");
		imx.setDateDebut(LocalDate.now().minusDays(35));
		imx.setIdContrat("contrat111");
		imx.setIdentiteInitiale(ident);

		ComplementEvenement compImx = new ComplementEvenement();
		compImx.setEvenement(imx);
		compImx.setAuditFichier(fic);
		compImx.setDateMaj(imx.getDateDebut());
		compImx.setDatePhoto(imx.getDateDebut());
		compImx.setStatutEvt(StatutEvenement.ACT);
		compImx.setArriereLitige(false);
		compImx.setArriereTech(false);
		compImx.setMiseAJour(false);
		compImx.setIdentiteInitiale(ident);
		imx.addComplement(compImx);
		entityManager.persist(imx);

		ElementsDeCalcul edc = new ElementsDeCalcul();
		edc.setTiers(tiers);
		entityManager.persist(edc);

		ArriereSignificatif as = new ArriereSignificatif();
		as.setTiers(tiers);
		as.setDateDebut(LocalDate.now().minusDays(3));
		ComplementArriere complAS = new ComplementArriere();
		complAS.setEntree(edc);
		as.setComplement(complAS);
		entityManager.persist(as);

		PeriodeProbatoire pp = new PeriodeProbatoire();
		pp.setTiers(tiers);
		pp.setDateDebut(LocalDate.now().minusDays(10));
		entityManager.persist(pp);

		AuditCalcul ac = new AuditCalcul();
		ac.setCode("PP");
		ac.setDateEffet(LocalDate.now().minusDays(10));
		ac.setEvenementCalcule(pp);
		ac.setIdTiers(tiers.getId());
		ac.setStatut(StatutAuditEvenement.ACT);
		entityManager.persist(ac);

		StatutHistorise statutPP = new StatutHistorise();
		statutPP.setDateDeb(LocalDate.now().minusDays(10));
		statutPP.setMotif(new MotifStatutTiers(pp));
		statutPP.setStatut(StatutTiers.DEFAUT);
		statutPP.setTiers(tiers);
		entityManager.persist(statutPP);

		entityManager.flush();

		// Act
		LocalDate dateCalcul = LocalDate.now();
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalcul);
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Assert
		StatutHistorise statutISF = statutTiersRepository.getStatutADate(tiers.getId(), LocalDate.now()).get(0);
		StatutHistorise statutPeriodeProbatoire = statutTiersRepository.findById(statutPP.getId()).get();
		Assert.assertEquals(StatutTiers.DEFAUT, statutISF.getStatut());
		Assert.assertEquals("IF", statutISF.getMotif().getMotif());
		Assert.assertEquals(LocalDate.now().minusDays(3), statutISF.getDateDebut());
		Assert.assertEquals("PP", statutPeriodeProbatoire.getMotif().getMotif());
		Assert.assertEquals(LocalDate.now().minusDays(10), statutPeriodeProbatoire.getDateDebut());
		Assert.assertEquals(LocalDate.now().minusDays(3), statutPeriodeProbatoire.getDateFin());
		Assert.assertEquals(LocalDate.now().minusDays(10),
				statutPeriodeProbatoire.getMotif().getPeriodeProbatoire().getDateDebut());
		Assert.assertEquals(LocalDate.now().minusDays(3),
				statutPeriodeProbatoire.getMotif().getPeriodeProbatoire().getDateFin());
	}

	@Test
	public void creationIFWithStatutSainPosterieure() {
		// Arrange
		Tiers tiers = new Tiers();
		IdentiteTiers ident = new IdentiteTiers();
		ident.setIdLocal("11111113");
		ident.setCodeBanque("10107");
		ident.setCodeSegment("3200");
		ident.setDateDebut(LocalDate.now().minusDays(91));
		tiers.addIdentite(ident);
		entityManager.persist(tiers);

		Evenement forb = new Evenement();
		forb.setCode("F");
		forb.setDateDebut(LocalDate.now().minusDays(45));
		forb.setIdContrat("contrat111");
		forb.setIdentiteInitiale(ident);

		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persist(fic);

		ComplementEvenement compForb = new ComplementEvenement();
		compForb.setEvenement(forb);
		compForb.setAuditFichier(fic);
		compForb.setDateMaj(forb.getDateDebut());
		compForb.setDatePhoto(forb.getDateDebut().plusDays(1));
		compForb.setStatutEvt(StatutEvenement.ACT);
		compForb.setArriereLitige(false);
		compForb.setArriereTech(false);
		compForb.setMiseAJour(false);
		compForb.setIdentiteInitiale(ident);
		forb.addComplement(compForb);
		entityManager.persist(forb);

		Evenement imx = new Evenement();
		imx.setCode("IMX");
		imx.setDateDebut(LocalDate.now().minusDays(35));
		imx.setIdContrat("contrat111");
		imx.setIdentiteInitiale(ident);

		ComplementEvenement compImx = new ComplementEvenement();
		compImx.setEvenement(imx);
		compImx.setAuditFichier(fic);
		compImx.setDateMaj(imx.getDateDebut());
		compImx.setDatePhoto(imx.getDateDebut());
		compImx.setStatutEvt(StatutEvenement.ACT);
		compImx.setArriereLitige(false);
		compImx.setArriereTech(false);
		compImx.setMiseAJour(false);
		compImx.setIdentiteInitiale(ident);
		imx.addComplement(compImx);
		entityManager.persist(imx);

		ElementsDeCalcul edc = new ElementsDeCalcul();
		edc.setTiers(tiers);
		entityManager.persist(edc);

		ArriereSignificatif as = new ArriereSignificatif();
		as.setTiers(tiers);
		as.setDateDebut(LocalDate.now().minusDays(3));
		ComplementArriere complAS = new ComplementArriere();
		complAS.setEntree(edc);
		as.setComplement(complAS);
		entityManager.persist(as);

		StatutHistorise statutSain = new StatutHistorise();
		statutSain.setDateDeb(LocalDate.now());
		statutSain.setStatut(StatutTiers.SAIN);
		statutSain.setTiers(tiers);
		entityManager.persist(statutSain);

		entityManager.flush();

		// Act
		LocalDate dateCalcul = LocalDate.now();
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalcul);
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Assert
		StatutHistorise statutISF = statutTiersRepository.getStatutADate(tiers.getId(), LocalDate.now()).get(0);
		StatutHistorise statutExistant = statutTiersRepository.findById(statutSain.getId()).get();
		Assert.assertEquals(StatutTiers.DEFAUT, statutISF.getStatut());
		Assert.assertEquals("IF", statutISF.getMotif().getMotif());
		Assert.assertEquals(StatutTiers.SAIN, statutExistant.getStatut());
		Assert.assertEquals(LocalDate.now().minusDays(3), statutISF.getDateDebut());
		Assert.assertEquals(LocalDate.now(), statutExistant.getDateDebut());
		Assert.assertEquals(LocalDate.now(), statutExistant.getDateFin());
	}

	@Test
	public void creationSimultaneeImpayesSurForbearanceEtAR3SurPresencePP() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);

		Tiers tiers = new Tiers();
		IdentiteTiers ident = new IdentiteTiers();
		ident.setCodeSegment("3200");
		ident.setIdLocal("abcd");
		ident.setCodeBanque("10107");
		ident.setDateDebut(LocalDate.now());
		tiers.addIdentite(ident);
		entityManager.persist(tiers);

		// Arriéré significatif
		ElementsDeCalcul edc = new ElementsDeCalcul();
		edc.setTiers(tiers);
		entityManager.persist(edc);

		ArriereSignificatif as = new ArriereSignificatif();
		as.setTiers(tiers);
		as.setDateDebut(LocalDate.now().minusDays(90));
		ComplementArriere complAS = new ComplementArriere();
		complAS.setEntree(edc);
		as.setComplement(complAS);
		entityManager.persist(as);

		// AuditCalcul
		PeriodeProbatoire pp = new PeriodeProbatoire();
		pp.setTiers(tiers);
		pp.setDateDebut(LocalDate.now().minusDays(50));
		entityManager.persist(pp);

		// Deux événements de forbearance
		Evenement forbearance = new Evenement();
		forbearance.setCode("F");
		forbearance.setDateDebut(LocalDate.now().minusDays(35));
		forbearance.setIdContrat("contratForb1");
		forbearance.setIdentiteInitiale(ident);

		ComplementEvenement compForb = new ComplementEvenement();
		compForb.setAuditFichier(fic);
		compForb.setDateMaj(forbearance.getDateDebut());
		compForb.setDatePhoto(forbearance.getDateDebut().plusDays(1));
		compForb.setStatutEvt(StatutEvenement.ACT);
		compForb.setArriereLitige(false);
		compForb.setArriereTech(false);
		compForb.setIdentiteInitiale(ident);
		forbearance.addComplement(compForb);
		entityManager.persist(forbearance);

		// 3 événements d'impayé
		Evenement impaye = new Evenement();
		impaye.setCode("IMX");
		impaye.setDateDebut(forbearance.getDateDebut().plusDays(2));
		impaye.setIdContrat(forbearance.getIdContrat());
		impaye.setIdentiteInitiale(ident);

		ComplementEvenement compImp = new ComplementEvenement();
		compImp.setAuditFichier(fic);
		compImp.setDateMaj(impaye.getDateDebut());
		compImp.setDatePhoto(impaye.getDateDebut().plusDays(1));
		compImp.setStatutEvt(StatutEvenement.ACT);
		compImp.setArriereLitige(false);
		compImp.setArriereTech(false);
		compImp.setIdentiteInitiale(ident);
		impaye.addComplement(compImp);
		entityManager.persist(impaye);

		entityManager.flush();

		// Act
		LocalDate dateCalcul = LocalDate.now();
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalcul);
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Assert
		List<AuditCalcul> listAudit = ((List<AuditCalcul>) auditCalculRepository.findAll()).stream()
				.filter(s -> "PP".equals(s.getCode())).collect(Collectors.toList());
		Assert.assertEquals(1, listAudit.size());
	}

	@Test
	public void plusieursImpayesAvecDateDifferentesSurMemeForbearance() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);

		Tiers tiers = new Tiers();
		IdentiteTiers ident = new IdentiteTiers();
		ident.setCodeSegment("3200");
		ident.setIdLocal("abcd");
		ident.setCodeBanque("10107");
		ident.setDateDebut(LocalDate.now());
		tiers.addIdentite(ident);
		entityManager.persist(tiers);

		// Arriéré significatif
		ElementsDeCalcul edc = new ElementsDeCalcul();
		edc.setTiers(tiers);
		entityManager.persist(edc);

		ArriereSignificatif as = new ArriereSignificatif();
		as.setTiers(tiers);
		as.setDateDebut(LocalDate.now().minusDays(3));
		ComplementArriere complAS = new ComplementArriere();
		complAS.setEntree(edc);
		as.setComplement(complAS);
		entityManager.persist(as);

		// Evénement de forbearance
		Evenement forbearance = new Evenement();
		forbearance.setCode("F");
		forbearance.setDateDebut(LocalDate.now().minusDays(60));
		forbearance.setIdContrat("contratForb1");
		forbearance.setIdentiteInitiale(ident);

		ComplementEvenement compForb = new ComplementEvenement();
		compForb.setAuditFichier(fic);
		compForb.setDateMaj(forbearance.getDateDebut());
		compForb.setDatePhoto(forbearance.getDateDebut());
		compForb.setStatutEvt(StatutEvenement.ACT);
		compForb.setArriereLitige(false);
		compForb.setArriereTech(false);
		compForb.setIdentiteInitiale(ident);
		forbearance.addComplement(compForb);
		entityManager.persist(forbearance);

		// 2 événements d'impayé
		Evenement impaye = new Evenement();
		impaye.setCode("IMX");
		impaye.setDateDebut(LocalDate.now().minusDays(12));
		impaye.setIdContrat(forbearance.getIdContrat());
		impaye.setIdentiteInitiale(ident);

		ComplementEvenement compImp = new ComplementEvenement();
		compImp.setAuditFichier(fic);
		compImp.setDateMaj(LocalDate.now().minusDays(4));
		compImp.setDatePhoto(LocalDate.now().minusDays(4));
		compImp.setStatutEvt(StatutEvenement.ACT);
		compImp.setArriereLitige(false);
		compImp.setArriereTech(false);
		compImp.setIdentiteInitiale(ident);
		impaye.addComplement(compImp);
		entityManager.persist(impaye);

		Evenement impaye2 = new Evenement();
		impaye2.setCode("IMX");
		impaye2.setDateDebut(LocalDate.now().minusDays(10));
		impaye2.setIdContrat(forbearance.getIdContrat());
		impaye2.setIdentiteInitiale(ident);

		ComplementEvenement compImp2 = new ComplementEvenement();
		compImp2.setAuditFichier(fic);
		compImp2.setDateMaj(LocalDate.now().minusDays(2));
		compImp2.setDatePhoto(LocalDate.now().minusDays(2));
		compImp2.setStatutEvt(StatutEvenement.ACT);
		compImp2.setArriereLitige(false);
		compImp2.setArriereTech(false);
		compImp2.setIdentiteInitiale(ident);
		impaye2.addComplement(compImp2);
		entityManager.persist(impaye2);

		entityManager.flush();

		// Act
		LocalDate dateCalcul = LocalDate.now().plusDays(35);
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalcul);
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Assert
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc = mapEvtsCalc.get(tiers.getId());
		Assert.assertNotNull(evtsCalc);
		Assert.assertEquals(1, evtsCalc.getImpayesSurForbearance().size());
		Assert.assertEquals(impaye.getDateDebut().plusDays(30),
				evtsCalc.getImpayesSurForbearance().get(0).getDateDebut());
	}

	@Test
	public void plusieursForbearancesAvecImpaye() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);

		Tiers tiers = new Tiers();
		IdentiteTiers ident = new IdentiteTiers();
		ident.setCodeSegment("3200");
		ident.setIdLocal("abcd");
		ident.setCodeBanque("10107");
		ident.setDateDebut(LocalDate.now());
		tiers.addIdentite(ident);
		entityManager.persist(tiers);

		// Arriéré significatif
		ElementsDeCalcul edc = new ElementsDeCalcul();
		edc.setTiers(tiers);
		entityManager.persist(edc);

		ArriereSignificatif as = new ArriereSignificatif();
		as.setTiers(tiers);
		as.setDateDebut(LocalDate.now().minusDays(15));
		ComplementArriere complAS = new ComplementArriere();
		complAS.setEntree(edc);
		as.setComplement(complAS);
		entityManager.persist(as);

		// Deux événements de forbearance
		Evenement forbearance = new Evenement();
		forbearance.setCode("F");
		forbearance.setDateDebut(LocalDate.now().minusDays(50));
		forbearance.setIdContrat("contratForb1");
		forbearance.setIdentiteInitiale(ident);

		ComplementEvenement compForb = new ComplementEvenement();
		compForb.setAuditFichier(fic);
		compForb.setDateMaj(LocalDate.now().minusDays(10));
		compForb.setDatePhoto(LocalDate.now().minusDays(10));
		compForb.setStatutEvt(StatutEvenement.ACT);
		compForb.setArriereLitige(false);
		compForb.setArriereTech(false);
		compForb.setIdentiteInitiale(ident);
		forbearance.addComplement(compForb);
		entityManager.persist(forbearance);

		// événement d'impayé
		Evenement impaye = new Evenement();
		impaye.setCode("IMX");
		impaye.setDateDebut(LocalDate.now().minusDays(40));
		impaye.setIdContrat(forbearance.getIdContrat());
		impaye.setIdentiteInitiale(ident);

		ComplementEvenement compImp = new ComplementEvenement();
		compImp.setAuditFichier(fic);
		compImp.setDateMaj(impaye.getDateDebut());
		compImp.setDatePhoto(impaye.getDateDebut());
		compImp.setStatutEvt(StatutEvenement.ACT);
		compImp.setArriereLitige(false);
		compImp.setArriereTech(false);
		compImp.setIdentiteInitiale(ident);
		impaye.addComplement(compImp);
		entityManager.persist(impaye);

		entityManager.flush();

		// Act
		LocalDate dateCalcul = LocalDate.now();
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalcul);
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Assert
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc = mapEvtsCalc.get(tiers.getId());
		Assert.assertNotNull(evtsCalc);
		Assert.assertEquals(1, evtsCalc.getImpayesSurForbearance().size());
		Assert.assertEquals(impaye.getDateDebut().plusDays(30),
				evtsCalc.getImpayesSurForbearance().get(0).getDateDebut());

		// Arrange 2
		Evenement forbearance2 = new Evenement();
		forbearance2.setCode("F");
		forbearance2.setDateDebut(LocalDate.now().minusDays(35));
		forbearance2.setIdContrat("contratForb1");
		forbearance2.setIdentiteInitiale(ident);

		ComplementEvenement compForb2 = new ComplementEvenement();
		compForb2.setAuditFichier(fic);
		compForb2.setDateMaj(LocalDate.now().minusDays(5));
		compForb2.setDatePhoto(LocalDate.now().minusDays(5));
		compForb2.setStatutEvt(StatutEvenement.ACT);
		compForb2.setArriereLitige(false);
		compForb2.setArriereTech(false);
		compForb2.setIdentiteInitiale(ident);
		forbearance2.addComplement(compForb2);
		entityManager.persist(forbearance2);
		entityManager.flush();

		// Act 2
		ccService.traiteMessage(lot);

		// Assert 2
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc2 = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc2 = mapEvtsCalc2.get(tiers.getId());
		Assert.assertNotNull(evtsCalc2);
		Assert.assertEquals(1, evtsCalc2.getImpayesSurForbearance().size());
		Assert.assertEquals(impaye.getDateDebut().plusDays(30),
				evtsCalc2.getImpayesSurForbearance().get(0).getDateDebut());
	}

	@Test
	public void CloPlusieursImpayesSurForbearance() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);

		Tiers tiers = new Tiers();
		IdentiteTiers ident = new IdentiteTiers();
		ident.setCodeSegment("3200");
		ident.setIdLocal("abcd");
		ident.setCodeBanque("10107");
		ident.setDateDebut(LocalDate.now());
		tiers.addIdentite(ident);
		entityManager.persist(tiers);

		// Arriéré significatif
		ElementsDeCalcul edc = new ElementsDeCalcul();
		edc.setTiers(tiers);
		entityManager.persist(edc);

		ArriereSignificatif as = new ArriereSignificatif();
		as.setTiers(tiers);
		as.setDateDebut(LocalDate.now().minusDays(2));
		ComplementArriere complAS = new ComplementArriere();
		complAS.setEntree(edc);
		as.setComplement(complAS);
		entityManager.persist(as);

		// Deux événements de forbearance
		Evenement forbearance = new Evenement();
		forbearance.setCode("F");
		forbearance.setDateDebut(LocalDate.now().minusDays(35));
		forbearance.setIdContrat("contratForb1");
		forbearance.setIdentiteInitiale(ident);

		ComplementEvenement compForb = new ComplementEvenement();
		compForb.setAuditFichier(fic);
		compForb.setDateMaj(forbearance.getDateDebut());
		compForb.setDatePhoto(forbearance.getDateDebut().plusDays(1));
		compForb.setStatutEvt(StatutEvenement.ACT);
		compForb.setArriereLitige(false);
		compForb.setArriereTech(false);
		compForb.setIdentiteInitiale(ident);
		forbearance.addComplement(compForb);
		entityManager.persist(forbearance);

		Evenement forbearance2 = new Evenement();
		forbearance2.setCode("F");
		forbearance2.setDateDebut(LocalDate.now().minusDays(45));
		forbearance2.setIdContrat("contratForb2");
		forbearance2.setIdentiteInitiale(ident);

		ComplementEvenement compForb2 = new ComplementEvenement();
		compForb2.setAuditFichier(fic);
		compForb2.setDateMaj(forbearance2.getDateDebut());
		compForb2.setDatePhoto(forbearance2.getDateDebut().plusDays(1));
		compForb2.setStatutEvt(StatutEvenement.ACT);
		compForb2.setArriereLitige(false);
		compForb2.setArriereTech(false);
		compForb2.setIdentiteInitiale(ident);
		forbearance2.addComplement(compForb2);
		entityManager.persist(forbearance2);

		// 3 événements d'impayé
		Evenement impaye = new Evenement();
		impaye.setCode("IMX");
		impaye.setDateDebut(forbearance.getDateDebut().plusDays(2));
		impaye.setIdContrat(forbearance.getIdContrat());
		impaye.setIdentiteInitiale(ident);

		ComplementEvenement compImp = new ComplementEvenement();
		compImp.setAuditFichier(fic);
		compImp.setDateMaj(impaye.getDateDebut());
		compImp.setDatePhoto(impaye.getDateDebut().plusDays(1));
		compImp.setStatutEvt(StatutEvenement.ACT);
		compImp.setArriereLitige(false);
		compImp.setArriereTech(false);
		compImp.setIdentiteInitiale(ident);
		impaye.addComplement(compImp);
		entityManager.persist(impaye);

		Evenement impaye2 = new Evenement();
		impaye2.setCode("IMX");
		impaye2.setDateDebut(forbearance2.getDateDebut().plusDays(4));
		impaye2.setIdContrat(forbearance2.getIdContrat());
		impaye2.setIdentiteInitiale(ident);

		ComplementEvenement compImp2 = new ComplementEvenement();
		compImp2.setAuditFichier(fic);
		compImp2.setDateMaj(impaye2.getDateDebut());
		compImp2.setDatePhoto(impaye2.getDateDebut().plusDays(1));
		compImp2.setStatutEvt(StatutEvenement.ACT);
		compImp2.setArriereLitige(false);
		compImp2.setArriereTech(false);
		compImp2.setIdentiteInitiale(ident);
		impaye2.addComplement(compImp2);
		entityManager.persist(impaye2);

		entityManager.flush();

		// Act
		LocalDate dateCalcul = LocalDate.now();
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalcul);
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Assert
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc = mapEvtsCalc.get(tiers.getId());
		Assert.assertNotNull(evtsCalc);
		Assert.assertEquals(2, evtsCalc.getImpayesSurForbearance().size());

		// Arrange 2
		ElementsDeCalcul edc2 = new ElementsDeCalcul();
		edc2.setTiers(tiers);
		entityManager.persist(edc2);

		as.setDateFin(LocalDate.now().plusDays(2));
		complAS.setSortie(edc2);
		entityManager.persist(as);

		entityManager.flush();

		// Act
		lot.setDateCalcul(LocalDate.now().plusDays(2));
		ccService.traiteMessage(lot);

		// Assert
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc2 = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc2 = mapEvtsCalc2.get(tiers.getId());
		Assert.assertNotNull(evtsCalc2);
		Assert.assertEquals(0, evtsCalc2.getImpayesSurForbearance().size());
		Assert.assertNotNull(evtsCalc2.getPeriodeProbatoire());

		// Act
		lot.setDateCalcul(LocalDate.now().plusDays(20));
		ccService.traiteMessage(lot);

		// Assert
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc3 = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc3 = mapEvtsCalc3.get(tiers.getId());
		Assert.assertNotNull(evtsCalc3);
		Assert.assertEquals(0, evtsCalc3.getImpayesSurForbearance().size());
		Assert.assertNotNull(evtsCalc3.getPeriodeProbatoire());

	}

	@Test
	public void casNonCreationIFpourUnTiersPartageSurMemeContrat() {
		// Arrange
		AuditFichiers fic = new AuditFichiers();
		fic = entityManager.persistAndFlush(fic);

		Tiers tiers1 = new Tiers();
		IdentiteTiers ident1 = new IdentiteTiers();
		ident1.setCodeSegment("3200");
		ident1.setIdLocal("idlocal1");
		ident1.setCodeBanque("10107");
		ident1.setDateDebut(LocalDate.now());
		tiers1.addIdentite(ident1);
		IdentiteTiers ident2 = new IdentiteTiers();
		ident2.setCodeSegment("3200");
		ident2.setIdLocal("idlocal2");
		ident2.setCodeBanque("11128");
		ident2.setDateDebut(LocalDate.now());
		tiers1.addIdentite(ident2);

		entityManager.persist(tiers1);

		// AS sur le tiers
		// Arriéré significatif sur le tiers
		ElementsDeCalcul elementT1 = new ElementsDeCalcul();
		elementT1.setTiers(tiers1);
		entityManager.persist(elementT1);

		ArriereSignificatif as = new ArriereSignificatif();
		as.setTiers(tiers1);
		as.setDateDebut(LocalDate.now().minusDays(2));
		ComplementArriere complAS = new ComplementArriere();
		complAS.setEntree(elementT1);
		as.setComplement(complAS);
		entityManager.persist(as);

		// Forbearance sur identité 2 avec contratForb1
		Evenement forbearance = new Evenement();
		forbearance.setCode("F");
		forbearance.setDateDebut(LocalDate.now().minusDays(35));
		forbearance.setIdContrat("contratForb1");
		forbearance.setIdentiteInitiale(ident2);

		ComplementEvenement compForb = new ComplementEvenement();
		compForb.setAuditFichier(fic);
		compForb.setDateMaj(forbearance.getDateDebut());
		compForb.setDatePhoto(forbearance.getDateDebut().plusDays(1));
		compForb.setStatutEvt(StatutEvenement.ACT);
		compForb.setArriereLitige(false);
		compForb.setArriereTech(false);
		compForb.setIdentiteInitiale(ident2);
		forbearance.addComplement(compForb);
		entityManager.persist(forbearance);

		// événements d'impayé sur identité 1 avec contratForb1
		Evenement impaye = new Evenement();
		impaye.setCode("IMX");
		impaye.setDateDebut(forbearance.getDateDebut().plusDays(2));
		impaye.setIdContrat("contratForb1");
		impaye.setIdentiteInitiale(ident1);

		ComplementEvenement compImp = new ComplementEvenement();
		compImp.setAuditFichier(fic);
		compImp.setDateMaj(impaye.getDateDebut());
		compImp.setDatePhoto(impaye.getDateDebut().plusDays(1));
		compImp.setStatutEvt(StatutEvenement.ACT);
		compImp.setArriereLitige(false);
		compImp.setArriereTech(false);
		compImp.setIdentiteInitiale(ident1);
		impaye.addComplement(compImp);
		entityManager.persist(impaye);
		entityManager.flush();

		// Act
		LocalDate dateCalcul = LocalDate.now();
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalcul);
		lot.addIdTiers(tiers1.getId());
		ccService.traiteMessage(lot);

		// Assert
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc = mapEvtsCalc.get(tiers1.getId());
		Assert.assertNotNull(evtsCalc);
		// pas d'IF crées
		Assert.assertEquals(0, evtsCalc.getImpayesSurForbearance().size());
	}

	@Test
	public void annulationImpayeForbearanceEvtForbearanceANN() {
		// Arrange
		String idContrat = "contratForbearance";
		Tiers tiers = initDonnees(idContrat, idContrat, LocalDate.now().minusDays(35), LocalDate.now().minusDays(32),
				LocalDate.now().minusDays(2));

		LocalDate dateCalculForb = LocalDate.now();
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalculForb);
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Assert
		assertHasForbearance(tiers, dateCalculForb, LocalDate.now().minusDays(2));

		// Annulation evenement forbearance
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc = mapEvtsCalc.get(tiers.getId());
		ImpayeSurForbearance isf = evtsCalc.getImpayesSurForbearance().get(0);

		LocalDate dateSortieForb = LocalDate.now().plusDays(5);
		annuleImpayeSurForbearance(isf, dateSortieForb);

		// Act 2
		LocalDate dateCalcul = dateSortieForb;
		lot.setDateCalcul(dateCalcul);
		ccService.traiteMessage(lot);

		// Assert 2
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc2 = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc2 = mapEvtsCalc2.get(tiers.getId());

		Assert.assertNull(evtsCalc2.getPeriodeProbatoire());
		Assert.assertTrue(evtsCalc2.getImpayesSurForbearance().isEmpty());

		List<StatutHistorise> listStatus = statutTiersRepository.findAll();
		List<StatutHistorise> statutAct = listStatus.stream().filter(s -> s.getDateFin() == null)
				.collect(Collectors.toList());
		Assert.assertEquals(1, statutAct.size());
		Assert.assertEquals(StatutTiers.SAIN, statutAct.get(0).getStatut());
		Assert.assertEquals(dateSortieForb, statutAct.get(0).getDateDebut());

		List<StatutHistorise> statutDefaut = listStatus.stream().filter(s -> StatutTiers.DEFAUT.equals(s.getStatut()))
				.collect(Collectors.toList());
		Assert.assertEquals(1, statutDefaut.size());
		Assert.assertEquals(Constant.EVENEMENT_IF, statutDefaut.get(0).getMotif().getMotif());
		Assert.assertEquals(dateSortieForb, statutDefaut.get(0).getDateFin());
		Assert.assertTrue(statutDefaut.get(0).getAnnule());
	}

	@Test
	public void annulationImpayeForbearanceEvtImpayeANN() {
		// Arrange
		String idContrat = "contratForbearance";
		Tiers tiers = initDonnees(idContrat, idContrat, LocalDate.now().minusDays(35), LocalDate.now().minusDays(32),
				LocalDate.now().minusDays(2));

		LocalDate dateCalculForb = LocalDate.now();
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalculForb);
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Assert
		assertHasForbearance(tiers, dateCalculForb, LocalDate.now().minusDays(2));

		// Annulation evenement forbearance
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc = mapEvtsCalc.get(tiers.getId());
		ImpayeSurForbearance isf = evtsCalc.getImpayesSurForbearance().get(0);

		LocalDate dateSortieForb = LocalDate.now().plusDays(5);
		Evenement impaye = isf.getComplement().getEvenementImpaye();
		ComplementEvenement premComplIMX = impaye.getComplements().iterator().next();
		ComplementEvenement compImpaye = new ComplementEvenement();
		compImpaye.setAuditFichier(auditFichier);
		compImpaye.setDateMaj(dateSortieForb);
		compImpaye.setDatePhoto(dateSortieForb.plusDays(1));
		compImpaye.setStatutEvt(StatutEvenement.ANN);
		compImpaye.setMiseAJour(true);
		compImpaye.setArriereLitige(false);
		compImpaye.setArriereTech(false);
		compImpaye.setIdentiteInitiale(impaye.getIdentiteInitiale());
		impaye.addComplement(compImpaye);
		entityManager.persist(compImpaye);
		premComplIMX.setDateFin(compImpaye.getDateDebut());

		entityManager.flush();

		// Act 2
		LocalDate dateCalcul = compImpaye.getDateDebut();
		lot.setDateCalcul(dateCalcul);
		ccService.traiteMessage(lot);

		// Assert 2
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc2 = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc2 = mapEvtsCalc2.get(tiers.getId());

		Assert.assertNull(evtsCalc2.getPeriodeProbatoire());
		Assert.assertTrue(evtsCalc2.getImpayesSurForbearance().isEmpty());

		List<StatutHistorise> listStatus = statutTiersRepository.findAll();
		List<StatutHistorise> statutAct = listStatus.stream().filter(s -> s.getDateFin() == null)
				.collect(Collectors.toList());
		Assert.assertEquals(1, statutAct.size());
		Assert.assertEquals(StatutTiers.SAIN, statutAct.get(0).getStatut());
		Assert.assertEquals(compImpaye.getDateDebut(), statutAct.get(0).getDateDebut());

		List<StatutHistorise> statutDefaut = listStatus.stream().filter(s -> StatutTiers.DEFAUT.equals(s.getStatut()))
				.collect(Collectors.toList());
		Assert.assertEquals(1, statutDefaut.size());
		Assert.assertEquals(Constant.EVENEMENT_IF, statutDefaut.get(0).getMotif().getMotif());
		Assert.assertEquals(compImpaye.getDateDebut(), statutDefaut.get(0).getDateFin());
		Assert.assertTrue(statutDefaut.get(0).getAnnule());
	}

	@Test
	public void annulationImpayeForbearanceEvtImpayeLitige() {
		// Arrange
		String idContrat = "contratForbearance";
		Tiers tiers = initDonnees(idContrat, idContrat, LocalDate.now().minusDays(35), LocalDate.now().minusDays(32),
				LocalDate.now().minusDays(2));

		LocalDate dateCalculForb = LocalDate.now();
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalculForb);
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Assert
		assertHasForbearance(tiers, dateCalculForb, LocalDate.now().minusDays(2));

		// Annulation evenement forbearance
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc = mapEvtsCalc.get(tiers.getId());
		ImpayeSurForbearance isf = evtsCalc.getImpayesSurForbearance().get(0);

		LocalDate dateSortieForb = LocalDate.now().plusDays(5);
		Evenement impaye = isf.getComplement().getEvenementImpaye();
		ComplementEvenement premComplIMX = impaye.getComplements().iterator().next();
		ComplementEvenement compImpaye = new ComplementEvenement();
		compImpaye.setAuditFichier(auditFichier);
		compImpaye.setDateMaj(dateSortieForb);
		compImpaye.setDatePhoto(dateSortieForb);
		compImpaye.setStatutEvt(StatutEvenement.ACT);
		compImpaye.setMiseAJour(true);
		compImpaye.setArriereLitige(true);
		compImpaye.setArriereTech(false);
		compImpaye.setIdentiteInitiale(impaye.getIdentiteInitiale());
		impaye.addComplement(compImpaye);
		entityManager.persist(compImpaye);
		premComplIMX.setDateFin(compImpaye.getDateDebut());

		entityManager.flush();

		// Act 2
		LocalDate dateCalcul = compImpaye.getDateDebut();
		lot.setDateCalcul(dateCalcul);
		ccService.traiteMessage(lot);

		// Assert 2
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc2 = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc2 = mapEvtsCalc2.get(tiers.getId());

		Assert.assertNull(evtsCalc2.getPeriodeProbatoire());
		Assert.assertTrue(evtsCalc2.getImpayesSurForbearance().isEmpty());

		List<StatutHistorise> listStatus = statutTiersRepository.findAll();
		List<StatutHistorise> statutAct = listStatus.stream().filter(s -> s.getDateFin() == null)
				.collect(Collectors.toList());
		Assert.assertEquals(1, statutAct.size());
		Assert.assertEquals(StatutTiers.SAIN, statutAct.get(0).getStatut());
		Assert.assertEquals(compImpaye.getDateDebut(), statutAct.get(0).getDateDebut());

		List<StatutHistorise> statutDefaut = listStatus.stream().filter(s -> StatutTiers.DEFAUT.equals(s.getStatut()))
				.collect(Collectors.toList());
		Assert.assertEquals(1, statutDefaut.size());
		Assert.assertEquals(Constant.EVENEMENT_IF, statutDefaut.get(0).getMotif().getMotif());
		Assert.assertEquals(compImpaye.getDateDebut(), statutDefaut.get(0).getDateFin());
		Assert.assertTrue(statutDefaut.get(0).getAnnule());
	}

	@Test
	public void nonAnnulationImpayeForbearanceEvtForbearanceLitige() {
		// Arrange
		String idContrat = "contratForbearance";
		Tiers tiers = initDonnees(idContrat, idContrat, LocalDate.now().minusDays(35), LocalDate.now().minusDays(32),
				LocalDate.now().minusDays(2));

		LocalDate dateCalculForb = LocalDate.now();
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalculForb);
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Assert
		assertHasForbearance(tiers, dateCalculForb, LocalDate.now().minusDays(2));

		// Annulation evenement forbearance
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc = mapEvtsCalc.get(tiers.getId());
		ImpayeSurForbearance isf = evtsCalc.getImpayesSurForbearance().get(0);

		LocalDate dateSortieForb = LocalDate.now().plusDays(5);
		Evenement forbearance = isf.getComplement().getEvenementForbearance();
		ComplementEvenement premComplF = forbearance.getComplements().iterator().next();
		ComplementEvenement compForb = new ComplementEvenement();
		compForb.setAuditFichier(auditFichier);
		compForb.setDateMaj(dateSortieForb);
		compForb.setDatePhoto(dateSortieForb.plusDays(1));
		compForb.setStatutEvt(StatutEvenement.ACT);
		compForb.setMiseAJour(true);
		compForb.setArriereLitige(true);
		compForb.setArriereTech(false);
		compForb.setIdentiteInitiale(forbearance.getIdentiteInitiale());
		forbearance.addComplement(compForb);
		entityManager.persist(compForb);
		premComplF.setDateFin(compForb.getDateDebut());

		entityManager.flush();

		// Act 2
		LocalDate dateCalcul = compForb.getDateDebut();
		lot.setDateCalcul(dateCalcul);
		ccService.traiteMessage(lot);

		// Assert 2
		assertHasForbearance(tiers, dateCalcul, LocalDate.now().minusDays(2));
	}

	@Test
	public void annulationImpayeForbearanceSurPresencePcoAct() {
		// Arrange
		String idContrat = "contratForbearance";
		Tiers tiers = initDonnees(idContrat, idContrat, LocalDate.now().minusDays(35), LocalDate.now().minusDays(32),
				LocalDate.now().minusDays(2));

		LocalDate dateCalculForb = LocalDate.now();
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalculForb);
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Assert
		assertHasForbearance(tiers, dateCalculForb, LocalDate.now().minusDays(2));

		// insertion d'un defaut PCO actif
		initDefautPcoAct(tiers, LocalDate.now().minusDays(10));

		// Annulation evenement forbearance
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc = mapEvtsCalc.get(tiers.getId());
		ImpayeSurForbearance isf = evtsCalc.getImpayesSurForbearance().get(0);

		LocalDate dateSortieForb = LocalDate.now().plusDays(5);
		annuleImpayeSurForbearance(isf, dateSortieForb);

		// Act 2
		LocalDate dateCalcul = dateSortieForb;
		lot.setDateCalcul(dateCalcul);
		ccService.traiteMessage(lot);

		// Assert 2
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc2 = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc2 = mapEvtsCalc2.get(tiers.getId());

		Assert.assertNull(evtsCalc2.getPeriodeProbatoire());
		Assert.assertTrue(evtsCalc2.getImpayesSurForbearance().isEmpty());

		List<StatutHistorise> listStatus = statutTiersRepository.findAll();
		List<StatutHistorise> statutAct = listStatus.stream().filter(s -> s.getDateFin() == null)
				.collect(Collectors.toList());
		Assert.assertEquals(1, statutAct.size());
		Assert.assertEquals(StatutTiers.DEFAUT, statutAct.get(0).getStatut());
		Assert.assertEquals("PCO", statutAct.get(0).getMotif().getMotif());
		Assert.assertEquals("CX", statutAct.get(0).getGravite());
		Assert.assertEquals(LocalDate.now().minusDays(10), statutAct.get(0).getDateDebut());

		List<StatutHistorise> statutDefaut = listStatus.stream().filter(s -> s.getDateFin() != null)
				.collect(Collectors.toList());
		Assert.assertEquals(1, statutDefaut.size());
		Assert.assertEquals(StatutTiers.DEFAUT, statutDefaut.get(0).getStatut());
		Assert.assertEquals(Constant.EVENEMENT_IF, statutDefaut.get(0).getMotif().getMotif());
		Assert.assertEquals(dateSortieForb, statutDefaut.get(0).getDateFin());
		Assert.assertTrue(statutDefaut.get(0).getAnnule());
	}

	@Test
	public void annulationImpayeForbearanceEnPresencePcoANN() {
		// Arrange
		String idContrat = "contratForbearance";
		Tiers tiers = initDonnees(idContrat, idContrat, LocalDate.now().minusDays(35), LocalDate.now().minusDays(32),
				LocalDate.now().minusDays(2));

		LocalDate dateCalculForb = LocalDate.now();
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalculForb);
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Assert
		assertHasForbearance(tiers, dateCalculForb, LocalDate.now().minusDays(2));

		// insertion d'un defaut PCO actif
		initDefautPcoAnn(tiers, LocalDate.now().minusDays(3));

		// Annulation evenement forbearance
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc = mapEvtsCalc.get(tiers.getId());
		ImpayeSurForbearance isf = evtsCalc.getImpayesSurForbearance().get(0);

		LocalDate dateSortieForb = LocalDate.now().plusDays(5);
		annuleImpayeSurForbearance(isf, dateSortieForb);

		// Act 2
		LocalDate dateCalcul = dateSortieForb;
		lot.setDateCalcul(dateCalcul);
		ccService.traiteMessage(lot);

		// Assert 2
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc2 = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc2 = mapEvtsCalc2.get(tiers.getId());

		Assert.assertNull(evtsCalc2.getPeriodeProbatoire());
		Assert.assertTrue(evtsCalc2.getImpayesSurForbearance().isEmpty());

		List<StatutHistorise> listStatus = statutTiersRepository.findAll();
		List<StatutHistorise> statutAct = listStatus.stream().filter(s -> s.getDateFin() == null)
				.collect(Collectors.toList());
		Assert.assertEquals(1, statutAct.size());
		Assert.assertEquals(StatutTiers.SAIN, statutAct.get(0).getStatut());
		Assert.assertEquals(dateSortieForb, statutAct.get(0).getDateDebut());

		List<StatutHistorise> statutDefaut = listStatus.stream()
				.filter(s -> s.getDateFin() != null && Constant.EVENEMENT_IF.equals(s.getMotif().getMotif()))
				.collect(Collectors.toList());
		Assert.assertEquals(1, statutDefaut.size());
		Assert.assertEquals(StatutTiers.DEFAUT, statutDefaut.get(0).getStatut());
		Assert.assertEquals(Constant.EVENEMENT_IF, statutDefaut.get(0).getMotif().getMotif());
		Assert.assertEquals(dateSortieForb, statutDefaut.get(0).getDateFin());
		Assert.assertTrue(statutDefaut.get(0).getAnnule());
	}

	@Test
	public void annulationImpayeForbearanceEnPresencePcoCLO() {
		// Arrange
		String idContrat = "contratForbearance";
		Tiers tiers = initDonnees(idContrat, idContrat, LocalDate.now().minusDays(35), LocalDate.now().minusDays(32),
				LocalDate.now().minusDays(2));

		LocalDate dateCalculForb = LocalDate.now();
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalculForb);
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Assert
		assertHasForbearance(tiers, dateCalculForb, LocalDate.now().minusDays(2));

		// insertion d'un defaut PCO actif
		initDefautPcoClo(tiers, LocalDate.now().minusDays(3));

		// Annulation evenement forbearance
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc = mapEvtsCalc.get(tiers.getId());
		ImpayeSurForbearance isf = evtsCalc.getImpayesSurForbearance().get(0);

		LocalDate dateSortieForb = LocalDate.now().plusDays(5);
		annuleImpayeSurForbearance(isf, dateSortieForb);

		// Act 2
		LocalDate dateCalcul = dateSortieForb;
		lot.setDateCalcul(dateCalcul);
		ccService.traiteMessage(lot);

		// Assert 2
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc2 = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc2 = mapEvtsCalc2.get(tiers.getId());

		Assert.assertNotNull(evtsCalc2.getPeriodeProbatoire());
		Assert.assertTrue(evtsCalc2.getImpayesSurForbearance().isEmpty());

		List<StatutHistorise> listStatus = statutTiersRepository.findAll();
		List<StatutHistorise> statutAct = listStatus.stream().filter(s -> s.getDateFin() == null)
				.collect(Collectors.toList());
		Assert.assertEquals(1, statutAct.size());
		Assert.assertEquals(StatutTiers.DEFAUT, statutAct.get(0).getStatut());
		Assert.assertEquals(Constant.EVENEMENT_PP, statutAct.get(0).getMotif().getMotif());
		Assert.assertEquals("CX", statutAct.get(0).getGravite());
		Assert.assertEquals(LocalDate.now().minusDays(1), statutAct.get(0).getDateDebut());

		List<StatutHistorise> statutDefaut = listStatus.stream()
				.filter(s -> s.getDateFin() != null && Constant.EVENEMENT_IF.equals(s.getMotif().getMotif()))
				.collect(Collectors.toList());
		Assert.assertEquals(1, statutDefaut.size());
		Assert.assertEquals(StatutTiers.DEFAUT, statutDefaut.get(0).getStatut());
		Assert.assertEquals(Constant.EVENEMENT_IF, statutDefaut.get(0).getMotif().getMotif());
		Assert.assertEquals(dateSortieForb, statutDefaut.get(0).getDateFin());
		Assert.assertTrue(statutDefaut.get(0).getAnnule());

		// Arrange 3 : cloture AS
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc3 = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc3 = mapEvtsCalc3.get(tiers.getId());
		ArriereSignificatif as = evtsCalc3.getArriereSignigicatif();
		as.setDateFin(LocalDate.now().plusDays(5));
		entityManager.flush();

		// Act 3 : retour en SAIN
		dateCalcul = LocalDate.now().plusDays(95);
		lot.setDateCalcul(dateCalcul);
		ccService.traiteMessage(lot);

		// Assert 3
		listStatus = statutTiersRepository.findAll();
		statutAct = listStatus.stream().filter(s -> s.getDateFin() == null).collect(Collectors.toList());
		Assert.assertEquals(1, statutAct.size());
		Assert.assertEquals(StatutTiers.SAIN, statutAct.get(0).getStatut());
		Assert.assertEquals(LocalDate.now().plusDays(95), statutAct.get(0).getDateDebut());
	}

	@Test
	public void annulationImpayeForbearanceApresPresencePcoCloPuisPP() {
		// Arrange
		String idContrat = "contratForbearance";
		Tiers tiers = initDonnees(idContrat, idContrat, LocalDate.now().minusDays(35), LocalDate.now().minusDays(32),
				LocalDate.now().minusDays(2));

		LocalDate dateCalculForb = LocalDate.now();
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalculForb);
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Assert
		assertHasForbearance(tiers, dateCalculForb, LocalDate.now().minusDays(2));

		// insertion d'un defaut PCO actif
		initDefautPcoCloPuisPP(tiers, LocalDate.now().minusDays(5));

		// Annulation evenement forbearance
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc = mapEvtsCalc.get(tiers.getId());
		ImpayeSurForbearance isf = evtsCalc.getImpayesSurForbearance().get(0);

		LocalDate dateSortieForb = LocalDate.now().plusDays(5);
		annuleImpayeSurForbearance(isf, dateSortieForb);

		// Act 2
		LocalDate dateCalcul = dateSortieForb;
		lot.setDateCalcul(dateCalcul);
		ccService.traiteMessage(lot);

		// Assert 2
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc2 = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc2 = mapEvtsCalc2.get(tiers.getId());

		Assert.assertNotNull(evtsCalc2.getPeriodeProbatoire());
		Assert.assertTrue(evtsCalc2.getImpayesSurForbearance().isEmpty());

		List<StatutHistorise> listStatus = statutTiersRepository.findAll();
		List<StatutHistorise> statutAct = listStatus.stream().filter(s -> s.getDateFin() == null)
				.collect(Collectors.toList());
		Assert.assertEquals(1, statutAct.size());
		Assert.assertEquals(StatutTiers.DEFAUT, statutAct.get(0).getStatut());
		Assert.assertEquals(Constant.EVENEMENT_PP, statutAct.get(0).getMotif().getMotif());
		Assert.assertEquals("CX", statutAct.get(0).getGravite());
		Assert.assertEquals(LocalDate.now().minusDays(3), statutAct.get(0).getDateDebut());

		List<StatutHistorise> statutDefaut = listStatus.stream()
				.filter(s -> s.getDateFin() != null && Constant.EVENEMENT_IF.equals(s.getMotif().getMotif()))
				.collect(Collectors.toList());
		Assert.assertEquals(1, statutDefaut.size());
		Assert.assertEquals(StatutTiers.DEFAUT, statutDefaut.get(0).getStatut());
		Assert.assertEquals(Constant.EVENEMENT_IF, statutDefaut.get(0).getMotif().getMotif());
		Assert.assertEquals(dateSortieForb, statutDefaut.get(0).getDateFin());
		Assert.assertTrue(statutDefaut.get(0).getAnnule());

		// Arrange 3 : cloture AS
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc3 = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc3 = mapEvtsCalc3.get(tiers.getId());
		ArriereSignificatif as = evtsCalc3.getArriereSignigicatif();
		as.setDateFin(LocalDate.now().plusDays(5));
		entityManager.flush();

		// Act 3 : retour en SAIN
		dateCalcul = LocalDate.now().plusDays(95);
		lot.setDateCalcul(dateCalcul);
		ccService.traiteMessage(lot);

		// Assert 3
		listStatus = statutTiersRepository.findAll();
		statutAct = listStatus.stream().filter(s -> s.getDateFin() == null).collect(Collectors.toList());
		Assert.assertEquals(1, statutAct.size());
		Assert.assertEquals(StatutTiers.SAIN, statutAct.get(0).getStatut());
		Assert.assertEquals(LocalDate.now().plusDays(94), statutAct.get(0).getDateDebut());
	}

	private void assertHasForbearance(Tiers tiers, LocalDate aDate, LocalDate debutantLe) {
		LotIdTiersDTO lot = new LotIdTiersDTO(aDate);
		lot.addIdTiers(tiers.getId());
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc = mapEvtsCalc.get(tiers.getId());
		Assert.assertNotNull(evtsCalc);
		Assert.assertEquals(1, evtsCalc.getImpayesSurForbearance().size());
		Assert.assertEquals(debutantLe, evtsCalc.getImpayesSurForbearance().get(0).getDateDebut());

		List<StatutHistorise> statutsCourants = statutTiersRepository.getStatutADate(tiers.getId(), aDate);
		Assert.assertTrue(statutsCourants.size() == 1);
		StatutHistorise statutCourant = statutsCourants.get(0);
		Assert.assertEquals(StatutTiers.DEFAUT, statutCourant.getStatut());
		Assert.assertEquals(Constant.EVENEMENT_IF, statutCourant.getMotif().getMotif());
		Assert.assertEquals(evtsCalc.getImpayesSurForbearance().get(0),
				statutCourant.getMotif().getImpayeSurForbearance());
	}

	private void assertHasNoForbearance(Tiers tiers, LocalDate aDate) {
		LotIdTiersDTO lot = new LotIdTiersDTO(aDate);
		lot.addIdTiers(tiers.getId());
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc = mapEvtsCalc.get(tiers.getId());

		Assert.assertNotNull(evtsCalc);
		Assert.assertTrue(evtsCalc.getImpayesSurForbearance().isEmpty());
	}

	private Tiers initDonnees(String idContratForb, String idContratImp, LocalDate dateDebutForb,
			LocalDate dateDebutImp, LocalDate dateAS) {
		auditFichier = new AuditFichiers();
		auditFichier = entityManager.persistAndFlush(auditFichier);

		Tiers tiers = new Tiers();
		IdentiteTiers ident = new IdentiteTiers();
		ident.setCodeSegment("3200");
		ident.setIdLocal("abcd");
		ident.setCodeBanque("10107");
		ident.setDateDebut(LocalDate.now().minusDays(100));
		tiers.addIdentite(ident);
		entityManager.persist(tiers);

		// Arriéré significatif
		if (dateAS != null) {
			ElementsDeCalcul edc = new ElementsDeCalcul();
			edc.setTiers(tiers);
			entityManager.persist(edc);

			ArriereSignificatif as = new ArriereSignificatif();
			as.setTiers(tiers);
			as.setDateDebut(dateAS);
			ComplementArriere complAS = new ComplementArriere();
			complAS.setEntree(edc);
			as.setComplement(complAS);
			entityManager.persist(as);
		}

		// Evenement forbearance
		if (idContratForb != null) {
			Evenement forbearance = new Evenement();
			forbearance.setCode("F");
			forbearance.setDateDebut(dateDebutForb);
			forbearance.setIdContrat(idContratForb);
//			forbearance.setTiers(tiers);
			forbearance.setIdentiteInitiale(ident);

			ComplementEvenement compForb = new ComplementEvenement();
			compForb.setAuditFichier(auditFichier);
			compForb.setDateMaj(forbearance.getDateDebut());
			compForb.setDatePhoto(forbearance.getDateDebut().plusDays(1));
			compForb.setStatutEvt(StatutEvenement.ACT);
			compForb.setArriereLitige(false);
			compForb.setArriereTech(false);
			compForb.setIdentiteInitiale(ident);
			forbearance.addComplement(compForb);
			entityManager.persist(forbearance);
		}

		// Evenement impayé
		if (idContratImp != null) {
			Evenement impaye = new Evenement();
			impaye.setCode("IMX");
			impaye.setDateDebut(dateDebutImp);
			impaye.setIdContrat(idContratImp);
//			impaye.setTiers(tiers);
			impaye.setIdentiteInitiale(ident);

			ComplementEvenement compImp = new ComplementEvenement();
			compImp.setAuditFichier(auditFichier);
			compImp.setDateMaj(impaye.getDateDebut());
			compImp.setDatePhoto(impaye.getDateDebut().plusDays(1));
			compImp.setStatutEvt(StatutEvenement.ACT);
			compImp.setArriereLitige(false);
			compImp.setArriereTech(false);
			compImp.setIdentiteInitiale(ident);
			impaye.addComplement(compImp);
			entityManager.persist(impaye);
		}

		// REF IMPACTEVT MDC
		RefImpactEvtMdc refImpact = new RefImpactEvtMdc();
		refImpact.setCodEvt("IF");
		refImpact.setCategorieSegment(Constant.TOUS_AUTRES);
		refImpact.setImpact("D");
		refImpact.setGraviteImpact("RX");
		refImpact.setDateDebut(LocalDate.now().minusDays(100));
		entityManager.persist(refImpact);

		// REF_CLI_SEG
		RefCliSeg refCliSeg = new RefCliSeg();
		refCliSeg.setCodSegCli("3200");
		refCliSeg.setLibSegCli("PARTICULIERS");
		refCliSeg.setCodSsClassCli("RETPAR");
		refCliSeg.setTopSuppr("N");
		entityManager.persist(refCliSeg);

		// REF_CLI_SS_CLASS
		RefCliSsClass refClassSsClass = new RefCliSsClass();
		refClassSsClass.setCodSsClassCli("RETPAR");
		refClassSsClass.setLibSsClassCli("PARTICULIERS");
		refClassSsClass.setCodClassCli("RET");
		refClassSsClass.setTopSuppr("N");
		refClassSsClass.setCodTypNot("PART");
		entityManager.persist(refClassSsClass);

		entityManager.flush();

		return tiers;
	}

	private LocalDate annuleImpayeSurForbearance(ImpayeSurForbearance isf, LocalDate dateSortieForb) {
		Evenement forbearance = isf.getComplement().getEvenementForbearance();
		ComplementEvenement premComplF = forbearance.getComplements().iterator().next();
		ComplementEvenement compForb = new ComplementEvenement();
		compForb.setAuditFichier(auditFichier);
		compForb.setDateMaj(dateSortieForb);
		compForb.setDatePhoto(dateSortieForb.plusDays(1));
		compForb.setStatutEvt(StatutEvenement.ANN);
		compForb.setMiseAJour(true);
		compForb.setArriereLitige(false);
		compForb.setArriereTech(false);
		compForb.setIdentiteInitiale(forbearance.getIdentiteInitiale());
		forbearance.addComplement(compForb);
		entityManager.persist(compForb);
		premComplF.setDateFin(compForb.getDateDebut());

		entityManager.flush();
		return dateSortieForb;
	}

	private Tiers initDefautPcoAct(Tiers tiers, LocalDate dateDefaut) {
		auditFichier = new AuditFichiers();
		auditFichier = entityManager.persistAndFlush(auditFichier);

		IdentiteTiers identite = tiers.getIdentites().iterator().next();

		Evenement pco = new Evenement();
		pco.setCode("PCO");
		pco.setDateDebut(dateDefaut);
		pco.setIdentiteInitiale(identite);
		entityManager.persist(pco);

		ComplementEvenement compPco = new ComplementEvenement();
		compPco.setAuditFichier(auditFichier);
		compPco.setDateMaj(pco.getDateDebut());
		compPco.setDatePhoto(pco.getDateDebut().plusDays(1));
		compPco.setStatutEvt(StatutEvenement.ACT);
		compPco.setArriereLitige(false);
		compPco.setArriereTech(false);
		compPco.setIdentiteInitiale(identite);
		pco.addComplement(compPco);
		entityManager.persist(compPco);

		StatutHistorise statutPCO = new StatutHistorise();
		statutPCO.setTiers(tiers);
		statutPCO.setStatut(StatutTiers.DEFAUT);
		statutPCO.setMotif(new MotifStatutTiers(compPco));
		statutPCO.setGravite("CX");
		statutPCO.setDateDeb(dateDefaut);
		statutPCO.setAnnule(false);
		entityManager.persist(statutPCO);

		entityManager.flush();

		return tiers;
	}

	private Tiers initDefautPcoAnn(Tiers tiers, LocalDate dateDefaut) {
		auditFichier = new AuditFichiers();
		auditFichier = entityManager.persistAndFlush(auditFichier);

		IdentiteTiers identite = tiers.getIdentites().iterator().next();

		Evenement pco = new Evenement();
		pco.setCode("PCO");
		pco.setDateDebut(dateDefaut);
		pco.setIdentiteInitiale(identite);
		entityManager.persist(pco);

		ComplementEvenement compPco = new ComplementEvenement();
		compPco.setAuditFichier(auditFichier);
		compPco.setDateMaj(pco.getDateDebut());
		compPco.setDatePhoto(pco.getDateDebut().plusDays(1));
		compPco.setStatutEvt(StatutEvenement.ACT);
		compPco.setArriereLitige(false);
		compPco.setArriereTech(false);
		compPco.setIdentiteInitiale(identite);
		pco.addComplement(compPco);
		entityManager.persist(compPco);

		StatutHistorise statutPCO = new StatutHistorise();
		statutPCO.setTiers(tiers);
		statutPCO.setStatut(StatutTiers.DEFAUT);
		statutPCO.setMotif(new MotifStatutTiers(compPco));
		statutPCO.setGravite("CX");
		statutPCO.setDateDeb(dateDefaut);
		statutPCO.setDateFin(dateDefaut.plusDays(2));
		statutPCO.setAnnule(true);
		entityManager.persist(statutPCO);

		entityManager.flush();

		return tiers;
	}

	private Tiers initDefautPcoClo(Tiers tiers, LocalDate dateDefaut) {
		auditFichier = new AuditFichiers();
		auditFichier = entityManager.persistAndFlush(auditFichier);

		IdentiteTiers identite = tiers.getIdentites().iterator().next();

		Evenement pco = new Evenement();
		pco.setCode("PCO");
		pco.setDateDebut(dateDefaut);
		pco.setIdentiteInitiale(identite);
		entityManager.persist(pco);

		ComplementEvenement compPco = new ComplementEvenement();
		compPco.setAuditFichier(auditFichier);
		compPco.setDateMaj(pco.getDateDebut());
		compPco.setDatePhoto(pco.getDateDebut().plusDays(1));
		compPco.setStatutEvt(StatutEvenement.ACT);
		compPco.setArriereLitige(false);
		compPco.setArriereTech(false);
		compPco.setIdentiteInitiale(identite);
		pco.addComplement(compPco);
		entityManager.persist(compPco);

		StatutHistorise statutPCO = new StatutHistorise();
		statutPCO.setTiers(tiers);
		statutPCO.setStatut(StatutTiers.DEFAUT);
		statutPCO.setMotif(new MotifStatutTiers(compPco));
		statutPCO.setGravite("CX");
		statutPCO.setDateDeb(dateDefaut);
		statutPCO.setDateFin(dateDefaut.plusDays(2));
		statutPCO.setAnnule(false);
		entityManager.persist(statutPCO);

		entityManager.flush();

		return tiers;
	}

	private Tiers initDefautPcoCloPuisPP(Tiers tiers, LocalDate dateDefaut) {
		auditFichier = new AuditFichiers();
		auditFichier = entityManager.persistAndFlush(auditFichier);

		IdentiteTiers identite = tiers.getIdentites().iterator().next();

		Evenement pco = new Evenement();
		pco.setCode("PCO");
		pco.setDateDebut(dateDefaut);
		pco.setIdentiteInitiale(identite);
		entityManager.persist(pco);

		ComplementEvenement compPco = new ComplementEvenement();
		compPco.setAuditFichier(auditFichier);
		compPco.setDateMaj(pco.getDateDebut());
		compPco.setDatePhoto(pco.getDateDebut().plusDays(1));
		compPco.setStatutEvt(StatutEvenement.ACT);
		compPco.setArriereLitige(false);
		compPco.setArriereTech(false);
		compPco.setIdentiteInitiale(identite);
		pco.addComplement(compPco);
		entityManager.persist(compPco);

		StatutHistorise statutPCO = new StatutHistorise();
		statutPCO.setTiers(tiers);
		statutPCO.setStatut(StatutTiers.DEFAUT);
		statutPCO.setMotif(new MotifStatutTiers(compPco));
		statutPCO.setGravite("CX");
		statutPCO.setDateDeb(dateDefaut);
		statutPCO.setDateFin(dateDefaut.plusDays(2));
		statutPCO.setAnnule(false);
		entityManager.persist(statutPCO);

		PeriodeProbatoire pp = new PeriodeProbatoire();
		pp.setTiers(tiers);
		pp.setDateDebut(statutPCO.getDateFin());
		pp.setDateFin(dateDefaut.plusDays(3));
		entityManager.persist(pp);

		StatutHistorise statutPP = new StatutHistorise();
		statutPP.setTiers(tiers);
		statutPP.setStatut(StatutTiers.DEFAUT);
		statutPP.setMotif(new MotifStatutTiers(pp));
		statutPP.setGravite("CX");
		statutPP.setDateDeb(statutPCO.getDateFin());
		statutPP.setDateFin(dateDefaut.plusDays(3));
		statutPP.setAnnule(false);
		entityManager.persist(statutPP);

		entityManager.flush();

		return tiers;
	}

	@Test
	public void clotureImpayeForbearanceDateFinPosterieureDateDebut() {
		// Arrange
		// Création de l'impayé sur forbearance
		String idContrat = "contratForbearance";
		Tiers tiers = initDonnees(idContrat, idContrat, LocalDate.now().minusDays(45), LocalDate.now().minusDays(42),
				LocalDate.now().minusDays(20));

		LocalDate dateCalculForb = LocalDate.now().minusDays(10);
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalculForb);
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Changement des conditions - Sortie de forbearance - événement clos
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc = mapEvtsCalc.get(tiers.getId());

		ImpayeSurForbearance isf = evtsCalc.getImpayesSurForbearance().get(0);
		LocalDate dateFinImp = LocalDate.now().minusDays(5);
		Evenement impaye = isf.getComplement().getEvenementImpaye();
		ComplementEvenement premComplI = impaye.getComplements().iterator().next();
		ComplementEvenement compFinImp = new ComplementEvenement();
		compFinImp.setAuditFichier(auditFichier);
		compFinImp.setDateMaj(dateFinImp);
		compFinImp.setDatePhoto(dateFinImp.plusDays(1));
		compFinImp.setStatutEvt(StatutEvenement.CLO);
		compFinImp.setMontantArriere(BigDecimal.ZERO);
		compFinImp.setMiseAJour(true);
		compFinImp.setArriereLitige(false);
		compFinImp.setArriereTech(false);
		compFinImp.setIdentiteInitiale(impaye.getIdentiteInitiale());
		impaye.addComplement(compFinImp);
		entityManager.persist(compFinImp);
		premComplI.setDateFin(compFinImp.getDateDebut());

		entityManager.flush();

		// Act
		LocalDate dateCalcul = LocalDate.now();
		lot.setDateCalcul(dateCalcul);
		ccService.traiteMessage(lot);

		// Assert
		Assert.assertEquals(compFinImp.getDateDebut(), isf.getDateFin());

		lot.setDateCalcul(dateCalcul);
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc2 = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc2 = mapEvtsCalc2.get(tiers.getId());

		Assert.assertNotNull(evtsCalc2.getPeriodeProbatoire());
		Assert.assertEquals(compFinImp.getDateDebut(), evtsCalc2.getPeriodeProbatoire().getDateDebut());
	}

	@Test
	public void clotureImpayeForbearanceDateFinAnterieureDateDebut() {
		// Arrange
		// Création de l'impayé sur forbearance
		String idContrat = "contratForbearance";
		Tiers tiers = initDonnees(idContrat, idContrat, LocalDate.now().minusDays(45), LocalDate.now().minusDays(42),
				LocalDate.now().minusDays(20));

		LocalDate dateCalculForb = LocalDate.now().minusDays(10);
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalculForb);
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Changement des conditions - Sortie de forbearance - événement clos
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc = mapEvtsCalc.get(tiers.getId());

		ImpayeSurForbearance isf = evtsCalc.getImpayesSurForbearance().get(0);
		LocalDate dateFinImp = LocalDate.now().minusDays(15);
		Evenement impaye = isf.getComplement().getEvenementImpaye();
		ComplementEvenement premComplI = impaye.getComplements().iterator().next();
		ComplementEvenement compFinImp = new ComplementEvenement();
		compFinImp.setAuditFichier(auditFichier);
		compFinImp.setDateMaj(dateFinImp);
		compFinImp.setDatePhoto(dateFinImp.plusDays(1));
		compFinImp.setStatutEvt(StatutEvenement.CLO);
		compFinImp.setMontantArriere(BigDecimal.ZERO);
		compFinImp.setMiseAJour(true);
		compFinImp.setArriereLitige(false);
		compFinImp.setArriereTech(false);
		compFinImp.setIdentiteInitiale(impaye.getIdentiteInitiale());
		impaye.addComplement(compFinImp);
		entityManager.persist(compFinImp);
		premComplI.setDateFin(compFinImp.getDateDebut());

		entityManager.flush();

		// Act
		LocalDate dateCalcul = LocalDate.now();
		lot.setDateCalcul(dateCalcul);
		ccService.traiteMessage(lot);

		// Assert
		Assert.assertEquals(dateCalcul, isf.getDateFin());

		lot.setDateCalcul(dateCalcul);
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc2 = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc2 = mapEvtsCalc2.get(tiers.getId());

		Assert.assertNotNull(evtsCalc2.getPeriodeProbatoire());
		Assert.assertEquals(dateCalcul, evtsCalc2.getPeriodeProbatoire().getDateDebut());
	}

	@Test
	public void clotureImpayeForbearanceDateFinEgaleDateDebut() {
		// Arrange
		// Création de l'impayé sur forbearance
		String idContrat = "contratForbearance";
		Tiers tiers = initDonnees(idContrat, idContrat, LocalDate.now().minusDays(45), LocalDate.now().minusDays(42),
				LocalDate.now().minusDays(20));

		LocalDate dateCalculForb = LocalDate.now().minusDays(10);
		LotIdTiersDTO lot = new LotIdTiersDTO(dateCalculForb);
		lot.addIdTiers(tiers.getId());
		ccService.traiteMessage(lot);

		// Changement des conditions - Sortie de forbearance - événement clos
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc = mapEvtsCalc.get(tiers.getId());

		ImpayeSurForbearance isf = evtsCalc.getImpayesSurForbearance().get(0);
		LocalDate dateFinImp = isf.getDateDebut();
		Evenement impaye = isf.getComplement().getEvenementImpaye();
		ComplementEvenement premComplI = impaye.getComplements().iterator().next();
		ComplementEvenement compFinImp = new ComplementEvenement();
		compFinImp.setAuditFichier(auditFichier);
		compFinImp.setDateMaj(dateFinImp);
		compFinImp.setDatePhoto(dateFinImp.plusDays(1));
		compFinImp.setStatutEvt(StatutEvenement.CLO);
		compFinImp.setMontantArriere(BigDecimal.ZERO);
		compFinImp.setMiseAJour(true);
		compFinImp.setArriereLitige(false);
		compFinImp.setArriereTech(false);
		compFinImp.setIdentiteInitiale(impaye.getIdentiteInitiale());
		impaye.addComplement(compFinImp);
		entityManager.persist(compFinImp);
		premComplI.setDateFin(compFinImp.getDateDebut());

		entityManager.flush();

		// Act
		LocalDate dateCalcul = LocalDate.now();
		lot.setDateCalcul(dateCalcul);
		ccService.traiteMessage(lot);

		// Assert
		Assert.assertEquals(compFinImp.getDateDebut(), isf.getDateFin());

		lot.setDateCalcul(dateCalcul);
		Map<Long, EvenementsCalculesTiers> mapEvtsCalc2 = ecService.rechercheEvenementsCalculesActifsADate(lot);
		EvenementsCalculesTiers evtsCalc2 = mapEvtsCalc2.get(tiers.getId());

		Assert.assertNotNull(evtsCalc2.getPeriodeProbatoire());
		Assert.assertEquals(compFinImp.getDateDebut(), evtsCalc2.getPeriodeProbatoire().getDateDebut());
	}
}

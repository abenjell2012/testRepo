package fr.bpce.yyd.service.simulateur.encours.notation.kafka.service.impl;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;

import fr.bpce.yyd.service.commun.yyc.constant.KafkaConstant;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.DemandeEncours;
import fr.bpce.yyd.service.simulateur.encours.notation.kafka.service.KafkaDemandeEncours;
import fr.bpce.yyd.service.simulateur.encours.notation.service.EncoursService;

@Service("demandeEncours")
@ConditionalOnProperty(value = "kafka.actif", havingValue = "true", matchIfMissing = false)
public class KafkaDemandeEncoursImpl implements KafkaDemandeEncours {

	private static final Logger LOG = LoggerFactory.getLogger(KafkaDemandeEncoursImpl.class);

	@Value("${folders.demandeEncours}")
	private String demandeEncoursFolder;

	@Autowired
	private EncoursService serviceEncours;

	ObjectMapper mapper = new ObjectMapper();

	@KafkaListener(topics = "${kafka.consumers.demandesEncours.topic}", groupId = "${kafka.consumers.demandesEncours.groupId}", containerFactory = "consumerDemandeEncours")
	@Override
	public void receive(@Payload DemandeEncours data, @Header(KafkaConstant.MSGID_HEADER) String msgId,
			@Header(KafkaHeaders.RECEIVED_MESSAGE_KEY) String msgKey,
			@Header(KafkaConstant.ISSUER_HEADER) String issuer, @Header(KafkaHeaders.RECEIVED_TOPIC) String topic)
			throws IOException {
		LOG.info("Reception DemandeEncours avec {msgId={}, dateArreteMensuelle={}, issuer={}}", msgId,
				data.getDateEncours(), issuer);

		Path encoursFolder = Paths.get(demandeEncoursFolder);
		String jsonString = mapper.writeValueAsString(data);

		Path outPath = encoursFolder.resolve(msgId + ".json");
		Files.createDirectories(outPath.getParent());

		Files.write(outPath, jsonString.getBytes());

		serviceEncours.generateAndSendEncoursTiers(data, msgId, issuer, KafkaConstant.APPLI_YYC);

	}

}

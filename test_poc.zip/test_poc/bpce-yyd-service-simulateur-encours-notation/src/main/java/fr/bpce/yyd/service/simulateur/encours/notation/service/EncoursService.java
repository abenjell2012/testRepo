package fr.bpce.yyd.service.simulateur.encours.notation.service;

import fr.bpce.yyd.service.commun.yyc.kafka.dto.DemandeEncours;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.ReponseEncours;

/**
 * Interface du service pour l'obtention des encours d'un tiers.
 */
public interface EncoursService {

	ReponseEncours generateEncoursTiers(DemandeEncours data);

	void generateAndSendEncoursTiers(DemandeEncours data, String msgId, String issuer, String provider);

}

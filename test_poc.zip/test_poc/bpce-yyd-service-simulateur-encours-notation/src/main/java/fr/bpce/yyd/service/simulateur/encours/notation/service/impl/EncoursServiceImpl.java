package fr.bpce.yyd.service.simulateur.encours.notation.service.impl;

import java.math.BigDecimal;
import java.security.SecureRandom;
import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

import fr.bpce.yyd.service.commun.yyc.kafka.dto.DemandeEncours;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.DemandeEncoursTiers;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.ReponseEncours;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.ReponseEncoursTiers;
import fr.bpce.yyd.service.simulateur.encours.notation.kafka.service.KafkaEncoursTiers;
import fr.bpce.yyd.service.simulateur.encours.notation.service.EncoursService;

@Service
@ConditionalOnProperty(value = "kafka.actif", havingValue = "true", matchIfMissing = false)
public class EncoursServiceImpl implements EncoursService {

	@Value(value = "${reponseEncoursBehavior.withCodeErreur}")
	private boolean withCodeError;

	@Value(value = "${reponseEncoursBehavior.withNotfound}")
	private boolean withNotFound;

	@Value(value = "${reponseEncoursBehavior.amountGeneration.minAmount}")
	private BigDecimal minAmount;

	@Value(value = "${reponseEncoursBehavior.amountGeneration.maxAmount}")
	private BigDecimal maxAmount;

	@Autowired
	KafkaEncoursTiers producerEncoursTiers;

	@Override
	public ReponseEncours generateEncoursTiers(DemandeEncours data) {
		ReponseEncours response = null;
		if (withCodeError) {
			response = new ReponseEncours(data.getDateEncours(), data.getDateEncours(), true);
			response.setDateTraitement(LocalDateTime.now());
			response.setMessageErreur("DB error");
			response.setCodeErreur("ERR_XX");
		} else if (withNotFound) {
			response = new ReponseEncours(data.getDateEncours(), data.getDateEncours(), false);
			response.setDateTraitement(LocalDateTime.now());
			for (DemandeEncoursTiers ddmEncoursTiers : data.getListTiers()) {
				ReponseEncoursTiers rpEncours = new ReponseEncoursTiers();
				rpEncours.setStatutRejet(true);
				rpEncours.setCodeRejet("E_CF201");
				rpEncours.setMessageRejet("client " + ddmEncoursTiers.getIdLocal() + " non trouve ");
				rpEncours.setIdRft(ddmEncoursTiers.getIdFederal());
				rpEncours.setClientId(ddmEncoursTiers.getIdLocal());
				rpEncours.setCodeFournisseur(ddmEncoursTiers.getCodeBanque());
				rpEncours.setTypeAgregat(ddmEncoursTiers.getTypeAgregat());
				response.getEncoursTiers().add(rpEncours);
			}
		} else {
			response = new ReponseEncours(data.getDateEncours(), data.getDateEncours(), false);
			response.setDateTraitement(LocalDateTime.now());
			for (DemandeEncoursTiers ddmEncoursTiers : data.getListTiers()) {
				ReponseEncoursTiers rpEncours = new ReponseEncoursTiers();
				rpEncours.setStatutRejet(false);
				rpEncours.setTypeAgregat(ddmEncoursTiers.getTypeAgregat());
				rpEncours.setIdRft(ddmEncoursTiers.getIdFederal());
				rpEncours.setClientId(ddmEncoursTiers.getIdLocal());
				rpEncours.setCodeFournisseur(ddmEncoursTiers.getCodeBanque());
				rpEncours.setMntEngBrutBil(generateRandomAmountFromRange());
				rpEncours.setMntEngBrut(generateRandomAmountFromRange());
				rpEncours.setMntEngBrutHbil(generateRandomAmountFromRange());
				rpEncours.setTopEng(true);
				response.getEncoursTiers().add(rpEncours);
			}

		}
		return response;

	}

	@Override
	public void generateAndSendEncoursTiers(DemandeEncours data, String msgId, String issuer, String provider) {
		ReponseEncours response = generateEncoursTiers(data);
		producerEncoursTiers.send(response, msgId);

	}

	private BigDecimal generateRandomAmountFromRange() {

		BigDecimal randomBigDecimal = minAmount
				.add(BigDecimal.valueOf(new SecureRandom().nextDouble()).multiply(maxAmount.subtract(minAmount)));
		return randomBigDecimal.setScale(2, BigDecimal.ROUND_HALF_UP);
	}

}

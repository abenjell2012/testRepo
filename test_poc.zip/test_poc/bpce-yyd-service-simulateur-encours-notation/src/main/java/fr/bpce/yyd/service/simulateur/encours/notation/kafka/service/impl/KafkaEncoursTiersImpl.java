package fr.bpce.yyd.service.simulateur.encours.notation.kafka.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;

import fr.bpce.yyd.service.commun.yyc.constant.KafkaConstant;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.ReponseEncours;
import fr.bpce.yyd.service.simulateur.encours.notation.kafka.service.KafkaEncoursTiers;

@Service("encoursTiers")
@ConditionalOnProperty(value = "kafka.actif", havingValue = "true", matchIfMissing = false)
public class KafkaEncoursTiersImpl implements KafkaEncoursTiers {

	private static final Logger LOG = LoggerFactory.getLogger(KafkaEncoursTiersImpl.class);

	@Autowired
	private KafkaTemplate<String, ReponseEncours> reponseEncoursTemplate;

	@Value("${kafka.producers.encours.topic}")
	private String topic;

	@Override
	public void send(ReponseEncours data, String msgId) {

		Message<ReponseEncours> message = MessageBuilder.withPayload(data).setHeader(KafkaConstant.MSGID_HEADER, msgId)
				.setHeader(KafkaConstant.ISSUER_HEADER, KafkaConstant.APPLI_YYD)
				.setHeader(KafkaConstant.PROVIDER_HEADER, KafkaConstant.APPLI_YYC)
				.setHeader(KafkaHeaders.MESSAGE_KEY, msgId).setHeader(KafkaHeaders.TOPIC, topic).build();

		LOG.info("Envoi ReponseEncours {msgId={}, dateEncours={}, nombre total d'encours={}}", msgId,
				data.getDateEncours(), data.getEncoursTiers().size());
		reponseEncoursTemplate.send(message);

	}
}
package fr.bpce.yyd.service.simulateur.encours.notation.kafka.service;

import fr.bpce.yyd.service.commun.yyc.kafka.dto.NotifEncours;

public interface KafkaNotifEncours {

	void send(NotifEncours data, String msgId, String msgProvider);

}

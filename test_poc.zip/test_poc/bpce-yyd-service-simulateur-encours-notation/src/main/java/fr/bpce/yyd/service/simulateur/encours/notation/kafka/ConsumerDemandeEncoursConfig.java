package fr.bpce.yyd.service.simulateur.encours.notation.kafka;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.SeekToCurrentErrorHandler;
import org.springframework.retry.backoff.FixedBackOffPolicy;
import org.springframework.retry.policy.AlwaysRetryPolicy;
import org.springframework.retry.support.RetryTemplate;

import fr.bpce.yyd.commun.util.KafkaUtil;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.DemandeEncours;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.DemandeEncoursDtoDeserializer;

@Configuration
@ConditionalOnProperty(value = "kafka.actif", havingValue = "true", matchIfMissing = false)
@EnableKafka
public class ConsumerDemandeEncoursConfig {

	@Value(value = "${kafka.bootstrapAddress}")
	private List<String> bootstrapAddress;

	@Value(value = "${kafka.consumers.demandesEncours.groupId}")
	private String groupId;

	@Value(value = "${kafka.consumers.demandesEncours.autoOffsetReset}")
	private String offsetReset;

	@Value(value = "${kafka.consumers.demandesEncours.maxPollRecords}")
	private String maxPollRecords;

	@Value(value = "${kafka.security-actif}")
	private boolean isSecurityActif;

	@Value(value = "${kafka.ssl-truststore-location}")
	private String sslTrustStoreLocation;

	@Value(value = "${kafka.ssl-truststore-password}")
	private String sslTrustStorePass;

	@Value(value = "${kafka.sasl-consumer-user}")
	private String saslUser;

	@Value(value = "${kafka.sasl-consumer-password}")
	private String saslPass;

	@Value(value = "${kafka.sessionTimeoutMs}")
	private String sessionTimeoutMs;

	@Value(value = "${kafka.heartbeatIntervalMs}")
	private String heartbeatIntervalMs;

	@Value(value = "${kafka.consumers.demandesEncours.maxPollIntervalMs}")
	private String maxPollIntervalMs;

	public Map<String, Object> consumerBaseFactory(Map<String, Object> props) {
		props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapAddress);
		return props;
	}

	@Bean
	public ConcurrentKafkaListenerContainerFactory<String, DemandeEncours> consumerDemandeEncours() {
		Map<String, Object> props = new HashMap<>();
		props = consumerBaseFactory(props);
		props.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
		props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, offsetReset);
		props.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, maxPollRecords);
		props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, DemandeEncoursDtoDeserializer.class);
		props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
		props.put(ConsumerConfig.MAX_POLL_INTERVAL_MS_CONFIG, maxPollIntervalMs);
		props.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, sessionTimeoutMs);
		props.put(ConsumerConfig.HEARTBEAT_INTERVAL_MS_CONFIG, heartbeatIntervalMs);
		if (isSecurityActif) {
			KafkaUtil.addSecurityConfig(props, sslTrustStoreLocation, sslTrustStorePass, saslUser, saslPass);
		}

		ConsumerFactory<String, DemandeEncours> consumerFactory = new DefaultKafkaConsumerFactory<>(props);

		ConcurrentKafkaListenerContainerFactory<String, DemandeEncours> factory = new ConcurrentKafkaListenerContainerFactory<>();
		factory.setConsumerFactory(consumerFactory);
		// needed to avoid committing offset
		factory.getContainerProperties().setAckOnError(false);
		// -1 now needed for infinite retries (since 2.2.1)
		factory.setErrorHandler(new SeekToCurrentErrorHandler(-1));
		factory.setStatefulRetry(true);
		RetryTemplate retryTemplate = new RetryTemplate();
		retryTemplate.setRetryPolicy(new AlwaysRetryPolicy());
		FixedBackOffPolicy fixedBackOffPolicy = new FixedBackOffPolicy();
		fixedBackOffPolicy.setBackOffPeriod(10000l);
		retryTemplate.setBackOffPolicy(fixedBackOffPolicy);
		factory.setRetryTemplate(retryTemplate);

		return factory;
	}
}

package fr.bpce.yyd.service.simulateur.encours.notation.kafka.service;

import fr.bpce.yyd.service.commun.yyc.kafka.dto.ReponseEncours;

public interface KafkaEncoursTiers {

	void send(ReponseEncours data, String msgId);

}

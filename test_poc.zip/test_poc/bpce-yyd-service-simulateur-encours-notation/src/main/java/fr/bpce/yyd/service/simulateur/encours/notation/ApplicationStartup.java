package fr.bpce.yyd.service.simulateur.encours.notation;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

import fr.bpce.yyd.service.commun.yyc.constant.KafkaConstant;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.NotifEncours;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.ReponseEncours;
import fr.bpce.yyd.service.simulateur.encours.notation.kafka.service.KafkaEncoursTiers;
import fr.bpce.yyd.service.simulateur.encours.notation.kafka.service.KafkaNotifEncours;

@Component
@ConditionalOnProperty(value = "kafka.actif", havingValue = "true", matchIfMissing = false)
public class ApplicationStartup implements ApplicationListener<ApplicationReadyEvent> {

	private static final Logger LOG = LoggerFactory.getLogger(ApplicationStartup.class);

	@Autowired
	KafkaNotifEncours notifEncours;

	@Autowired
	KafkaEncoursTiers encoursTiers;

	@Value("${folders.notifEncours}")
	private String notifFolder;

	@Value("${folders.encours}")
	private String encoursTiersFolder;

	@Value("${encoursInit.sendNotif}")
	private Boolean sendNotif;

	@Value("${encoursInit.sendEncoursTiers}")
	private Boolean sendEncoursTiers;

	@Override
	public void onApplicationEvent(ApplicationReadyEvent event) {
		sendNotifEncoursJson();
		sendEncoursTiersJson();
	}

	private void sendNotifEncoursJson() {
		if (!Boolean.TRUE.equals(sendNotif)) {
			LOG.info("Envoi de NotificationEncours d'initialisation est desactive");
		} else {
			LOG.info("L'envoi de NotificationEncours d'initialisation ...");
			Path notifPath = Paths.get(notifFolder);
			if (!notifPath.toFile().exists()) {
				LOG.warn("Le repertoire des notifications encours={}. Veuillez vérifier la configuration", notifPath);
				return;
			}
			List<Path> listPaths = getFiles(notifPath);
			LOG.info("Repertoire des notifications encours={}, nombre de fichiers={}", notifPath, listPaths.size());
			ObjectMapper mapper = new ObjectMapper();
			for (Path path : listPaths) {
				String msgId = UUID.randomUUID().toString();
				LOG.info("======= Envoi du fichier {} via kafka avec msgId={}  ... =====", path, msgId);
				try {
					NotifEncours notif = mapper.readValue(path.toFile(), NotifEncours.class);
					notifEncours.send(notif, msgId, KafkaConstant.APPLI_YYC);
				} catch (IOException e) {
					LOG.error("Erreur à l'envoi du fichier  du fichier {} via kafka. Message d'erreur {} ", path,
							e.getMessage());
				}
			}
		}
	}

	private void sendEncoursTiersJson() {
		if (!Boolean.TRUE.equals(sendEncoursTiers)) {
			LOG.info("L'envoi d'encoursTiers d'initialisation est desactive");
		} else {
			LOG.info("Envoi d'encoursTiers d'initialisation ...");
			Path encoursTiersPath = Paths.get(encoursTiersFolder);
			if (!encoursTiersPath.toFile().exists()) {
				LOG.warn("Repertoire des encoursTiers={} n'existe pas. Veuillez vérifier la configuration",
						encoursTiersPath);
				return;
			}
			List<Path> listPaths = getFiles(encoursTiersPath);
			LOG.info("Repertoire des encoursTiers={}, nombre de fichiers={}", encoursTiersPath, listPaths.size());
			ObjectMapper mapper = new ObjectMapper();
			for (Path path : listPaths) {
				// le msgId doit correspondre au nom du fichier sans l'extention
				String msgId = path.toFile().getName().replace(".json", "");
				LOG.info("===========Envoi du fichier encoursTiers {} via kafka  avec msgId={}... ======", path, msgId);
				try {
					ReponseEncours encours = mapper.readValue(path.toFile(), ReponseEncours.class);
					encoursTiers.send(encours, msgId);
				} catch (IOException e) {
					LOG.error("Erreur à l'envoi du fichier encoursTiers {} via kafka. Message d'erreur {} ", path,
							e.getMessage());
				}
			}
		}
	}

	private List<Path> getFiles(Path path) {
		return Stream.of(path.toFile().listFiles()).filter(file -> !file.isDirectory()).map(File::toPath)
				.collect(Collectors.toList());
	}

}

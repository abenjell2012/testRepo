package fr.bpce.yyd.service.simulateur.encours.notation.kafka.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;

import fr.bpce.yyd.service.commun.yyc.constant.KafkaConstant;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.NotifEncours;
import fr.bpce.yyd.service.simulateur.encours.notation.kafka.service.KafkaNotifEncours;

@Service("notifEncours")
@ConditionalOnProperty(value = "kafka.actif", havingValue = "true", matchIfMissing = false)
public class KafkaNotifEncoursImpl implements KafkaNotifEncours {

	private static final Logger LOG = LoggerFactory.getLogger(KafkaNotifEncoursImpl.class);

	@Autowired
	private KafkaTemplate<String, NotifEncours> notifEncoursEncoursTemplate;

	@Value("${kafka.producers.notifEncours.topic}")
	private String topic;

	@Override
	public void send(NotifEncours data, String msgId, String provider) {

		Message<NotifEncours> message = MessageBuilder.withPayload(data).setHeader(KafkaConstant.MSGID_HEADER, msgId)
				.setHeader(KafkaConstant.PROVIDER_HEADER, provider).setHeader(KafkaHeaders.TOPIC, topic)
				.setHeader(KafkaHeaders.MESSAGE_KEY, msgId).build();

		notifEncoursEncoursTemplate.send(message);
		LOG.info("Envoi NotifEncours {msgId={}, dateEncours={}}", msgId, data.getDateArreteMensuelle());

	}
}
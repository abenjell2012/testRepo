package fr.bpce.yyd.service.simulateur.encours;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.junit.ClassRule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.KafkaListenerContainerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.listener.MessageListenerContainer;
import org.springframework.kafka.listener.SeekToCurrentErrorHandler;
import org.springframework.kafka.test.rule.EmbeddedKafkaRule;
import org.springframework.kafka.test.utils.KafkaTestUtils;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.retry.backoff.FixedBackOffPolicy;
import org.springframework.retry.policy.AlwaysRetryPolicy;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

import fr.bpce.yyd.service.commun.yyc.kafka.dto.DemandeEncours;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.DemandeEncoursDtoDeserializer;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.DemandeEncoursDtoSerializer;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.DemandeEncoursTiers;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.TypeAgregat;

@RunWith(SpringRunner.class)
@DirtiesContext
public class DemandeEncoursStatefulRetryTest {

	private static final String DEFAULT_TEST_GROUP_ID = "DemandeEncoursRetry";
	static final String DEMANDES_ENCOURS_TOPIC = "BF_J1_YYD_DEMANDES_ENCOURS";

	@ClassRule
	public static EmbeddedKafkaRule embeddedKafka = new EmbeddedKafkaRule(1, true, 1, DEMANDES_ENCOURS_TOPIC);

	@Autowired
	private Config config;

	@Autowired
	private KafkaTemplate<String, DemandeEncours> template;

	@Test
	public void testStatefulRetry() throws Exception {
		LocalDate dateEncours = LocalDate.now();
		DemandeEncours encours = new DemandeEncours(dateEncours);

		DemandeEncoursTiers tiers1 = new DemandeEncoursTiers(TypeAgregat.N, "0000002734", null, null);
		encours.getListTiers().add(tiers1);

		DemandeEncoursTiers tiers2 = new DemandeEncoursTiers(TypeAgregat.N, null, "13807", "0305919");
		encours.getListTiers().add(tiers2);

		String msgId = UUID.randomUUID().toString();
		Message<DemandeEncours> message = MessageBuilder.withPayload(encours).setHeader("CustomHeader-MsgId", msgId)
				.build();

		/*
		 * Message<DemandeEncours> message = MessageBuilder.withPayload(encours) //
		 * .setHeader(KafkaConstant.MSGID_HEADER, msgId)
		 * .setHeader(KafkaHeaders.MESSAGE_KEY, UUID.randomUUID().toString())//
		 * .setHeader(KafkaConstant.ISSUER_HEADER, KafkaConstant.APPLI_YYD) //
		 * .setHeader(KafkaHeaders.TOPIC, DEMANDES_ENCOURS_TOPIC).build();
		 * 
		 */

		// send demandeEncours
		template.send(message);
		assertThat(this.config.latch1.await(10, TimeUnit.SECONDS)).isTrue();
		assertThat(this.config.seekPerformed).isTrue();
	}

	@Configuration
	@EnableKafka
	public static class Config {

		private final CountDownLatch latch1 = new CountDownLatch(3);

		private boolean seekPerformed;

		@Bean
		public KafkaListenerContainerFactory<?> kafkaListenerContainerFactory() {
			ConcurrentKafkaListenerContainerFactory<String, DemandeEncours> factory = new ConcurrentKafkaListenerContainerFactory<>();
			factory.setConsumerFactory(consumerFactory());
			factory.setConcurrency(10);
			// needed to avoid committing offset
			factory.getContainerProperties().setAckOnError(false);
			// -1 now needed for infinite retries (since 2.2.1)
			factory.setErrorHandler(new SeekToCurrentErrorHandler(-1) {
				@Override
				public void handle(Exception thrownException, List<ConsumerRecord<?, ?>> records,
						Consumer<?, ?> consumer, MessageListenerContainer container) {
					Config.this.seekPerformed = true;
					super.handle(thrownException, records, consumer, container);
				}
			});
			factory.setStatefulRetry(true);
			RetryTemplate retryTemplate = new RetryTemplate();
			retryTemplate.setRetryPolicy(new AlwaysRetryPolicy());
			FixedBackOffPolicy fixedBackOffPolicy = new FixedBackOffPolicy();
			fixedBackOffPolicy.setBackOffPeriod(100l);
			retryTemplate.setBackOffPolicy(fixedBackOffPolicy);
			factory.setRetryTemplate(retryTemplate);
			return factory;
		}

		@Bean
		public DefaultKafkaConsumerFactory<String, DemandeEncours> consumerFactory() {
			return new DefaultKafkaConsumerFactory<>(consumerConfigs());
		}

		@Bean
		public Map<String, Object> consumerConfigs() {
			Map<String, Object> consumerProps = KafkaTestUtils.consumerProps(DEFAULT_TEST_GROUP_ID, "false",
					embeddedKafka.getEmbeddedKafka());
			consumerProps.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
			consumerProps.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
			consumerProps.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, DemandeEncoursDtoDeserializer.class);
			return consumerProps;
		}

		@Bean
		public KafkaTemplate<String, DemandeEncours> template() {
			KafkaTemplate<String, DemandeEncours> producer = new KafkaTemplate<>(producerFactory());
			producer.setDefaultTopic(DEMANDES_ENCOURS_TOPIC);
			return producer;
		}

		@Bean
		public ProducerFactory<String, DemandeEncours> producerFactory() {
			return new DefaultKafkaProducerFactory<>(producerConfigs());
		}

		@Bean
		public Map<String, Object> producerConfigs() {
			Map<String, Object> producerProperties = KafkaTestUtils.producerProps(embeddedKafka.getEmbeddedKafka());
			producerProperties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
			producerProperties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, DemandeEncoursDtoSerializer.class);
			return producerProperties;
		}

		@KafkaListener(id = "retry", topics = DEMANDES_ENCOURS_TOPIC, groupId = "sr1")
		public void listen1(String in) {
			this.latch1.countDown();
			throw new RuntimeException("retry");
		}

	}

}
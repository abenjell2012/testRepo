package fr.bpce.yyd.service.simulateur.encours;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.Map;
import java.util.UUID;

import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.listener.MessageListenerContainer;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.kafka.test.EmbeddedKafkaBroker;
import org.springframework.kafka.test.context.EmbeddedKafka;
import org.springframework.kafka.test.utils.ContainerTestUtils;
import org.springframework.kafka.test.utils.KafkaTestUtils;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

import com.fasterxml.jackson.databind.ObjectMapper;

import fr.bpce.yyd.service.commun.yyc.constant.KafkaConstant;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.DemandeEncours;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.DemandeEncoursDtoSerializer;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.DemandeEncoursTiers;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.TypeAgregat;
import fr.bpce.yyd.service.simulateur.encours.notation.Application;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class, webEnvironment = WebEnvironment.RANDOM_PORT)
@EmbeddedKafka(partitions = 1, topics = {
		KafkaDemandeEncoursConsumerTest.DEMANDES_ENCOURS_TOPIC }, controlledShutdown = true)
@DirtiesContext
public class KafkaDemandeEncoursConsumerTest {

	static final String DEMANDES_ENCOURS_TOPIC = "BF_J1_YYD_DEMANDES_ENCOURS";

	@Value("${spring.embedded.kafka.brokers}")
	private String brokerAddresses;

	@Autowired
	private EmbeddedKafkaBroker kafkaEmbedded;

	@Autowired
	private KafkaListenerEndpointRegistry kafkaListenerEndpointRegistry;

	private KafkaTemplate<String, DemandeEncours> template;

	String msgId = "testKafkaDemandeEncoursConsumer";

	@Value("${folders.demandeEncours}")
	private String demandeEncoursFolder;

	@Before
	public void setup() throws Exception {
		// set up producer properties
		Map<String, Object> producerProperties = KafkaTestUtils.consumerProps("testDemandeEncours", "false",
				kafkaEmbedded);
		producerProperties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
		producerProperties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, DemandeEncoursDtoSerializer.class);

		// create a Kafka producer factory
		ProducerFactory<String, DemandeEncours> producerFactory = new DefaultKafkaProducerFactory<String, DemandeEncours>(
				producerProperties);

		// create a Kafka template
		template = new KafkaTemplate<>(producerFactory);
		// set the default topic to send to
		template.setDefaultTopic(DEMANDES_ENCOURS_TOPIC);

		// wait until the partitions are assigned
		for (MessageListenerContainer messageListenerContainer : kafkaListenerEndpointRegistry
				.getListenerContainers()) {
			ContainerTestUtils.waitForAssignment(messageListenerContainer, kafkaEmbedded.getPartitionsPerTopic());
		}
	}

	@Test
	public void receive_DemandeEncours_Kafka() throws Exception {
		LocalDate dateEncours = LocalDate.now();

		DemandeEncours encours = new DemandeEncours(dateEncours);

		DemandeEncoursTiers tiers1 = new DemandeEncoursTiers(TypeAgregat.N, "0000002734", null, null);
		encours.getListTiers().add(tiers1);

		DemandeEncoursTiers tiers2 = new DemandeEncoursTiers(TypeAgregat.N, null, "13807", "0305919");
		encours.getListTiers().add(tiers2);

		String messageKey = UUID.randomUUID().toString();

		Message<DemandeEncours> message = MessageBuilder.withPayload(encours) //
				.setHeader(KafkaConstant.MSGID_HEADER, msgId)//
				.setHeader(KafkaHeaders.MESSAGE_KEY, messageKey)
				.setHeader(KafkaConstant.ISSUER_HEADER, KafkaConstant.APPLI_YYD) //
				.setHeader(KafkaHeaders.TOPIC, DEMANDES_ENCOURS_TOPIC).build();

		PrintStream previousConsole = System.out;
		// redirect system.out
		ByteArrayOutputStream newConsole = redirectSystemOut();

		// send demandeEncours
		template.send(message);

		Thread.sleep(10000);

		// Check if log trace after the message receiving
		String logTrace = "Reception DemandeEncours avec {msgId=" + msgId + ", dateArreteMensuelle=" + dateEncours
				+ ", issuer=" + KafkaConstant.APPLI_YYD + "}";
		searchConsumerLogTrace(newConsole, logTrace);

		// reset system.out
		resetSystemOut(previousConsole);

		// check the encours saved on the disk
		Path encoursFolder = Paths.get(demandeEncoursFolder).resolve(msgId + ".json");
		ObjectMapper mapper = new ObjectMapper();
		DemandeEncours demandeEncours2 = mapper.readValue(encoursFolder.toFile(), DemandeEncours.class);
		Assert.assertTrue(encours.getDateEncours().equals(demandeEncours2.getDateEncours()));
		Assert.assertTrue(encours.getListTiers().size() == demandeEncours2.getListTiers().size());

	}

	private ByteArrayOutputStream redirectSystemOut() {
		// Set the standard output to use newConsole.
		ByteArrayOutputStream newConsole = new ByteArrayOutputStream();
		System.setOut(new PrintStream(newConsole));
		return newConsole;

	}

	private void searchConsumerLogTrace(ByteArrayOutputStream newConsole, String logTrace) {
		// Check if log trace after the message receiving
		Assert.assertTrue(newConsole.toString().contains(logTrace));
	}

	private void resetSystemOut(PrintStream previousConsole) {
		System.setOut(previousConsole);
	}
}

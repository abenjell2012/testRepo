package fr.bpce.yyd.service.simulateur.encours;

import java.time.LocalDate;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.listener.KafkaMessageListenerContainer;
import org.springframework.kafka.listener.MessageListener;
import org.springframework.kafka.test.EmbeddedKafkaBroker;
import org.springframework.kafka.test.context.EmbeddedKafka;
import org.springframework.kafka.test.utils.ContainerTestUtils;
import org.springframework.kafka.test.utils.KafkaTestUtils;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

import fr.bpce.yyd.service.commun.yyc.kafka.dto.NotifEncours;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.NotifEncoursDtoDeserializer;
import fr.bpce.yyd.service.simulateur.encours.notation.Application;
import fr.bpce.yyd.service.simulateur.encours.notation.kafka.service.KafkaNotifEncours;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class, webEnvironment = WebEnvironment.RANDOM_PORT)
@EmbeddedKafka(partitions = 1, topics = {
		KafkaNotifEncoursProducerTest.NOTIF_ENCOURS_TOPIC }, controlledShutdown = true)
@DirtiesContext
public class KafkaNotifEncoursProducerTest {

	private static final Logger LOG = LoggerFactory.getLogger(KafkaNotifEncoursProducerTest.class);

	static final String NOTIF_ENCOURS_TOPIC = "BF_J1_YYC_NOTIF_ENCOURS";

	@Value("${spring.embedded.kafka.brokers}")
	private String brokerAddresses;

	@Autowired
	private EmbeddedKafkaBroker kafkaEmbedded;

	@Autowired
	KafkaNotifEncours kafkaNotifEncours;

	private KafkaMessageListenerContainer<String, NotifEncours> container;

	private BlockingQueue<ConsumerRecord<String, NotifEncours>> records;

	@Before
	public void setup() throws Exception {
		// set up consumer properties
		Map<String, Object> consumerProperties = KafkaTestUtils.consumerProps("testNotif", "false", kafkaEmbedded);
		consumerProperties.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, NotifEncoursDtoDeserializer.class);
		consumerProperties.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
		// create a Kafka consumer factory
		DefaultKafkaConsumerFactory<String, NotifEncours> consumerFactory = new DefaultKafkaConsumerFactory<String, NotifEncours>(
				consumerProperties);

		// set the topic that needs to be consumed
		ContainerProperties containerProperties = new ContainerProperties(NOTIF_ENCOURS_TOPIC);

		// create a Kafka MessageListenerContainer
		container = new KafkaMessageListenerContainer<>(consumerFactory, containerProperties);

		// create a thread safe queue to store the received message
		records = new LinkedBlockingQueue<>();

		// setup a Kafka message listener
		container.setupMessageListener(new MessageListener<String, NotifEncours>() {
			@Override
			public void onMessage(ConsumerRecord<String, NotifEncours> record) {
				LOG.debug("test-listener received message='{}'", record.toString());
				records.add(record);
			}
		});

		// start the container and underlying message listener
		container.start();

		// wait until the container has the required number of assigned partitions
		ContainerTestUtils.waitForAssignment(container, kafkaEmbedded.getPartitionsPerTopic());
	}

	@After
	public void tearDown() {
		// stop the container
		container.stop();
	}

	@Test
	public void send_encoursNotif_toKafka() throws Exception {
		NotifEncours notifEncours = new NotifEncours(LocalDate.now());

		// send to kafka
		kafkaNotifEncours.send(notifEncours, UUID.randomUUID().toString(), "TEST YYC");

		// check message received
		ConsumerRecord<String, NotifEncours> received = records.poll(10, TimeUnit.SECONDS);
		NotifEncours notifReceived = received.value();
		Assert.assertTrue(notifEncours.getDateArreteMensuelle().equals(notifReceived.getDateArreteMensuelle()));

	}

}

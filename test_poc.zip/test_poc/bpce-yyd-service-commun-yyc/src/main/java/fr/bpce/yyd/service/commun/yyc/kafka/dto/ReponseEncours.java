package fr.bpce.yyd.service.commun.yyc.kafka.dto;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;

public class ReponseEncours implements Serializable {

	private static final long serialVersionUID = -1755189334435951191L;

	@JsonDeserialize(using = EncoursDateDeserializer.class)
	@JsonSerialize(using = EncoursDateSerializer.class)
	private LocalDate dateEncours;

	@JsonDeserialize(using = EncoursDateDeserializer.class)
	@JsonSerialize(using = EncoursDateSerializer.class)
	private LocalDate dateArreteMensuelle;

	@JsonSerialize(using = LocalDateTimeSerializer.class, as = LocalDateTime.class)
	@JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
	private LocalDateTime dateTraitement;

	@JsonDeserialize(using = BooleanDeserializer.class)
	@JsonSerialize(using = BooleanSerializer.class)
	private Boolean codeRetour;

	private String codeErreur;

	private String messageErreur;

	private List<ReponseEncoursTiers> encoursTiers = new ArrayList<>();

	public ReponseEncours() {
		super();
	}

	public ReponseEncours(LocalDate dateEncours, LocalDate dateArreteMensuelle, Boolean codeRetour) {
		super();
		this.dateEncours = dateEncours;
		this.dateArreteMensuelle = dateArreteMensuelle;
		this.codeRetour = codeRetour;
	}

	public LocalDate getDateEncours() {
		return dateEncours;
	}

	public void setDateEncours(LocalDate dateEncours) {
		this.dateEncours = dateEncours;
	}

	public LocalDate getDateArreteMensuelle() {
		return dateArreteMensuelle;
	}

	public void setDateArreteMensuelle(LocalDate dateArreteMensuelle) {
		this.dateArreteMensuelle = dateArreteMensuelle;
	}

	public Boolean getCodeRetour() {
		return codeRetour;
	}

	public void setCodeRetour(Boolean codeRetour) {
		this.codeRetour = codeRetour;
	}

	public String getCodeErreur() {
		return codeErreur;
	}

	public void setCodeErreur(String codeErreur) {
		this.codeErreur = codeErreur;
	}

	public String getMessageErreur() {
		return messageErreur;
	}

	public void setMessageErreur(String messageErreur) {
		this.messageErreur = messageErreur;
	}

	public List<ReponseEncoursTiers> getEncoursTiers() {
		return encoursTiers;
	}

	public void setEncoursTiers(List<ReponseEncoursTiers> encoursTiers) {
		this.encoursTiers = encoursTiers;
	}

	public LocalDateTime getDateTraitement() {
		return dateTraitement;
	}

	public void setDateTraitement(LocalDateTime dateTraitement) {
		this.dateTraitement = dateTraitement;
	}
}

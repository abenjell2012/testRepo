package fr.bpce.yyd.service.commun.yyc.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;


import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import fr.bpce.yyd.service.commun.yyc.kafka.dto.EncoursDateDeserializer;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.EncoursDateSerializer;

public class ReponseLotTiersRft implements Serializable  {
	private static final long serialVersionUID = 1L;

	@JsonDeserialize(using = EncoursDateDeserializer.class)
	@JsonSerialize(using = EncoursDateSerializer.class)
	private LocalDate dateAppel;

	@JsonDeserialize(using = EncoursDateDeserializer.class)
	@JsonSerialize(using = EncoursDateSerializer.class)
	private LocalDate dateArreteMensuelle;

	private List<ReponseTiersRFT> tiers;


	public ReponseLotTiersRft(LocalDate dateAppel, LocalDate dateArreteMensuelle, List<ReponseTiersRFT> tiers) {
		super();
		this.dateAppel = dateAppel;
		this.dateArreteMensuelle = dateArreteMensuelle;
		this.tiers = tiers;
	}


	public ReponseLotTiersRft(LocalDate dateAppel,  LocalDate dateArreteMensuelle) {
		this(dateAppel, dateArreteMensuelle, null);
	}


	public ReponseLotTiersRft() {
		super();
	}



	public List<ReponseTiersRFT> getTiers() {
		if(tiers == null) {
			tiers = new ArrayList<>();
		}

		return tiers;
	}

	public void setTiers(List<ReponseTiersRFT> tiers) {
		this.tiers = tiers;
	}

	public LocalDate getDateAppel() {
		return dateAppel;
	}

	public void setDateAppel(LocalDate dateAppel) {
		this.dateAppel = dateAppel;
	}



	public LocalDate getDateArreteMensuelle() {
		return dateArreteMensuelle;
	}



	public void setDateArreteMensuelle(LocalDate dateArreteMensuelle) {
		this.dateArreteMensuelle = dateArreteMensuelle;
	}
 }

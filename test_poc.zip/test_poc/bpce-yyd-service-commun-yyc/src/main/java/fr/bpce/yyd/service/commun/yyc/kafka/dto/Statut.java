package fr.bpce.yyd.service.commun.yyc.kafka.dto;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum Statut {

	TROUVE(1),
	NON_TROUVE(0);

	private int code;

	Statut(int code) {
		this.code = code;
	}

	public int getCode() {
		return code;
	}

	@JsonValue
	public int toValue() {
		return getCode();
	}

	public static Statut forCode(int code) {
		for (Statut element : values()) {
			if (element.code == code) {
				return element;
			}
		}
		return null; //or throw exception if you like...
	}

	@JsonCreator
	public static Statut forValue(String v) {
		return Statut.forCode(Integer.parseInt(v));
	}
}
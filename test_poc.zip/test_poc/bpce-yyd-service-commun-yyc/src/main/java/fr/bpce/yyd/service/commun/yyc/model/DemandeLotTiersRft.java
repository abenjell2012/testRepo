package fr.bpce.yyd.service.commun.yyc.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;


import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import fr.bpce.yyd.service.commun.yyc.kafka.dto.EncoursDateDeserializer;
import fr.bpce.yyd.service.commun.yyc.kafka.dto.EncoursDateSerializer;


public class DemandeLotTiersRft implements Serializable {
	private static final long serialVersionUID = 1L;

	@JsonDeserialize(using = EncoursDateDeserializer.class)
	@JsonSerialize(using = EncoursDateSerializer.class)
	private LocalDate dateAppel;


	private List<DemandeTiersRFT> tiers;

	public DemandeLotTiersRft() {
		super();
	}

	public DemandeLotTiersRft(List<DemandeTiersRFT> tiers, LocalDate dateAppel) {
		super();
		this.tiers = tiers;
		this.dateAppel = dateAppel;
	}


	public DemandeLotTiersRft(LocalDate dateAppel) {
		this(null, dateAppel);
	}

	public List<DemandeTiersRFT> getTiers() {
		if(tiers == null) {
			tiers = new ArrayList<>();
		}

		return tiers;
	}

	public void setListTiers(List<DemandeTiersRFT> tiers) {
		this.tiers = tiers;
	}

	public LocalDate getDateAppel() {
		return dateAppel;
	}

	public void setDateAppel(LocalDate dateAppel) {
		this.dateAppel = dateAppel;
	}
 }

package fr.bpce.yyd.service.commun.yyc.kafka.dto;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

public class BooleanSerializer extends StdSerializer<Boolean> {

	private static final long serialVersionUID = 3632798386404236978L;

	public BooleanSerializer() {
		super(Boolean.class);
	}

	@Override
	public void serialize(Boolean value, JsonGenerator gen, SerializerProvider provider) throws IOException {
		gen.writeString(Boolean.TRUE.equals(value) ? "1" : "0");

	}
}

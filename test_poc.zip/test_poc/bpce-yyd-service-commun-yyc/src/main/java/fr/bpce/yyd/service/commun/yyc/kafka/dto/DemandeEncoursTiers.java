package fr.bpce.yyd.service.commun.yyc.kafka.dto;

import java.io.Serializable;

public class DemandeEncoursTiers implements Serializable {

	private static final long serialVersionUID = -1755189334435951191L;

	private String idFederal;
	private String codeBanque;
	private String idLocal;

	private TypeAgregat typeAgregat;

	public String getIdFederal() {
		return idFederal;
	}

	public void setIdFederal(String idFederal) {
		this.idFederal = idFederal;
	}

	public String getCodeBanque() {
		return codeBanque;
	}

	public void setCodeBanque(String codeBanque) {
		this.codeBanque = codeBanque;
	}

	public String getIdLocal() {
		return idLocal;
	}

	public void setIdLocal(String idLocal) {
		this.idLocal = idLocal;
	}

	public DemandeEncoursTiers(TypeAgregat typeAgregat, String idFederal, String codeBanque, String idLocal) {
		super();
		this.typeAgregat = typeAgregat;
		this.idFederal = idFederal;
		this.codeBanque = codeBanque;
		this.idLocal = idLocal;
	}

	public DemandeEncoursTiers() {
		super();
	}

	public TypeAgregat getTypeAgregat() {
		return typeAgregat;
	}

	public void setTypeAgregat(TypeAgregat typeAgregat) {
		this.typeAgregat = typeAgregat;
	}
}

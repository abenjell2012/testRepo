package fr.bpce.yyd.service.commun.yyc.model;

import fr.bpce.yyd.service.commun.yyc.kafka.dto.Statut;


public class ReponseTiersRFT extends DemandeTiersRFT {

	private static final long serialVersionUID = 1L;


    private String idRFT;

	private Statut statut;

    public ReponseTiersRFT(String codeBanque, String idLocal, String idRFT, Statut statut) {
		super(codeBanque, idLocal);
		this.idRFT = idRFT;
		this.statut = statut;
	}

    public ReponseTiersRFT(String codeBanque, String idLocal) {
		super(codeBanque, idLocal);
	}

	public ReponseTiersRFT() {
    }

	public String getIdRFT() {
		return idRFT;
	}

	public void setIdRFT(String idRFT) {
		this.idRFT = idRFT;
	}

	public Statut getStatut() {
		return statut;
	}

	public void setStatut(Statut statut) {
		this.statut = statut;
	}


}

package fr.bpce.yyd.service.commun.yyc.kafka.dto;

import java.io.Serializable;
import java.time.LocalDate;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

public class NotifEncours implements Serializable {

	private static final long serialVersionUID = -1755189334435951191L;

	@JsonDeserialize(using = EncoursDateDeserializer.class)
	@JsonSerialize(using = EncoursDateSerializer.class)
	private LocalDate dateArreteMensuelle;

	public NotifEncours() {
		super();
	}

	public NotifEncours(LocalDate dateArreteMensuelle) {
		super();
		this.dateArreteMensuelle = dateArreteMensuelle;
	}

	public LocalDate getDateArreteMensuelle() {
		return dateArreteMensuelle;
	}

	public void setDateArreteMensuelle(LocalDate dateArreteMensuelle) {
		this.dateArreteMensuelle = dateArreteMensuelle;
	}

}

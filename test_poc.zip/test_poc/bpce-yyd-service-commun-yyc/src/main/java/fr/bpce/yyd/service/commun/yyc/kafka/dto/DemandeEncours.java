package fr.bpce.yyd.service.commun.yyc.kafka.dto;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

public class DemandeEncours implements Serializable {

	private static final long serialVersionUID = -1755189334435951191L;

	@JsonDeserialize(using = EncoursDateDeserializer.class)
	@JsonSerialize(using = EncoursDateSerializer.class)
	private LocalDate dateEncours;

	private List<DemandeEncoursTiers> listTiers = new ArrayList<>();

	public DemandeEncours(LocalDate dateEncours, List<DemandeEncoursTiers> listTiers) {
		super();
		this.dateEncours = dateEncours;
		this.listTiers = listTiers;
	}

	public DemandeEncours(LocalDate dateEncours) {
		super();
		this.dateEncours = dateEncours;
	}

	public DemandeEncours() {
		super();
	}

	public LocalDate getDateEncours() {
		return dateEncours;
	}

	public void setDateEncours(LocalDate dateEncours) {
		this.dateEncours = dateEncours;
	}

	public List<DemandeEncoursTiers> getListTiers() {
		return listTiers;
	}

	public void setListTiers(List<DemandeEncoursTiers> listTiers) {
		this.listTiers = listTiers;
	}

}

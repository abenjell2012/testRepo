package fr.bpce.yyd.service.commun.yyc.kafka.dto;

public enum TypeAgregat {
    N, R, L
}

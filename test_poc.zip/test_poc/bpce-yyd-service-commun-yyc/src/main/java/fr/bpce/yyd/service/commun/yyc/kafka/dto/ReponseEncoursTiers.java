package fr.bpce.yyd.service.commun.yyc.kafka.dto;

import java.io.Serializable;
import java.math.BigDecimal;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

public class ReponseEncoursTiers implements Serializable {

	private static final long serialVersionUID = -1755189334435951191L;

	@JsonDeserialize(using = BooleanDeserializer.class)
	@JsonSerialize(using = BooleanSerializer.class)
	private Boolean statutRejet;

	private String idRft;
	private String codeFournisseur;
	private String clientId;

	private String codeRejet;
	private String messageRejet;

	private BigDecimal mntEngBrutBil;
	private BigDecimal mntEngBrutHbil;
	private BigDecimal mntEngBrut;

	private TypeAgregat typeAgregat;

	@JsonDeserialize(using = BooleanDeserializer.class)
	@JsonSerialize(using = BooleanSerializer.class)
	private Boolean topEng;

	public String getIdRft() {
		return idRft;
	}

	public void setIdRft(String idRft) {
		this.idRft = idRft;
	}

	public String getCodeFournisseur() {
		return codeFournisseur;
	}

	public void setCodeFournisseur(String codeFournisseur) {
		this.codeFournisseur = codeFournisseur;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public BigDecimal getMntEngBrutBil() {
		return mntEngBrutBil;
	}

	public void setMntEngBrutBil(BigDecimal mntEngBrutBil) {
		this.mntEngBrutBil = mntEngBrutBil;
	}

	public BigDecimal getMntEngBrutHbil() {
		return mntEngBrutHbil;
	}

	public void setMntEngBrutHbil(BigDecimal mntEngBrutHbil) {
		this.mntEngBrutHbil = mntEngBrutHbil;
	}

	public BigDecimal getMntEngBrut() {
		return mntEngBrut;
	}

	public void setMntEngBrut(BigDecimal mntEngBrut) {
		this.mntEngBrut = mntEngBrut;
	}

	public Boolean getTopEng() {
		return topEng;
	}

	public void setTopEng(Boolean topEng) {
		this.topEng = topEng;
	}

	public String getCodeRejet() {
		return codeRejet;
	}

	public void setCodeRejet(String codeRejet) {
		this.codeRejet = codeRejet;
	}

	public String getMessageRejet() {
		return messageRejet;
	}

	public void setMessageRejet(String messageRejet) {
		this.messageRejet = messageRejet;
	}

	public TypeAgregat getTypeAgregat() {
		return typeAgregat;
	}

	public void setTypeAgregat(TypeAgregat typeAgregat) {
		this.typeAgregat = typeAgregat;
	}

	public ReponseEncoursTiers(boolean statutRejet, String idRft, String codeFournisseur, String clientId,
			BigDecimal mntEngBrutBil, BigDecimal mntEngBrutHbil, BigDecimal mntEngBrut, Boolean topEng) {
		super();
		this.statutRejet = statutRejet;
		this.idRft = idRft;
		this.codeFournisseur = codeFournisseur;
		this.clientId = clientId;
		this.mntEngBrutBil = mntEngBrutBil;
		this.mntEngBrutHbil = mntEngBrutHbil;
		this.mntEngBrut = mntEngBrut;
		this.topEng = topEng;
	}

	public ReponseEncoursTiers() {
		super();
	}

	public Boolean getStatutRejet() {
		return statutRejet;
	}

	public void setStatutRejet(Boolean statutRejet) {
		this.statutRejet = statutRejet;
	}
}

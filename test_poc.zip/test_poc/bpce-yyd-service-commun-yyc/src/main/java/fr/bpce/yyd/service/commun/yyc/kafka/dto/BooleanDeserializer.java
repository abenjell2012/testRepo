package fr.bpce.yyd.service.commun.yyc.kafka.dto;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;

public class BooleanDeserializer extends StdDeserializer<Boolean> {

	private static final long serialVersionUID = 3632798386404236978L;


	public BooleanDeserializer() {
		super(Boolean.class);
	}

	@Override
	public Boolean deserialize(JsonParser parser, DeserializationContext context) throws IOException {
		return !"0".equals(parser.getText());
	}
}

package fr.bpce.yyd.service.commun.yyc.model;

import java.io.Serializable;




public class DemandeTiersRFT implements Serializable {

	private static final long serialVersionUID = 1L;


    private String codeBanque;

    private String idLocal;

    public DemandeTiersRFT(String codeBanque, String idLocal) {
		super();
		this.idLocal = idLocal;
		this.codeBanque = codeBanque;
	}

	public DemandeTiersRFT() {
    }



	public String getIdLocal() {
		return idLocal;
	}

	public void setIdLocal(String idLocal) {
		this.idLocal = idLocal;
	}

	public String getCodeBanque() {
		return codeBanque;
	}

	public void setCodeBanque(String codeBanque) {
		this.codeBanque = codeBanque;
	}

}

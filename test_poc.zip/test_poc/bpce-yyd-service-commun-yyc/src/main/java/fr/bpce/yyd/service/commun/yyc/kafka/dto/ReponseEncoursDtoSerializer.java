package fr.bpce.yyd.service.commun.yyc.kafka.dto;

import org.springframework.kafka.support.serializer.JsonSerializer;

public class ReponseEncoursDtoSerializer extends JsonSerializer<ReponseEncours> {

}

package fr.bpce.yyd.service.commun.yyc.constant;

public final class KafkaConstant {

	private KafkaConstant() {
		// classe non instantiable
	}

	public static final String MSGID_HEADER = "CustomHeader-MsgId";
	public static final String ISSUER_HEADER = "CustomHeader-Issuer";
	public static final String PROVIDER_HEADER = "CustomHeader-Provider";
	public static final String APPLI_YYC = "YYC";
	public static final String APPLI_YYD = "YYD";

}

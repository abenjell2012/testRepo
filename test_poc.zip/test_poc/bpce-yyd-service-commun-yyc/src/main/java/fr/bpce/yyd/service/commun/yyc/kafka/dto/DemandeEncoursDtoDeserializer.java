package fr.bpce.yyd.service.commun.yyc.kafka.dto;

import org.springframework.kafka.support.serializer.JsonDeserializer;

public class DemandeEncoursDtoDeserializer extends JsonDeserializer<DemandeEncours> {

}

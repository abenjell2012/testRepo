package fr.bpce.yyd.service.commun.yyc;

import org.junit.Assert;
import org.junit.Test;

public class BidonTest {

	@Test
	public void testBidon() {
		// Arrange

		// Assert
		Assert.assertTrue(true);

	}
}

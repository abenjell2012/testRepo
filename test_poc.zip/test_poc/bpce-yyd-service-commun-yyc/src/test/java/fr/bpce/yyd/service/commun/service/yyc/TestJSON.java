package fr.bpce.yyd.service.commun.service.yyc;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;

import org.junit.Assert;
import org.junit.Test;

import com.fasterxml.jackson.databind.ObjectMapper;

import fr.bpce.yyd.service.commun.yyc.kafka.dto.NotifEncours;

public class TestJSON {

	String dirPath = "target/generated-encours/";

	@Test
	public void NotificationEncours() throws IOException {
		ObjectMapper mapper = new ObjectMapper();

		NotifEncours notifEncours = new NotifEncours(LocalDate.now());
		String jsonString = mapper.writeValueAsString(notifEncours);
		String filePath = new File(System.getProperty("user.dir")).getCanonicalPath();
		Path userDir = Paths.get(filePath);
		Path outPath = userDir.resolve(dirPath).resolve("notifEncours.json");
		Files.createDirectories(outPath.getParent());

		Files.write(outPath, jsonString.getBytes());

		NotifEncours notifEncours2 = mapper.readValue(outPath.toFile(), NotifEncours.class);

		Assert.assertTrue(notifEncours.getDateArreteMensuelle().equals(notifEncours2.getDateArreteMensuelle()));
	}

}

package fr.bpce.yyd.batch.ti;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.persistence.EntityManager;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.orm.jpa.JpaTransactionManager;

import fr.bpce.yyd.batch.commun.constantes.Constant;

public class AbstractTestsLauncher {

	private static ApplicationContext context = null;

	@BeforeClass
	public static void initSpring() {
		context = new ClassPathXmlApplicationContext("classpath:JobLauncher-context-ti.xml");
	}

	/**
	 * test batch traitement evenement pour une date donnée
	 *
	 * @param strDateCalcul
	 */
	public BatchStatus traitementEvenements(String strDateCalcul) {
		Job job = (Job) context.getBean(Constant.JOB_TRAITEMENT_EVTS);
		Long guid = java.util.UUID.randomUUID().getMostSignificantBits();
		JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");
		JobParameters jobParameters = new JobParametersBuilder()
				.addString("date", LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME))
				.addString("dateCalcul", strDateCalcul).addLong("guid", guid).addString("kafka", "disable")
				.toJobParameters();

		try {
			JobExecution execution = jobLauncher.run(job, jobParameters);
			return execution.getStatus();
		} catch (Exception e) {
			e.printStackTrace();
			return BatchStatus.UNKNOWN;
		}
	}

	public EntityManager getEntityManager() {
		return (EntityManager) context.getBean("entityManager");
	}

	public static JpaTransactionManager getTransactionManager() {
		return (JpaTransactionManager) context.getBean("transactionManager");
	}

	@Test
	public void test() {
		// Act
		String dateCalcul = "20100101";

		BatchStatus batchStatus = traitementEvenements(dateCalcul);

		// Assert
		Assert.assertEquals(BatchStatus.COMPLETED, batchStatus);

	}
}

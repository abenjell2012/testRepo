package fr.bpce.yyd.batch.traitementevenements.launch;

import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.batchStatus;
import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.exitWithErrorCode;
import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.finaliserTraitement;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import fr.bpce.yyd.batch.commun.configuration.ConfigManager;
import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.commun.exception.UnknownPropertyException;

public class Launcher {

	private static Logger logger = Logger.getLogger(Launcher.class);

	private static final String KAFKA_DISABLE = "disable";

	private ApplicationContext context = null;

	public void setApplicationContext(ApplicationContext newContext) {
		context = newContext;
	}

	public ApplicationContext getApplicationContext() {
		if (context == null) {
			context = new ClassPathXmlApplicationContext("classpath:JobLauncher-context.xml");
		}
		return context;
	}

	public void runBatch(String strDateDebutCalcul, String strDateFinCalcul) {

		JobExecution execution = null;
		try {
			logger.info("Debut BATCH " + Constant.JOB_TRAITEMENT_EVTS);
			if (KAFKA_DISABLE.equals(ConfigManager.getProperty("retro.kafka.statut"))) {
				logger.warn("Traitement interrompu : l'envoie kafka est désactivé");
				return;
			}

			String nbTiersParLot = ConfigManager.getProperty("nb.tiers.liste.batch.trt.evenements");

			Job job = (Job) getApplicationContext().getBean(Constant.JOB_TRAITEMENT_EVTS);
			JobLauncher jobLauncher = (JobLauncher) getApplicationContext().getBean("jobLauncher");

			Long guid = java.util.UUID.randomUUID().getMostSignificantBits();
			JobParameters jobParameters = new JobParametersBuilder()
					.addString("date", LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME))
					.addString("dateDebutCalcul", strDateDebutCalcul).addString("dateFinCalcul", strDateFinCalcul)
					.addLong("guid", guid).addString("nb.tiers.par.lot", nbTiersParLot).toJobParameters();

			execution = jobLauncher.run(job, jobParameters);

		} catch (UnknownPropertyException e) {
			logger.error("Erreur de paramètre " + e.getMessage());
			exitWithErrorCode(1);
		} catch (Exception err) {
			logger.error("Erreur inattendue pour le batch " + Constant.JOB_TRAITEMENT_EVTS + " " + err.getMessage(),
					err);
			exitWithErrorCode(1);
		} finally {
			finaliserTraitement(batchStatus(execution));
		}
	}

	public static void main(String[] args) {
		PropertyConfigurator
				.configure(ClassLoader.getSystemClassLoader().getResource("log4j-traitement_evenements.properties"));
		// Paramètre (éventuel) : date pour laquelle on calcule.
		// Sinon, ce sera la date du jour.
		String strDateDebutCalcul = LocalDate.now().format(DateTimeFormatter.BASIC_ISO_DATE);
		String strDateFinCalcul = LocalDate.now().format(DateTimeFormatter.BASIC_ISO_DATE);
		if (args != null && args.length == 2) {
			String dateDebut = args[0];
			String dateFin = args[1];
			try {
				LocalDate.parse(dateDebut, DateTimeFormatter.BASIC_ISO_DATE);
				strDateDebutCalcul = dateDebut; // Le format est bon
				LocalDate.parse(dateFin, DateTimeFormatter.BASIC_ISO_DATE);
				strDateFinCalcul = dateFin; // Le format est bon
			} catch (DateTimeParseException dtpe) {
				logger.error("Erreur le format de la date passe en parametre est incorrect " + args[0] + " " + args[1]);
				exitWithErrorCode(1);
			}
		} else if (args == null || args.length < 2) {
			logger.error("Erreur - mauvais paramètres en entrée, on attend pas plus de 2 paramètres");
			exitWithErrorCode(1);
		}

		Launcher launcher = new Launcher();
		launcher.runBatch(strDateDebutCalcul, strDateFinCalcul);
	}
}

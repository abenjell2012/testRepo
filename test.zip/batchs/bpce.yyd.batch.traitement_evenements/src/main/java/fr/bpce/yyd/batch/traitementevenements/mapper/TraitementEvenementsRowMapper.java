package fr.bpce.yyd.batch.traitementevenements.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.springframework.jdbc.core.RowMapper;

import fr.bpce.yyd.batch.messages.dto.LotIdTiersDTO;

public class TraitementEvenementsRowMapper implements RowMapper<LotIdTiersDTO> {

	private Long guid;

	@Override
	public LotIdTiersDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

		Long tiersId = rs.getLong(1);
		LocalDate dateCalcul = LocalDate.parse(rs.getString(2), DateTimeFormatter.BASIC_ISO_DATE);

		LotIdTiersDTO lotIds = new LotIdTiersDTO();
		lotIds.setDateCalcul(dateCalcul);
		lotIds.getIdsTiers().add(tiersId);
		lotIds.setGuid(guid);

		return lotIds;
	}

	public void setParamGuid(Long paramGuidl) {
		guid = paramGuidl;
	}

}

package fr.bpce.yyd.batch.traitementevenements.processor;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Service;

import fr.bpce.yyd.batch.messages.dto.LotIdTiersDTO;

@Service
public class TraitementEvenementsItemProcessor implements ItemProcessor<LotIdTiersDTO, LotIdTiersDTO> {

	@Override
	public LotIdTiersDTO process(LotIdTiersDTO item) throws Exception {
		return item;
	}

}

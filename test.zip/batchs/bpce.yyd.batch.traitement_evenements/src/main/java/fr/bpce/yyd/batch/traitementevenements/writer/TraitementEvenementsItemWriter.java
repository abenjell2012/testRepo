package fr.bpce.yyd.batch.traitementevenements.writer;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;
import java.util.TreeMap;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemWriter;
import org.springframework.stereotype.Service;

import fr.bpce.yyd.batch.commun.configuration.ConfigManager;
import fr.bpce.yyd.batch.commun.exception.InvalidInitialisationException;
import fr.bpce.yyd.batch.commun.exception.UnknownPropertyException;
import fr.bpce.yyd.batch.commun.messages.MessagesFactory;
import fr.bpce.yyd.batch.commun.messages.ProducteurMessages;
import fr.bpce.yyd.batch.commun.messages.Topic;
import fr.bpce.yyd.batch.messages.dto.LotIdTiersDTO;

@Service
public class TraitementEvenementsItemWriter implements ItemWriter<LotIdTiersDTO> {
	private static Logger logger = Logger.getLogger(TraitementEvenementsItemWriter.class);
	private Long guid;

	@Override
	public void write(List<? extends LotIdTiersDTO> items) throws Exception {

		TreeMap<LocalDate, List<Long>> hashLotIdTiersDTO = makeHashMessage(items);

		logger.info("Début d'envoi des messages kafka");

		for (Entry<LocalDate, List<Long>> entry : hashLotIdTiersDTO.entrySet()) {
			LotIdTiersDTO lotIds = new LotIdTiersDTO();
			lotIds.setDateCalcul(entry.getKey());
			lotIds.getIdsTiers().addAll(entry.getValue());
			lotIds.setGuid(guid);
			envoieLotIds(lotIds);
		}
		logger.info("Fin d'envoi des messages kafka");
	}

	private void envoieLotIds(LotIdTiersDTO lotIds) throws UnknownPropertyException, InvalidInitialisationException {
		if (!lotIds.getIdsTiers().isEmpty()) {
			String topicName = ConfigManager.getProperty("kafka.topic.calcul_liste");
			ProducteurMessages producteur = MessagesFactory.getProducteur();
			producteur.envoieMessage(Topic.CALCUL_LISTE, topicName, lotIds);
			// Réinitialisation
			lotIds.getIdsTiers().clear();
		}
	}

	private TreeMap<LocalDate, List<Long>> makeHashMessage(List<? extends LotIdTiersDTO> items) {

		TreeMap<LocalDate, List<Long>> hashLotIdTiersDTO = new TreeMap<>();
		if (!items.isEmpty()) {
			for (int i = 0; i < items.size(); i++) {
				LotIdTiersDTO lotIdTiers = items.get(i);
				List<Long> idsTiers = hashLotIdTiersDTO.get(lotIdTiers.getDateCalcul());
				if (idsTiers == null) {
					idsTiers = new ArrayList<>();
					hashLotIdTiersDTO.put(lotIdTiers.getDateCalcul(), idsTiers);
				}
				idsTiers.addAll(lotIdTiers.getIdsTiers());

			}
		}
		return hashLotIdTiersDTO;
	}

	public void setParamGuid(Long paramGuidl) {
		guid = paramGuidl;
	}

}

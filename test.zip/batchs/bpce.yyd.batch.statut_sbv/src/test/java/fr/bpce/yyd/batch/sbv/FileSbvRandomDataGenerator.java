package fr.bpce.yyd.batch.sbv;

import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import fr.bpce.yyd.batch.commun.constantes.Constant;

public class FileSbvRandomDataGenerator {

	private static final String DATE_FICHIER = "07102019";
	private static final int NB_LIGNES_AGENERER = 100000;
	private static final boolean WITH_ID_RFT = true;
	private static final boolean WITH_DATE_FIN_NULL = false;
	private static final List<String> COD_BQ_LIST = Arrays.asList("10107", "12128", "17107", "14948", "30000", "15007",
			"15135", "23000", "15149", "15707", "15228", "15348", "15358");
	private static final List<String> STATUTS_FORCE_LIST = Arrays.asList("D", "ND");
	private static final List<String> GRAVITES_LIST = Arrays.asList("CX", "RX", "DX");

	public static void main(String[] args) throws IOException {

		Writer writer1 = new FileWriter("/appli/ndod/data/forcage_sbv/SBV_FICHIER_FORCAGE_" + DATE_FICHIER + ".csv");
		writer1.write(Constant.ENTETE_FIC_SBV + "\n");
		String codeBQ = "";
		String idLocal = "";
		String idRFt = "";
		String siren = "";
		String dateDebut = "";
		String dateFin = "";
		String statutForce = "";
		String gravite = "";
		String codifMotif = "";
		String commentaire = "";
		for (int i = 0; i < NB_LIGNES_AGENERER; i++) {
			if (WITH_ID_RFT) {
				idRFt = StringUtils.leftPad(String.valueOf(new SecureRandom().nextInt(NB_LIGNES_AGENERER)), 10, '0');
			} else {
				codeBQ = getRandomValueFromList(COD_BQ_LIST);
				idLocal = StringUtils.leftPad(String.valueOf(new SecureRandom().nextInt(NB_LIGNES_AGENERER)), 15, '0');
			}

			int randomDay = 1 + new SecureRandom().nextInt(30);
			dateDebut = "201905" + StringUtils.leftPad(String.valueOf(randomDay), 2, '0');
			if (WITH_DATE_FIN_NULL) {
				dateFin = "";
			} else {
				dateFin = "201906" + StringUtils.leftPad(String.valueOf(randomDay), 2, '0');
			}
			statutForce = getRandomValueFromList(STATUTS_FORCE_LIST);
			if ("D".equals(statutForce)) {
				gravite = getRandomValueFromList(GRAVITES_LIST);
			} else {
				gravite = "";
			}
			codifMotif = StringUtils.rightPad("Motif " + i, 100);
			commentaire = StringUtils.rightPad("Commentaire " + i, 100);
			writer1.write(idLocal + ";" + codeBQ + ";" + idRFt + ";" + siren + ";" + dateDebut + ";" + dateFin + ";"
					+ statutForce + ";" + gravite + ";" + codifMotif + ";" + commentaire);
			writer1.write("\n");
		}
		writer1.close();
		System.out.println("Fin génération de fichier");

	}

	private static <T> T getRandomValueFromList(List<T> list) {
		return list.get(new SecureRandom().nextInt(list.size()));

	}

}

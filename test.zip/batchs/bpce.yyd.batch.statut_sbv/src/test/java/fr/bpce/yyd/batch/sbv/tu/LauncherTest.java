package fr.bpce.yyd.batch.sbv.tu;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;

import java.nio.file.Paths;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.SimpleJobLauncher;
import org.springframework.beans.factory.BeanDefinitionStoreException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import fr.bpce.yyd.batch.commun.configuration.ConfigManager;
import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.commun.utils.FileCommunUtils;
import fr.bpce.yyd.batch.sbv.launch.Launcher;

@RunWith(PowerMockRunner.class)
@PrepareForTest(value = { FileCommunUtils.class, ConfigManager.class })
public class LauncherTest {

	@Mock
	private ApplicationContext context;

	@InjectMocks
	private Launcher launcher;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testRunBatchOK() throws Exception {
		String fileName = "SBV_TEST_FILE.csv";
		JobLauncher jobLauncher = mock(SimpleJobLauncher.class);
		JobExecution jobExec = new JobExecution(1L);
		jobExec.setStatus(BatchStatus.COMPLETED);

		// Mock FileCommunUtils
		PowerMockito.mockStatic(FileCommunUtils.class);
		PowerMockito.doNothing().when(FileCommunUtils.class);
		FileCommunUtils.exitWithErrorCode(Mockito.anyInt());
		FileCommunUtils.checkRepertoire(Mockito.anyString());

		// Mock ConfigManager
		PowerMockito.mockStatic(ConfigManager.class);
		PowerMockito.doReturn("./src/test/resources/ti/ok/").when(ConfigManager.class);
		ConfigManager.getProperty(Mockito.anyString());

		PowerMockito.doReturn(Paths.get("./src/test/resources/ti/ok/SBV_TEST_FILE.csv")).when(FileCommunUtils.class);
		FileCommunUtils.moveFileToDir(Mockito.any(), Mockito.any());
		FileCommunUtils.moveFileReplaceExist(Mockito.any(), Mockito.any());

		PowerMockito.doReturn(".csv").when(FileCommunUtils.class);
		FileCommunUtils.getExtension(Mockito.anyString());
		PowerMockito.doReturn("SBV_TEST_FILE").when(FileCommunUtils.class);
		FileCommunUtils.removeFileExtension(Mockito.anyString());

		Mockito.when(context.getBean(Constant.JOB_FORCAGE_SBV)).thenReturn(Mockito.mock(Job.class));
		Mockito.when(context.getBean("jobLauncher")).thenReturn(jobLauncher);
		Mockito.when(jobLauncher.run(Mockito.any(Job.class), Mockito.any(JobParameters.class))).thenReturn(jobExec);
		launcher.runBatch(fileName);
	}

	@Test(expected = BeanDefinitionStoreException.class)
	public void testGetAppContext() {
		Launcher launcher = new Launcher();
		launcher.getApplicationContext();
	}

	@Test
	public void testSetAppContext() {
		Launcher launcher = new Launcher();
		launcher.setApplicationContext(new ClassPathXmlApplicationContext("classpath:JobLauncher-context-ti.xml"));
		assertNotNull(launcher.getApplicationContext());
	}

}
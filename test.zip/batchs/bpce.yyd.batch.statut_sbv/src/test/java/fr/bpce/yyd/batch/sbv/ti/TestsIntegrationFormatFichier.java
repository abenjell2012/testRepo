package fr.bpce.yyd.batch.sbv.ti;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.util.List;

import org.junit.Test;

import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.sbv.enums.ForcageSbvControles;

public class TestsIntegrationFormatFichier extends AbstractIntegrationTest {

	@Test
	public void nomDeFichierIncorrect() throws IOException {
		// Act
		String nomFichier = "SBV_FICHIER_FORC_AGE_03102019.csv";
		importFile(nomFichier);

		List<String> rejets = lireFichierRejet();
		assertNotNull(rejets);
		assertEquals(1, rejets.size());
		assertEquals(ForcageSbvControles.CT002.getMessage(Constant.REG_NDOD_FORCAGE_SBV_FILE), rejets.get(0));

	}

	@Test
	public void dateFichierIncorrect() throws IOException {
		// Act
		String nomFichier = "SBV_FICHIER_FORCAGE_20190707.csv";
		importFile(nomFichier);

		List<String> rejets = lireFichierRejet();
		assertNotNull(rejets);
		assertEquals(1, rejets.size());
		assertEquals(ForcageSbvControles.CT003.getMessage("20190707", Constant.FORMAT_DATE_DDMMYYYY), rejets.get(0));

	}

	@Test
	public void entetefichierIncorrect() throws IOException {
		// Act
		String nomFichier = "SBV_FICHIER_FORCAGE_04102019.csv";
		importFile(nomFichier);

		List<String> rejets = lireFichierRejet();
		assertNotNull(rejets);
		assertEquals(1, rejets.size());
		assertEquals(Constant.ENTETE_FIC_REJET_SBV, rejets.get(0));
	}

	@Test
	public void fichierMalFormate() throws IOException {
		// Act
		String nomFichier = "SBV_FICHIER_FORCAGE_05102019.csv";
		importFile(nomFichier);

		List<String> rejets = lireFichierRejet();
		assertNotNull(rejets);
		assertEquals(1, rejets.size());
		assertEquals(ForcageSbvControles.CT006.getMessage(2, "11"), rejets.get(0));

	}

	@Test
	public void fichierAvecCaractereSpecial() throws IOException {
		// Act
		String nomFichier = "SBV_FICHIER_FORCAGE_06102019.csv";
		importFile(nomFichier);

		List<String> rejets = lireFichierRejet();
		assertNotNull(rejets);
		assertEquals(1, rejets.size());
		assertEquals(ForcageSbvControles.CT014.getMessage("2"), rejets.get(0));

	}

}

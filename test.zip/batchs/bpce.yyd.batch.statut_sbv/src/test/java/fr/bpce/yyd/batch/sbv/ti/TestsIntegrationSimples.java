package fr.bpce.yyd.batch.sbv.ti;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

import org.junit.Test;

import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.sbv.beans.LigneStatutSbv;
import fr.bpce.yyd.batch.sbv.enums.ForcageSbvControles;
import fr.bpce.yyd.commun.model.StatutSbv;

public class TestsIntegrationSimples extends AbstractIntegrationTest {

	@Test
	public void testFichierSansRejet() throws IOException {
		// Act
		String nomFichier = "SBV_FICHIER_FORCAGE_07102019.csv";
		importFile(nomFichier);

		// Fichier rejet avec entete uniquement
		List<String> fichierRejets = lireFichierRejet();
		assertNotNull(fichierRejets);
		assertEquals(1, fichierRejets.size());
		assertEquals(Constant.ENTETE_FIC_REJET_SBV, fichierRejets.get(0));

		List<StatutSbv> statutSbvDb = findAllStatutSbv();
		assertNotNull(statutSbvDb);
		assertEquals(5, statutSbvDb.size());

		// controller par rapport au fichier IN
		List<LigneStatutSbv> statutSbvFic = lireFichierIn(nomFichier);
		assertNotNull(statutSbvFic);
		assertEquals(5, statutSbvFic.size());

		for (int i = 0; i < statutSbvFic.size(); i++) {
			LigneStatutSbv ligneFichieri = statutSbvFic.get(i);
			StatutSbv ligneDbi = statutSbvDb.get(i);
			assertionEgalite(ligneFichieri, ligneDbi);

		}

	}

	@Test
	public void testFichierAvec7Rejet() throws IOException {
		// Act
		String nomFichier = "SBV_FICHIER_FORCAGE_08102019.csv";
		importFile(nomFichier);

		// Fichier rejet avec entete uniquement
		List<String> fichierRejets = lireFichierRejet();
		assertNotNull(fichierRejets);
		assertEquals(7, fichierRejets.size());
		assertEquals(Constant.ENTETE_FIC_REJET_SBV, fichierRejets.get(0));

		assertEquals(";;;;2;" + ForcageSbvControles.CF001.getMessage(), fichierRejets.get(1));
		assertEquals(";12128;;;4;" + ForcageSbvControles.CF009.getMessage(), fichierRejets.get(2));
		assertEquals("000001;12128;1542131541;;6;" + ForcageSbvControles.CT010.getMessage("20190511954"),
				fichierRejets.get(3));
		assertEquals("000001;12128;1542131541;;6;" + ForcageSbvControles.CT011.getMessage("20194545"),
				fichierRejets.get(4));
		assertEquals("000001;12128;1542131584;;7;" + ForcageSbvControles.CF004.getMessage(), fichierRejets.get(5));

		assertEquals("000001;12128;1542131587;;9;" + ForcageSbvControles.CF005.getMessage("D,ND"),
				fichierRejets.get(6));

		List<StatutSbv> statutSbvDb = findAllStatutSbv();
		assertNotNull(statutSbvDb);
		assertEquals(3, statutSbvDb.size());
	}

	@Test
	public void testFichierAvecChevauchementDates() throws IOException {
		// Act
		String nomFichier = "SBV_FICHIER_FORCAGE_09102019.csv";
		importFile(nomFichier);

		// Fichier rejet avec entete uniquement
		List<String> lignesFichierRejets = lireFichierRejet();
		assertNotNull(lignesFichierRejets);
		assertEquals(4, lignesFichierRejets.size());
		assertEquals(Constant.ENTETE_FIC_REJET_SBV, lignesFichierRejets.get(0));

		assertEquals("000001;12128;1542131545;;3;" + ForcageSbvControles.CF011.getMessage(),
				lignesFichierRejets.get(1));
		assertEquals("000001;12128;1542131587;;5;" + ForcageSbvControles.CF011.getMessage(),
				lignesFichierRejets.get(2));
		assertEquals("000001;12128;;;7;" + ForcageSbvControles.CF011.getMessage(), lignesFichierRejets.get(3));

		List<StatutSbv> statutSbvDb = findAllStatutSbv();
		assertNotNull(statutSbvDb);
		assertEquals(3, statutSbvDb.size());

		// controller par rapport au fichier en entrée
		List<LigneStatutSbv> statutSbvFic = lireFichierIn(nomFichier);
		assertNotNull(statutSbvFic);
		assertEquals(6, statutSbvFic.size());
		assertionEgalite(statutSbvFic.get(0), statutSbvDb.get(0));
		assertionEgalite(statutSbvFic.get(2), statutSbvDb.get(1));
		assertionEgalite(statutSbvFic.get(4), statutSbvDb.get(2));

	}

	@Test
	public void testFichier12Rejets() throws IOException {
		// Act
		String nomFichier = "SBV_FICHIER_FORCAGE_27082020.csv";
		importFile(nomFichier);

		List<String> fichierRejets = lireFichierRejet();
		assertNotNull(fichierRejets);
		assertEquals(13, fichierRejets.size());
		assertEquals(Constant.ENTETE_FIC_REJET_SBV, fichierRejets.get(0));

		List<StatutSbv> statutSbvDb = findAllStatutSbv();
		assertNotNull(statutSbvDb);
		assertEquals(0, statutSbvDb.size());
	}

	@Test
	public void testFichierAvecNomInvalide() throws IOException {
		// Act
		String nomFichier = "SBV_LJFICHIER_FORCAGE_27082020.csv";
		importFile(nomFichier);

		List<String> fichierRejets = lireFichierRejet();
		assertNotNull(fichierRejets);
		assertEquals(1, fichierRejets.size());
		assertEquals(ForcageSbvControles.CT002.getMessage(Constant.REG_NDOD_FORCAGE_SBV_FILE), fichierRejets.get(0));

	}

	private void assertionEgalite(LigneStatutSbv ligneFichieri, StatutSbv ligneDbi) {
		assertEquals(ligneFichieri.getCodeBanque(), convertNullToEmpty(ligneDbi.getCodeBanque()));
		assertEquals(ligneFichieri.getIdLocal(), convertNullToEmpty(ligneDbi.getIdLocal()));
		assertEquals(ligneFichieri.getIdRft(), convertNullToEmpty(ligneDbi.getIdRft()));
		assertEquals(ligneFichieri.getStatutForce(), convertNullToEmpty(ligneDbi.getStatutForce()));
		assertEquals(ligneFichieri.getGravite(), convertNullToEmpty(ligneDbi.getGravite()));
		assertEquals(ligneFichieri.getDateDebut(), convertDateToString(ligneDbi.getDateDebut()));
		assertEquals(ligneFichieri.getDateFin(), convertDateToString(ligneDbi.getDateFin()));
		assertEquals(ligneFichieri.getCommentaire(), convertNullToEmpty(ligneDbi.getCommentaire()));
		assertEquals(ligneFichieri.getCodificationMotif(), convertNullToEmpty(ligneDbi.getCodificationMotif()));
	}

	private String convertNullToEmpty(String chaine) {
		return chaine == null ? "" : chaine;
	}

	private String convertDateToString(LocalDate date) {
		if (date == null) {
			return "";
		}
		return date.format(Constant.YYYYMMDD_FORMATTER);

	}

}

package fr.bpce.yyd.batch.sbv.ti;

import java.io.File;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;

import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.sbv.beans.LigneStatutSbv;
import fr.bpce.yyd.batch.sbv.service.impl.ControlReferenceSrvcImpl;
import fr.bpce.yyd.commun.model.AuditFichiers;
import fr.bpce.yyd.commun.model.AuditLignesImport;
import fr.bpce.yyd.commun.model.StatutSbv;

public abstract class AbstractIntegrationTest {

	public static final String TEST_FILES_FOLDER_NAME = "./src/test/resources/ti/fichiers/";

	public static final String TEST_REJET_FOLDER_NAME = "./src/test/resources/ti/rejets/";

	@FunctionalInterface
	public interface TransactionCallback {
		void doInTransaction();
	}

	private static ApplicationContext context = null;
	private static TransactionTemplate transactionTemplate = null;

	@BeforeClass
	public static void initSpring() throws IOException {
		// PropertyConfigurator.configure(ClassLoader.getSystemClassLoader().getResource("log4j-ti.properties"));
		context = new ClassPathXmlApplicationContext("classpath:JobLauncher-context-ti.xml");
		transactionTemplate = new TransactionTemplate(getTransactionManager());
		initDataReference();
		createFolderIfAbsent(TEST_REJET_FOLDER_NAME);
	}

	@AfterClass
	public static void supprimerFichierRepRejet() throws IOException {
		removeAllFilesInFolder(TEST_REJET_FOLDER_NAME);
	}

	@Before
	public void nettoyerRepRejet() throws IOException {
		removeAllFilesInFolder(TEST_REJET_FOLDER_NAME);
	}

	private static void initDataReference() {
		// initialiser les données statiques
		ControlReferenceSrvcImpl referenceSrvc = context.getBean(ControlReferenceSrvcImpl.class);
		referenceSrvc.setCodbqList(Arrays.asList("10107", "10807", "12128", "17515", "11138"));
	}

	public static ApplicationContext getContext() {
		return context;
	}

	/**
	 * Import d'un fichier dans le dossier par défaut des TI
	 *
	 * @param filename
	 */
	public BatchStatus importFile(String filename) {
		return importFile(TEST_FILES_FOLDER_NAME, filename);
	}

	public List<String> lireFichierRejet() throws IOException {
		// lecture du fichier de rejet:
		File repRejets = new File(TEST_REJET_FOLDER_NAME);
		File fichierRejet = repRejets.listFiles()[0];
		List<String> rejets = Files.readAllLines(fichierRejet.toPath());
		return rejets;
	}

	public List<LigneStatutSbv> lireFichierIn(String nomFIchier) throws IOException {
		// lecture du fichier de rejet:
		try (Reader reader = Files.newBufferedReader(Paths.get(TEST_FILES_FOLDER_NAME + nomFIchier))) {
			// parser le fichier csv avec openCSV
			CsvToBean<LigneStatutSbv> csvToBeanBuilder = new CsvToBeanBuilder<LigneStatutSbv>(reader)
					.withType(LigneStatutSbv.class) //
					.withSeparator(Constant.CHAR_POINT_VIRGULE).withSkipLines(1).build();//
			return csvToBeanBuilder.parse();
		}
	}

	public static void removeAllFilesInFolder(String folderName) throws IOException {
		Path folderPath = Paths.get(folderName);
		DirectoryStream<Path> stream = Files.newDirectoryStream(folderPath);
		for (Path entry : stream) {
			File file = entry.toFile();
			if (file.isFile()) {
				file.delete();
			}
		}
	}

	/**
	 * Import d'un fichier se situant dans un dossier précisé.
	 *
	 * @param folder
	 * @param filename
	 */
	public BatchStatus importFile(String folder, String filename) {
		Job job = (Job) context.getBean(Constant.JOB_FORCAGE_SBV);
		JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");
		JobParameters jobParameters = new JobParametersBuilder().addString("file", folder + filename)
				.addString("dateLancement", LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME))
				.addString("repertoireRejet", TEST_REJET_FOLDER_NAME).toJobParameters();
		try {
			JobExecution execution = jobLauncher.run(job, jobParameters);
			return execution.getStatus();
		} catch (Exception e) {
			e.printStackTrace();
			return BatchStatus.UNKNOWN;
		}
	}

	public EntityManager getEntityManager() {
		return (EntityManager) context.getBean("entityManager");
	}

	public static JpaTransactionManager getTransactionManager() {
		return (JpaTransactionManager) context.getBean("transactionManager");
	}

	/**
	 * Exécute la méthode check() du paramètre checker au sein d'une transaction.
	 * Utilisée pour les assertions d'après import. Elles doivent effectivement être
	 * exécutées au sein d'une transaction pour pouvoir parcourir les relations
	 * ayant un chargement à la demande (LAZY).
	 *
	 * @param checker
	 */
	public void doInTransaction(final TransactionCallback checker) {
		transactionTemplate.execute(new TransactionCallbackWithoutResult() {
			@Override
			protected void doInTransactionWithoutResult(TransactionStatus status) {
				checker.doInTransaction();
			}
		});
	}

	private void deleteEntityData(Class<?> entityClass) {
		EntityManager entityManager = getEntityManager();
		Query delQuery = entityManager.createQuery("delete from " + entityClass.getSimpleName());
		delQuery.executeUpdate();
	}

	/**
	 * Entre chaque test, la base est entièrement vidée.
	 */
	@After
	public void resetData() {
		transactionTemplate.execute(new TransactionCallbackWithoutResult() {
			@Override
			protected void doInTransactionWithoutResult(TransactionStatus status) {
				deleteEntityData(AuditFichiers.class);
				deleteEntityData(AuditLignesImport.class);
				deleteEntityData(StatutSbv.class);
			}
		});
	}

	/**
	 * Utilitaire pour assertions : retourne l'instance d'AuditFichiers
	 * correspondant au nom de fichier paramètre.
	 *
	 * @param nomFichier
	 * @return
	 */
	public AuditFichiers findAuditFichierByNomFichier(String nomFichier) {
		EntityManager entityManager = getEntityManager();
		TypedQuery<AuditFichiers> query = entityManager
				.createQuery("select af from AuditFichiers af where af.nomFichier = :nomFichier", AuditFichiers.class);
		query.setParameter("nomFichier", nomFichier);
		return query.getSingleResult();
	}

	/**
	 * Utilitaire pour assertions : retourne l'ensemble des statut SBV en base.
	 *
	 * @return
	 */
	public List<StatutSbv> findAllStatutSbv() {
		TypedQuery<StatutSbv> query = getEntityManager().createQuery("select statut from StatutSbv statut",
				StatutSbv.class);
		return query.getResultList();
	}

	public List<StatutSbv> findStatutByIdLocal(Long idLocal) {
		TypedQuery<StatutSbv> query = getEntityManager()
				.createQuery("select s from StatutSbv s where s.idLocal = :idLocal", StatutSbv.class);
		query.setParameter("idLocal", idLocal);
		return query.getResultList();

	}

	protected static void createFolderIfAbsent(String folderName) throws IOException {
		File folderAsFile = new File(folderName);
		if (folderAsFile.exists()) {
			if (folderAsFile.isDirectory()) {
				return;
			}
			folderAsFile.delete(); // Si un fichier existe avec ce nom.
		}
		folderAsFile.mkdir();
	}
}

package fr.bpce.yyd.batch.sbv.service;

public interface ControlReferenceSrvc {

	boolean isCodeBanqueValid(String codeBq);

}

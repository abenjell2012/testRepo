package fr.bpce.yyd.batch.sbv.beans;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.opencsv.bean.CsvBindByPosition;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LigneStatutSbv {

	@CsvBindByPosition(position = 0)
	private String idLocal;

	@CsvBindByPosition(position = 1)
	private String codeBanque;

	@CsvBindByPosition(position = 2)
	private String idRft;

	@CsvBindByPosition(position = 3)
	private String siren;

	@CsvBindByPosition(position = 4)
	private String dateDebut;

	@CsvBindByPosition(position = 5)
	private String dateFin;

	@CsvBindByPosition(position = 6)
	private String statutForce;

	@CsvBindByPosition(position = 7)
	private String gravite;

	@CsvBindByPosition(position = 8)
	private String codificationMotif;

	@CsvBindByPosition(position = 9)
	private String commentaire;

	private int numLigne;
	private boolean valide = true;
	private LocalDate localDateDebut;
	private LocalDate localDateFin;

	List<LigneRejetSbv> rejetsList = new ArrayList<>();

	public void addRejet(LigneRejetSbv ligneRejetSbv) {
		valide = false;
		this.rejetsList.add(ligneRejetSbv);

	}

}

package fr.bpce.yyd.batch.sbv.task;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

public class PurgeTableStatutSbvTask implements Tasklet {

	@Autowired
	private EntityManager entityManager;

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {

		Query truncateQuery = entityManager.createNativeQuery("TRUNCATE TABLE STATUT_SBV");
		truncateQuery.executeUpdate();

		return RepeatStatus.FINISHED;
	}

}

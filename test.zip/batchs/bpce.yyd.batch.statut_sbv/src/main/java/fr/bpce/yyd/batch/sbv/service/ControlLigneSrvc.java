package fr.bpce.yyd.batch.sbv.service;

import java.util.List;
import java.util.Map;

import fr.bpce.yyd.batch.sbv.beans.LigneStatutSbv;

public interface ControlLigneSrvc {

	boolean isLigneValide(LigneStatutSbv lgnSbv, Map<String, List<LigneStatutSbv>> hashMapLgn);

}

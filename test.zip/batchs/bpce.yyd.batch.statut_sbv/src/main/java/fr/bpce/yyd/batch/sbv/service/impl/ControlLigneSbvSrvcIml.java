package fr.bpce.yyd.batch.sbv.service.impl;

import static fr.bpce.yyd.batch.commun.utils.DateUtil.isFormatDateValid;
import static fr.bpce.yyd.batch.commun.utils.DateUtil.parseDate;
import static fr.bpce.yyd.batch.commun.utils.StringUtil.isEmpty;
import static fr.bpce.yyd.batch.commun.utils.StringUtil.isSizeExceeded;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.commun.utils.DateUtil;
import fr.bpce.yyd.batch.commun.utils.StringUtil;
import fr.bpce.yyd.batch.sbv.beans.LigneRejetSbv;
import fr.bpce.yyd.batch.sbv.beans.LigneStatutSbv;
import fr.bpce.yyd.batch.sbv.enums.ForcageSbvControles;
import fr.bpce.yyd.batch.sbv.service.ControlLigneSrvc;
import fr.bpce.yyd.batch.sbv.service.ControlReferenceSrvc;

@Service
public class ControlLigneSbvSrvcIml implements ControlLigneSrvc {

	@Autowired
	private ControlReferenceSrvc controlReferenceSrvc;

	private static final int ID_LOC_SIZE = 50;
	private static final int ID_RFT_SIZE = 10;
	private static final int CODE_BQ_SIZE = 5;
	private static final int MOTIF_FORCAGE_SIZE = 500;
	private static final int COMMENTAIRE_SIZE = 500;
	private static final String DEFAUT = "D";
	private static final String NON_DEFAUT = "ND";
	private static final List<String> STATUTS_FORCE_LIST = Arrays.asList(DEFAUT, NON_DEFAUT);
	private static final List<String> GRAVITES_LIST = Arrays.asList("CX", "RX", "DX");

	@Override
	public boolean isLigneValide(LigneStatutSbv lgnSbv, Map<String, List<LigneStatutSbv>> hashMapLgn) {

		if (isEmpty(lgnSbv.getCodeBanque()) && isEmpty(lgnSbv.getIdLocal()) && isEmpty(lgnSbv.getIdRft())) {
			addRejet(lgnSbv, ForcageSbvControles.CF001);
			return false;
		}

		if (isEmpty(lgnSbv.getIdRft()) && (isEmpty(lgnSbv.getIdLocal()) || isEmpty(lgnSbv.getCodeBanque()))) {
			// rejet car le couple est obligatoire
			addRejet(lgnSbv, ForcageSbvControles.CF009);
			return false;
		}

		if (isEmpty(lgnSbv.getIdLocal()) || isEmpty(lgnSbv.getCodeBanque())) {
			// rejet car le couple est obligatoire
			addRejet(lgnSbv, ForcageSbvControles.CF009);
			return false;
		}

		// controle taille Id RFT
		if (isSizeExceeded(lgnSbv.getIdRft(), ID_RFT_SIZE)) {
			addRejet(lgnSbv, ForcageSbvControles.CT009, ID_RFT_SIZE);
		}
		// controle taille Identifiant local
		if (isSizeExceeded(lgnSbv.getIdLocal(), ID_LOC_SIZE)) {
			addRejet(lgnSbv, ForcageSbvControles.CT007, ID_LOC_SIZE);
		}
		// controle taille code banque
		if (!isEmpty(lgnSbv.getCodeBanque()) && lgnSbv.getCodeBanque().length() != CODE_BQ_SIZE) {
			addRejet(lgnSbv, ForcageSbvControles.CT008, CODE_BQ_SIZE);
		}
		// controle l'existence du code banque dans le référentiel
		if (!isEmpty(lgnSbv.getCodeBanque()) && !controlReferenceSrvc.isCodeBanqueValid(lgnSbv.getCodeBanque())) {
			addRejet(lgnSbv, ForcageSbvControles.CF002, lgnSbv.getCodeBanque());
		}

		// controle date de debut
		boolean isDateDebutValide = false;
		if (isEmpty(lgnSbv.getDateDebut())) {
			// si vide rejet
			addRejet(lgnSbv, ForcageSbvControles.CF003);
		} else {
			// sinon vérifier le format YYYYDDMM
			isDateDebutValide = isFormatDateValid(lgnSbv.getDateDebut(), Constant.YYYYMMDD_FORMATTER);
			if (!isDateDebutValide) {
				addRejet(lgnSbv, ForcageSbvControles.CT010, lgnSbv.getDateDebut());
			} else {
				// date debut avec format valide
				lgnSbv.setLocalDateDebut(parseDate(lgnSbv.getDateDebut()));
				if (lgnSbv.getLocalDateDebut().isAfter(LocalDate.now())) {
					addRejet(lgnSbv, ForcageSbvControles.CF007);
				}
			}
		}
		// controle date de fin
		if (!isEmpty(lgnSbv.getDateFin())) {
			boolean isDateFinValide = isFormatDateValid(lgnSbv.getDateFin(), Constant.YYYYMMDD_FORMATTER);
			if (!isDateFinValide) {
				addRejet(lgnSbv, ForcageSbvControles.CT011, lgnSbv.getDateFin());
			} else {
				lgnSbv.setLocalDateFin(parseDate(lgnSbv.getDateFin()));
				if (isDateDebutValide && lgnSbv.getLocalDateDebut().compareTo(lgnSbv.getLocalDateFin()) >= 0) {
					addRejet(lgnSbv, ForcageSbvControles.CF004);
				}
			}
		}

		if (!STATUTS_FORCE_LIST.contains(lgnSbv.getStatutForce())) {
			addRejet(lgnSbv, ForcageSbvControles.CF005, String.join(",", STATUTS_FORCE_LIST));
		}

		if (DEFAUT.equals(lgnSbv.getStatutForce()) && !isEmpty(lgnSbv.getGravite())
				&& !GRAVITES_LIST.contains(lgnSbv.getGravite())) {
			addRejet(lgnSbv, ForcageSbvControles.CF006, String.join(",", GRAVITES_LIST));
		}

		if (StringUtil.isSizeExceeded(lgnSbv.getCodificationMotif(), MOTIF_FORCAGE_SIZE)) {
			addRejet(lgnSbv, ForcageSbvControles.CT012, MOTIF_FORCAGE_SIZE);
		}
		if (StringUtil.isSizeExceeded(lgnSbv.getCommentaire(), COMMENTAIRE_SIZE)) {
			addRejet(lgnSbv, ForcageSbvControles.CT013, COMMENTAIRE_SIZE);
		}

		if (lgnSbv.isValide()) {
			String cle = null;
			if (!isEmpty(lgnSbv.getIdRft())) {
				cle = lgnSbv.getIdRft().trim();
			} else {
				cle = lgnSbv.getIdLocal().trim() + "." + lgnSbv.getCodeBanque().trim();
			}
			if (!hashMapLgn.containsKey(cle)) {
				List<LigneStatutSbv> listSbv = new ArrayList<>();
				listSbv.add(lgnSbv);
				hashMapLgn.put(cle, listSbv);
			} else {
				// controle chevauchement de date
				boolean isChevauchement = isChevauchement(lgnSbv, hashMapLgn.get(cle));
				if (isChevauchement) {
					addRejet(lgnSbv, ForcageSbvControles.CF011);
				}
				hashMapLgn.get(cle).add(lgnSbv);
			}
		}
		return lgnSbv.isValide();
	}

	private boolean isChevauchement(LigneStatutSbv lgnSbv, List<LigneStatutSbv> listDoublon) {

		for (LigneStatutSbv lgnSbvD : listDoublon) {
			if (DateUtil.isDatesOverlaps(lgnSbv.getLocalDateDebut(), lgnSbv.getLocalDateFin(),
					lgnSbvD.getLocalDateDebut(), lgnSbvD.getLocalDateFin())) {
				return true;
			}
		}
		return false;

	}

	public void addRejet(LigneStatutSbv lgnSbv, ForcageSbvControles codeErreur, Object... argumentsErreur) {
		LigneRejetSbv rejetSbv = new LigneRejetSbv();
		rejetSbv.setCodeBq(lgnSbv.getCodeBanque());
		rejetSbv.setIdFederal(lgnSbv.getIdRft());
		rejetSbv.setIdTiersLocal(lgnSbv.getIdLocal());
		rejetSbv.setNumLigne(lgnSbv.getNumLigne());
		rejetSbv.setSiren(lgnSbv.getSiren());
		rejetSbv.setMotifRejet(codeErreur.getMessage(argumentsErreur));
		lgnSbv.addRejet(rejetSbv);
	}

}

package fr.bpce.yyd.batch.sbv.task;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.MessageFormat;
import java.time.LocalDateTime;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;

import com.opencsv.CSVParser;
import com.opencsv.CSVParserBuilder;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;

import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.commun.exception.InvalidFileException;
import fr.bpce.yyd.batch.sbv.beans.SbvFileInfo;
import fr.bpce.yyd.batch.sbv.enums.ForcageSbvControles;

public class ValidationFichierTask implements Tasklet {

	private static final Logger LOGGER = Logger.getLogger(ValidationFichierTask.class);

	private String fichier;
	private String repertoireRejet;
	private SbvFileInfo sbvFile;

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

		sbvFile.initInfosFile(new File(fichier));

		if (!sbvFile.isNomValid()) {
			generateRejetFile(ForcageSbvControles.CT002, Constant.REG_NDOD_FORCAGE_SBV_FILE);
		}
		if (!sbvFile.isFormatDateFichierValid()) {
			generateRejetFile(ForcageSbvControles.CT003, sbvFile.getDateFichier(), Constant.FORMAT_DATE_DDMMYYYY);
		}
		// Controle que le fichier n'est pas vide
		if (sbvFile.erreurDeLecture()) {
			generateRejetFile(ForcageSbvControles.CT001, fichier);
		} else if (sbvFile.isFichierVide()) {
			generateRejetFile(ForcageSbvControles.CT004, fichier);
		} else if (sbvFile.isFichierAvecEnteteSeul()) {
			if (!Constant.ENTETE_FIC_SBV.equals(sbvFile.getLigneEntete())) {
				LOGGER.warn("Entête recue = " + sbvFile.getLigneEntete());
			}
			generateRejetFile(ForcageSbvControles.CT015, fichier);
		}
		// vérifier que le fichier est bien formaté
		controlerFormatCsv();

		return RepeatStatus.FINISHED;
	}

	private void controlerFormatCsv() throws FileNotFoundException, InvalidFileException {
		CSVParser csvParser = new CSVParserBuilder().withSeparator(Constant.CHAR_POINT_VIRGULE).withQuoteChar('µ')
				.build();
		CSVReader csvReader = new CSVReaderBuilder(new FileReader(fichier)).withCSVParser(csvParser).build();
		Integer numLigne = 0;
		try {
			String[] nextLine;
			while ((nextLine = csvReader.readNext()) != null) {
				numLigne++;
				if (nextLine.length != 10) { // fichier mal formaté
					generateRejetFile(ForcageSbvControles.CT006, numLigne, nextLine.length);
				}
			}
		} catch (IOException e) {
			generateRejetFile(ForcageSbvControles.CT014, numLigne);
		}
	}

	private void generateRejetFile(ForcageSbvControles ctrl, Object... arguments)
			throws FileNotFoundException, InvalidFileException {

		String rejetMessage = ctrl.getMessage(arguments);
		String rejetFileName = MessageFormat.format(Constant.REJET_FORCAGE_SBV_FILE,
				LocalDateTime.now().format(Constant.DATE_TIME_FORMATTER_2));

		File rejetSbvFile = new File(repertoireRejet + rejetFileName);
		try (PrintWriter pw = new PrintWriter(rejetSbvFile)) {
			pw.write(rejetMessage);
		}
		throw new InvalidFileException(rejetMessage);

	}

	public void setFichier(String fichier) {
		this.fichier = fichier;
	}

	public void setRepertoireRejet(String repertoireRejet) {
		this.repertoireRejet = repertoireRejet;
	}

	public void setSbvFile(SbvFileInfo sbvFile) {
		this.sbvFile = sbvFile;
	}

}

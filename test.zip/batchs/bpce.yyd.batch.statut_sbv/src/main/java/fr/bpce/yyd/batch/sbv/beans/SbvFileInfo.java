package fr.bpce.yyd.batch.sbv.beans;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.commun.utils.DateUtil;

public class SbvFileInfo {

	public static final Integer FICHIER_VIDE = -1;
	public static final Integer FICHIER_AVEC_ENTETE_SEUL = 0;
	public static final Integer ERREUR_LECTURE = -3;

	private static final Logger LOGGER = Logger.getLogger(SbvFileInfo.class);

	private File file;
	private boolean nomValid;
	private boolean formatDateFichierValid;
	private String dateFichier;
	private Integer nbLines;
	private int nbLinesRejet = 0;
	private String ligneEntete;

	public void initInfosFile(File file) {
		this.file = file;
		Pattern patternSbvFile = Pattern.compile(Constant.REG_NDOD_FORCAGE_SBV_FILE);
		Matcher matcherRegExp = patternSbvFile.matcher(file.getName());
		if (!matcherRegExp.matches()) {
			nomValid = false;
		} else {
			nomValid = true;
			dateFichier = matcherRegExp.group(1);
			formatDateFichierValid = DateUtil.isFormatDateValid(dateFichier, Constant.DDMMYYYY_FORMATTER);
		}
	}

	private void initNbLigneEntete(File fichier) throws IOException {
		int nb = 0;
		FileReader fR = new FileReader(fichier);
		BufferedReader bR = new BufferedReader(fR);
		int nbLignesVide = 0;

		try {
			String line = bR.readLine();
			if (line != null) {
				nb++;
				setLigneEntete(line);

				// Nombre total des lignes trouvées inclut entete et footer.
				while ((line = bR.readLine()) != null) {
					if (!line.trim().isEmpty()) {
						nb++;
					} else {
						nbLignesVide++;
						LOGGER.info("Ligne vide trouvée à la ligne " + (nb + nbLignesVide));
					}
				}
			}
		} finally {
			bR.close();
		}
		// on enleve l'entete
		nbLines = nb - 1;
	}

	@Override
	public String toString() {
		return file.getName();
	}

	public File getFile() {
		return file;
	}

	public boolean erreurDeLecture() {
		return ERREUR_LECTURE.equals(getNbLines());
	}

	public boolean isFichierVide() {
		return FICHIER_VIDE.equals(getNbLines());
	}

	public boolean isFichierAvecEnteteSeul() {
		return FICHIER_AVEC_ENTETE_SEUL.equals(getNbLines());
	}

	public Integer getNbLines() {
		if (nbLines == null) {
			try {
				initNbLigneEntete(file);
			} catch (IOException e) {
				nbLines = ERREUR_LECTURE;
			}
		}
		return nbLines;
	}

	public Integer getNbLinesAudit() {
		return getNbLines() < 0 ? 0 : getNbLines();
	}

	public Integer getNbLinesRejet() {
		return nbLinesRejet;
	}

	public Integer incrementeNbLinesRejet() {
		return ++nbLinesRejet;
	}

	public void setNbLinesRejet(Integer nbLinesRejet) {
		this.nbLinesRejet = nbLinesRejet;
	}

	public String getLigneEntete() {
		return ligneEntete;
	}

	public void setLigneEntete(String ligneEntete) {
		this.ligneEntete = ligneEntete;
	}

	public boolean isNomValid() {
		return nomValid;
	}

	public void setNomValid(boolean nomValid) {
		this.nomValid = nomValid;
	}

	public boolean isFormatDateFichierValid() {
		return formatDateFichierValid;
	}

	public void setFormatDateFichierValid(boolean formatDateFichierValid) {
		this.formatDateFichierValid = formatDateFichierValid;
	}

	public String getDateFichier() {
		return dateFichier;
	}

	public void setDateFichier(String dateFichier) {
		this.dateFichier = dateFichier;
	}

}

package fr.bpce.yyd.batch.sbv.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.sbv.service.ControlReferenceSrvc;

@Service
public class ControlReferenceSrvcImpl implements ControlReferenceSrvc {

	private static final String PARAM_TOP_SUPPR = "topSuppr";

	@Autowired
	private EntityManager entityManager;

	private List<String> codbqList = new ArrayList<>();

	@Override
	public boolean isCodeBanqueValid(String codeBq) {
		if (codbqList.isEmpty()) {
			TypedQuery<String> query = entityManager.createQuery("select codBq from RefBqBfbp where topSuppr=:topSuppr",
					String.class);
			query.setParameter(PARAM_TOP_SUPPR, Constant.FLAG_NON);
			codbqList = query.getResultList();
		}
		return codbqList.contains(codeBq);

	}

	public void setCodbqList(List<String> codbqList) {
		this.codbqList = codbqList;
	}
}

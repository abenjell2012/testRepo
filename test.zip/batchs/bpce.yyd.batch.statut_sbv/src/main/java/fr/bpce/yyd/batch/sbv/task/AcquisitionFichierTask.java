package fr.bpce.yyd.batch.sbv.task;

import java.io.FileWriter;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.text.MessageFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;
import com.opencsv.bean.StatefulBeanToCsv;
import com.opencsv.bean.StatefulBeanToCsvBuilder;

import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.sbv.beans.LigneRejetSbv;
import fr.bpce.yyd.batch.sbv.beans.LigneStatutSbv;
import fr.bpce.yyd.batch.sbv.service.ControlLigneSrvc;
import fr.bpce.yyd.commun.model.StatutSbv;

public class AcquisitionFichierTask implements Tasklet {

	private static final String INSERT_QUERY = "INSERT INTO STATUT_SBV (ID_LOCAL, CODE_BANQUE, ID_RFT, DATE_GENERATION, DATE_DEBUT, DATE_FIN, STATUT_FORCE, GRAVITE, MOTIF_FORCAGE, COMMENTAIRE) "
			+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	private static final Logger LOGGER = Logger.getLogger(AcquisitionFichierTask.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private ControlLigneSrvc controlLigneSrvc;

	private String fichier;
	private String repertoireRejet;

	@Transactional
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

		Map<String, List<LigneStatutSbv>> hashMapLgn = new HashMap<>();
		// preparation fichier de rejet (généré dans tous les cas)
		String nomFichierRejet = MessageFormat.format(Constant.REJET_FORCAGE_SBV_FILE,
				LocalDateTime.now().format(Constant.DATE_TIME_FORMATTER_2));

		try (Writer rejetWriter = new FileWriter(repertoireRejet + nomFichierRejet)) {
			rejetWriter.write(Constant.ENTETE_FIC_REJET_SBV + "\n");
			StatefulBeanToCsv<LigneRejetSbv> rejetCsvWriter = new StatefulBeanToCsvBuilder<LigneRejetSbv>(rejetWriter)
					.withSeparator(Constant.CHAR_POINT_VIRGULE).withApplyQuotesToAll(false).build();

			try (Reader reader = Files.newBufferedReader(Paths.get(fichier))) {
				// parser le fichier csv avec openCSV
				CsvToBean<LigneStatutSbv> csvToBeanBuilder = new CsvToBeanBuilder<LigneStatutSbv>(reader)
						.withType(LigneStatutSbv.class) //
						.withSeparator(Constant.CHAR_POINT_VIRGULE)//
						.withQuoteChar('µ').withSkipLines(1).build();//

				Iterator<LigneStatutSbv> ligneSbvIterator = csvToBeanBuilder.iterator();
				int numLigne = 2;
				int batchSize = 5000;
				int nbInserts = 0;
				int nbRejets = 0;
				List<StatutSbv> lignsSbvValid = new ArrayList<>();
				while (ligneSbvIterator.hasNext()) {
					LigneStatutSbv statutSbv = ligneSbvIterator.next();
					statutSbv.setNumLigne(numLigne);
					if (controlLigneSrvc.isLigneValide(statutSbv, hashMapLgn)) {
						lignsSbvValid.add(mapLineToEntity(statutSbv));
						if ((lignsSbvValid.size() % batchSize) == 0) {
							nbInserts += lignsSbvValid.size();
							LOGGER.info("Insertion de " + lignsSbvValid.size() + " Ligne(s) dans STATUT_SBV");
							batchInsert(lignsSbvValid);
							lignsSbvValid.clear();
						}
					} else {
						rejetCsvWriter.write(statutSbv.getRejetsList());
						nbRejets += statutSbv.getRejetsList().size();
					}
					numLigne++;
				}

				if (!lignsSbvValid.isEmpty()) {
					nbInserts += lignsSbvValid.size();
					LOGGER.info("Insertion de " + lignsSbvValid.size() + " Ligne(s) dans STATUT_SBV");
					batchInsert(lignsSbvValid);
					lignsSbvValid.clear();
				}
				LOGGER.info("Nombre de lignes chargées avec succès: [" + nbInserts + "], rejetés : [" + nbRejets + "]"
						+ " | Nombre lignes fichier = [" + (numLigne - 2) + "]");

			}
		}

		return RepeatStatus.FINISHED;

	}

	private void batchInsert(List<StatutSbv> lignsSbvValid) {
		jdbcTemplate.batchUpdate(INSERT_QUERY, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				StatutSbv statSbv = lignsSbvValid.get(i);
				ps.setString(1, statSbv.getIdLocal());
				ps.setString(2, statSbv.getCodeBanque());
				ps.setString(3, statSbv.getIdRft());
				ps.setTimestamp(4, java.sql.Timestamp.valueOf(statSbv.getDateGeneration()));

				ps.setDate(5, java.sql.Date.valueOf(statSbv.getDateDebut()));
				if (statSbv.getDateFin() != null) {
					ps.setDate(6, java.sql.Date.valueOf(statSbv.getDateFin()));
				} else {
					ps.setNull(6, Types.DATE);
				}
				ps.setString(7, statSbv.getStatutForce());
				ps.setString(8, statSbv.getGravite());
				ps.setString(9, statSbv.getCodificationMotif());
				ps.setString(10, statSbv.getCommentaire());
			}

			@Override
			public int getBatchSize() {
				return lignsSbvValid.size();
			}
		});

	}

	public void setRepertoireRejet(String repertoireRejet) {
		this.repertoireRejet = repertoireRejet;
	}

	public void setFichier(String fichier) {
		this.fichier = fichier;
	}

	public StatutSbv mapLineToEntity(LigneStatutSbv statSbv) {
		StatutSbv statutSbv = new StatutSbv();
		statutSbv.setCodeBanque(statSbv.getCodeBanque());
		statutSbv.setIdLocal(statSbv.getIdLocal());
		statutSbv.setIdRft(statSbv.getIdRft());
		statutSbv.setDateGeneration(LocalDateTime.now());
		statutSbv.setDateDebut(statSbv.getLocalDateDebut());
		statutSbv.setDateFin(statSbv.getLocalDateFin());
		statutSbv.setStatutForce(statSbv.getStatutForce());
		if ("D".equals(statSbv.getStatutForce())) {
			if (StringUtils.isBlank(statSbv.getGravite())) {
				statutSbv.setGravite("DX");
			} else {
				statutSbv.setGravite(statSbv.getGravite());
			}
		}
		statutSbv.setCodificationMotif(statSbv.getCodificationMotif().trim());
		statutSbv.setCommentaire(statSbv.getCommentaire().trim());
		return statutSbv;

	}

}

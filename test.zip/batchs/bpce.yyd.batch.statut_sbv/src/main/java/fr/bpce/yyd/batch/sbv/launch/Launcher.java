/**
* Ce package contient la classe main java pour lancer le batch.
**/
package fr.bpce.yyd.batch.sbv.launch;

import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.batchStatus;
import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.exitWithErrorCode;
import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.moveFileToDir;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import fr.bpce.yyd.batch.commun.configuration.ConfigManager;
import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.commun.exception.InvalidInitialisationException;
import fr.bpce.yyd.batch.commun.exception.UnknownPropertyException;
import fr.bpce.yyd.batch.commun.utils.FileCommunUtils;

public class Launcher {

	private static final String REP_SBV_REJET = "rep.sbv.rejet";
	private static final Logger LOGGER = Logger.getLogger(Launcher.class);

	private ApplicationContext context = null;

	public ApplicationContext getApplicationContext() {
		if (context == null) {
			context = new ClassPathXmlApplicationContext("classpath:JobLauncher-context.xml");
		}
		return context;
	}


	public void runBatch(String fileName) throws IOException {

		LOGGER.info("DEBUT BATCH " + Constant.JOB_FORCAGE_SBV);

		JobExecution execution = null;
		String fichier = null;
		String repertoireRejet = null;
		String repertoireOK = null;
		Path repertoireEnCours = null;
		Path movedFilePath = null;

		Job job = (Job) getApplicationContext().getBean(Constant.JOB_FORCAGE_SBV);
		JobLauncher jobLauncher = (JobLauncher) getApplicationContext().getBean("jobLauncher");

		try {
			repertoireRejet = ConfigManager.getProperty(REP_SBV_REJET);
			repertoireEnCours = Paths.get(ConfigManager.getProperty("rep.sbv.encours"));
			repertoireOK = ConfigManager.getProperty("rep.sbv.ok");
			// crée les répertoires s'ils n'existent pas déjà
			checkRepertoires();
		} catch (UnknownPropertyException | InvalidInitialisationException e) {
			LOGGER.error("Fichier [" + fileName + "] introuvable");
			exitWithErrorCode(1);
		}

		try {
			movedFilePath = moveFileToDir(Paths.get(fileName), repertoireEnCours);
			fichier = movedFilePath.toString();
		} catch (IOException e) {
			LOGGER.error("Propriété inconnu " + e.getMessage(), e);
			exitWithErrorCode(1);
		}

		LOGGER.info("Debut traitement fichier [" + fichier + "]");

		JobParameters jobParameters = new JobParametersBuilder().addString("file", fichier)
				.addString("repertoireRejet", repertoireRejet)
				.addString("dateLancement", LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME))
				.toJobParameters();
		try {
			execution = jobLauncher.run(job, jobParameters);
		} catch (Exception e) {
			LOGGER.info("Erreur inattendue en traitement du fichier " + fichier, e);
			exitWithErrorCode(1);
		} finally {
			finaliserTraitement(batchStatus(execution), movedFilePath, Paths.get(repertoireOK),
					Paths.get(repertoireRejet));
		}
		LOGGER.info("FIN BATCH " + Constant.JOB_FORCAGE_SBV);
	}

	private void checkRepertoires() throws UnknownPropertyException, InvalidInitialisationException {
		// crée les répertoires s'il n'existe pas déjà
		FileCommunUtils.checkRepertoire(ConfigManager.getProperty("rep.sbv.in"));
		FileCommunUtils.checkRepertoire(ConfigManager.getProperty("rep.sbv.ok"));
		FileCommunUtils.checkRepertoire(ConfigManager.getProperty("rep.sbv.encours"));
		FileCommunUtils.checkRepertoire(ConfigManager.getProperty(REP_SBV_REJET));

	}

	public static void main(String[] args) {
		PropertyConfigurator.configure(ClassLoader.getSystemClassLoader().getResource("log4j-forcage-sbv.properties"));
		Launcher launcher = new Launcher();
		if (args != null && args.length == 1) {
			String fileName = args[0];
			try {
				launcher.runBatch(fileName);
			} catch (IOException err) {
				LOGGER.error("Erreur inattendue en import du fichier de forcage sbv: " + err.getMessage(), err);
				exitWithErrorCode(1);
			}
		} else {
			LOGGER.error(
					"Erreur - mauvais paramètres en entrée, le nom du fichier au bon format avec son chemin attendu");
			exitWithErrorCode(1);
		}
	}

	private Path moveAndAddTimeStampToFile(Path filePath, Path destDirPath) throws IOException {
		String extension = FileCommunUtils.getExtension(filePath.toFile().getName());
		String fileNameWithoutExt = FileCommunUtils.removeFileExtension(filePath.toFile().getName());
		String timeStampedName = fileNameWithoutExt + "_" + LocalDateTime.now().format(Constant.DATE_TIME_FORMATTER_2)
				+ "." + extension;

		return FileCommunUtils.moveFileReplaceExist(filePath, destDirPath.resolve(timeStampedName));
	}

	private void finaliserTraitement(BatchStatus statut, Path repEncours, Path repSucces, Path repRejet)
			throws IOException {
		if (statut == BatchStatus.COMPLETED) {
			LOGGER.info("Fin traitement fichier [" + repEncours + "] OK");
			moveAndAddTimeStampToFile(repEncours, repSucces);
			exitWithErrorCode(0);
		} else {
			LOGGER.info("Fin traitement fichier [" + repEncours + "] KO");
			moveAndAddTimeStampToFile(repEncours, repRejet);
			exitWithErrorCode(1);
		}
	}

	public void setApplicationContext(ApplicationContext context) {
		this.context = context;

	}

}

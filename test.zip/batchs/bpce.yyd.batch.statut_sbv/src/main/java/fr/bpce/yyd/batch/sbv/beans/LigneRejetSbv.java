/**
* Ce package contient les java beans utilisés par le batch.
**/
package fr.bpce.yyd.batch.sbv.beans;

import com.opencsv.bean.CsvBindByPosition;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class LigneRejetSbv {

	@CsvBindByPosition(position = 0)
	private String idTiersLocal;

	@CsvBindByPosition(position = 1)
	private String codeBq;

	@CsvBindByPosition(position = 2)
	private String idFederal;

	@CsvBindByPosition(position = 3)
	private String siren;

	@CsvBindByPosition(position = 4)
	private int numLigne;

	@CsvBindByPosition(position = 5)
	private String motifRejet;

}

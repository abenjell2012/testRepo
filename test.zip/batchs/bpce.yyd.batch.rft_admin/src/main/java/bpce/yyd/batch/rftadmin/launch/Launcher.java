package bpce.yyd.batch.rftadmin.launch;

import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.exitWithErrorCode;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import bpce.yyd.batch.rftadmin.utils.Constants;
import bpce.yyd.batch.rftadmin.utils.GeneralUtility;
import fr.bpce.yyd.batch.commun.utils.FileCommunUtils;

public class Launcher {

	private static Logger logger = Logger.getLogger(Launcher.class);

	private ApplicationContext context = null;

	public void setApplicationContext(ApplicationContext newContext) {
		context = newContext;
	}

	public ApplicationContext getApplicationContext() {
		if (context == null) {
			context = new ClassPathXmlApplicationContext(Constants.CONTEXT_FILE_NAME);
		}
		return context;
	}

	public void runBatch(String fileName) throws IOException {

		Path movedFilePath = null;
		try {

			logger.info("Debut BATCH NDOD : import RFT Admin");

			Job job = (Job) getApplicationContext().getBean(Constants.JOB_NAME);
			JobLauncher jobLauncher = (JobLauncher) getApplicationContext().getBean("jobLauncher");

			Constants.setContext(context);
			Constants.initConstans();

			Path pathFileName = Paths.get(fileName);
			GeneralUtility.checkNameFileFormat(pathFileName);
			movedFilePath = GeneralUtility.moveFileToDir(pathFileName, Paths.get(Constants.getRepEncours()));
			GeneralUtility.initNbLignes(movedFilePath.toString());

			JobParameters jobParameters = new JobParametersBuilder().addLong("id", new Date().getTime())
					.addString("dateImport", GeneralUtility.getDateImport(pathFileName))
					.addString("fileSource", movedFilePath.toString()).toJobParameters();

			runJob(movedFilePath, job, jobLauncher, jobParameters);
		} catch (Exception err) {
			logger.error("Erreur inattendue : " + err.getMessage(), err);
			if (movedFilePath != null) {
				finaliserTraitement(null, movedFilePath, Paths.get(Constants.getRepOk()),
						Paths.get(Constants.getRepKo()));
			}
			exitWithErrorCode(1);
		}
		logger.info("Fin BATCH NDOD");
	}

	private void runJob(Path movedFilePath, Job job, JobLauncher jobLauncher, JobParameters jobParameters)
			throws IOException {
		JobExecution execution = null;
		try {
			execution = jobLauncher.run(job, jobParameters);

		} catch (Exception err) {
			logger.error("Erreur inattendue : " + err.getMessage(), err);
			exitWithErrorCode(1);
		} finally {
			finaliserTraitement(batchStatus(execution), movedFilePath, Paths.get(Constants.getRepOk()),
					Paths.get(Constants.getRepKo()));
		}
	}

	public static void main(String[] args) throws IOException {

		PropertyConfigurator.configure(ClassLoader.getSystemClassLoader().getResource(Constants.LOG_FILE_NAME));
		Launcher launcher = new Launcher();
		if (args != null && args.length == 1) {
			String secureStr = FileCommunUtils.sanitizePathRft(args[0]);
			launcher.runBatch(secureStr);
		} else {
			logger.error(
					"Erreur - mauvais paramètres en entrée, le nom du fichier au bon format avec son chemin attendu");
			exitWithErrorCode(1);
		}

	}

	private void finaliserTraitement(BatchStatus statut, Path encours, Path repSucces, Path repRejet)
			throws IOException {
		if (statut == BatchStatus.COMPLETED) {
			logger.info("Fin traitement fichier [" + encours + "] OK");
			GeneralUtility.moveFileToDir(encours, repSucces);
			exitWithErrorCode(0);
		} else {
			logger.info("Fin traitement fichier [" + encours + "] KO");
			GeneralUtility.moveFileToDir(encours, repRejet);
			exitWithErrorCode(1);
		}
	}

	private BatchStatus batchStatus(JobExecution execution) {
		return execution == null ? BatchStatus.UNKNOWN : execution.getStatus();
	}
}

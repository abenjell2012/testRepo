package bpce.yyd.batch.rftadmin.listener;

import java.io.File;
import java.time.LocalDate;
import java.util.Date;

import javax.persistence.EntityManager;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import bpce.yyd.batch.rftadmin.utils.Constants;
import fr.bpce.yyd.commun.enums.Controles;
import fr.bpce.yyd.commun.model.AuditFichiers;
import fr.bpce.yyd.commun.model.AuditLignesImport;

public class AcquisitionListener implements StepExecutionListener {

	@Autowired
	private EntityManager entityManager;

	@Autowired
	private PlatformTransactionManager transactionManager;

	private String fileSource;

	public void setFileSource(String fileSource) {
		this.fileSource = fileSource;
	}

	@Override
	public void beforeStep(StepExecution stepExecution) {

		String libelleAudit = Controles.FICENCOURS.getMessage();
		AuditFichiers audit = new AuditFichiers("", new File(fileSource).getName(), Constants.getNbLignes(), 0,
				new Date(), Controles.FICENCOURS, libelleAudit, LocalDate.now());
		audit.setJobExecutionId(stepExecution.getJobExecutionId());

		TransactionTemplate transactionTemplate = new TransactionTemplate(transactionManager);
		transactionTemplate.execute(new TransactionCallbackWithoutResult() {
			@Override
			protected void doInTransactionWithoutResult(TransactionStatus status) {
				entityManager.persist(audit);
				Constants.setAuditfichier(audit);
			}
		});
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {

		TransactionTemplate transactionTemplate = new TransactionTemplate(transactionManager);
		transactionTemplate.execute(new TransactionCallbackWithoutResult() {
			@Override
			protected void doInTransactionWithoutResult(TransactionStatus status) {
				for (AuditLignesImport ligne : Constants.getAuditfichier().getLignes()) {
					entityManager.persist(ligne);
				}
				String libelleAudit = Controles.FICOK.getMessage();
				Constants.getAuditfichier().setCodAudit(Controles.FICOK);
				Constants.getAuditfichier().setLibCodAudit(libelleAudit);
				Constants.getAuditfichier().setNbLignesRejet(Constants.getNbLignesRejTot());
				entityManager.merge(Constants.getAuditfichier());
			}
		});
		return ExitStatus.COMPLETED;
	}

}

package bpce.yyd.batch.rftadmin.task;

import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

public class ChargeRFTAdminADateTask implements Tasklet {

	private EntityManager entityManager;

	private String insertQuery;

	private LocalDate dateImport;

	@Autowired
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public void setDateImport(String dateImport) {
		this.dateImport = LocalDate.parse(dateImport, DateTimeFormatter.BASIC_ISO_DATE);
	}

	public void setInsertQuery(String insertQuery) {
		this.insertQuery = insertQuery;
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

		Query query = entityManager.createNativeQuery(insertQuery);
		query.setParameter("dateImport", Date.valueOf(dateImport));
		query.executeUpdate();

		return RepeatStatus.FINISHED;
	}

}

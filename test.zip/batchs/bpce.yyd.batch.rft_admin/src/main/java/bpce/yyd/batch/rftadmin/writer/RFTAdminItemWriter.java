package bpce.yyd.batch.rftadmin.writer;

import java.sql.BatchUpdateException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;

import bpce.yyd.batch.rftadmin.beans.RFTAdminImport;
import bpce.yyd.batch.rftadmin.utils.Constants;
import bpce.yyd.batch.rftadmin.utils.GeneralUtility;
import fr.bpce.yyd.batch.commun.exception.TechnicalException;
import fr.bpce.yyd.commun.model.AuditLignesImport;

public class RFTAdminItemWriter implements ItemWriter<RFTAdminImport> {

	private static final String INSERT_QUERY = "insert into RFT_ADMIN_TMP "
			+ "(IDENTIFIANT_FEDERAL,DENOMINATION_SOCIALE,DATE_DE_CREATION,PAYS_DE_RESIDENCE,CODE_BANQUE,"
			+ "LIBELLE_BANQUE,CODE_POSTAL,TOP_GD_GROUP,NIVEAU_WLN,DATE_ENTREE_WLN,DATE_SORTIE_WLN,"
			+ "STATUT_NATIONAL,DATE_ENTREE_SN,DATE_SORTIE_SN) " + "values (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

	private static Logger logger = Logger.getLogger(RFTAdminItemWriter.class);

	@Autowired
	private EntityManager entityManager;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	private int nbLignesOk;

	private int nbLignesKo;

	private int nbIteration;

	@Override
	public void write(List<? extends RFTAdminImport> items) throws Exception {

		ArrayList<RFTAdminImport> okList = new ArrayList<>();
		for (RFTAdminImport rftAdmin : items) {
			Constants.incrementeLigne();
			if (!GeneralUtility.validate(rftAdmin, Constants.getLigneCount())) {
				nbLignesKo++;
			} else {
				okList.add(rftAdmin);
				nbLignesOk++;
			}
		}

		try {
			batchInsert(okList);
		} catch (Exception exp) {
			if (exp.getCause() instanceof BatchUpdateException) {
				BatchUpdateException be = (BatchUpdateException) exp.getCause();
				int[] batchRes = be.getUpdateCounts();
				if (batchRes != null && batchRes.length > 0) {
					GeneralUtility.addImportLigneError(okList.get(batchRes.length),
							(nbIteration * 10000) + batchRes.length + 1, be.getMessage());
				}
			}
			throw new TechnicalException("", exp);
		}

		Constants.setNbLignesRejTot(nbLignesKo);
		nbIteration++;
		logger.info(GeneralUtility.generateLogMsg(nbLignesOk, nbLignesKo, Constants.getNbLignes()));
		saveDetailTrace();
	}

	private void batchInsert(ArrayList<RFTAdminImport> items) {

		jdbcTemplate.batchUpdate(INSERT_QUERY, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setString(1, items.get(i).getIdFederal());
				ps.setString(2, items.get(i).getDenominationSociale());
				ps.setString(3, items.get(i).getDateDeCreation());
				ps.setString(4, items.get(i).getPaysDeResidence());
				ps.setString(5, items.get(i).getCodeBanque());
				ps.setString(6, items.get(i).getLibelleBanque());
				ps.setString(7, items.get(i).getCodePostal());
				ps.setString(8, items.get(i).getTopGdGroup());
				ps.setString(9, items.get(i).getNiveauWln());
				ps.setString(10, items.get(i).getDateEntreeWln());
				ps.setString(11, items.get(i).getDateSortieWln());
				ps.setString(12, items.get(i).getStatutNational());
				ps.setString(13, items.get(i).getDateEntreeSn());
				ps.setString(14, items.get(i).getDateSortieSn());
			}

			@Override
			public int getBatchSize() {
				return items.size();
			}
		});
	}

	private void saveDetailTrace() {
		for (AuditLignesImport ligne : Constants.getAuditfichier().getLignes()) {
			entityManager.persist(ligne);
		}
		Constants.getAuditfichier().getLignes().clear();
	}

}

package bpce.yyd.batch.rftadmin.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import bpce.yyd.batch.rftadmin.beans.RFTAdminImport;
import fr.bpce.yyd.batch.commun.exception.InvalidFileException;
import fr.bpce.yyd.batch.commun.exception.TechnicalException;
import fr.bpce.yyd.commun.enums.Controles;
import fr.bpce.yyd.commun.model.AuditLignesImport;

public final class GeneralUtility {

	private GeneralUtility() {

	}

	public static void checkNameFileFormat(Path filePath) throws InvalidFileException {

		if (!filePath.toFile().exists()) {
			throw new InvalidFileException("Le fichier [" + filePath.toString() + "] est inexistant");
		}
		String filename = filePath.getFileName().toString();
		Pattern patternRftFile = Pattern.compile(Constants.REG_RFT_ADMIN);
		Matcher matcherRegExpRft = patternRftFile.matcher(filename);
		if (!matcherRegExpRft.matches()) {
			throw new InvalidFileException("Le format du nom du fichier [" + filename + "] est incorrect");
		}
	}

	public static Path moveFileToDir(Path filePath, Path destDirPath) throws IOException {

		return Files.move(filePath, destDirPath.resolve(filePath.getFileName()), StandardCopyOption.REPLACE_EXISTING);
	}

	public static String getDateImport(Path filePath) {

		String filename = filePath.getFileName().toString();
		return filename.substring(filename.length() - 12).replaceAll(".dat", "");
	}

	public static boolean validateLength(RFTAdminImport rftAdmin, Integer numLigne) {

		boolean valide = true;
		if (rftAdmin.getIdFederal().length() > 10) {
			Constants.getAuditfichier().getLignes().add(generateLignesImport(numLigne, rftAdmin.toString(),
					Controles.CT044, Constants.FIELD_IDENTIFIANT_FEDERAL, rftAdmin.getIdFederal().length(), 10));
			valide = false;
		}
		if (rftAdmin.getDenominationSociale().length() > 100) {
			Constants.getAuditfichier().getLignes()
					.add(generateLignesImport(numLigne, rftAdmin.toString(), Controles.CT044,
							Constants.FIELD_DENOMINATION_SOCIALE, rftAdmin.getDenominationSociale().length(), 100));
			valide = false;
		}
		if (rftAdmin.getDateDeCreation().length() > 10) {
			Constants.getAuditfichier().getLignes().add(generateLignesImport(numLigne, rftAdmin.toString(),
					Controles.CT044, Constants.FIELD_DATE_DE_CREATION, rftAdmin.getDateDeCreation().length(), 10));
			valide = false;
		}
		if (rftAdmin.getPaysDeResidence().length() > 3) {
			Constants.getAuditfichier().getLignes().add(generateLignesImport(numLigne, rftAdmin.toString(),
					Controles.CT044, Constants.FIELD_PAYS_DE_RESIDENCE, rftAdmin.getPaysDeResidence().length(), 3));
			valide = false;
		}
		if (rftAdmin.getCodeBanque().length() > 5) {
			Constants.getAuditfichier().getLignes().add(generateLignesImport(numLigne, rftAdmin.toString(),
					Controles.CT044, Constants.FIELD_CODE_BANQUE, rftAdmin.getCodeBanque().length(), 5));
			valide = false;
		}
		if (rftAdmin.getLibelleBanque().length() > 256) {
			Constants.getAuditfichier().getLignes().add(generateLignesImport(numLigne, rftAdmin.toString(),
					Controles.CT044, Constants.FIELD_LIBELLE_BANQUE, rftAdmin.getLibelleBanque().length(), 256));
			valide = false;
		}
		if (rftAdmin.getCodePostal().length() > 30) {
			Constants.getAuditfichier().getLignes().add(generateLignesImport(numLigne, rftAdmin.toString(),
					Controles.CT044, Constants.FIELD_CODE_POSTAL, rftAdmin.getCodePostal().length(), 30));
			valide = false;
		}
		if (rftAdmin.getTopGdGroup().length() > 1) {
			Constants.getAuditfichier().getLignes().add(generateLignesImport(numLigne, rftAdmin.toString(),
					Controles.CT044, Constants.FIELD_TOP_GD_GROUP, rftAdmin.getTopGdGroup().length(), 1));
			valide = false;
		}
		if (rftAdmin.getNiveauWln().length() > 20) {
			Constants.getAuditfichier().getLignes().add(generateLignesImport(numLigne, rftAdmin.toString(),
					Controles.CT044, Constants.FIELD_NIVEAU_WLN, rftAdmin.getNiveauWln().length(), 20));
			valide = false;
		}
		if (rftAdmin.getDateEntreeWln().length() > 10) {
			Constants.getAuditfichier().getLignes().add(generateLignesImport(numLigne, rftAdmin.toString(),
					Controles.CT044, Constants.FIELD_DATE_ENTREE_WLN, rftAdmin.getDateEntreeWln().length(), 10));
			valide = false;
		}
		if (rftAdmin.getDateSortieWln().length() > 10) {
			Constants.getAuditfichier().getLignes().add(generateLignesImport(numLigne, rftAdmin.toString(),
					Controles.CT044, Constants.FIELD_DATE_SORTIE_WLN, rftAdmin.getDateSortieWln().length(), 10));
			valide = false;
		}
		if (rftAdmin.getStatutNational().length() > 3) {
			Constants.getAuditfichier().getLignes().add(generateLignesImport(numLigne, rftAdmin.toString(),
					Controles.CT044, Constants.FIELD_STATUT_NATIONAL, rftAdmin.getStatutNational().length(), 3));
			valide = false;
		}
		if (rftAdmin.getDateEntreeSn().length() > 10) {
			Constants.getAuditfichier().getLignes().add(generateLignesImport(numLigne, rftAdmin.toString(),
					Controles.CT044, Constants.FIELD_DATE_ENTREE_SN, rftAdmin.getDateEntreeSn().length(), 256));
			valide = false;
		}
		if (rftAdmin.getDateSortieSn().length() > 10) {
			Constants.getAuditfichier().getLignes().add(generateLignesImport(numLigne, rftAdmin.toString(),
					Controles.CT044, Constants.FIELD_DATE_SORTIE_SN, rftAdmin.getDateSortieSn().length(), 10));
			valide = false;
		}

		return valide;
	}

	public static boolean validateFormat(RFTAdminImport rftAdmin, Integer numLigne) {

		boolean valide = true;
		if (!checkDateFormat(rftAdmin.getDateDeCreation())) {
			Constants.getAuditfichier().getLignes().add(generateLignesImport(numLigne, rftAdmin.toString(),
					Controles.CT045, Constants.FIELD_DATE_DE_CREATION, Constants.DATE_FORMATTER));
			valide = false;
		}

		if (!checkDateFormat(rftAdmin.getDateEntreeWln())) {
			Constants.getAuditfichier().getLignes().add(generateLignesImport(numLigne, rftAdmin.toString(),
					Controles.CT045, Constants.FIELD_DATE_ENTREE_WLN, Constants.DATE_FORMATTER));
			valide = false;
		}

		if (!checkDateFormat(rftAdmin.getDateSortieWln())) {
			Constants.getAuditfichier().getLignes().add(generateLignesImport(numLigne, rftAdmin.toString(),
					Controles.CT045, Constants.FIELD_DATE_SORTIE_WLN, Constants.DATE_FORMATTER));
			valide = false;
		}

		if (!checkDateFormat(rftAdmin.getDateEntreeSn())) {
			Constants.getAuditfichier().getLignes().add(generateLignesImport(numLigne, rftAdmin.toString(),
					Controles.CT045, Constants.FIELD_DATE_ENTREE_SN, Constants.DATE_FORMATTER));
			valide = false;
		}

		if (!checkDateFormat(rftAdmin.getDateSortieSn())) {
			Constants.getAuditfichier().getLignes().add(generateLignesImport(numLigne, rftAdmin.toString(),
					Controles.CT045, Constants.FIELD_DATE_SORTIE_SN, Constants.DATE_FORMATTER));
			valide = false;
		}

		return valide;
	}

	public static boolean validate(RFTAdminImport rftAdmin, Integer numLigne) throws TechnicalException {

		if (Constants.getAuditfichier().getLignes().size() > Constants.MAX_NB_ERRORS) {
			throw new TechnicalException("Le nombre des lignes rejetées dépasse " + Constants.MAX_NB_ERRORS);
		}
		return validateLength(rftAdmin, numLigne) && validateFormat(rftAdmin, numLigne);
	}

	public static AuditLignesImport generateLignesImport(Integer numLigne, String detailLigne, Controles ctrl,
			Object... parametres) {

		String libCodeAudit = ctrl.getMessage(parametres);
		return new AuditLignesImport(Constants.getAuditfichier(), numLigne, detailLigne, ctrl, libCodeAudit,
				ctrl.getType());

	}

	public static void addImportLigneError(RFTAdminImport rftAdmin, Integer numLigne, String errorMsg)
			throws TechnicalException {

		if (Constants.getAuditfichier().getLignes().size() > Constants.MAX_NB_ERRORS) {
			throw new TechnicalException("Le nombre des lignes rejetées dépasse " + Constants.MAX_NB_ERRORS);
		}
		Constants.getAuditfichier().getLignes()
				.add(new AuditLignesImport(Constants.getAuditfichier(), numLigne, rftAdmin.toString(), Controles.CT046,
						Controles.CT046.getMessage(errorMsg) + errorMsg, Controles.CT046.getType()));
	}

	public static boolean checkDateFormat(String dateStr) {

		if (dateStr == null || dateStr.equals("")) {
			return true;
		}
		try {
			LocalDate.parse(dateStr, DateTimeFormatter.ofPattern(Constants.DATE_FORMATTER));
		} catch (DateTimeParseException e) {
			return false;
		}
		return true;
	}

	public static void initNbLignes(String filePath) throws IOException {

		FileReader reader = new FileReader(new File(filePath));
		try (BufferedReader buffer = new BufferedReader(reader)) {
			int nbLignes = 0;
			String line = null;
			while ((line = buffer.readLine()) != null) {
				nbLignes++;
			}
			// -1 to remove the header
			Constants.setNbLignes(nbLignes - 1);
		}
	}

	public static String generateLogMsg(int nbOk, int nbKo, int nbTot) {

		StringBuilder msg = new StringBuilder("Progression ");
		msg.append(" : [lignes inserées ");
		msg.append(nbOk);
		msg.append("/");
		msg.append(nbTot);
		msg.append(" ,");
		msg.append("lignes rejetées ");
		msg.append(nbKo);
		msg.append("/");
		msg.append(nbTot);
		msg.append("]");

		return msg.toString();
	}

}

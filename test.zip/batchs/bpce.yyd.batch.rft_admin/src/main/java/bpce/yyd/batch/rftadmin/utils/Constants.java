package bpce.yyd.batch.rftadmin.utils;

import org.springframework.context.ApplicationContext;

import fr.bpce.yyd.batch.commun.configuration.ConfigManager;
import fr.bpce.yyd.batch.commun.exception.InvalidInitialisationException;
import fr.bpce.yyd.batch.commun.exception.UnknownPropertyException;
import fr.bpce.yyd.batch.commun.utils.FileCommunUtils;
import fr.bpce.yyd.commun.model.AuditFichiers;

public final class Constants {

	public static final String ENTITY_MANAGER_BEAN_NAME = "entityManager";

	public static final String JOB_NAME = "IMPORT_RFT_ADMIN";

	public static final String LOG_FILE_NAME = "log4j-import-rft-admin.properties";

	public static final String CONTEXT_FILE_NAME = "classpath:JobLauncher-context.xml";

	public static final String REG_RFT_ADMIN = "^NDOD_P_REF_ADMIN_[0-9]{8}[\\.]dat$";

	public static final String DATE_FORMATTER = "dd/MM/yyyy";

	public static final String FIELD_IDENTIFIANT_FEDERAL = "IDENTIFIANT_FEDERAL";

	public static final String FIELD_DENOMINATION_SOCIALE = "DENOMINATION_SOCIALE";

	public static final String FIELD_DATE_DE_CREATION = "DATE_DE_CREATION";

	public static final String FIELD_PAYS_DE_RESIDENCE = "PAYS_DE_RESIDENCE";

	public static final String FIELD_CODE_BANQUE = "CODE_BANQUE";

	public static final String FIELD_LIBELLE_BANQUE = "LIBELLE_BANQUE";

	public static final String FIELD_CODE_POSTAL = "CODE_POSTAL";

	public static final String FIELD_TOP_GD_GROUP = "TOP_GD_GROUP";

	public static final String FIELD_NIVEAU_WLN = "NIVEAU_WLN";

	public static final String FIELD_DATE_ENTREE_WLN = "DATE_ENTREE_WLN";

	public static final String FIELD_DATE_SORTIE_WLN = "DATE_SORTIE_WLN";

	public static final String FIELD_STATUT_NATIONAL = "STATUT_NATIONAL";

	public static final String FIELD_DATE_ENTREE_SN = "DATE_ENTREE_SN";

	public static final String FIELD_DATE_SORTIE_SN = "DATE_SORTIE_SN";

	public static final int MAX_NB_ERRORS = 1000;

	private static ApplicationContext context;

	private static String repIn;

	private static String repOk;

	private static String repKo;

	private static String repEncours;

	private static int nbLignes;

	private static int nbLignesRejTot;

	private static int ligneCount;

	public static void incrementeLigne() {
		ligneCount++;
	}

	public static int getLigneCount() {
		return ligneCount;
	}

	public static void setLigneCount(int ligneCount) {
		Constants.ligneCount = ligneCount;
	}

	public static int getNbLignesRejTot() {
		return nbLignesRejTot;
	}

	public static void setNbLignesRejTot(int nbLignesRejTot) {
		Constants.nbLignesRejTot = nbLignesRejTot;
	}

	private static AuditFichiers auditfichier;

	public static AuditFichiers getAuditfichier() {
		return auditfichier;
	}

	public static void setAuditfichier(AuditFichiers auditfichier) {
		Constants.auditfichier = auditfichier;
	}

	public static int getNbLignes() {
		return nbLignes;
	}

	public static void setNbLignes(int nbLignes) {
		Constants.nbLignes = nbLignes;
	}

	public static String getRepIn() {
		return repIn;
	}

	public static void setRepIn(String repIn) {
		Constants.repIn = repIn;
	}

	public static String getRepOk() {
		return repOk;
	}

	public static void setRepOk(String repOk) {
		Constants.repOk = repOk;
	}

	public static String getRepKo() {
		return repKo;
	}

	public static void setRepKo(String repKo) {
		Constants.repKo = repKo;
	}

	public static String getRepEncours() {
		return repEncours;
	}

	public static void setRepEncours(String repEncours) {
		Constants.repEncours = repEncours;
	}

	public static ApplicationContext getContext() {
		return context;
	}

	public static void setContext(ApplicationContext context) {
		Constants.context = context;
	}

	private Constants() {

	}

	public static void initConstans() throws UnknownPropertyException, InvalidInitialisationException {

		repIn = ConfigManager.getProperty("rep.rft.in");
		repOk = ConfigManager.getProperty("rep.rft_admin.ok");
		repKo = ConfigManager.getProperty("rep.rft_admin.ko");
		repEncours = ConfigManager.getProperty("rep.rft_admin.encours");

		FileCommunUtils.checkRepertoire(repIn);
		FileCommunUtils.checkRepertoire(repOk);
		FileCommunUtils.checkRepertoire(repKo);
		FileCommunUtils.checkRepertoire(repEncours);
	}

}

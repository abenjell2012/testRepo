package bpce.yyd.batch.rftadmin.task;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import fr.bpce.yyd.batch.commun.utils.SpringBatchUtil;
import lombok.Setter;

@Setter
public class MiseAJourDataRFTSyntheseTask implements Tasklet {

	@Autowired
	private EntityManager entityManager;

	private String updateQuery;

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

		Query query = entityManager.createNativeQuery(updateQuery);
		int rowUpdate = query.executeUpdate();

		StepExecution stepExec = SpringBatchUtil.getStepExecution(chunkContext);
		stepExec.setWriteCount(rowUpdate);

		return RepeatStatus.FINISHED;
	}

}

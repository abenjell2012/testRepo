package bpce.yyd.batch.rftadmin.task;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

public class VidageTableTemporaireTask implements Tasklet {

	@Autowired
	private EntityManager entityManager;

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {

		Query deleteQuery = entityManager.createNativeQuery("truncate table RFT_ADMIN_TMP");
		deleteQuery.executeUpdate();

		return RepeatStatus.FINISHED;
	}

}

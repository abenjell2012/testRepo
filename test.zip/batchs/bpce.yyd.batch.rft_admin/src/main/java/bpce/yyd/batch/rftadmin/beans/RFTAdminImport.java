package bpce.yyd.batch.rftadmin.beans;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class RFTAdminImport {

	private String idFederal;

	private String codeBanque;

	private String denominationSociale;

	private String dateDeCreation;

	private String paysDeResidence;

	private String libelleBanque;

	private String codePostal;

	private String topGdGroup;

	private String niveauWln;

	private String dateEntreeWln;

	private String dateSortieWln;

	private String statutNational;

	private String dateEntreeSn;

	private String dateSortieSn;
}

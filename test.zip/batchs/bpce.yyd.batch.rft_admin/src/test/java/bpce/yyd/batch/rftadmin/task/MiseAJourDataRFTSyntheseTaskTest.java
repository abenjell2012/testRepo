package bpce.yyd.batch.rftadmin.task;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.batch.core.scope.context.ChunkContext;

import bpce.yyd.batch.rftadmin.ti.AbstractIntegrationTest;
import fr.bpce.yyd.commun.model.RftAdmin;
import fr.bpce.yyd.commun.model.restitution.RestTiersIdRft;

public class MiseAJourDataRFTSyntheseTaskTest extends AbstractIntegrationTest {
	
	private static String sql = "update rest_tiers_id_rft synRFT" + 
			" set synrft.cd_banque_referente = (select rftadmin.code_banque " + 
			"                                  from rft_admin rftadmin " + 
			"                                  where synrft.id_rft = rftadmin.identifiant_federal and  rftadmin.date_import = (select max(date_import) from rft_admin) ), " + 
			" synrft.raison_sociale = (select rftadmin.denomination_sociale " + 
			"                                  from rft_admin rftadmin " + 
			"                                  where synrft.id_rft = rftadmin.identifiant_federal and  rftadmin.date_import = (select max(date_import) from rft_admin) ) " + 
			" where synRFT.ID_P_RFT " + 
			" in (select rft.ID_P_RFT " + 
			"     from rest_tiers_id_rft rft " + 
			"     inner join (select identifiant_federal, " + 
			"             denomination_sociale, " + 
			"             code_banque from rft_admin " + 
			"             where date_import = (select max(date_import) from rft_admin) " + 
			"      ) lastRft on lastRft.identifiant_federal = rft.ID_RFT " + 
			"      where rft.cd_banque_referente != lastRft.code_banque or rft.raison_sociale != lastRft.denomination_sociale " + 
			"     )";

	@BeforeClass
	public static void initVariables() throws Exception {

		initData();
		MiseAJourDataRFTSyntheseTask task = new MiseAJourDataRFTSyntheseTask();
		task.setEntityManager(getEntityManager());
		task.setUpdateQuery(sql);
		doInTransaction(() -> {
			ChunkContext chunk = new ChunkContext(null);
			try {
				task.execute(null, chunk);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
	}

	private static void initData() {

		doInTransaction(() -> {

			LocalDate dateNow = LocalDate.now();
			EntityManager entityManager = getEntityManager();
			RestTiersIdRft synRft = new RestTiersIdRft();
			synRft.setIdRft("0000000001");
			synRft.setCodeBanqueReferente("10200");
			synRft.setRaisonSociale("test");
			entityManager.persist(synRft);

			RftAdmin rft = new RftAdmin();
			rft.setIdFederal("0000000001");
			rft.setCodeBanque("10107");
			rft.setDenominationSociale("denomination");
			rft.setImportDate(dateNow);
			entityManager.persist(rft);

		});

	}

	@Test
	public void updateCodebanqueAndRaisonTest() {

		EntityManager entityManager = getEntityManager();
		Query query = entityManager.createNativeQuery("select * from REST_TIERS_ID_RFT", RestTiersIdRft.class);
		RestTiersIdRft synRft = (RestTiersIdRft) query.getSingleResult();

		assertNotNull(synRft);
		assertEquals("10107", synRft.getCodeBanqueReferente());
		assertEquals("denomination", synRft.getRaisonSociale());
	}

}

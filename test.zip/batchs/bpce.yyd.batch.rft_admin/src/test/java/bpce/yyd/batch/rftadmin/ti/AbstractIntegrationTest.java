package bpce.yyd.batch.rftadmin.ti;

import java.io.FileInputStream;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.net.URL;
import java.util.Properties;

import javax.persistence.EntityManager;

import org.junit.BeforeClass;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import bpce.yyd.batch.rftadmin.utils.Constants;
import fr.bpce.yyd.batch.commun.configuration.ConfigManager;

public abstract class AbstractIntegrationTest {

	protected static ApplicationContext context = null;
	protected static TransactionTemplate transactionTemplate = null;
	protected static Properties properties;

	@FunctionalInterface
	public interface TransactionCallback {
		void doInTransaction();
	}

	@BeforeClass
	public static void initProperties() throws Exception {

		context = new ClassPathXmlApplicationContext("classpath:JobLauncher-context-ti.xml");
		transactionTemplate = new TransactionTemplate(getTransactionManager());

		// Chargement du fichier de propriétés des TI
		URL url = ClassLoader.getSystemClassLoader().getResource("config-ti.properties");
		String filename = url.getPath();
		properties = new Properties();
		InputStream input = new FileInputStream(filename);
		properties.load(input);
		input.close();

		// Utilisation de ces propriétés pour le ConfigManager
		Field propertiesField = ConfigManager.class.getDeclaredField("properties");
		propertiesField.setAccessible(true);
		propertiesField.set(null, properties);

		Constants.initConstans();
	}

	public static JpaTransactionManager getTransactionManager() {
		return (JpaTransactionManager) context.getBean("transactionManager");
	}

	public static EntityManager getEntityManager() {
		return (EntityManager) context.getBean("entityManager");
	}

	public static void doInTransaction(final TransactionCallback checker) {
		transactionTemplate.execute(new TransactionCallbackWithoutResult() {
			@Override
			protected void doInTransactionWithoutResult(TransactionStatus status) {
				checker.doInTransaction();
			}
		});
	}

}

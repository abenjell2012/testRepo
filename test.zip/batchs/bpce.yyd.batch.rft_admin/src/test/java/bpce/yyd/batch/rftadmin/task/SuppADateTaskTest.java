package bpce.yyd.batch.rftadmin.task;

import java.math.BigInteger;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import bpce.yyd.batch.rftadmin.ti.AbstractIntegrationTest;
import fr.bpce.yyd.commun.model.RftAdmin;

public class SuppADateTaskTest extends AbstractIntegrationTest {

	@BeforeClass
	public static void initVariables() throws Exception {

		initData();
		SupprimeDonneesADateTask task = new SupprimeDonneesADateTask();
		task.setEntityManager(getEntityManager());
		task.setDateImport(LocalDate.now().format(DateTimeFormatter.BASIC_ISO_DATE));
		doInTransaction(() -> {
			try {
				task.execute(null, null);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
	}

	private static void initData() {

		doInTransaction(() -> {

			EntityManager entityManager = getEntityManager();
			RftAdmin rft = new RftAdmin();
			rft.setIdFederal("0000000001");
			rft.setCodeBanque("10107");
			rft.setImportDate(LocalDate.now());
			entityManager.persist(rft);

			rft.setIdFederal("0000000002");
			rft.setCodeBanque("10107");
			rft.setImportDate(LocalDate.now());
			entityManager.persist(rft);
		});
	}

	@Test
	public void countTest() {

		EntityManager entityManager = getEntityManager();
		Query query = entityManager.createNativeQuery("select count(*) from RFT_ADMIN");
		Object count = query.getSingleResult();

		Assert.assertTrue(((BigInteger) count).intValue() == 0);
	}
}

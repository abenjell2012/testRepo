package bpce.yyd.batch.rftadmin.task;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.net.URL;
import java.nio.file.Paths;
import java.util.Properties;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import bpce.yyd.batch.rftadmin.beans.RFTAdminImport;
import bpce.yyd.batch.rftadmin.utils.Constants;
import bpce.yyd.batch.rftadmin.utils.GeneralUtility;
import fr.bpce.yyd.batch.commun.configuration.ConfigManager;
import fr.bpce.yyd.batch.commun.exception.InvalidFileException;
import fr.bpce.yyd.batch.commun.exception.TechnicalException;
import fr.bpce.yyd.commun.model.AuditFichiers;

public class GeneralUtilityTest {

	private static Properties properties = null;

	@BeforeClass
	public static void initProperties() throws Exception {
		// Chargement du fichier de propriétés des TI
		URL url = ClassLoader.getSystemClassLoader().getResource("config-ti.properties");
		String filename = url.getPath();
		properties = new Properties();
		InputStream input = new FileInputStream(filename);
		properties.load(input);
		input.close();

		// Utilisation de ces propriétés pour le ConfigManager
		Field propertiesField = ConfigManager.class.getDeclaredField("properties");
		propertiesField.setAccessible(true);
		propertiesField.set(null, properties);

		Constants.initConstans();
	}

	@Test
	public void checkNameFileFormatTest() throws InvalidFileException {
		GeneralUtility.checkNameFileFormat(Paths.get("./src/test/resources/reps/in/NDOD_P_REF_ADMIN_20190924.dat"));
	}

	@Test(expected = InvalidFileException.class)
	public void checkNameFileFormatExpTest() throws InvalidFileException {
		GeneralUtility.checkNameFileFormat(Paths.get("./src/test/resources/reps/in/NDOD_P_REF_ADMIN_20190924.csv"));
	}

	@Test
	public void getDateImportTest() {

		String date = GeneralUtility
				.getDateImport(Paths.get("./src/test/resources/reps/in/NDOD_P_REF_ADMIN_20190924.dat"));

		Assert.assertTrue(date.length() == 8);
	}

	@Test
	public void checkDateFormatTest() {

		Assert.assertTrue(GeneralUtility.checkDateFormat("01/01/2019"));
		Assert.assertTrue(!GeneralUtility.checkDateFormat("20191924"));
	}

	@Test
	public void initNbLignesTest() throws IOException {

		GeneralUtility.initNbLignes("./src/test/resources/reps/in/NDOD_P_REF_ADMIN_20190924.dat");
		Assert.assertTrue(Constants.getNbLignes() == 18);
	}

	@Test
	public void generateLogMsgTest() {

		String msg = GeneralUtility.generateLogMsg(10, 2, 12);
		Assert.assertTrue("Progression  : [lignes inserées 10/12 ,lignes rejetées 2/12]".equals(msg));
	}

	@Test
	public void validateTest() throws TechnicalException {

		AuditFichiers audit = new AuditFichiers();
		Constants.setAuditfichier(audit);

		RFTAdminImport rft = new RFTAdminImport();
		rft.setIdFederal("23476584965");
		rft.setDenominationSociale("");
		rft.setDateDeCreation("");
		rft.setCodeBanque("");
		rft.setCodePostal("");
		rft.setDateEntreeSn("");
		rft.setDateEntreeWln("");
		rft.setDateSortieSn("");
		rft.setDateSortieWln("");
		rft.setLibelleBanque("");
		rft.setNiveauWln("");
		rft.setPaysDeResidence("");
		rft.setStatutNational("");
		rft.setTopGdGroup("");

		GeneralUtility.validateLength(rft, 1);
		Assert.assertTrue(Constants.getAuditfichier().getLignes().size() == 1);

		GeneralUtility.validateFormat(rft, 1);
		Assert.assertTrue(Constants.getAuditfichier().getLignes().size() == 1);
	}

}

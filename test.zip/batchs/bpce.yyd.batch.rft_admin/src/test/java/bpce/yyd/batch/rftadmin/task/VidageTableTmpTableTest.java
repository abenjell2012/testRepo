package bpce.yyd.batch.rftadmin.task;

import java.math.BigInteger;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import bpce.yyd.batch.rftadmin.ti.AbstractIntegrationTest;

public class VidageTableTmpTableTest extends AbstractIntegrationTest {

	@BeforeClass
	public static void initVariables() throws Exception {

		initData();
		VidageTableTemporaireTask task = new VidageTableTemporaireTask();
		task.setEntityManager(getEntityManager());
		doInTransaction(() -> {
			task.execute(null, null);
		});
	}

	private static void initData() {

		doInTransaction(() -> {

			EntityManager entityManager = getEntityManager();
			Query query = entityManager.createNativeQuery("drop table RFT_ADMIN_TMP if exists");
			query.executeUpdate();
			query = entityManager.createNativeQuery("CREATE TABLE RFT_ADMIN_TMP (  ID NUMBER(19,0) AUTO_INCREMENT,"
					+ "  IDENTIFIANT_FEDERAL   VARCHAR2(10), DENOMINATION_SOCIALE  VARCHAR2(120),"
					+ "  DATE_DE_CREATION      VARCHAR2(10), PAYS_DE_RESIDENCE     VARCHAR2(3),"
					+ "  CODE_BANQUE           VARCHAR2(5), LIBELLE_BANQUE        VARCHAR2(256),"
					+ "  CODE_POSTAL           VARCHAR2(30), TOP_GD_GROUP          VARCHAR2(1),"
					+ "  NIVEAU_WLN            VARCHAR2(20), DATE_ENTREE_WLN       VARCHAR2(10),"
					+ "  DATE_SORTIE_WLN       VARCHAR2(10), STATUT_NATIONAL       VARCHAR2(3),"
					+ "  DATE_ENTREE_SN        VARCHAR2(10), DATE_SORTIE_SN        VARCHAR2(10))");
			query.executeUpdate();

			query = entityManager.createNativeQuery(
					"insert into RFT_ADMIN_TMP (IDENTIFIANT_FEDERAL,CODE_BANQUE) values ('6758943567','10107')");
			query.executeUpdate();
		});

	}

	@Test
	public void countTest() {

		EntityManager entityManager = getEntityManager();
		Query query = entityManager.createNativeQuery("select count(*) from RFT_ADMIN_TMP");
		Object count = query.getSingleResult();

		Assert.assertTrue(((BigInteger) count).intValue() == 0);
	}

}

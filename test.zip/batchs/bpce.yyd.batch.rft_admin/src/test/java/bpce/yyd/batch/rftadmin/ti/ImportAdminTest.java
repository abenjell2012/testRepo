package bpce.yyd.batch.rftadmin.ti;

import java.math.BigInteger;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;

import bpce.yyd.batch.rftadmin.utils.Constants;
import bpce.yyd.batch.rftadmin.utils.GeneralUtility;

public class ImportAdminTest extends AbstractIntegrationTest {

	@BeforeClass
	public static void initVariables() throws Exception {

		initData();

		Job job = (Job) context.getBean(Constants.JOB_NAME);
		JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");

		Constants.setContext(context);
		Constants.initConstans();

		Path pathFileName = Paths.get("./src/test/resources/reps/in/NDOD_P_REF_ADMIN_20190924.dat");
		GeneralUtility.checkNameFileFormat(pathFileName);
		// Path movedFilePath = GeneralUtility.moveFileToDir(pathFileName,
		// Paths.get(Constants.getRepEncours()));
		GeneralUtility.initNbLignes(pathFileName.toString());

		JobParameters jobParameters = new JobParametersBuilder().addLong("id", new Date().getTime())
				.addString("dateImport", GeneralUtility.getDateImport(pathFileName))
				.addString("fileSource", pathFileName.toString()).toJobParameters();

		jobLauncher.run(job, jobParameters);

	}

	private static void initData() {

		doInTransaction(() -> {

			EntityManager entityManager = getEntityManager();
			Query queryDrop = entityManager.createNativeQuery("drop table RFT_ADMIN_TMP if exists");
			queryDrop.executeUpdate();
			Query queryCreate = entityManager
					.createNativeQuery("CREATE TABLE RFT_ADMIN_TMP (  ID NUMBER(19,0) AUTO_INCREMENT,"
							+ "  IDENTIFIANT_FEDERAL   VARCHAR2(10), DENOMINATION_SOCIALE  VARCHAR2(120),"
							+ "  DATE_DE_CREATION      VARCHAR2(10), PAYS_DE_RESIDENCE     VARCHAR2(3),"
							+ "  CODE_BANQUE           VARCHAR2(5), LIBELLE_BANQUE        VARCHAR2(256),"
							+ "  CODE_POSTAL           VARCHAR2(30), TOP_GD_GROUP          VARCHAR2(1),"
							+ "  NIVEAU_WLN            VARCHAR2(20), DATE_ENTREE_WLN       VARCHAR2(10),"
							+ "  DATE_SORTIE_WLN       VARCHAR2(10), STATUT_NATIONAL       VARCHAR2(3),"
							+ "  DATE_ENTREE_SN        VARCHAR2(10), DATE_SORTIE_SN        VARCHAR2(10))");
			queryCreate.executeUpdate();
		});
	}

	@Test
	public void countRFT_ADMIN_TMP_Test() {

		EntityManager entityManager = getEntityManager();
		Query query = entityManager.createNativeQuery("select count(*) from RFT_ADMIN_TMP");
		Object count = query.getSingleResult();

		Assert.assertTrue(((BigInteger) count).intValue() == 17);
	}
}

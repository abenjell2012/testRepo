package bpce.yyd.batch.restit_evenement_quotidien.writer;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;

import fr.bpce.yyd.batch.commun.beans.DataEventLocal;
import fr.bpce.yyd.batch.commun.constantes.Constant;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Setter
@Slf4j
public class WriterEventLocal implements ItemWriter<DataEventLocal> {

	private String date;

	private static final String INSERT_QUERY_EVENT_LOCAL = "insert into REST_SYNTH_EVT_LOCAL_STATUS ("
			+ "ID_SYNTH_TIERS_LOCAL_STATUS, CODE_BANQUE_EM, ID_LOCAL_EVT, CODE, SOUS_CODE,"
			+ "DATE_DEBUT_EVT, DATE_PHOTO_EVT, DATE_CLOTURE, STATUT, DATE_MAJ_STATUT, COMMENTAIRE,"
			+ "TOP_TECH, TOP_LITIGE, MONTANT, ID_CONTRAT, DATE_GENERATION_EVT) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public void write(List<? extends DataEventLocal> dataEventLocals) throws Exception {

		log.info("Début de chargement de: " + dataEventLocals.size() + " Event  Local");
		dataEventLocals.stream().filter(x -> x.getIdSynthese() == null).forEach(x -> log.info(x.toString()));

		List<DataEventLocal> dataForInsert = dataEventLocals.stream().filter(x -> x.getIdSynthese() != null)
				.collect(Collectors.toList());

		jdbcTemplate.batchUpdate(INSERT_QUERY_EVENT_LOCAL, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {

				ps.setLong(1, dataForInsert.get(i).getIdSynthese());
				ps.setString(2, dataForInsert.get(i).getCodeBq());
				ps.setString(3, dataForInsert.get(i).getIdLocal());
				ps.setString(4, dataForInsert.get(i).getCode());
				ps.setString(5, dataForInsert.get(i).getType());
				ps.setDate(6, dataForInsert.get(i).getDateDebut());
				ps.setDate(7, dataForInsert.get(i).getDatePhoto());
				ps.setDate(8, dataForInsert.get(i).getDateCloture());
				ps.setString(9, dataForInsert.get(i).getStatutEvenement());
				ps.setDate(10, dataForInsert.get(i).getDateMaj());
				ps.setString(11, dataForInsert.get(i).getCommentaire());
				ps.setBoolean(12, dataForInsert.get(i).getArriereTech());
				ps.setBoolean(13, dataForInsert.get(i).getArriereLitige());
				ps.setBigDecimal(14, dataForInsert.get(i).getMontantArriere());
				ps.setString(15, dataForInsert.get(i).getIdContrat());
				ps.setTimestamp(16, Timestamp.valueOf(
						LocalDateTime.of(LocalDate.parse(date, Constant.YYYYMMDD_FORMATTER), LocalTime.of(0, 0))));

			}

			@Override
			public int getBatchSize() {
				return dataForInsert.size();
			}
		});
	}
}
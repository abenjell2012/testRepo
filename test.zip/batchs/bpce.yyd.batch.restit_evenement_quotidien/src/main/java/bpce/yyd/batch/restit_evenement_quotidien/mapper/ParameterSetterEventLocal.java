package bpce.yyd.batch.restit_evenement_quotidien.mapper;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;

import org.springframework.jdbc.core.PreparedStatementSetter;

import fr.bpce.yyd.batch.commun.constantes.Constant;

public class ParameterSetterEventLocal implements PreparedStatementSetter {

	private LocalDate date;

	public ParameterSetterEventLocal(String dateCalcul) {
		this.date = LocalDate.parse(dateCalcul,Constant.YYYYMMDD_FORMATTER);
	}

	@Override
	public void setValues(PreparedStatement ps) throws SQLException {
		ps.setDate(1, Date.valueOf(date));
		ps.setDate(2, Date.valueOf(date.plusDays(1)));
	}

}

package bpce.yyd.batch.restit_evenement_quotidien.writer;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;

import fr.bpce.yyd.batch.commun.beans.DataEventMDC;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Setter
@Slf4j
public class WriterDuplicateEventMDC implements ItemWriter<DataEventMDC> {

	private static final String INSERT_QUERY_EVENT_MDC = "insert into REST_SYNTH_EVT_MDC_STATUS ("
			+ "ID_SYNTH_TIERS_LOCAL_STATUS, CODE_BANQUE_EVT, ID_MDC_EVT,CODE_MDC,DATE_CREATION_EVT,STATUT_EVT,DATE_MAJ_STATUT, DATE_CLOTURE, DATE_GENERATION_MDC) VALUES (?,?,?,?,?,?,?,?,?)";

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public void write(List<? extends DataEventMDC> dataEventMDCs) throws Exception {

		log.info("Début de chargement de: " + dataEventMDCs.size() + " Event  MDC");

		jdbcTemplate.batchUpdate(INSERT_QUERY_EVENT_MDC, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {

				ps.setLong(1, dataEventMDCs.get(i).getIdSynthese());
				ps.setString(2, "MDC");
				ps.setObject(3, dataEventMDCs.get(i).getIdEvt());
				ps.setString(4, dataEventMDCs.get(i).getCodeEvt());
				ps.setDate(5, dataEventMDCs.get(i).getDateDebut());
				ps.setString(6, dataEventMDCs.get(i).getStatut());
				ps.setDate(7, dataEventMDCs.get(i).getDateEffet());
				ps.setDate(8, dataEventMDCs.get(i).getDateCloture());
				ps.setTimestamp(9, dataEventMDCs.get(i).getDateGenerationMdc());
			}

			@Override
			public int getBatchSize() {
				return dataEventMDCs.size();
			}
		});
	}
}
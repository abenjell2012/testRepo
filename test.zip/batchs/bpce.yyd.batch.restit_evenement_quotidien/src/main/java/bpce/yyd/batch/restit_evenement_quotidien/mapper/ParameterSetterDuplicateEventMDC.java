package bpce.yyd.batch.restit_evenement_quotidien.mapper;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.jdbc.core.PreparedStatementSetter;

public class ParameterSetterDuplicateEventMDC implements PreparedStatementSetter {

	private Date date;

	public ParameterSetterDuplicateEventMDC(Date date) {
		this.date = date;
	}

	@Override
	public void setValues(PreparedStatement ps) throws SQLException {
		ps.setDate(1, date);
	}
}

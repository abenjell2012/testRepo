package bpce.yyd.batch.restit_evenement_quotidien.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fr.bpce.yyd.batch.commun.beans.DataEventMDC;

public class DataEventMdcMapper implements RowMapper<DataEventMDC> {

	@Override
	public DataEventMDC mapRow(ResultSet rs, int rowNum) throws SQLException {

		DataEventMDC dataEvt = new DataEventMDC();
		dataEvt.setIdSynthese((rs.getBigDecimal(1) == null) ? null : rs.getLong(1));
		dataEvt.setIdEvt(rs.getBigDecimal(2) == null ? null : rs.getLong(2));
		dataEvt.setDateDebut(rs.getDate(3));
		dataEvt.setCodeEvt(rs.getString(4));
		dataEvt.setStatut(rs.getString(5));
		dataEvt.setDateEffet(rs.getDate(6));
		dataEvt.setDateCloture(rs.getDate(7));
		return dataEvt;
	}

}

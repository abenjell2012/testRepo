package bpce.yyd.batch.restit_evenement_quotidien.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import fr.bpce.yyd.batch.commun.beans.DataEventMDC;

public class DataDupEventMdcMapper extends DataEventMdcMapper {

	@Override
	public DataEventMDC mapRow(ResultSet rs, int rowNum) throws SQLException {

		DataEventMDC dataEvt = super.mapRow(rs, rowNum);
		dataEvt.setDateGenerationMdc(rs.getTimestamp(8));
		return dataEvt;
	}

}

package bpce.yyd.batch.restit_evenement_quotidien.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import fr.bpce.yyd.batch.commun.beans.DataEventLocal;

public class DataDupEventLocalMapper extends DataEventLocalMapper {

	@Override
	public DataEventLocal mapRow(ResultSet rs, int rowNum) throws SQLException {

		DataEventLocal dataEvt = super.mapRow(rs, rowNum);
		dataEvt.setDateGenerationEvt(rs.getTimestamp(16));
		return dataEvt;
	}

}

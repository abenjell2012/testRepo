package bpce.yyd.batch.ti;

import org.junit.Assert;
import org.junit.Test;

public abstract class AbstractTest {

	@Test
	public void test() {
		Long value = 10L;
		Assert.assertEquals(10L, value);
	}
}

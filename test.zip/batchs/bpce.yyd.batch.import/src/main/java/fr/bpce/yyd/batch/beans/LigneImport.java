package fr.bpce.yyd.batch.beans;

import static fr.bpce.yyd.commun.constantes.Constant.SEP_POINT_VIRGULE;


import java.util.ArrayList;
import java.util.List;

import fr.bpce.yyd.commun.model.AuditLignesImport;
import fr.bpce.yyd.commun.model.ComplementEvenement;
import fr.bpce.yyd.commun.model.Evenement;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.ImportEvenementSir;
import fr.bpce.yyd.commun.model.Tiers;

public class LigneImport {

	private IdentiteTiers identite;
	private Tiers tiers;
	private Evenement evenement;
	private ComplementEvenement complementEvenement;
	private ImportEvenementSir ligneFlux;
	private List<AuditLignesImport> auditLigne = new ArrayList<>();
	private boolean topTraitement = true;
	private boolean isDetail = true;
	private boolean isNouveauEvenememt = false;
	private boolean complementDejaExistant = false;

	public LigneImport() {
		// default constructor
	}

	public IdentiteTiers getIdentite() {
		return identite;
	}

	public void setIdentite(IdentiteTiers identite) {
		this.identite = identite;
	}

	public Tiers getTiers() {
		return tiers;
	}

	public void setTiers(Tiers tiers) {
		this.tiers = tiers;
	}

	public Evenement getEvenement() {
		return evenement;
	}

	public void setEvenement(Evenement evenement) {
		this.evenement = evenement;
	}

	public ComplementEvenement getComplementEvenement() {
		return complementEvenement;
	}

	public void setComplementEvenement(ComplementEvenement complementEvenement) {
		this.complementEvenement = complementEvenement;
	}

	public List<AuditLignesImport> getAuditLigne() {
		return auditLigne;
	}

	public void setAuditLigne(List<AuditLignesImport> auditLigne) {
		this.auditLigne = auditLigne;
	}

	public boolean getTopTraitement() {
		return topTraitement;
	}

	public void setTopTraitement(boolean topTraitement) {
		this.topTraitement = topTraitement;
	}

	public boolean isDetail() {
		return isDetail;
	}

	public void setIsDetail(boolean isDetail) {
		this.isDetail = isDetail;
	}

	public void ajouterLigneAudit(AuditLignesImport ligneAudit) {
		auditLigne.add(ligneAudit);
	}

	public boolean isNouveauEvenememt() {
		return isNouveauEvenememt;
	}

	public void setNouveauEvenememt(boolean isNouveauEvenememt) {
		this.isNouveauEvenememt = isNouveauEvenememt;
	}

	public String toRestitCsvLine() {
		if (identite == null || evenement == null || complementEvenement == null) {
			return "Identite tiers, Evenement, ou Complement Evenement nulle";
		}
		StringBuilder lineCsvBuilder = new StringBuilder(identite.getCodeBanque());
		lineCsvBuilder.append(SEP_POINT_VIRGULE).append(identite.getIdLocal()).append(SEP_POINT_VIRGULE)
				.append(evenement.getIdLocal()).append(SEP_POINT_VIRGULE).append(evenement.getCode())
				.append(SEP_POINT_VIRGULE).append(complementEvenement.getStatutEvt().name()).append(SEP_POINT_VIRGULE)
				.append(evenement.getIdContrat());
		return lineCsvBuilder.toString();

	}

	public boolean isComplementDejaExistant() {
		return complementDejaExistant;
	}

	public void setComplementDejaExistant(boolean complementDejaExistant) {
		this.complementDejaExistant = complementDejaExistant;
	}

	public ImportEvenementSir getLigneFlux() {
		return ligneFlux;
	}

	public void setLigneFlux(ImportEvenementSir ligneFlux) {
		this.ligneFlux = ligneFlux;
	}
}

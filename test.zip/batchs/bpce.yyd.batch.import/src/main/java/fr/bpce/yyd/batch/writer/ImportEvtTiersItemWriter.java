package fr.bpce.yyd.batch.writer;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import fr.bpce.yyd.batch.beans.ImportBean;
import fr.bpce.yyd.batch.beans.NdodFile;
import fr.bpce.yyd.batch.commun.repositories.ParMdcRechercheRFTRepository;
import fr.bpce.yyd.batch.repositories.ImportRepository;
import fr.bpce.yyd.batch.repositories.TiersRFTRepository;
import fr.bpce.yyd.batch.service.FunctionnalCheckerSrvc;
import fr.bpce.yyd.commun.enums.CategorieSegment;
import fr.bpce.yyd.commun.enums.StatutEvenement;
import fr.bpce.yyd.commun.model.ComplementEvenement;
import fr.bpce.yyd.commun.model.Evenement;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.ParMdcRechercheRft;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.commun.model.TiersRFT;

public class ImportEvtTiersItemWriter implements ItemWriter<ImportBean> {
	private static Logger logger = Logger.getLogger(ImportEvtTiersItemWriter.class);

	@Autowired
	private ImportRepository importRepo;

	@Autowired
	private NdodFile ndodFile;

	@Autowired
	TiersRFTRepository rftRepo;

	@Autowired
	ParMdcRechercheRFTRepository parMcdRftSearchRepo;

	@Autowired
	private FunctionnalCheckerSrvc functionnalCheckerSrvc;

	private static Map<String, TiersRFT> photoRft;
	private static Map<String, ParMdcRechercheRft> parMcdRftRecherche;

	private static Map<String, IdentiteTiers> listTiersInseres;

	private static Map<String, Evenement> listEvtInseres;

	@BeforeStep
	public void initialize(StepExecution stepExecution) {
		// initialise table Parametrage
		logger.info("Début de chargement du paramétrage de transcodification RFT");
		parMcdRftRecherche = parMcdRftSearchRepo.findBqSearchRft();
		for (ParMdcRechercheRft rechRft : parMcdRftRecherche.values()) {
			ndodFile.addCodeBqDetail(rechRft.getCodeBqRechercheRft());
		}

		// initialise RFT
		LocalDate datePhoto = rftRepo.findDatePhotoRFTByDateCalcul(ndodFile.getDateConstitFlux());
		if (datePhoto != null) {
			logger.info("Photo RFT trouvée : " + datePhoto.toString());
		}
		logger.info("Début de chargement RFT");
		photoRft = rftRepo.findPhotoRFTByDateImport(datePhoto, ndodFile.getDetailCodeBqsList());

		listTiersInseres = new HashMap<>();
		listEvtInseres = new HashMap<>();
	}

	@Override
	@Transactional
	public void write(List<? extends ImportBean> items) throws Exception {
		logger.info("Début de chargement de : " + items.size() + " lignes");

		final List<IdentiteTiers> identites2Update = new ArrayList<>();
		final List<ComplementEvenement> complements2UpdateDateFin = new ArrayList<>();
		final List<ComplementEvenement> complements2UpdateMiseAJour = new ArrayList<>();

		for (ImportBean item : items) {
			Evenement evenement = creerEvenementEtTiers(item, identites2Update);
			// Pour ajouter à la liste des tiers à évaluer par le service trt-evt, les
			// evenements qui changes pour le commentaire, segement etc .. autre que ce
			// qu'on a dans complément_evenemnt
			ndodFile.addIdTiersATraiter(item.getIdTiersCourant());

			if (item.getIdComplCourant() == null) {
				ComplementEvenement complEvt = new ComplementEvenement(ndodFile.getAuditFichier(), item.getDatePhoto(),
						item.getDateMajEvenement(), item.getStatutEvenement(), item.getMontantArriere(),
						item.getArriereTechnique(), item.getArriereLitige(), item.getCommentaire());

				if (item.getNombreOccurenceComplement() == 1 && item.getIdEvenementCourant() == null) {
					insereComplementDansLEvenement(complEvt, evenement, null, null);
					complEvt.setIdentiteInitiale(evenement.getIdentiteInitiale());

					if (!complEvt.isMiseAJour() && StatutEvenement.ACT.equals(complEvt.getStatutEvt())) {
						complEvt.setDateMaj(item.getDateDebEvenement());
					}

					importRepo.insertComplementEvenement(complEvt);

				} else {
					// CORRECT SONAR => Method has 8 parameters, which is greater than 7 authorized.
					complEvt = importRepo.loadComplementEvenement(evenement.getId(),
							evenement.getIdentiteInitiale().getId(), item);
					if (complEvt == null) {
						complEvt = new ComplementEvenement(ndodFile.getAuditFichier(), item.getDatePhoto(),
								item.getDateMajEvenement(), item.getStatutEvenement(), item.getMontantArriere(),
								item.getArriereTechnique(), item.getArriereLitige(), item.getCommentaire());

						ComplementEvenement avant = importRepo.loadComplementPrecedent(evenement.getId(),
								evenement.getIdentiteInitiale().getId(), item);

						ComplementEvenement apres = importRepo.loadComplementSuivant(evenement.getId(),
								evenement.getIdentiteInitiale().getId(), item);

						insereComplementDansLEvenement(complEvt, evenement, avant, apres);
						complEvt.setIdentiteInitiale(evenement.getIdentiteInitiale());

						if (!complEvt.isMiseAJour() && StatutEvenement.ACT.equals(complEvt.getStatutEvt())) {
							complEvt.setDateMaj(item.getDateDebEvenement());
						}

						importRepo.insertComplementEvenement(complEvt);

						if (avant != null) {
							complements2UpdateDateFin.add(avant);
						}

						if (apres != null) {
							complements2UpdateMiseAJour.add(apres);
						}

					}
				}
			} else {
				item.setComplementDejaExistant(true);
			}
		}

		importRepo.updateDateFinAndIdentiteSuivante(identites2Update);
		importRepo.updateDateFinComplementEvenement(complements2UpdateDateFin);
		importRepo.updateMiseAJourComplementEvenement(complements2UpdateMiseAJour);
	}

	/**
	 * Insertion de complementEvt dans la collection des compléments de evenement.
	 * L'algo insère complementEvt sur le critère de la datePhoto et en mettant en
	 * cohérence les dateFin des compléments.
	 *
	 * @param complementEvt
	 * @param evenement
	 */
	protected void insereComplementDansLEvenement(ComplementEvenement complementEvt, Evenement evenement,
			ComplementEvenement avant, ComplementEvenement apres) {

		// on va chercher à insérer le complementEvt entre un avant et un après.

		if (avant == null && apres == null) {
			complementEvt.setMiseAJour(false);
		}

		if (avant != null) {
			complementEvt.setMiseAJour(true);
			avant.setDateFin(complementEvt.getDateDebut());
		}

		if (apres != null) {
			apres.setMiseAJour(true);
			complementEvt.setDateFin(apres.getDateDebut());
		}
		evenement.addComplement(complementEvt);
	}

	private Evenement creerEvenementEtTiers(ImportBean item, List<IdentiteTiers> identites2Update) {
		Evenement evenement = null;
		IdentiteTiers identite = null;

		if (item.getIdIdentiteCourante() == null) {
			Long nbrOccurenceIdentite = item.getNombreOccurenceIdentite();
			if (nbrOccurenceIdentite == 1) {
				// créer identite
				evenement = createIdentite(item);
			} else {
				identite = listTiersInseres.get(item.getIdTiersLocal() + "-" + item.getCodeBanque());
				if (identite == null) { // creation
					evenement = createIdentite(item);
				} else { // update
					evenement = updateIdentiteExistant(item, identite, identites2Update);
				}
			}
		} else {
			identite = listTiersInseres.get(item.getIdTiersLocal() + "-" + item.getCodeBanque());
			if (identite == null) {
				identite = importRepo.findIdentiteById(item.getIdIdentiteCourante(), item.getIdTiersCourant());
			}
			evenement = updateIdentiteExistant(item, identite, identites2Update);
		}
		return evenement;
	}

	private Evenement createIdentite(ImportBean item) {
		Tiers tiers;
		Evenement evenement;
		IdentiteTiers identite;
		identite = new IdentiteTiers(item.getIdTiersLocal(), item.getCodeBanque(), item.getSegmentRisque(),
				item.getSiren());
		identite.setDateDebut(item.getDateDebEvenement());

		// créer evenemet
		evenement = new Evenement(item.getNumContrat(), item.getIdEvenementLocal(), item.getCodeEvenement(),
				item.getSsCodeEvenement(), item.getDateDebEvenement());
		evenement.setIdentiteInitiale(identite);

		// créer tiers
		tiers = chercheTiersHorsRetailExistantOuNouveau(identite);
		identite.setTiers(tiers);
		if (item.getIdTiersCourant() == null) {
			item.setIdTiersCourant(tiers.getId());
		}

		Long identiteId = importRepo.insertIdentiteTiers(identite);
		identite.setId(identiteId);
		if (item.getNombreOccurenceIdentite() > 1) {
			listTiersInseres.put(item.getIdTiersLocal() + "-" + item.getCodeBanque(), identite);
		}
		Long evtId = importRepo.insertEvenement(evenement);
		evenement.setId(evtId);
		if (item.getNombreOccurenceEvenement() > 1) {
			listEvtInseres.put(item.getIdEvenementLocal() + "-" + item.getIdTiersLocal() + "-" + item.getCodeBanque()
					+ "-" + item.getDateDebEvenement() + "-" + item.getCodeEvenement(), evenement);
		}
		item.setNouveauEvenememt(true);

		return evenement;
	}

	private Evenement updateIdentiteExistant(ImportBean item, IdentiteTiers identiteCouranteBdd,
			List<IdentiteTiers> identites2Update) {
		Tiers tiers = identiteCouranteBdd.getTiers();
		IdentiteTiers identite = new IdentiteTiers(item.getIdTiersLocal(), item.getCodeBanque(),
				item.getSegmentRisque(), item.getSiren());
		item.setIdTiersCourant(tiers.getId());

		if (!identite.equals(identiteCouranteBdd)) { // Evolution de l'identité
			item.setMajIdentite(true);
			// la date debut de la nouvelle identite est égale à datePhato
			identite.setDateDebut(item.getDatePhoto());
			identite.setDateFin(item.getDatePhoto().isBefore(identiteCouranteBdd.getDateDebut())
					? identiteCouranteBdd.getDateDebut()
					: null);
			identite.setSuivante(
					item.getDatePhoto().isBefore(identiteCouranteBdd.getDateDebut()) ? identiteCouranteBdd : null);

			// actuel segment
			String catSeg = functionnalCheckerSrvc.findCategorieSegment(identiteCouranteBdd.getCodeSegment());
			// recu segment
			String catSegItem = functionnalCheckerSrvc.findCategorieSegment(identite.getCodeSegment());

			if (catSeg != null && catSegItem != null && !catSeg.equals(catSegItem)) { // detection changement
																						// segment
				if (!CategorieSegment.PART.name().equals(catSegItem) && !CategorieSegment.PROF.name().equals(catSegItem)
						&& !CategorieSegment.NSEG.name().equals(catSegItem)) {// passage de retail a hors retail
					TiersRFT tiersRft = photoRft.get(identite.getCodeBanque() + "-" + identite.getIdLocal());
					Tiers t = importRepo.findTiersByIdFederal(tiersRft != null ? tiersRft.getIdFederal() : null);

					if (t != null) {
						ndodFile.addIdTiersACloturer(tiers.getId());
						tiers = t;
						tiers.addIdentite(identite);
						Long identiteId = importRepo.insertIdentiteTiers(identite);
						identite.setId(identiteId);
						listTiersInseres.put(item.getIdTiersLocal() + "-" + item.getCodeBanque(), identite);
						IdentiteTiers identite2Update = new IdentiteTiers();
						identite2Update.setId(identiteCouranteBdd.getId());
						identite2Update
								.setDateFin(item.getDatePhoto().isBefore(identiteCouranteBdd.getDateDebut()) ? null
										: identite.getDateDebut());
						identite2Update.setSuivante(
								item.getDatePhoto().isBefore(identiteCouranteBdd.getDateDebut()) ? null : identite);
						if (!item.getDatePhoto().isBefore(identiteCouranteBdd.getDateDebut())) {
							identites2Update.add(identite2Update);
						}

					} else {
						tiers.addIdentite(identite);
						if (tiersRft != null) {
							tiers.setIdFederal(tiersRft.getIdFederal());
						}
						importRepo.updateIdFederal(tiers);
						Long identiteId = importRepo.insertIdentiteTiers(identite);
						identite.setId(identiteId);
						listTiersInseres.put(item.getIdTiersLocal() + "-" + item.getCodeBanque(), identite);
						IdentiteTiers identite2Update = new IdentiteTiers();
						identite2Update.setId(identiteCouranteBdd.getId());
						identite2Update
								.setDateFin(item.getDatePhoto().isBefore(identiteCouranteBdd.getDateDebut()) ? null
										: identite.getDateDebut());
						identite2Update.setSuivante(
								item.getDatePhoto().isBefore(identiteCouranteBdd.getDateDebut()) ? null : identite);
						if (!item.getDatePhoto().isBefore(identiteCouranteBdd.getDateDebut())) {
							identites2Update.add(identite2Update);
						}
					}
				} else { // passage de hors retail a retail
					if (importRepo.checkTiersPartage(tiers.getId(), identite.getIdLocal(), identite.getCodeBanque())) {
						tiers = new Tiers();
						Long tiersId = importRepo.insertTiers(tiers);
						ndodFile.addIdTiersATraiter(tiersId);
						tiers.setId(tiersId);
						tiers.addIdentite(identite);
						Long identiteId = importRepo.insertIdentiteTiers(identite);
						identite.setId(identiteId);
						listTiersInseres.put(item.getIdTiersLocal() + "-" + item.getCodeBanque(), identite);
						IdentiteTiers identite2Update = new IdentiteTiers();
						identite2Update.setId(identiteCouranteBdd.getId());
						identite2Update
								.setDateFin(item.getDatePhoto().isBefore(identiteCouranteBdd.getDateDebut()) ? null
										: identite.getDateDebut());
						identite2Update.setSuivante(
								item.getDatePhoto().isBefore(identiteCouranteBdd.getDateDebut()) ? null : identite);
						if (!item.getDatePhoto().isBefore(identiteCouranteBdd.getDateDebut())) {
							identites2Update.add(identite2Update);
						}
					} else {
						tiers.setIdFederal(null);
						importRepo.updateIdFederal(tiers);
						tiers.addIdentite(identite);
						Long identiteId = importRepo.insertIdentiteTiers(identite);
						identite.setId(identiteId);
						listTiersInseres.put(item.getIdTiersLocal() + "-" + item.getCodeBanque(), identite);
						IdentiteTiers identite2Update = new IdentiteTiers();
						identite2Update.setId(identiteCouranteBdd.getId());
						identite2Update
								.setDateFin(item.getDatePhoto().isBefore(identiteCouranteBdd.getDateDebut()) ? null
										: identite.getDateDebut());
						identite2Update.setSuivante(
								item.getDatePhoto().isBefore(identiteCouranteBdd.getDateDebut()) ? null : identite);
						if (!item.getDatePhoto().isBefore(identiteCouranteBdd.getDateDebut())) {
							identites2Update.add(identite2Update);
						}

					}
				}

			} else {
				tiers.addIdentite(identite);
				Long identiteId = importRepo.insertIdentiteTiers(identite);
				identite.setId(identiteId);
				listTiersInseres.put(item.getIdTiersLocal() + "-" + item.getCodeBanque(), identite);
				IdentiteTiers identite2Update = new IdentiteTiers();
				identite2Update.setId(identiteCouranteBdd.getId());
				identite2Update.setDateFin(item.getDatePhoto().isBefore(identiteCouranteBdd.getDateDebut()) ? null
						: identite.getDateDebut());
				identite2Update.setSuivante(
						item.getDatePhoto().isBefore(identiteCouranteBdd.getDateDebut()) ? null : identite);
				if (!item.getDatePhoto().isBefore(identiteCouranteBdd.getDateDebut())) {
					identites2Update.add(identite2Update);
				}
			}

		} else { // identite deja existante
			identite = identiteCouranteBdd;
		}

		Evenement evenementR = null;
		if (item.getIdEvenementCourant() == null) {
			if (item.getNombreOccurenceEvenement() == 1) {
				// Le tiers existe, mais création de l'événement.
				evenementR = new Evenement(item.getNumContrat(), item.getIdEvenementLocal(), item.getCodeEvenement(),
						item.getSsCodeEvenement(), item.getDateDebEvenement());
				evenementR.setIdentiteInitiale(identite);
				Long evetId = importRepo.insertEvenement(evenementR);
				evenementR.setId(evetId);
				item.setNouveauEvenememt(true);
			} else {
				evenementR = listEvtInseres.get(item.getIdEvenementLocal() + "-" + item.getIdTiersLocal() + "-"
						+ item.getCodeBanque() + "-" + item.getDateDebEvenement() + "-" + item.getCodeEvenement());
				if (evenementR == null) {
					evenementR = new Evenement(item.getNumContrat(), item.getIdEvenementLocal(),
							item.getCodeEvenement(), item.getSsCodeEvenement(), item.getDateDebEvenement());
					evenementR.setIdentiteInitiale(identite);
					Long evetId = importRepo.insertEvenement(evenementR);
					evenementR.setId(evetId);
					listEvtInseres.put(item.getIdEvenementLocal() + "-" + item.getIdTiersLocal() + "-"
							+ item.getCodeBanque() + "-" + item.getDateDebEvenement() + "-" + item.getCodeEvenement(),
							evenementR);
					item.setNouveauEvenememt(true);
				}
			}
		} else {
			evenementR = importRepo.findEvenementById(item.getIdEvenementCourant());
		}
		return evenementR;
	}

	/**
	 * Aucune identité n'a été trouvée => si le segment définit un "hors retail", on
	 * cherche l'id federal pour voir si un tiers existe déjà avec ça.
	 *
	 * @param nouvelleIdentite
	 * @return
	 */
	protected Tiers chercheTiersHorsRetailExistantOuNouveau(IdentiteTiers nouvelleIdentite) {
		Tiers ret = null;
		String segment = nouvelleIdentite.getCodeSegment();
		String catSeg = functionnalCheckerSrvc.findCategorieSegment(segment);
		if (!CategorieSegment.PART.name().equals(catSeg) && !CategorieSegment.PROF.name().equals(catSeg)
				&& !CategorieSegment.NSEG.name().equals(catSeg)) {

			TiersRFT tiersRft = lookForTiersRft(nouvelleIdentite);

			String idFederal = null;
			if (tiersRft != null) {
				idFederal = tiersRft.getIdFederal();
			}

			if (idFederal != null) {
				Tiers t = importRepo.findTiersByIdFederal(idFederal);
				if (t != null) {
					ret = t;
				} else {
					ret = new Tiers();
					ret.setIdFederal(idFederal);
					Long tiersId = importRepo.insertTiers(ret);
					ndodFile.addIdTiersATraiter(tiersId);
					ret.setId(tiersId);
				}
			}
		}

		if (ret == null) {
			// PART, PRO ou absent de RFT (?) => il faut sortir d'ici avec un Tiers
			// persistant
			ret = new Tiers();
			Long tiersId = importRepo.insertTiers(ret);
			ndodFile.addIdTiersATraiter(tiersId);
			ret.setId(tiersId);
		}
		return ret;
	}

	private TiersRFT lookForTiersRft(IdentiteTiers identite) {
		// Hors retail
		String codeBq = identite.getCodeBanque();
		String idLocal = identite.getIdLocal();

		TiersRFT tiersRft = photoRft.get(codeBq + "-" + idLocal);
		if (tiersRft == null && parMcdRftRecherche.containsKey(codeBq)) {

			// recherche en forcant le code banque avec la table de paramètrage
			// PAR_MDC_RECHERCHE_RFT
			ParMdcRechercheRft parBqRerche = parMcdRftRecherche.get(codeBq);

			if (parBqRerche != null) {
				String codeBqRecherche = parBqRerche.getCodeBqRechercheRft();
				tiersRft = photoRft.get(codeBqRecherche + "-" + idLocal);
			}
		}
		return tiersRft;
	}

}

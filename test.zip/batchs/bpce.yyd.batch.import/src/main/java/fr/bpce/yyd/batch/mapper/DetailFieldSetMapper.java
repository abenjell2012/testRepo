package fr.bpce.yyd.batch.mapper;

import java.math.BigDecimal;
import java.time.LocalDate;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.context.annotation.Scope;

import fr.bpce.yyd.batch.beans.LigneImport;
import fr.bpce.yyd.batch.beans.NdodFile;
import fr.bpce.yyd.batch.util.ControleTechniqueUtil;
import fr.bpce.yyd.commun.enums.StatutEvenement;
import fr.bpce.yyd.commun.model.ImportEvenementSir;

@Scope("step")
public class DetailFieldSetMapper implements FieldSetMapper<LigneImport> {

	public static final String ID_TIERS_LOC = "id_tiers_loc";
	public static final String COD_BQ = "cod_bq";
	public static final String SIREN = "siren";
	public static final String CODE_SEG = "code_seg";
	public static final String ID_EVT_LOC = "id_evt_loc";
	public static final String CODE_EVT = "code_evt";
	public static final String TYPE_EVT = "type_evt";
	public static final String DAT_DEB_EVT = "date_deb_evt";
	public static final String ST_EVT = "st_evt";
	public static final String DATE_MAJ_EVT = "date_maj_evt";
	public static final String DATE_PHOTO = "date_photo";
	public static final String ID_CTRT = "id_ctrt";
	public static final String FG_AR_TEC = "fg_ar_tec";
	public static final String FG_AR_LIT = "fg_ar_lit";
	public static final String MT_ARRIERE = "mt_arriere";
	public static final String CMT_EVT = "cmt_evt";

	private NdodFile ndodFile;
	private int nombreLigneOk;

	@Override
	public LigneImport mapFieldSet(FieldSet fs) {

		LigneImport ligneImport = new LigneImport();
		int nombreLignesRejet = ndodFile.getNbLinesRejet();
		int numLigne = nombreLigneOk + nombreLignesRejet + 2;
		String originalLine = constructOriginalLine(fs);
		ControleTechniqueUtil controle = new ControleTechniqueUtil(ligneImport, ndodFile.getAuditFichier(),
				originalLine, numLigne, ndodFile.isInitFile(), ndodFile.isMensuelFile());

		// Controle date photo
		String datePhotoStr = fs.readString(DATE_PHOTO).trim();
		LocalDate datePhoto = null;
		if (!controle.controleNullOrEmpty(DATE_PHOTO, datePhotoStr)) {
			datePhoto = controle.controleDatePhoto(datePhotoStr, ndodFile.getDateConstitFlux());
		}

		// Controle presence ID_TIERS_LOC
		String idTiersLoc = controle.controlePresence(ID_TIERS_LOC, fs.readString(ID_TIERS_LOC).trim());

		// Controle CODE_BANQUE
		String codBq = fs.readString(COD_BQ).trim();
		if (!controle.controleNullOrEmpty(COD_BQ, codBq)) {
			codBq = controle.controleCodeBanqueDetail(codBq);
			ndodFile.addCodeBqDetail(codBq);
		}

		// Controle SIREN
		String siren = nullIfEmpty(controle.controleSiren(fs.readString(SIREN).trim()));

		// Controle presence code segment
		String codSeg = fs.readString(CODE_SEG).trim();
		if (!controle.controleNullOrEmpty(CODE_SEG, codSeg)) {
			// conversion en UPPERCASE (il faut accepter NSEG et nseg)
			codSeg = controle.controleCodeSeg(codSeg.toUpperCase());
		}

		// Controle presence ID_EVT_LOC
		String idEvtLoc = fs.readString(ID_EVT_LOC).trim();
		if (!controle.controleNullOrEmpty(ID_EVT_LOC, idEvtLoc)) {
			idEvtLoc = controle.controlePresence(ID_EVT_LOC, idEvtLoc);
		}

		// Controle CODE_EVT
		String codEvt = fs.readString(CODE_EVT).trim();
		if (!controle.controleNullOrEmpty(CODE_EVT, codEvt) && datePhoto != null) {
			codEvt = controle.controleCodeEvt(codEvt, datePhoto);
		}

		// Controle SOUS CODE EVT
		String ssCodeEvt = controle.controleTypeEvt(fs.readString(TYPE_EVT).trim(), codEvt, datePhoto);

		// Controle Format date debut
		String dateDebStr = fs.readString(DAT_DEB_EVT).trim();
		LocalDate dateDebEvt = null;
		if (!controle.controleNullOrEmpty(DAT_DEB_EVT, dateDebStr)) {
			dateDebEvt = controle.controleDateDebEvt(dateDebStr, datePhoto);
		}

		// Controle Statut Evenement
		String stEvtStr = fs.readString(ST_EVT).trim();
		StatutEvenement stEvt = null;
		if (!controle.controleNullOrEmpty(ST_EVT, stEvtStr) && datePhoto != null) {
			stEvt = controle.controleStatutEvt(stEvtStr, codEvt, codSeg, datePhoto);
		}

		// Controle Format date maj
		String dateMajStr = fs.readString(DATE_MAJ_EVT).trim();
		LocalDate dateMaj = null;
		if (!controle.controleNullOrEmpty(DATE_MAJ_EVT, dateMajStr)) {
			dateMaj = controle.controleDateMajEvt(dateMajStr, datePhoto, dateDebEvt, codEvt, stEvt, codSeg);
		}

		// Controle de l'identifiant contrat
		String idCtrt = nullIfEmpty(controle.controleIdCtrt(fs.readString(ID_CTRT).trim(), codEvt));

		String arTechStr = fs.readString(FG_AR_TEC).trim();
		boolean arTech = false;
		if (!controle.controleNullOrEmpty(FG_AR_TEC, arTechStr)) {
			arTech = controle.controleFlagTech(arTechStr);
		}

		String arLitStr = fs.readString(FG_AR_LIT).trim();
		boolean arLit = false;
		if (!controle.controleNullOrEmpty(FG_AR_LIT, arLitStr)) {
			arLit = controle.controleFlagLitige(arLitStr);
		}

		// Controle MONTANT_ARRIERE
		String mtArriereStr = fs.readString(MT_ARRIERE).trim();
		BigDecimal mtArriere = null;
		if (!controle.controleNullOrEmpty(MT_ARRIERE, mtArriereStr)) {
			mtArriere = controle.controleMontantArriere(mtArriereStr);
		}

		// Controle que l'evenement n'est pas deja annule dans le MDC
		controle.controleEvenementNotAnnule(codEvt, idEvtLoc, codBq, idTiersLoc, dateDebEvt, stEvt);

		// EVOL JIRA 109/182 : si l'evemement est annulé, vérifier que la date
		// d'annulation
		// n'est pas antérieure à la date de cloture
		controle.controleDateEvenementAnnule(codEvt, idEvtLoc, codBq, idTiersLoc, dateDebEvt, stEvt, dateMaj);

		// Pas de controle sur le commentaire de l'événement
		String commentaire = fs.readString(CMT_EVT).trim();
		commentaire = commentaire.replaceAll("[é]", "e");
		commentaire = commentaire.replaceAll("[è]", "e");
		commentaire = nullIfEmpty(commentaire);

		if (!ligneImport.getTopTraitement()) {
			ndodFile.incrementeNbLinesRejet();
		} else {
			nombreLigneOk++;
			ImportEvenementSir line = new ImportEvenementSir(datePhoto, codBq, idTiersLoc, siren, codSeg, idEvtLoc,
					codEvt, ssCodeEvt, dateDebEvt, dateMaj, stEvt, mtArriere, idCtrt, commentaire, arTech, arLit,
					ndodFile.getCodBq());
			ligneImport.setLigneFlux(line);
		}

		return ligneImport;
	}

	private String constructOriginalLine(FieldSet fs) {

		String datePhoto = fs.readRawString(DATE_PHOTO);
		String codBq = fs.readRawString(COD_BQ);
		String idTiersLoc = fs.readRawString(ID_TIERS_LOC);
		String siren = fs.readRawString(SIREN);
		String codSeg = fs.readRawString(CODE_SEG);
		String idEvtLoc = fs.readRawString(ID_EVT_LOC);
		String codEvt = fs.readRawString(CODE_EVT);
		String ssCodeEvt = fs.readRawString(TYPE_EVT);
		String dateDeb = fs.readRawString(DAT_DEB_EVT);
		String dateMaj = fs.readRawString(DATE_MAJ_EVT);
		String statutEvt = fs.readRawString(ST_EVT);
		String mtArriere = fs.readRawString(MT_ARRIERE);
		String idContrat = fs.readRawString(ID_CTRT);
		String commentaire = fs.readRawString(CMT_EVT);
		String arTech = fs.readRawString(FG_AR_TEC);
		String arLit = fs.readRawString(FG_AR_LIT);

		StringBuilder line = new StringBuilder(datePhoto);
		line.append(codBq).append(idTiersLoc).append(siren).append(codSeg).append(idEvtLoc).append(codEvt)
				.append(ssCodeEvt).append(dateDeb).append(dateMaj).append(statutEvt).append(mtArriere).append(idContrat)
				.append(commentaire).append(arTech).append(arLit);
		return line.toString();
	}

	private String nullIfEmpty(String str) {
		if (str == null || str.isEmpty()) {
			return null;
		}
		return str;
	}

	public void setNdodFile(NdodFile ndodFile) {
		this.ndodFile = ndodFile;
	}
}

package fr.bpce.yyd.batch.beans;

import static fr.bpce.yyd.batch.commun.constantes.Constant.SEP_POINT_VIRGULE;

import org.apache.commons.text.StringEscapeUtils;

public class RestitDtSgmEvt {

	private String codeSeg;
	private String libelleSeg;
	private Long nombreEvt;

	public String getCodeSeg() {
		return codeSeg;
	}

	public void setCodeSeg(String codeSeg) {
		this.codeSeg = codeSeg;
	}

	public String getLibelleSeg() {
		return libelleSeg;
	}

	public void setLibelleSeg(String libelleSeg) {
		this.libelleSeg = libelleSeg;
	}

	public Long getNombreEvt() {
		return nombreEvt;
	}

	public void setNombreEvt(Long nombreEvt) {
		this.nombreEvt = nombreEvt;
	}

	public String toRestitCsvLine() {
		StringBuilder lineCsvBuilder = new StringBuilder(codeSeg);
		lineCsvBuilder.append(SEP_POINT_VIRGULE).append(libelleSeg).append(SEP_POINT_VIRGULE)
				.append(nombreEvt.toString());
		return StringEscapeUtils.escapeHtml4(lineCsvBuilder.toString());
	}

}

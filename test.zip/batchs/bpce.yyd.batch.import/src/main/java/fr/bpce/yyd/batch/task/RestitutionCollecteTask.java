package fr.bpce.yyd.batch.task;

import static fr.bpce.yyd.batch.enums.TypeFichierRestit.DTREJFIX;
import static fr.bpce.yyd.batch.util.RestitImportUtil.convertIntToFixedLength;
import static fr.bpce.yyd.batch.util.RestitImportUtil.convertLongToFixedLength;
import static fr.bpce.yyd.batch.util.RestitImportUtil.convertToFixedLength;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.transaction.annotation.Transactional;

import fr.bpce.yyd.batch.beans.ImportBean;
import fr.bpce.yyd.batch.beans.NdodFile;
import fr.bpce.yyd.batch.commun.utils.FileCommunUtils;
import fr.bpce.yyd.batch.mapper.EvtExistMdcNotFullRowMapper;
import fr.bpce.yyd.batch.repositories.RestitCollecteRepository;
import fr.bpce.yyd.batch.util.RestitImportUtil;
import fr.bpce.yyd.batch.writer.DtCrMensuelFixFileWriter;
import fr.bpce.yyd.commun.enums.Controles;
import fr.bpce.yyd.commun.model.AuditFichiers;
import fr.bpce.yyd.commun.model.AuditLignesImport;

public class RestitutionCollecteTask implements Tasklet {

	private NdodFile ndodFile;
	private String insertSynchroEvtFullQuery;
	private String fichier;
	private String repRejets;

	private static final Logger LOGGER = Logger.getLogger(RestitutionCollecteTask.class);

	private final SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private RestitCollecteRepository restitCollecteRepository;

	@Override
	@Transactional
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws FileNotFoundException {

		AuditFichiers auditFichier = restitCollecteRepository.findAuditFichierByJobId(ndodFile.getJobExecutionId());
		String dateGenerationStr = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss"));
		// JIRA 362 : 1- suppression des anciens fichiers de rejet
		// EVOL JIRA 34: générer un fichier de rejet au format fixe
		LOGGER.info("Génération du fichier des rejets DTREJ");
		generateRejetFixLengthFile(auditFichier, dateGenerationStr);
		// JIRA 362 : 2- suppression des fichiers DTSTEVT, DTSGMEVT
		// Fichiers de CRs mensuel
		if (ndodFile.isMensuelFile()) {
			insertSynchronisationEvtFull();
			ExecutionContext jobContext = chunkContext.getStepContext().getStepExecution().getJobExecution()
					.getExecutionContext();
			String fichierCrRatt = (String) jobContext.get(DtCrMensuelFixFileWriter.NOM_FIC_CR_MENSUEL);
			Long nbLignesCrRatt = (Long) jobContext.get(DtCrMensuelFixFileWriter.NB_LIGNES_FIC_CR_MENSUEL);
			// EVOL JIRA 27: completer le fichier de synchro mensuel
			LOGGER.info("Complétion du fichier de rattrappage mensuel DTCRMENS");
			completeCrSynchroEvtFull(fichierCrRatt, nbLignesCrRatt, auditFichier);
		}

		return RepeatStatus.FINISHED;
	}

	private void completeCrSynchroEvtFull(String fichierCrRattrapage, Long nbLignesCrRatt, AuditFichiers auditFichier) {

		List<ImportBean> evtBeans = jdbcTemplate.query(
				"select * from EVT_EXIST_MDC_NOT_FULL where code_banque_emetteur = ? and "
						+ " nom_fichier = ? and date_traitement = trunc(sysdate)",
				new Object[] { auditFichier.getCodBq(), auditFichier.getNomFichier() },
				new EvtExistMdcNotFullRowMapper());

		Long nbLignes = Long.valueOf(evtBeans.size());
		FileWriter fw = null;
		try {
			// ouverture du fichier de cr mensuel en mode APPEND
			fw = new FileWriter(fichierCrRattrapage, true);
		} catch (IOException e) {
			LOGGER.error("erreur lors de l'ouverture du fichier " + fichierCrRattrapage, e);
			return;
		}
		try (BufferedWriter bw = new BufferedWriter(fw)) {
			for (ImportBean evtBean : evtBeans) {
				bw.write(evtBean.toRestitFixedLine(true));
				bw.newLine();
			}
			// Ecriture enqueue
			bw.write(RestitImportUtil.generateEnqueueFic(ndodFile.getAuditFichier().getCodBq(),
					ndodFile.getAuditFichier().getDateAudit(), nbLignes + nbLignesCrRatt));
		} catch (IOException e) {
			LOGGER.error("La génération de CR de synchronisation FULL a échoué", e);
		}

		try {
			FileCommunUtils.compressToGZIP(fichierCrRattrapage, fichierCrRattrapage + ".gz");
			Files.deleteIfExists(Paths.get(fichierCrRattrapage));
		} catch (IOException e) {
			LOGGER.error("La compression de CR de synchronisation FULL a échoué", e);
		}

	}

	private void generateRejetFixLengthFile(AuditFichiers auditFichier, String dateGenerationStr)
			throws FileNotFoundException {

		String crrejFileName = DTREJFIX.getNomFichier(ndodFile.getFile().getName(), ndodFile.getCodBq(),
				ndodFile.getEnvironnement(), dateGenerationStr);

		String cheminFichier = repRejets + crrejFileName;

		File crrejOutputFile = new File(cheminFichier);
		// ENTETE
		StringBuilder enteteBuilder = new StringBuilder();
		enteteBuilder.append("*1");
		enteteBuilder.append(convertToFixedLength(ndodFile.getFile().getName(), 50));
		enteteBuilder.append(sdf.format(auditFichier.getDateAudit()));
		enteteBuilder
				.append(convertIntToFixedLength((auditFichier.getNbLignes() - auditFichier.getNbLignesRejet()), 7));
		enteteBuilder.append(convertIntToFixedLength(auditFichier.getNbLignesRejet(), 7));
		enteteBuilder.append("+" + convertLongToFixedLength(auditFichier.getJobExecutionId(), 18));
		enteteBuilder.append("MDC");
		enteteBuilder.append("001");
		// ENQUEUE
		StringBuilder enqueueBuilder = new StringBuilder();
		enqueueBuilder.append("*9");
		enqueueBuilder.append(sdf.format(auditFichier.getDateAudit()));
		enqueueBuilder.append(auditFichier.getCodBq());
		enqueueBuilder.append("MDC");
		enqueueBuilder.append("001+");
		enqueueBuilder.append(convertIntToFixedLength(auditFichier.getLignes().size(), 14));

		// syntaxe try-with-ressource , gére la cloture auto du fichier
		// le flush est appelé par la méthode pw.close() géré par la syntaxe
		// try-with-ressource
		try (PrintWriter pw = new PrintWriter(crrejOutputFile)) {
			// Ecriture de l'entête
			pw.println(enteteBuilder.toString());
			// Ecriture du corps ( 1 seule ligne restituée)
			for (AuditLignesImport auditLigne : auditFichier.getLignes()) {
				pw.print(convertToFixedLength(auditLigne.getCodeAudit().name(), 10));
				pw.print(convertToFixedLength(auditLigne.getLibelleAudit(), 300));
				pw.print(convertIntToFixedLength(auditLigne.getNumLigne(), 7));
				// si la ligne est trop longue (CT030) , on envoi une chaine vide
				if (Controles.CT030.equals(auditLigne.getCodeAudit())) {
					pw.println(convertToFixedLength(" ", 402));
				} else {
					pw.println(auditLigne.getLigne());
				}
			}
			pw.print(enqueueBuilder.toString());
		} catch (IOException e) {
			LOGGER.error("La génération du fichier de rejet a échoué", e);
			return;
		}

		try {
			FileCommunUtils.compressToGZIP(cheminFichier, cheminFichier + ".gz");
			Files.deleteIfExists(Paths.get(cheminFichier));
		} catch (IOException e) {
			LOGGER.error("La compression du fichier de rejet a échoué", e);
		}

	}

	private void insertSynchronisationEvtFull() {

		LOGGER.info("INSERTION dans EVT_EXIST_MDC_NOT_FULL....");

		int nbInserts = 0;
		try {
			nbInserts = jdbcTemplate.update(insertSynchroEvtFullQuery, new PreparedStatementSetter() {

				@Override
				public void setValues(PreparedStatement ps) throws SQLException {
					ps.setString(1, ndodFile.getCodBq());
					ps.setString(2, ndodFile.getCodBq());
					ps.setString(3, ndodFile.getFile().getName());
				}
			});
		} catch (Exception e) {
			LOGGER.warn("l'insertion dans EVT_EXIST_MDC_NOT_FULL a échouée");
		}

		LOGGER.info(nbInserts + " ligne(s) insérée(s) dans EVT_EXIST_MDC_NOT_FULL.");

	}

	public void setNdodFile(NdodFile ndodFile) {
		this.ndodFile = ndodFile;
	}

	public void setInsertSynchroEvtFullQuery(String insertSynchroEvtFullQuery) {
		this.insertSynchroEvtFullQuery = insertSynchroEvtFullQuery;
	}

	public String getFichier() {
		return fichier;
	}

	public void setFichier(String fichier) {
		this.fichier = fichier;
	}

	public void setRepRejets(String repRejets) {
		this.repRejets = repRejets;
	}

}
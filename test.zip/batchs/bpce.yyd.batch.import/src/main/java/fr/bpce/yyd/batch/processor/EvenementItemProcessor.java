package fr.bpce.yyd.batch.processor;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Service;

import fr.bpce.yyd.batch.beans.LigneImport;

@Service
public class EvenementItemProcessor implements ItemProcessor<LigneImport, LigneImport> {

	@Override
	public LigneImport process(LigneImport item) throws Exception {
		// TO DO : Controles Fonctionnels
		if (item.isDetail()) {
			return item;
		}
		return null;
	}

}

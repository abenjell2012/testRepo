package fr.bpce.yyd.batch.listener;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import fr.bpce.yyd.batch.beans.NdodFile;
import fr.bpce.yyd.batch.repositories.ImportRepository;

public class CommitAuditOnFailListener implements JobExecutionListener {

	private NdodFile ndodFile;

	private PlatformTransactionManager transactionManager;

	@Autowired
	ImportRepository importRepo;

	@Override
	public void beforeJob(JobExecution jobExecution) {
		// Rien à faire de particulier
	}

	@Override
	public void afterJob(JobExecution jobExecution) {
		if (jobExecution.getExitStatus().getExitCode().equals(ExitStatus.FAILED.getExitCode())) {
			TransactionTemplate transactionTemplate = new TransactionTemplate(transactionManager);
			transactionTemplate.execute(new TransactionCallbackWithoutResult() {
				@Override
				protected void doInTransactionWithoutResult(TransactionStatus status) {
					if (ndodFile.getAuditFichier() != null) {
						importRepo.update(ndodFile.getAuditFichier());
					}
				}
			});
		}
	}

	public void setNdodFile(NdodFile ndodFile) {
		this.ndodFile = ndodFile;
	}

	public void setTransactionManager(PlatformTransactionManager transactionManager) {
		this.transactionManager = transactionManager;
	}

}

package fr.bpce.yyd.batch.repositories;

import fr.bpce.yyd.commun.model.Evenement;
import fr.bpce.yyd.commun.model.IdentiteTiers;

public class IdentiteEtEvenement {
	private final IdentiteTiers identite;
	private final Evenement evenement;

	public IdentiteEtEvenement(IdentiteTiers identite, Evenement evenement) {
		this.identite = identite;
		this.evenement = evenement;
	}

	public IdentiteTiers getIdentite() {
		return identite;
	}

	public Evenement getEvenement() {
		return evenement;
	}
}

package fr.bpce.yyd.batch.task;

import java.io.File;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import fr.bpce.yyd.batch.beans.NdodFile;
import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.commun.exception.InvalidFileException;
import fr.bpce.yyd.batch.commun.utils.SpringBatchUtil;
import fr.bpce.yyd.batch.exception.AcquisitionEvenementException;
import fr.bpce.yyd.batch.repositories.ImportRepository;
import fr.bpce.yyd.batch.service.FunctionnalCheckerSrvc;
import fr.bpce.yyd.batch.util.ControleTechniqueUtil;
import fr.bpce.yyd.commun.enums.Controles;
import fr.bpce.yyd.commun.model.AuditFichiers;

public class ValidationFichierTask implements Tasklet {

	private static final Logger LOGGER = LoggerFactory.getLogger(ValidationFichierTask.class);
	private static final Integer LONGUEUR_ENTETE = 21;
	private static final Integer LONGUEUR_ENQUEUE = 36;
	private static final String KAFKA_ENABLE = "enable";
	private static final String COD_ENT_FIC = "CdEntFic";
	private static final String DAT_ENT_CONSTIT_FLX = "DtEntCsttFlx";
	private static final String COD_BQ_ENT_FIC = "CdBqEntFic";
	private static final String APPLI_RECPT_ENT = "AppliRecpEnt";
	private static final String NUM_VERS_ENT = "NmVersEnt";
	private static final String COD_ENQ_FIC = "CdEnqFic";
	private static final String DAT_ENQ_CONSTIT_FLX = "DtEnqCsttFlx";
	private static final String COD_BQ_ENQ_FIC = "CdBqEnqFic";
	private static final String APPLI_RECPT_ENQ = "AppliRecpEnq";
	private static final String NUM_VERS_ENQ = "NmVersEnq";
	private static final String NB_ENR_ENQ = "NenrEnq";

	private NdodFile ndodFile;
	private String fichier;
	private String kafka;

	@Autowired
	private ImportRepository importRepo;

	@Autowired
	private FunctionnalCheckerSrvc functionnalCheckerSrvc;

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws InvalidFileException {

		fichier = (String) chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext()
				.get(DecompressionFichierTask.FICHIER_DEZIPE);

		// instancie le fichier et met à jour l'attribut isValide
		ndodFile.setFile(new File(fichier));

		// envoi du fichier avec kafka
		ndodFile.setaEnvoyer(KAFKA_ENABLE.equals(kafka));

		// jira 20, date calcul courante
		ndodFile.setDateCalculCourante(importRepo.findDateCalculCourante());
		// mettre à jour le job id
		ndodFile.setJobExecutionId(SpringBatchUtil.getJobExecutionId(chunkContext));

		try {
			// controle nom du fichier
			if (!ndodFile.isValid()) {
				insertAuditFichier(Controles.CT002, Constant.REG_NDOD_EVT_FILE + " ou "
						+ Constant.REG_NDOD_EVT_INIT_FILE + " ou " + Constant.REG_NDOD_EVT_MENSUEL_FILE);
			}
			if (!functionnalCheckerSrvc.isCodeBanqueValide(ndodFile.getCodBq())) {
				insertAuditFichier(Controles.CF004, ndodFile.getCodBq());
			}

			// Controle que le fichier n'est pas vide
			if (ndodFile.erreurDeLecture()) {
				insertAuditFichier(Controles.CT001);
			} else if (ndodFile.isFichierVide()) {
				insertAuditFichier(Controles.CT003);
			}

			// Controles Entete
			controleEnteteFichier();

			// Controles Enqueue
			controleEnqueueFichier();

			// Persister un objet AuditFichier pour les steps suivantes
			insertAuditFichier(Controles.FICENCOURS);

		} catch (AcquisitionEvenementException aee) {
			LOGGER.error("Erreur en contrôle du fichier {} : {}", fichier, aee.getMessage());
			SpringBatchUtil.setStepExitMessage(chunkContext, aee.getMessage());
			throw new InvalidFileException("CONTROLE_FILE_KO");
		}
		return RepeatStatus.FINISHED;
	}

	private void controleEnqueueFichier() throws AcquisitionEvenementException {

		// Controle de la longueur totale de la ligne d'enqueue
		if (ndodFile.getLigneEnqueue().length() != LONGUEUR_ENQUEUE) {
			insertAuditFichier(Controles.CT040, ndodFile.getLigneEnqueue().length(), LONGUEUR_ENQUEUE);
		}

		// Controle du type de la ligne de l'entete
		String cdEnqFic = ndodFile.getLigneEnqueue().substring(0, 2).trim();

		// Controle presence CdEnqFic entete
		if (cdEnqFic == null || cdEnqFic.isEmpty()) {
			insertAuditFichier(Controles.CT043, COD_ENQ_FIC);
		}

		// Controle du type de la ligne de l'enqueue
		if (!ControleTechniqueUtil.controleTypeLigne(ndodFile.getLigneEnqueue(), Constant.TYPE_LIGNE_ENQUEUE)) {
			insertAuditFichier(Controles.CT008, Constant.TYPE_LIGNE_ENQUEUE, ndodFile.getLigneEnqueue());
		}
		// Controle date sur la ligne d'enqueue
		controleDateEnqueue();

		// Controle code banque de l'enqueue
		String codeBanqueEnqueue = ndodFile.getLigneEnqueue().substring(10, 15).trim();

		// Controle presence codeBanqueEnqueue enqueue fichier
		if (codeBanqueEnqueue == null || codeBanqueEnqueue.isEmpty()) {
			insertAuditFichier(Controles.CT043, COD_BQ_ENQ_FIC);
		}

		if (codeBanqueEnqueue != null && !codeBanqueEnqueue.equals(ndodFile.getCodBq())) {
			insertAuditFichier(Controles.CT032, codeBanqueEnqueue, ndodFile.getCodBq());
		}

		// Controle AppliRecpEnq
		String appliRecpEnq = ndodFile.getLigneEnqueue().substring(15, 18).trim();

		// Controle presence codeBanqueEnqueue enqueue fichier
		if (appliRecpEnq == null || appliRecpEnq.isEmpty()) {
			insertAuditFichier(Controles.CT043, APPLI_RECPT_ENQ);
		}

		if (!ControleTechniqueUtil.controleNumVersion(appliRecpEnq, Constant.CODE_APPLI)) {
			insertAuditFichier(Controles.CT029, appliRecpEnq, Constant.CODE_APPLI);
		}

		controleNumVersionEnqueue();

		// NB ligne enqueue n'est pas correct car ce n'est pas un nombre
		controleNbLinesFooter();
	}

	private void controleDateEnqueue() throws AcquisitionEvenementException {
		String dateLigneEnqueue = null;
		LocalDate dateLigneEnq = null;
		try {
			dateLigneEnqueue = ndodFile.getLigneEnqueue().substring(2, 10).trim();

			// Controle presence date constitution fichier
			if (dateLigneEnqueue == null || dateLigneEnqueue.isEmpty()) {
				insertAuditFichier(Controles.CT043, DAT_ENQ_CONSTIT_FLX);
			}

			dateLigneEnq = ControleTechniqueUtil.formateDate(dateLigneEnqueue);
		} catch (DateTimeParseException e) {
			insertAuditFichier(Controles.CT009, dateLigneEnqueue, Constant.FORMAT_DATE);
		}

		// Controle pour l'INIT
		if (ndodFile.isInitFile() && dateLigneEnq != null && !dateLigneEnq.equals(ndodFile.getDateConstitFlux())) {
			insertAuditFichier(Controles.CT041, dateLigneEnq.toString(), ndodFile.getDateConstitFlux().toString());
		}
	}

	private void controleEnteteFichier() throws AcquisitionEvenementException {

		// Controle de la longueur totale de la ligne d'entete
		if (ndodFile.getLigneEntete().length() != LONGUEUR_ENTETE) {
			insertAuditFichier(Controles.CT039, ndodFile.getLigneEntete().length(), LONGUEUR_ENTETE);
		}

		// Controle du type de la ligne de l'entete
		String cdEntFic = ndodFile.getLigneEntete().substring(0, 2).trim();

		// Controle presence CdEntFic entete
		if (cdEntFic == null || cdEntFic.isEmpty()) {
			insertAuditFichier(Controles.CT043, COD_ENT_FIC);
		}

		if (!ControleTechniqueUtil.controleTypeLigne(ndodFile.getLigneEntete(), Constant.TYPE_LIGNE_ENTETE)) {
			insertAuditFichier(Controles.CT005, Constant.TYPE_LIGNE_ENTETE, ndodFile.getLigneEntete());
		}
		// Controle date de constitution sur la ligne d'entete
		String dateLigne = ndodFile.getLigneEntete().substring(2, 10).trim();

		// Controle presence date constitution fichier
		if (dateLigne == null || dateLigne.isEmpty()) {
			insertAuditFichier(Controles.CT043, DAT_ENT_CONSTIT_FLX);
		}

		// Controle format
		LocalDate dateConstitFlux = null;
		try {
			dateConstitFlux = ControleTechniqueUtil.formateDate(dateLigne);
		} catch (DateTimeParseException e) {
			insertAuditFichierErrorDate(Controles.CT006, dateLigne, Constant.FORMAT_DATE);
		}

		ndodFile.setDateConstitFlux(dateConstitFlux);

		// Controle code banque de l'entete
		String codeBanqueEntete = ndodFile.getLigneEntete().substring(10, 15).trim();

		// Controle presence code banque entete
		if (codeBanqueEntete == null || codeBanqueEntete.isEmpty()) {
			insertAuditFichier(Controles.CT043, COD_BQ_ENT_FIC);
		}

		if (codeBanqueEntete != null && !codeBanqueEntete.equals(ndodFile.getCodBq())) {
			insertAuditFichier(Controles.CT031, codeBanqueEntete, ndodFile.getCodBq());
		}

		// Controle Application réceptrice AppliRecpEnt
		String appliRecpEnt = ndodFile.getLigneEntete().substring(15, 18).trim();

		// Controle presence AppliRecpEnt entete
		if (appliRecpEnt == null || appliRecpEnt.isEmpty()) {
			insertAuditFichier(Controles.CT043, APPLI_RECPT_ENT);
		}

		if (!ControleTechniqueUtil.controleNumVersion(appliRecpEnt, Constant.CODE_APPLI)) {
			insertAuditFichier(Controles.CT029, appliRecpEnt, Constant.CODE_APPLI);
		}

		// Controle Numéro de version NmVersEnt
		controleNumeroVersionEntete();
	}

	private void controleNumeroVersionEntete() throws AcquisitionEvenementException {
		String nmVersEnt = ndodFile.getLigneEntete().substring(18, 21).trim();

		// Controle presence nmVersEnt entete
		if (nmVersEnt == null || nmVersEnt.isEmpty()) {
			insertAuditFichier(Controles.CT043, NUM_VERS_ENT);
		}

		if (!ControleTechniqueUtil.controleNumVersion(nmVersEnt, Constant.NUM_VERS_IMPORT_EVT)) {
			insertAuditFichier(Controles.CT028, nmVersEnt, Constant.NUM_VERS_IMPORT_EVT);
		}
	}

	private void controleNumVersionEnqueue() throws AcquisitionEvenementException {
		// Controle NmVersEnq
		String nmVersEnq = ndodFile.getLigneEnqueue().substring(18, 21).trim();

		// Controle presence codeBanqueEnqueue enqueue fichier
		if (nmVersEnq == null || nmVersEnq.isEmpty()) {
			insertAuditFichier(Controles.CT043, NUM_VERS_ENQ);
		}

		if (!ControleTechniqueUtil.controleNumVersion(nmVersEnq, Constant.NUM_VERS_IMPORT_EVT)) {
			insertAuditFichier(Controles.CT028, nmVersEnq, Constant.NUM_VERS_IMPORT_EVT);
		}
	}

	private void controleNbLinesFooter() throws AcquisitionEvenementException {
		String nbLinesFooterStr = ndodFile.getLigneEnqueue().substring(21, 36).trim();

		// Controle presence nbLinesFooter fichier
		if (nbLinesFooterStr == null || nbLinesFooterStr.isEmpty()) {
			insertAuditFichier(Controles.CT043, NB_ENR_ENQ);
		}

		int nbLinesFooter = -1;
		try {
			nbLinesFooter = Integer.parseInt(nbLinesFooterStr);
		} catch (NumberFormatException e) {
			insertAuditFichier(Controles.CT011, nbLinesFooterStr);
		}

		// nb de ligne détail ne correspond pas à celui de l'enqueue
		if (ndodFile.getNbLines() != nbLinesFooter) {
			insertAuditFichier(Controles.CT012, nbLinesFooterStr, ndodFile.getNbLines());
		}
	}

	private void insertAuditFichier(Controles numControle, Object... detailsErreur)
			throws AcquisitionEvenementException {
		String libelleAudit = numControle.getMessage(detailsErreur);
		AuditFichiers auditFichier = new AuditFichiers(ndodFile.getCodBq(), ndodFile.getFile().getName(),
				ndodFile.getNbLinesAudit(), ndodFile.getNbLinesRejet(), new Date(), numControle, libelleAudit,
				ndodFile.getDatePhoto());

		auditFichier.setJobExecutionId(ndodFile.getJobExecutionId());
		importRepo.persist(auditFichier);
		ndodFile.setAuditFichier(auditFichier);
		if (numControle.isErreur()) {
			throw new AcquisitionEvenementException(numControle, libelleAudit);
		}
	}

	private void insertAuditFichierErrorDate(Controles numControle, Object... detailsErreur)
			throws AcquisitionEvenementException {
		String libelleAudit = numControle.getMessage(detailsErreur);
		AuditFichiers auditFichier = new AuditFichiers(ndodFile.getCodBq(), ndodFile.getFile().getName(),
				ndodFile.getNbLinesAudit(), ndodFile.getNbLinesRejet(), new Date(), numControle, libelleAudit,
				LocalDate.now());

		auditFichier.setJobExecutionId(ndodFile.getJobExecutionId());
		importRepo.persist(auditFichier);
		ndodFile.setAuditFichier(auditFichier);
		if (numControle.isErreur()) {
			throw new AcquisitionEvenementException(numControle, libelleAudit);
		}
	}

	public void setNdodFile(NdodFile ndodFile) {
		this.ndodFile = ndodFile;
	}

	public void setImportRepo(ImportRepository importRepo) {
		this.importRepo = importRepo;
	}

	public void setFichier(String fichier) {
		this.fichier = fichier;
	}

	public void setKafka(String kafka) {
		this.kafka = kafka;
	}

}
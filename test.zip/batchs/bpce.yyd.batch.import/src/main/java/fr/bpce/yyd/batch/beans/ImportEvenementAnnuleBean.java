package fr.bpce.yyd.batch.beans;

import java.time.LocalDate;

public class ImportEvenementAnnuleBean {
	private String idEvenementLocal;
	private String codeEvenement;
	private LocalDate dateDebEvenement;
	private String codeBanque;
	private String idTiersLocal;

	public ImportEvenementAnnuleBean(String idEvenementLocal, String codeEvenement, LocalDate dateDebEvenement,
			String codeBanque, String idTiersLocal) {
		this.idEvenementLocal = idEvenementLocal;
		this.codeEvenement = codeEvenement;
		this.dateDebEvenement = dateDebEvenement;
		this.codeBanque = codeBanque;
		this.idTiersLocal = idTiersLocal;
	}

	public String getCodeBanque() {
		return codeBanque;
	}

	public void setCodeBanque(String codeBanque) {
		this.codeBanque = codeBanque;
	}

	public String getIdTiersLocal() {
		return idTiersLocal;
	}

	public void setIdTiersLocal(String idTiersLocal) {
		this.idTiersLocal = idTiersLocal;
	}

	public String getIdEvenementLocal() {
		return idEvenementLocal;
	}

	public void setIdEvenementLocal(String idEvenementLocal) {
		this.idEvenementLocal = idEvenementLocal;
	}

	public String getCodeEvenement() {
		return codeEvenement;
	}

	public void setCodeEvenement(String codeEvenement) {
		this.codeEvenement = codeEvenement;
	}

	public LocalDate getDateDebEvenement() {
		return dateDebEvenement;
	}

	public void setDateDebEvenement(LocalDate dateDebEvenement) {
		this.dateDebEvenement = dateDebEvenement;
	}

}

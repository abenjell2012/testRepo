package fr.bpce.yyd.batch.launch;

import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.exitWithErrorCode;

import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.MDC;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import fr.bpce.yyd.batch.commun.configuration.ConfigManager;
import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.commun.exception.InvalidInitialisationException;
import fr.bpce.yyd.batch.commun.exception.UnknownPropertyException;
import fr.bpce.yyd.batch.commun.utils.FileCommunUtils;
import fr.bpce.yyd.batch.task.DecompressionFichierTask;

public class Launcher {

	static {
		RuntimeMXBean rt = ManagementFactory.getRuntimeMXBean();
		String pid = rt.getName().replaceAll("@.*", "");
		MDC.put("PID", pid);
	}

	private static Logger logger = Logger.getLogger(Launcher.class);

	private static final String REGEX_SECURE_FILE = "[a-zA-Z0-9-_./\\\\]+";

	private static final Pattern PATTERN_EVT_FILE = Pattern.compile(REGEX_SECURE_FILE);

	private ApplicationContext context = null;

	public void setApplicationContext(ApplicationContext newContext) {
		context = newContext;
	}

	public ApplicationContext getApplicationContext() {
		if (context == null) {
			context = new ClassPathXmlApplicationContext("classpath:JobLauncher-context.xml");
		}
		return context;
	}

	public void runBatch(String fileName) throws IOException {

		logger.info("Debut BATCH NDOD");

		String repertoireEnCours = null;
		String repertoireOK = null;
		String repertoireKO = null;
		String kafkaStatut = null;
		String repertoireRestit = null;
		String fichier = null;
		Path movedFilePath = null;
		Path pathEnCours;
		Path pathFileName;
		String repertoireRejets = null;
		String repertoireCrsMensuels = null;

		Job job = (Job) getApplicationContext().getBean(Constant.JOB_IMPORT_EVT);
		JobLauncher jobLauncher = (JobLauncher) getApplicationContext().getBean("jobLauncher");

		try {
			repertoireEnCours = ConfigManager.getProperty("rep.encours");
			repertoireOK = ConfigManager.getProperty("rep.ok");
			repertoireKO = ConfigManager.getProperty("rep.ko");
			kafkaStatut = ConfigManager.getProperty("kafka.statut");
			repertoireRestit = ConfigManager.getProperty("rep.out.collecte");
			repertoireRejets = ConfigManager.getProperty("rep.out.collecte.rejets");
			repertoireCrsMensuels = ConfigManager.getProperty("rep.out.collecte.crsmensuels");

			// crée les répertoires s'ils n'existent pas déjà
			checkRepertoires();
		} catch (UnknownPropertyException | InvalidInitialisationException e) {
			logger.error("Erreur de parametre " + e.getMessage());
			exitWithErrorCode(1);
		}

		try {
			pathEnCours = Paths.get(repertoireEnCours);
			pathFileName = Paths.get(fileName);
			movedFilePath = moveFileToDir(pathFileName, pathEnCours);

			fichier = movedFilePath.toString();
		} catch (IOException e) {
			logger.error("Fichier [" + fileName + "] introuvable");
			exitWithErrorCode(1);
		}
		logger.info("Debut traitement fichier [" + fichier + "]");

		Long guid = java.util.UUID.randomUUID().getMostSignificantBits();
		JobParameters jobParameters = new JobParametersBuilder().addString("file", fichier)
				.addString("date", LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME))
				.addString("kafka", kafkaStatut).addString("repRestitOut", repertoireRestit)
				.addString("repRejets", repertoireRejets).addString("repCrsMensuels", repertoireCrsMensuels)
				.addLong("guid", guid).toJobParameters();
		JobExecution execution = null;

		try {
			execution = jobLauncher.run(job, jobParameters);
		} catch (Exception e) {
			logger.error("Erreur inattendue en traitement du fichier " + fichier, e);
			exitWithErrorCode(1);
		} finally {
			deleteUnzippedFileIfExists(execution, fichier);
			if (execution != null) {
				finaliserTraitement(batchStatus(execution), movedFilePath, Paths.get(repertoireOK),
						Paths.get(repertoireKO), execution);
			}
		}
		logger.info("Fin BATCH NDOD");
	}

	private void deleteUnzippedFileIfExists(JobExecution execution, String fichier) throws IOException {
		if (execution == null) {
			return;
		}
		String extentionFic = FileCommunUtils.getExtension(fichier);
		// le fichier en entrée est il un fichier compressé ??
		if (Constant.EXT_ZIP.equalsIgnoreCase(extentionFic) || Constant.EXT_GZ.equalsIgnoreCase(extentionFic)) {
			// récupérer le nom du fichier dézippé stocké dans le contexte du job
			String fichierDezippe = execution.getExecutionContext().getString(DecompressionFichierTask.FICHIER_DEZIPE);
			if (StringUtils.isNotEmpty(fichierDezippe)) {
				Files.deleteIfExists(Paths.get(fichierDezippe));
			}
		}

	}

	private void checkRepertoires() throws UnknownPropertyException, InvalidInitialisationException {
		// crée les répertoires s'il n'existe pas déjà
		FileCommunUtils.checkRepertoire(ConfigManager.getProperty("rep.in"));
		FileCommunUtils.checkRepertoire(ConfigManager.getProperty("rep.encours"));
		FileCommunUtils.checkRepertoire(ConfigManager.getProperty("rep.ok"));
		FileCommunUtils.checkRepertoire(ConfigManager.getProperty("rep.ko"));
		FileCommunUtils.checkRepertoire(ConfigManager.getProperty("rep.log"));
		FileCommunUtils.checkRepertoire(ConfigManager.getProperty("rep.out.collecte"));
		FileCommunUtils.checkRepertoire(ConfigManager.getProperty("rep.out.collecte.rejets"));
		FileCommunUtils.checkRepertoire(ConfigManager.getProperty("rep.out.collecte.crsmensuels"));

	}

	public Path moveFileToDir(Path filePath, Path destDirPath) throws IOException {
		return Files.move(filePath, destDirPath.resolve(filePath.getFileName()), StandardCopyOption.REPLACE_EXISTING);
	}

	private BatchStatus batchStatus(JobExecution execution) {
		return execution == null ? BatchStatus.UNKNOWN : execution.getStatus();
	}

	private void finaliserTraitement(BatchStatus statut, Path encours, Path repSucces, Path repRejet,
			JobExecution execution) throws IOException {
		if (statut == BatchStatus.COMPLETED) {
			logger.info("Fin traitement fichier [" + encours + "] OK");
			moveFileToDir(encours, repSucces);
			exitWithErrorCode(0);
		} else {
			logger.info("Fin traitement fichier [" + encours + "] KO");
			moveFileToDir(encours, repRejet);
			if (execution.getAllFailureExceptions().get(0).getMessage().contains("CONTROLE_FILE_KO")) {
				exitWithErrorCode(0);
			} else {
				exitWithErrorCode(1);
			}
		}
	}

	public static void main(String[] args) {
		PropertyConfigurator.configure(ClassLoader.getSystemClassLoader().getResource("log4j-import-evt.properties"));
		Launcher launcher = new Launcher();
		if (args != null && args.length == 1) {
			if (args[0] == null || !PATTERN_EVT_FILE.matcher(args[0]).matches()) {
				logger.warn("insecure file name, prevent Path Traversal vulnerability ");
				exitWithErrorCode(1);
			} else {
				String fileName = "";
				try {
					fileName = FileCommunUtils.sanitizePathImport(args[0]);
					launcher.runBatch(fileName);
				} catch (IOException e) {
					logger.error("Erreur de parametre " + e.getMessage());
					exitWithErrorCode(1);
				}
			}
		} else {
			logger.error(
					"Erreur - mauvais paramètres en entrée, le nom du fichier au bon format avec son chemin attendu");
			exitWithErrorCode(1);
		}
	}

}

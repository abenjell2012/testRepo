package fr.bpce.yyd.batch.mapper;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.stereotype.Service;
import org.springframework.validation.BindException;

import fr.bpce.yyd.batch.beans.LigneImport;

@Service
public class FooterFieldSetMapper implements FieldSetMapper<Object> {

	@Override
	public Object mapFieldSet(FieldSet fieldSet) throws BindException {

		LigneImport data = new LigneImport();
		data.setIsDetail(false);

		return data;
	}
}


package fr.bpce.yyd.batch.beans;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
@AllArgsConstructor
public class ImportEvtCloBean {
	private String idEvenementLocal;
	private String codeEvenement;
	private LocalDate dateDebEvenement;
	private String codeBanque;
	private String idTiersLocal;
	private LocalDate dateMaj;
}

package fr.bpce.yyd.batch.enums;

import java.text.MessageFormat;

public enum TypeFichierRestit {

	// Les nouveaux fichiers à longueur FIXE
	DTREJFIX("NDOD_REJEVT_{0}_DTREJ_{1}_{2}_{3}.txt", ""), //
	DTCRMENSUELFIX("NDOD_CR_MENS_{0}_DTCRMENS_{1}_{2}_{3}.txt", "");

	private String nomFic;
	private String entete;

	private TypeFichierRestit(String nomFic, String entete) {
		this.nomFic = nomFic;
		this.entete = entete;
	}

	public String getNomFic() {
		return nomFic;
	}

	public String getEntete() {
		return entete;
	}

	/**
	 * retourne le nom du fichier formaté à partir des paramètres passés
	 *
	 * @param parametres : paramètres utiles pour le nom du fichier
	 * @return nom du fichier formaté
	 */
	public String getNomFichier(Object... parametres) {
		return MessageFormat.format(nomFic, parametres);
	}

}

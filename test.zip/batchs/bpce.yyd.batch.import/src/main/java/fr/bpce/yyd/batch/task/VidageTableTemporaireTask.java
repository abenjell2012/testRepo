package fr.bpce.yyd.batch.task;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fr.bpce.yyd.batch.beans.NdodFile;

@Service
public class VidageTableTemporaireTask implements Tasklet {

	private EntityManager entityManager;

	@Autowired
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	private NdodFile ndodFile;

	public void setNdodFile(NdodFile ndodFile) {
		this.ndodFile = ndodFile;
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {

		Query deleteQuery = entityManager
				.createNativeQuery("DELETE FROM IMPORT_EVENEMENTS_SIR WHERE CODE_BANQUE_EMETTEUR = :codBqEm");
		deleteQuery.setParameter("codBqEm", ndodFile.getCodBq());
		deleteQuery.executeUpdate();

		return RepeatStatus.FINISHED;
	}
}

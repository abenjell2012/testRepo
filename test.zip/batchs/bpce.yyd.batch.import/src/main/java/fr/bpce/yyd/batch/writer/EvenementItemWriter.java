package fr.bpce.yyd.batch.writer;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import fr.bpce.yyd.batch.beans.LigneImport;
import fr.bpce.yyd.batch.repositories.ImportRepository;
import fr.bpce.yyd.commun.model.AuditLignesImport;
import fr.bpce.yyd.commun.model.ImportEvenementSir;

public class EvenementItemWriter implements ItemWriter<LigneImport> {
	private static Logger logger = Logger.getLogger(EvenementItemWriter.class);

	@Autowired
	ImportRepository importRepo;

	@Autowired
	JdbcTemplate jdbcTemplate;

	private static final String INSERT_QUERY_IMPORT_EVENEMENTS_SIR = "insert into IMPORT_EVENEMENTS_SIR "
			+ "(DATE_PHOTO,CODE_BANQUE,ID_TIERS_LOCAL,SIREN,SEGMENT_RISQUE,"
			+ "ID_EVENEMENT_LOCAL,CODE_EVENEMENT,SS_CODE_EVENEMENT,DATE_DEB_EVENEMENT,DATE_MAJ_EVENEMENT,"
			+ "STATUT_EVENEMENT, MONTANT_ARRIERE,NUM_CONTRAT,COMMENTAIRE,ARRIERE_TECHNIQUE,ARRIERE_LITIGE, CODE_BANQUE_EMETTEUR) "
			+ "values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

	private static final String INSERT_QUERY_AUDIT_LIGNES_IMPORT = "insert into AUDIT_LIGNES_IMPORT "
			+ "(AUDIT_FICHIER_ID,NUMERO_LIGNE,LIGNE,CODE_AUDIT,LIBELLE_AUDIT,TYPE_AUDIT) " + " values (?,?,?,?,?,?)";

	@Override
	@Transactional
	public void write(List<? extends LigneImport> items) throws Exception {
		int nbLignesOk = 0;
		int nbLignesKo = 0;

		logger.info("Début de chargement de : " + items.size() + " lignes");
		List<ImportEvenementSir> lignesOk = new ArrayList<>();
		List<AuditLignesImport> lignesKo = new ArrayList<>();
		for (LigneImport item : items) {

			if (item.getTopTraitement()) {
				nbLignesOk++;
				lignesOk.add(item.getLigneFlux());
			} else {
				nbLignesKo++;
				lignesKo.addAll(item.getAuditLigne());
			}
		}
		jdbcTemplate.batchUpdate(INSERT_QUERY_IMPORT_EVENEMENTS_SIR, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setDate(1, Date.valueOf(lignesOk.get(i).getDatePhoto()));
				ps.setString(2, lignesOk.get(i).getCodeBanque());
				ps.setString(3, lignesOk.get(i).getIdTiersLocal());
				ps.setString(4, lignesOk.get(i).getSiren());
				ps.setString(5, lignesOk.get(i).getSegmentRisque());
				ps.setString(6, lignesOk.get(i).getIdEvenementLocal());
				ps.setString(7, lignesOk.get(i).getCodeEvenement());
				ps.setString(8, lignesOk.get(i).getSsCodeEvenement());
				ps.setDate(9, Date.valueOf(lignesOk.get(i).getDateDebEvenement()));
				ps.setDate(10, Date.valueOf(lignesOk.get(i).getDateMajEvenement()));
				ps.setString(11, lignesOk.get(i).getStatutEvenement().toString());
				ps.setBigDecimal(12, lignesOk.get(i).getMontantArriere());
				ps.setString(13, lignesOk.get(i).getNumContrat());
				ps.setString(14, lignesOk.get(i).getCommentaire());
				ps.setBoolean(15, lignesOk.get(i).getArriereTechnique());
				ps.setBoolean(16, lignesOk.get(i).getArriereLitige());
				ps.setString(17, lignesOk.get(i).getCodeBanqueEmetteur());
			}

			@Override
			public int getBatchSize() {
				return lignesOk.size();
			}
		});

		jdbcTemplate.batchUpdate(INSERT_QUERY_AUDIT_LIGNES_IMPORT, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setLong(1, lignesKo.get(i).getAuditFichier().getId());
				ps.setInt(2, lignesKo.get(i).getNumLigne());
				ps.setString(3, lignesKo.get(i).getLigne());
				ps.setString(4, lignesKo.get(i).getCodeAudit().name());
				ps.setString(5, lignesKo.get(i).getLibelleAudit());
				ps.setString(6, lignesKo.get(i).getTypeAudit().name());
			}

			@Override
			public int getBatchSize() {
				return lignesKo.size();
			}
		});
		logger.info("Nombre de lignes chargées dans la table IMPORT_EVENEMENTS_SIR avec succès: [" + nbLignesOk
				+ "], rejeté : [" + nbLignesKo + "]");
	}

	public void setImportRepo(ImportRepository importRepo) {
		this.importRepo = importRepo;
	}
}

package fr.bpce.yyd.batch.util;

import static fr.bpce.yyd.batch.commun.constantes.Constant.FLAG_NON;
import static fr.bpce.yyd.batch.commun.constantes.Constant.FLAG_OUI;
import static fr.bpce.yyd.batch.commun.constantes.Constant.FORMAT_DATE;
import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.isFlagValide;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Arrays;
import java.util.List;

import fr.bpce.yyd.batch.beans.ImportEvtCloBean;
import fr.bpce.yyd.batch.beans.LigneImport;
import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.service.FunctionnalCheckerSrvc;
import fr.bpce.yyd.commun.enums.CodeEvenement;
import fr.bpce.yyd.commun.enums.Controles;
import fr.bpce.yyd.commun.enums.StatutEvenement;
import fr.bpce.yyd.commun.model.AuditFichiers;
import fr.bpce.yyd.commun.model.AuditLignesImport;

public class ControleTechniqueUtil {

	public static final char SEPARATEUR_VIRGULE = ',';
	public static final char SEPARATEUR_POINT = '.';
	private static final BigDecimal DIVISEUR_100 = new BigDecimal(100);
	public static final String IMPACT_DEFAUT = "D";

	private FunctionnalCheckerSrvc functionnalCheckerSrvc;

	private LigneImport ligneImport;
	private AuditFichiers auditFichier;
	private String ligne;
	private int numLigne;
	private boolean isInitFile;
	private boolean isMensuelFile;

	static final List<String> LIST_CODE_EVT_CTRL_CTRT = Arrays.asList(CodeEvenement.DAX.name(),
			CodeEvenement.IMX.name(), CodeEvenement.FNP.name(), CodeEvenement.F.name());

	private static final List<String> LIST_CODE_EVT_INIT_CTRL = Arrays.asList(CodeEvenement.IMX.name(),
			CodeEvenement.DAX.name());

	public ControleTechniqueUtil(LigneImport ligneImport, AuditFichiers auditFichier, String ligne, int numLigne,
			boolean isInitFile, boolean isMensuelFile) {
		this.ligneImport = ligneImport;
		this.auditFichier = auditFichier;
		this.ligne = ligne;
		this.numLigne = numLigne;
		this.isInitFile = isInitFile;
		this.setMensuelFile(isMensuelFile);
		functionnalCheckerSrvc = SpringBeanUtil.getBean(FunctionnalCheckerSrvc.class);
	}

	public String controlePresence(String champ, String valeurChamp) {
		if (valeurChamp == null || valeurChamp.isEmpty()) {
			traiteRejet(Controles.CT043, champ, valeurChamp);
		}
		return valeurChamp;
	}

	public String controleCodeBanqueDetail(String codeBq) {
		if (!controleCodeBanque(codeBq)) {
			traiteRejet(Controles.CT015, codeBq);
		} else if (!functionnalCheckerSrvc.isCodeBanqueValide(codeBq)) {
			traiteRejet(Controles.CF001, codeBq);
		}
		return codeBq;
	}

	public boolean controleCodeBanque(String codeBq) {
		return codeBq.length() == 5 && isInteger(codeBq);
	}

	public String controleSiren(String siren) {
		if (!siren.isEmpty() && (!isAlphaNum(siren) || siren.length() != 9)) {
			traiteRejet(Controles.CT017, siren);
		}
		return siren;
	}

	public LocalDate controleDatePhoto(String dateStr, LocalDate dateCnstFlux) {

		LocalDate datePhoto = controleFormatDate(dateStr, Controles.CT013);
		if (datePhoto != null) {
			controleDatePhotoInferieureDateConstitutioFlux(datePhoto, dateCnstFlux);
		}
		return datePhoto;
	}

	public LocalDate controleDateDebEvt(String dateStr, LocalDate datePhoto) {
		LocalDate dateDebEvt = controleFormatDate(dateStr, Controles.CT025);
		if (dateDebEvt != null && datePhoto != null && dateDebEvt.isAfter(datePhoto)) {
			traiteRejet(Controles.CT036, dateDebEvt.toString(), datePhoto.toString());
		}
		return dateDebEvt;
	}

	public LocalDate controleDateMajEvt(String dateStr, LocalDate datePhoto, LocalDate dateDebEvt, String codEvt,
			StatutEvenement statutEvt, String codSeg) {
		LocalDate dateMajEvt = controleFormatDate(dateStr, Controles.CT027);
		if (dateMajEvt != null && datePhoto != null && dateMajEvt.isAfter(datePhoto)) {
			traiteRejet(Controles.CT037, dateMajEvt.toString(), datePhoto.toString());
		}
		// EVOL 17/06/2019 : le controle DtMajEvt >= DtDebEvt ne doit pas se faire pour
		// l'INIT
		if (!isInitFile && dateMajEvt != null && dateDebEvt != null && dateMajEvt.isBefore(dateDebEvt)) {
			traiteRejet(Controles.CT038, dateMajEvt.toString(), dateDebEvt.toString());
		}
		// controle spécifique pour l'INIT
		if (isInitFile && dateMajEvt != null && datePhoto != null) {
			String catSeg = functionnalCheckerSrvc.findCategorieSegment(codSeg);
			String impact = functionnalCheckerSrvc.findImpactEvenement(codEvt, catSeg, datePhoto);
			if ((LIST_CODE_EVT_INIT_CTRL.contains(codEvt) || IMPACT_DEFAUT.equals(impact))
					&& StatutEvenement.CLO.equals(statutEvt)) {
				LocalDate dateMajMin = datePhoto.minusDays(Constant.NB_JOURS_INIT);
				if (dateMajMin.isAfter(dateMajEvt)) {
					traiteRejet(Controles.CF009, dateMajEvt.toString(), datePhoto.toString(), dateMajMin.toString());
				}
			}

		}
		return dateMajEvt;
	}

	public LocalDate controleFormatDate(String dateStr, Controles ctrl) {
		LocalDate dateMajEvt = null;
		try {
			dateMajEvt = formateDate(dateStr);
		} catch (DateTimeParseException e) {
			traiteRejet(ctrl, dateStr, FORMAT_DATE);
		}
		return dateMajEvt;
	}

	public static LocalDate formateDate(String dateStr) {
		return LocalDate.parse(dateStr, DateTimeFormatter.BASIC_ISO_DATE);
	}

	public String controleCodeEvt(String codeEvt, LocalDate datePhoto) {
		if (!functionnalCheckerSrvc.isCodeEvementValide(codeEvt, datePhoto)) {
			traiteRejet(Controles.CT018, codeEvt);
		}
		return codeEvt;
	}

	public String controleTypeEvt(String ssCodeEvt, String codeEvt, LocalDate datePhoto) {
		if (isDMWithSsCode(ssCodeEvt, codeEvt)
				&& !functionnalCheckerSrvc.isSousCodeEvtValide(ssCodeEvt, codeEvt, datePhoto)) {
			traiteRejet(Controles.CT019, ssCodeEvt);

		}
		return ssCodeEvt;
	}

	private boolean isDMWithSsCode(String ssCodeEvt, String codeEvt) {
		return (ssCodeEvt != null && !ssCodeEvt.isEmpty()) && CodeEvenement.DM.name().equals(codeEvt);
	}

	public StatutEvenement controleStatutEvt(String stEvt, String codEvt, String codSeg, LocalDate datePhoto) {

		StatutEvenement statut = null;
		if (StatutEvenement.get(stEvt) == null) {
			traiteRejet(Controles.CT020, stEvt);
		} else {
			statut = StatutEvenement.valueOf(stEvt);
			if (isInitFile) {
				String catSeg = functionnalCheckerSrvc.findCategorieSegment(codSeg);
				String impact = functionnalCheckerSrvc.findImpactEvenement(codEvt, catSeg, datePhoto);
				boolean typeEvtCond = LIST_CODE_EVT_INIT_CTRL.contains(codEvt) || IMPACT_DEFAUT.equals(impact);
				if (typeEvtCond && !StatutEvenement.ACT.equals(statut) && !StatutEvenement.CLO.equals(statut)) {
					traiteRejet(Controles.CF008, stEvt);
				} else if (!typeEvtCond && !StatutEvenement.ACT.equals(statut)) {
					traiteRejet(Controles.CF007, stEvt, codEvt);
				}
			}
		}
		return statut;
	}

	public String controleCodeSeg(String codeSeg) {
		if (codeSeg.length() != 4) {
			traiteRejet(Controles.CT021, codeSeg);
		} else if (!functionnalCheckerSrvc.isCodeSegmentValide(codeSeg)) {
			traiteRejet(Controles.CF005, codeSeg);
		}
		return codeSeg;
	}

	public void controleEvenementNotAnnule(String codeEvt, String idLocalEvenement, String codeBanque,
			String idLocalTiers, LocalDate dateDebut, StatutEvenement statutEvt) {

		if (isCondition1(statutEvt) && functionnalCheckerSrvc.isEvementAnnule(codeEvt, idLocalTiers, idLocalEvenement,
				codeBanque, dateDebut)) {
			traiteRejet(Controles.CF010, codeEvt, idLocalEvenement);
		}

	}

	public void controleDateEvenementAnnule(String codeEvt, String idLocalEvenement, String codeBanque,
			String idLocalTiers, LocalDate dateDebut, StatutEvenement statutEvt, LocalDate dateMaj) {
		if (StatutEvenement.ANN.equals(statutEvt)) {
			ImportEvtCloBean evtClo = functionnalCheckerSrvc.chercheEvenementCloture(codeBanque, idLocalTiers, codeEvt,
					idLocalEvenement, dateDebut);
			if (evtClo != null && dateMaj.isBefore(evtClo.getDateMaj())) {
				traiteRejet(Controles.CF011, codeEvt, idLocalEvenement);
			}
		}

	}

	private boolean isCondition1(StatutEvenement statutEvt) {
		return !isInitFile && (!StatutEvenement.ANN.equals(statutEvt) || !isMensuelFile());
	}

	public boolean isInteger(final CharSequence cs) {
		if (cs == null || cs.length() == 0) {
			return false;
		}
		final int sz = cs.length();
		for (int i = 0; i < sz; i++) {
			if (!Character.isDigit(cs.charAt(i))) {
				return false;
			}
		}
		return true;
	}

	public boolean isAlphaNum(final CharSequence cs) {
		if (cs == null || cs.length() == 0) {
			return false;
		}
		final int sz = cs.length();
		for (int i = 0; i < sz; i++) {
			if (!Character.isLetterOrDigit(cs.charAt(i))) {
				return false;
			}
		}
		return true;
	}

	public boolean controleDatePhotoInferieureDateConstitutioFlux(LocalDate datePhoto, LocalDate dateCnstFlux) {
		if (datePhoto.isAfter(dateCnstFlux)) {
			traiteRejet(Controles.CT014, datePhoto.toString(), dateCnstFlux.toString());
			return false;
		}
		return true;
	}

	public BigDecimal controleMontantArriere(String mtArriereStr) {
		BigDecimal mtArriere = null;
		if (mtArriereStr.length() != 18) {
			traiteRejet(Controles.CT022, mtArriereStr);
		} else if (!mtArriereStr.startsWith("+")) {
			traiteRejet(Controles.CT033, mtArriereStr);
		} else {
			try {
				mtArriere = new BigDecimal(mtArriereStr).divide(DIVISEUR_100, 2, RoundingMode.HALF_UP);
			} catch (NumberFormatException e) {
				traiteRejet(Controles.CT022, mtArriereStr);
			}
		}
		return mtArriere;
	}

	public String controleIdCtrt(String idCtrt, String codeEvt) {
		if (LIST_CODE_EVT_CTRL_CTRT.contains(codeEvt) && idCtrt.isEmpty()) {
			traiteRejet(Controles.CT023, codeEvt);
		}
		return idCtrt;
	}

	public void controleLongeureLigne(Controles ctrl, int lineCount, int expectedLineCount) {
		traiteRejet(ctrl, lineCount, expectedLineCount);
	}

	public static boolean controleTypeLigne(String ligne, String typeLigneEntete) {
		String typeLigne = ligne.substring(0, 2).trim();
		return typeLigneEntete.equals(typeLigne);
	}

	public void traiteRejet(Controles ctrl, Object... detailsErreur) {
		if (ctrl.getType().isPassant()) {
			AuditLignesImport auditLigne = instancieAuditLigne(auditFichier, numLigne, ligne, ctrl, detailsErreur);
			ligneImport.ajouterLigneAudit(auditLigne);
		}
		ligneImport.setTopTraitement(false);
	}

	public AuditLignesImport instancieAuditLigne(AuditFichiers auditFichier, Integer numLigne, String detailLigne,
			Controles ctrl, Object... parametres) {
		String libCodeAudit = ctrl.getMessage(parametres);
		// Création d'un objet AuditLigne
		return new AuditLignesImport(auditFichier, numLigne, detailLigne, ctrl, libCodeAudit, ctrl.getType());
	}

	public static boolean controleNumVersion(String nmVersEnt, String versionConstante) {
		return nmVersEnt.equals(versionConstante);

	}

	public boolean controleFlagTech(String flagTech) {
		if (!isFlagValide(flagTech)) {
			traiteRejet(Controles.CT034, flagTech, FLAG_OUI, FLAG_NON);
		}
		return FLAG_OUI.equals(flagTech);
	}

	public boolean controleFlagLitige(String flagLitige) {
		if (!isFlagValide(flagLitige)) {
			traiteRejet(Controles.CT035, flagLitige, FLAG_OUI, FLAG_NON);
		}
		return FLAG_OUI.equals(flagLitige);
	}

	public boolean controleNullOrEmpty(String champ, String chaineCaracteres) {
		boolean ret = false;
		if (chaineCaracteres == null || chaineCaracteres.isEmpty()) {
			traiteRejet(Controles.CT043, champ);
			ret = true;
		}
		return ret;
	}

	public boolean isMensuelFile() {
		return isMensuelFile;
	}

	public void setMensuelFile(boolean isMensuelFile) {
		this.isMensuelFile = isMensuelFile;
	}

	public void setFunctionnalCheckerSrvc(FunctionnalCheckerSrvc functionnalCheckerSrvc) {
		this.functionnalCheckerSrvc = functionnalCheckerSrvc;
	}

}
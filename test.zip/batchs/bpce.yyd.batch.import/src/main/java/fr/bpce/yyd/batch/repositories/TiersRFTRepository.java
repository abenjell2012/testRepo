package fr.bpce.yyd.batch.repositories;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import fr.bpce.yyd.commun.model.TiersRFT;

@Repository
public class TiersRFTRepository {

	private EntityManager entityManager;

	@Autowired
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public Map<String, TiersRFT> findPhotoRFTByDateImport(LocalDate datePhoto, Set<String> codesBanques) {

		if (datePhoto == null) {
			return new HashMap<>();
		}

		Query query = entityManager.createNamedQuery("tiers.rtf.par.dateimport.and.codeBanques");
		query.setParameter("dateImport", datePhoto);
		query.setParameter("codeBanqueList", codesBanques);
		Map<String, TiersRFT> ret = new HashMap<>();

		for (Object line : query.getResultList()) {
			Object[] lineAsArray = (Object[]) line;
			TiersRFT tiers = new TiersRFT();
			tiers.setCodeBanque((String) lineAsArray[0]);
			tiers.setIdLocal((String) lineAsArray[1]);
			tiers.setIdFederal((String) lineAsArray[2]);
			tiers.setDate(datePhoto);

			ret.put((String) lineAsArray[0] + "-" + (String) lineAsArray[1], tiers);
		}
		return ret;
	}

	public LocalDate findDatePhotoRFTByDateCalcul(LocalDate dateCalcul) {
		Query query = entityManager.createNamedQuery("photo.rtf.par.datecalcul");
		query.setParameter("dateCalcul", dateCalcul);
		Object line = query.getSingleResult();

		return (LocalDate) line;
	}

}
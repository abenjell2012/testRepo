package fr.bpce.yyd.batch.repositories;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import fr.bpce.yyd.batch.beans.ImportBean;
import fr.bpce.yyd.batch.beans.ImportEvenementAnnuleBean;
import fr.bpce.yyd.batch.beans.ImportEvtCloBean;
import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.commun.enums.StatutEvenement;
import fr.bpce.yyd.commun.model.ComplementEvenement;
import fr.bpce.yyd.commun.model.Evenement;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.Tiers;

@Repository
public class ImportRepository {

	private EntityManager entityManager;
	private JdbcTemplate jdbcTemplate;

	private static final String CODE_BQ = "CODE_BQ";
	private static final String DATE_DEBUT = "DATE_DEBUT";

	private static final String SQL_TIERS_INSERT = "INSERT INTO tiers (id_rft) values (?)";
	private static final String SQL_TIERS_UPDATE = "UPDATE tiers set id_rft = ? where id = ?";

	private static final String SQL_IDENTITE_INSERT = "INSERT INTO identite_tiers (code_bq, id_local, code_segment, siren, date_debut, tiers_id, date_fin, identite_suivante_id) values (?,?,?,?,?,?,?,?)";
	private static final String SQL_IDENTITE_UPDATE = "UPDATE identite_tiers set date_fin = ?, identite_suivante_id = ? where id = ?";

	private static final String SQL_EVENEMENT_INSERT = "INSERT INTO evenement (id_local, code, identite_initiale_id, date_debut, type, id_contrat) values (?,?,?,?,?,?)";

	private static final String SQL_COMPLEMENT_INSERT = "INSERT INTO complement_evenement (evenement_id, statut_evenement, montant_arriere, arriere_tech, arriere_litige, commentaire, date_maj, date_photo, date_fin, mise_a_jour, audit_fichier_id, identite_initiale_id) values (?,?,?,?,?,?,?,?,?,?,?,?)";
	private static final String SQL_COMPLEMENT_UPDATE_DATE_FIN = "UPDATE complement_evenement set date_fin = ? where id = ?";
	private static final String SQL_COMPLEMENT_UPDATE_MISE_A_JOUR = "UPDATE complement_evenement set mise_a_jour = ? where id = ?";

	private static final String SQL_SEARCH_EVT_CLO = "select e.id_local as id_local_evenement, e.code, e.date_debut, "
			+ "i.id_local as id_local_tiers, i.code_bq, c.date_maj, c.date_photo  from evenement e "
			+ "inner join identite_tiers i on i.id = e.identite_initiale_id "
			+ "inner join complement_evenement c on c.evenement_id = e.id "
			+ "and c.statut_evenement = 'CLO' and c.date_fin is  null and i.code_bq in (%s)";

	private static final String RECHERCHE_DATE_CALCUL_COURANTE = "select valeur_param from par_mdc_seg where code_param = 'DATE_CALCUL_COURANTE'";

	@Autowired
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Autowired
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	/**
	 * Rend l'entite paramètre persistante.
	 *
	 * @param entite
	 */
	public void persist(Object entite) {
		entityManager.persist(entite);
	}

	/**
	 * Met à jour l'entite paramètre, pour l'instant détachée, dans la session.
	 *
	 * @param entite
	 */
	public void update(Object entite) {
		entityManager.merge(entite);
	}

	public Long insertTiers(Tiers item) {
		KeyHolder keyHolder = new GeneratedKeyHolder();
		jdbcTemplate.update(connection -> {
			PreparedStatement ps = connection.prepareStatement(SQL_TIERS_INSERT, new String[] { "ID" });
			ps.setString(1, item.getIdFederal());
			return ps;
		}, keyHolder);

		return keyHolder.getKey().longValue();
	}

	public Long insertIdentiteTiers(IdentiteTiers item) {
		KeyHolder keyHolder = new GeneratedKeyHolder();
		jdbcTemplate.update(connection -> {
			PreparedStatement ps = connection.prepareStatement(SQL_IDENTITE_INSERT, new String[] { "ID" });
			ps.setString(1, item.getCodeBanque());
			ps.setString(2, item.getIdLocal());
			ps.setString(3, item.getCodeSegment());
			ps.setString(4, item.getSiren());
			ps.setDate(5, Date.valueOf(item.getDateDebut()));
			ps.setLong(6, item.getTiers().getId());
			ps.setDate(7, item.getDateFin() != null ? Date.valueOf(item.getDateFin()) : null);
			if (item.getSuivante() != null) {
				ps.setLong(8, item.getSuivante().getId());
			} else {
				ps.setObject(8, null);
			}
			return ps;
		}, keyHolder);

		return keyHolder.getKey().longValue();
	}

	public Long insertEvenement(Evenement item) {
		KeyHolder keyHolder = new GeneratedKeyHolder();
		jdbcTemplate.update(connection -> {
			PreparedStatement ps = connection.prepareStatement(SQL_EVENEMENT_INSERT, new String[] { "ID" });
			ps.setString(1, item.getIdLocal());
			ps.setString(2, item.getCode());
			ps.setLong(3, item.getIdentiteInitiale().getId());
			ps.setDate(4, Date.valueOf(item.getDateDebut()));
			ps.setString(5, item.getType());
			ps.setString(6, item.getIdContrat());
			return ps;
		}, keyHolder);

		return keyHolder.getKey().longValue();
	}

	public void insertComplementEvenement(ComplementEvenement item) {
		jdbcTemplate.update(SQL_COMPLEMENT_INSERT, item.getEvenement().getId(), item.getStatutEvt().name(),
				item.getMontantArriere(), item.isArriereTech(), item.isArriereLitige(), item.getCommentaire(),
				Date.valueOf(item.getDateMaj()), Date.valueOf(item.getDatePhoto()),
				item.getDateFin() != null ? Date.valueOf(item.getDateFin()) : null, item.isMiseAJour(),
				item.getAuditFichier().getId(), item.getIdentiteInitiale().getId());
	}

	public void updateIdFederal(Tiers item) {
		jdbcTemplate.update(SQL_TIERS_UPDATE, item.getIdFederal(), item.getId());
	}

	public void updateDateFinAndIdentiteSuivante(final List<IdentiteTiers> items) {
		jdbcTemplate.batchUpdate(SQL_IDENTITE_UPDATE, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int j) throws SQLException {
				IdentiteTiers item = items.get(j);
				ps.setDate(1, Date.valueOf(item.getDateFin()));
				ps.setLong(2, item.getSuivante().getId());
				ps.setLong(3, item.getId());
			}

			@Override
			public int getBatchSize() {
				return items.size();
			}
		});
	}

	public void updateDateFinComplementEvenement(final List<ComplementEvenement> items) {
		jdbcTemplate.batchUpdate(SQL_COMPLEMENT_UPDATE_DATE_FIN, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int j) throws SQLException {
				ComplementEvenement item = items.get(j);
				ps.setDate(1, Date.valueOf(item.getDateFin()));
				ps.setLong(2, item.getId());
			}

			@Override
			public int getBatchSize() {
				return items.size();
			}
		});
	}

	public void updateMiseAJourComplementEvenement(final List<ComplementEvenement> items) {
		jdbcTemplate.batchUpdate(SQL_COMPLEMENT_UPDATE_MISE_A_JOUR, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int j) throws SQLException {
				ComplementEvenement item = items.get(j);
				ps.setBoolean(1, item.isMiseAJour());
				ps.setLong(2, item.getId());
			}

			@Override
			public int getBatchSize() {
				return items.size();
			}
		});
	}

	public ComplementEvenement loadComplementEvenement(Long evtId, Long identiteInitialeId, ImportBean item) {
		List<ComplementEvenement> items = jdbcTemplate.query("select id from Complement_Evenement "
				+ "where evenement_id = ? and identite_initiale_id = ? and statut_evenement = ? and montant_arriere = ? and arriere_tech = ? "
				+ "and arriere_litige = ? and nvl(commentaire,'vide') = ? and date_photo = ?",
				new Object[] { evtId, identiteInitialeId, item.getStatutEvenement().name(), item.getMontantArriere(),
						item.getArriereTechnique(), item.getArriereLitige(),
						item.getCommentaire() != null ? item.getCommentaire() : "vide", item.getDatePhoto() },
				(resultSet, i) -> new ComplementEvenement(resultSet.getLong("ID")));

		if (!items.isEmpty()) {
			return items.get(0);
		}
		return null;
	}

	public ComplementEvenement loadComplementPrecedent(Long evtId, Long identiteInitialeId, ImportBean importBean) {
		Date dateDebut = Date.valueOf("ACT".equals(importBean.getStatutEvenement().name()) ? importBean.getDatePhoto()
				: importBean.getDateMajEvenement());

		List<ComplementEvenement> items = jdbcTemplate.query(
				"select id from ( select id, case when STATUT_EVENEMENT = 'ACT' and mise_a_jour = 1 "
						+ "then DATE_PHOTO else DATE_MAJ end as dateDebut from complement_evenement "
						+ "where evenement_id = ? and identite_initiale_id = ? and ((STATUT_EVENEMENT = 'ACT' and mise_a_jour = 1 and date_photo <= ?) "
						+ "or ((STATUT_EVENEMENT != 'ACT' or mise_a_jour = 0) and date_maj <= ?)) order by dateDebut desc, id desc) "
						+ "where rownum = 1",
				new Object[] { evtId, identiteInitialeId, dateDebut, dateDebut },
				(resultSet, i) -> new ComplementEvenement(resultSet.getLong("ID")));

		if (!items.isEmpty()) {
			return items.get(0);
		}
		return null;
	}

	public ComplementEvenement loadComplementSuivant(Long evtId, Long identiteInitialeId, ImportBean importBean) {
		Date dateDebut = Date.valueOf("ACT".equals(importBean.getStatutEvenement().name()) ? importBean.getDatePhoto()
				: importBean.getDateMajEvenement());

		List<ComplementEvenement> items = jdbcTemplate.query(
				"select id, STATUT_EVENEMENT, date_maj, date_photo from ( select id, STATUT_EVENEMENT, date_maj, date_photo, case when STATUT_EVENEMENT = 'ACT' and mise_a_jour = 1 "
						+ "then DATE_PHOTO else DATE_MAJ end as dateDebut from complement_evenement "
						+ "where evenement_id = ? and identite_initiale_id = ? and ((STATUT_EVENEMENT = 'ACT' and mise_a_jour = 1 and date_photo > ?) "
						+ "or ((STATUT_EVENEMENT != 'ACT' or mise_a_jour = 0) and date_maj > ?)) order by dateDebut asc, id asc) "
						+ "where rownum = 1",
				new Object[] { evtId, identiteInitialeId, dateDebut, dateDebut },
				(resultSet, i) -> new ComplementEvenement(resultSet.getLong("ID"),
						StatutEvenement.valueOf(resultSet.getString("STATUT_EVENEMENT")),
						resultSet.getDate("DATE_MAJ").toLocalDate(), resultSet.getDate("DATE_PHOTO").toLocalDate()));

		if (!items.isEmpty()) {
			return items.get(0);
		}
		return null;
	}

	public IdentiteTiers findIdentiteById(Long id, Long idTiers) {
		List<IdentiteTiers> items = jdbcTemplate.query(
				"select id, id_local, code_bq, code_segment, siren, tiers_id, date_debut from identite_tiers where id = ? and tiers_id = ?",
				new Object[] { id, idTiers },
				(resultSet, i) -> new IdentiteTiers(resultSet.getLong("ID"), resultSet.getString("ID_LOCAL"),
						resultSet.getString(CODE_BQ), resultSet.getString("CODE_SEGMENT"), resultSet.getString("SIREN"),
						new Tiers(resultSet.getLong("TIERS_ID")), resultSet.getDate(DATE_DEBUT).toLocalDate()));

		if (!items.isEmpty()) {
			return items.get(0);
		}
		return null;
	}

	public Tiers findTiersByIdFederal(String idFederal) {
		List<Tiers> items = jdbcTemplate.query("select id, id_rft from tiers where id_rft = ?",
				new Object[] { idFederal },
				(resultSet, i) -> new Tiers(resultSet.getLong("ID"), resultSet.getString("ID_RFT")));

		if (!items.isEmpty()) {
			return items.get(0);
		}
		return null;
	}

	public boolean checkTiersPartage(Long idTiers, String idLocal, String codeBanque) {

		Long count = jdbcTemplate.queryForObject(
				"select count(*) from IDENTITE_TIERS i where (i.ID_LOCAL != ? or i.CODE_BQ !=  ? ) and i.TIERS_ID = ? "
						+ "and i.DATE_FIN is null",
				new Object[] { idLocal, codeBanque, idTiers }, Long.class);
		return count != 0;
	}

	public Evenement findEvenementById(Long id) {
		List<Evenement> items = jdbcTemplate.query(
				"select e.id, e.identite_initiale_id, i.tiers_id from evenement e "
						+ "inner join identite_tiers i on i.id = e.identite_initiale_id where e.id = ?",
				new Object[] { id }, (resultSet, i) -> new Evenement(resultSet.getLong("ID"), new IdentiteTiers(
						resultSet.getLong("IDENTITE_INITIALE_ID"), new Tiers(resultSet.getLong("TIERS_ID")))));

		if (!items.isEmpty()) {
			return items.get(0);
		}
		return null;
	}

	public Map<String, List<ImportEvenementAnnuleBean>> loadEvenementTiersAnnule() {
		Map<String, List<ImportEvenementAnnuleBean>> mapEvt = new HashMap<>();
		List<ImportEvenementAnnuleBean> listTmpEvt = null;
		List<ImportEvenementAnnuleBean> listEvt = jdbcTemplate.query(
				"select e.id_local as id_local_evenement, e.code, e.date_debut, "
						+ "i.id_local as id_local_tiers, i.code_bq  from evenement e "
						+ "inner join identite_tiers i on i.id = e.identite_initiale_id "
						+ "inner join complement_evenement c on c.evenement_id = e.id and c.statut_evenement = 'ANN' ",
				new Object[] {},
				(resultSet, i) -> new ImportEvenementAnnuleBean(resultSet.getString("ID_LOCAL_EVENEMENT"),
						resultSet.getString("CODE"), resultSet.getDate(DATE_DEBUT).toLocalDate(),
						resultSet.getString(CODE_BQ), resultSet.getString("ID_LOCAL_TIERS")));
		for (ImportEvenementAnnuleBean evt : listEvt) {
			listTmpEvt = mapEvt.get(evt.getCodeBanque() + "-" + evt.getIdTiersLocal());
			if (listTmpEvt == null) {
				listTmpEvt = new ArrayList<>();
			}
			listTmpEvt.add(evt);
			mapEvt.put(evt.getCodeBanque() + "-" + evt.getIdTiersLocal(), listTmpEvt);
		}
		return mapEvt;
	}

	public List<ImportEvtCloBean> loadEvenementsTiersClotures(Set<String> codsBq) {
		if (codsBq.isEmpty()) {
			return new ArrayList<>();
		}
		String inCodBqSql = String.join(",", Collections.nCopies(codsBq.size(), "?"));
		return jdbcTemplate.query(String.format(SQL_SEARCH_EVT_CLO, inCodBqSql), codsBq.toArray(),
				(resultSet, i) -> new ImportEvtCloBean(resultSet.getString("ID_LOCAL_EVENEMENT"),
						resultSet.getString("CODE"), resultSet.getDate(DATE_DEBUT).toLocalDate(),
						resultSet.getString(CODE_BQ), resultSet.getString("ID_LOCAL_TIERS"),
						resultSet.getDate("DATE_MAJ").toLocalDate()));
	}

	public LocalDate findDateCalculCourante() {
		List<String> dateStrList = jdbcTemplate.query(RECHERCHE_DATE_CALCUL_COURANTE,
				(rs, i) -> rs.getString("valeur_param"));
		if (dateStrList != null && !dateStrList.isEmpty()) {
			return LocalDate.parse(dateStrList.get(0), DateTimeFormatter.ofPattern(Constant.FORMAT_DATE));
		}
		return LocalDate.now().minusDays(1);

	}
}
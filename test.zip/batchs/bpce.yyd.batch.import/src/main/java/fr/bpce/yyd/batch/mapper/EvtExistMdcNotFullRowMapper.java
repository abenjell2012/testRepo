package fr.bpce.yyd.batch.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fr.bpce.yyd.batch.beans.ImportBean;
import fr.bpce.yyd.commun.enums.StatutEvenement;

public class EvtExistMdcNotFullRowMapper implements RowMapper<ImportBean> {

	@Override
	public ImportBean mapRow(ResultSet rs, int rowNum) throws SQLException {
		ImportBean importBean = new ImportBean();
		importBean.setDatePhoto(rs.getTimestamp("DATE_PHOTO").toLocalDateTime().toLocalDate());
		importBean.setCodeBanque(rs.getString("CODE_BANQUE"));
		importBean.setIdTiersLocal(rs.getString("ID_TIERS_LOCAL"));
		importBean.setSiren(rs.getString("SIREN"));
		importBean.setSegmentRisque(rs.getString("SEGMENT_RISQUE"));
		importBean.setIdEvenementLocal(rs.getString("ID_EVENEMENT_LOCAL"));
		importBean.setCodeEvenement(rs.getString("CODE_EVENEMENT"));
		importBean.setSsCodeEvenement(rs.getString("SS_CODE_EVENEMENT"));
		importBean.setDateDebEvenement(rs.getTimestamp("DATE_DEB_EVENEMENT").toLocalDateTime().toLocalDate());
		importBean.setDateMajEvenement(rs.getTimestamp("DATE_MAJ_EVENEMENT").toLocalDateTime().toLocalDate());
		importBean.setStatutEvenement(StatutEvenement.get(rs.getString("STATUT_EVENEMENT")));
		importBean.setMontantArriere(rs.getBigDecimal("MONTANT_ARRIERE"));
		importBean.setNumContrat(rs.getString("NUM_CONTRAT"));
		importBean.setCommentaire(rs.getString("COMMENTAIRE"));
		importBean.setArriereTechnique(rs.getBoolean("ARRIERE_TECHNIQUE"));
		importBean.setArriereLitige(rs.getBoolean("ARRIERE_LITIGE"));

		return importBean;
	}
}

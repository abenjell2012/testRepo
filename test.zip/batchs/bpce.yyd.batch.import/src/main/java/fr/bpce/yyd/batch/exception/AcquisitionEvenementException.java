package fr.bpce.yyd.batch.exception;

import fr.bpce.yyd.commun.enums.Controles;

public class AcquisitionEvenementException extends Exception {

	private static final long serialVersionUID = 1L;
	private final Controles controle;

	public AcquisitionEvenementException(Controles controle, String libelle) {
		super(libelle);
		this.controle = controle;
	}

	public Controles getControle() {
		return controle;
	}

	public String getLibelle() {
		return getMessage();
	}
}
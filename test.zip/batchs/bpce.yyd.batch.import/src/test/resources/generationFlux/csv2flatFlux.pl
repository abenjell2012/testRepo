#!/usr/bin/perl
use POSIX qw(strftime);
use strict;

my $entete_template  = "*1BBBBBBBBCCCCCMDC001";
my $enqueue_template = "*9GGGGGGGGHHHHHMDC001KKKKKKKKKKKKKKK";
my $detail_template  = "LLLLLLLLMMMMMNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNOOOOOOOOOPPPPQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQRRRSSSSTTTTTTTTUUUUUUUUVVV+WWWWWWWWWWWWWWWWWXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYZA";
	
opendir ( DIR, "input" ) || die "Error in opening dir input\n";
while ( my $filename = readdir(DIR) ) {
	next unless -f "input/$filename";
	open (CSV,"<input/$filename") or die $!;
	
	my ($jour, $mois, $annee) = (localtime)[3..5];
	$jour = complete_nombre($jour, 2);
	$mois = complete_nombre($mois + 1, 2);
	$annee = complete_nombre($annee + 1900, 4);

	my ($cod_banque) = ( $filename =~ m/^\w*_\w*_\w*_(\d{5})_/ );
	my $date_cst_flx = $annee.$mois.$jour;
	
	# creation output file .txt 
	my $txt_file = $filename;
	$txt_file =~ s/csv$/txt/;
	open(TXT,">output/$txt_file") or die $!;
	
	# creation entete
	$entete_template =~ s/B{8}/$date_cst_flx/;
	$entete_template =~ s/C{5}/$cod_banque/;
	print TXT "$entete_template\n";
	
	my $entete = <CSV>; # entete du fichier
	
	my $nombrelignes = 0;
	while (<CSV>) {
		my $line = $_;
		chomp($line);
		$nombrelignes++;
		
		my ($date_ph, $cod_bq, $idTiers, $siren, $codeSeg, $idEvt, $codeEvt, $typEvt, 
			$date_deb, $date_fin, $statutEvt, $montant, $idctrt, $cmt, $flg_tech, $flg_lit) = split(/;/,$line);
		my $detail = $detail_template;		
		$detail =~s/Z/$flg_tech/;
		$detail =~s/A/$flg_lit/;
		$detail =~s/R{3}/$codeEvt/;
		$detail =~s/S{4}/$typEvt/;
		$detail =~s/V{3}/$statutEvt/;
		$detail =~s/P{4}/$codeSeg/;
		$detail =~s/M{5}/$cod_bq/;
		$detail =~s/L{8}/$date_ph/;
		$detail =~s/T{8}/$date_deb/;
		$detail =~s/U{8}/$date_fin/;
		$detail =~s/O{9}/$siren/;
		$detail =~s/W{17}/complete_nombre($montant,17)/e;
		$detail =~s/Q{30}/complete_string($idEvt, 30)/e;
		$detail =~s/N{50}/complete_string($idTiers, 50)/e;
		$detail =~s/X{50}/complete_string($idctrt,50)/e;
		$detail =~s/Y{200}/complete_string($cmt,200)/e;
		print TXT "$detail\n";
	}
	
	# creation entete
	$enqueue_template =~ s/G{8}/$date_cst_flx/;
	$enqueue_template =~ s/H{5}/$cod_banque/;
	$enqueue_template =~ s/K{15}/complete_nombre($nombrelignes,15)/e;
	print TXT $enqueue_template;
	close(CSV);
	close(TXT);
}
closedir(DIR);

sub complete_string {
	my ($in, $taille) = @_;
	while (length($in) < $taille) { $in .= " ";}
	return $in;
}

sub complete_nombre {
	my ($in, $taille) = @_;
	while (length($in) < $taille) { $in = "0".$in;}
	return $in;
}


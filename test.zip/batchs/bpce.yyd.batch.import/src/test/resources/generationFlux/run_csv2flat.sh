#!/bin/bash

perl csv2flatFlux.pl 

package fr.bpce.yyd.batch.ti;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;

import org.junit.Assert;
import org.junit.Test;

import fr.bpce.yyd.commun.enums.Controles;
import fr.bpce.yyd.commun.model.AuditFichiers;
import fr.bpce.yyd.commun.model.AuditLignesImport;
import fr.bpce.yyd.commun.model.ComplementEvenement;
import fr.bpce.yyd.commun.model.Evenement;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.Tiers;

public class TestsIntegrationSimples extends AbstractIntegrationTest {

	@Test
	public void fichier2Lignes1EvtMajComplement() {

		doInTransaction(() -> {
			insertDateCalculCourante(LocalDate.now().minusDays(1));
		});
		// Act
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180000.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(2, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
			Assert.assertEquals(LocalDate.now(), fichier.getDatePhoto());

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(1, tousTiers.size());

			Tiers tiers = tousTiers.get(0);
			Collection<IdentiteTiers> identites = tiers.getIdentites();
			Collection<Evenement> evenements = new ArrayList<>();
			for (IdentiteTiers identite : identites) {
				evenements.addAll(findEvenementByIdentiteTiers(identite.getId()));
			}

			Assert.assertEquals(1, identites.size());
			Assert.assertEquals(1, evenements.size());

			Evenement evt = evenements.iterator().next();
			Collection<ComplementEvenement> complements = evt.getComplements();
			Assert.assertEquals(2, complements.size());
		});
	}

	@Test
	public void fichier2Lignes1EvtChgtIdentiteSegment() {
		// Act
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180001.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(2, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
			Assert.assertEquals(LocalDate.now(), fichier.getDatePhoto());

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(1, tousTiers.size());

			Tiers tiers = tousTiers.get(0);
			Collection<IdentiteTiers> identites = tiers.getIdentites();
			Collection<Evenement> evenements = new ArrayList<>();
			for (IdentiteTiers identite : identites) {
				evenements.addAll(findEvenementByIdentiteTiers(identite.getId()));
			}

			Assert.assertEquals(2, identites.size());
			Assert.assertEquals(1, evenements.size());

			Evenement evt = evenements.iterator().next();
			Collection<ComplementEvenement> complements = evt.getComplements();
			Assert.assertEquals(1, complements.size());
		});
	}

	@Test
	public void fichier2Lignes2Tiers2Evt() {
		// Act
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180002.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(2, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(2, tousTiers.size());

			for (Tiers tiers : tousTiers) {
				Collection<IdentiteTiers> identites = tiers.getIdentites();
				Collection<Evenement> evenements = new ArrayList<>();
				for (IdentiteTiers identite : identites) {
					evenements.addAll(findEvenementByIdentiteTiers(identite.getId()));
				}

				Assert.assertEquals(1, identites.size());
				Assert.assertEquals(1, evenements.size());

				Evenement evt = evenements.iterator().next();
				Collection<ComplementEvenement> complements = evt.getComplements();
				Assert.assertEquals(1, complements.size());
			}
		});
	}

	@Test
	public void fichier2LignesPresente2Fois() {
		// Act
		String nomFichier = "NDOD_EVT_DELTA_10807_RCT_190313-180000.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(1, tousTiers.size());

			Tiers tiers = tousTiers.get(0);
			Collection<IdentiteTiers> identites = tiers.getIdentites();
			Collection<Evenement> evenements = new ArrayList<>();
			for (IdentiteTiers identite : identites) {
				evenements.addAll(findEvenementByIdentiteTiers(identite.getId()));
			}

			Assert.assertEquals(1, identites.size());
			Assert.assertEquals(1, evenements.size());

			Evenement evt = evenements.iterator().next();
			Collection<ComplementEvenement> complements = evt.getComplements();
			Assert.assertEquals(2, complements.size());
		});

		// Act - bis
		importFile(nomFichier);

		// Assert - bis : rien n'a changé
		doInTransaction(() -> {

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(1, tousTiers.size());

			Tiers tiers = tousTiers.get(0);
			Collection<IdentiteTiers> identites = tiers.getIdentites();
			Collection<Evenement> evenements = new ArrayList<>();
			for (IdentiteTiers identite : identites) {
				evenements.addAll(findEvenementByIdentiteTiers(identite.getId()));
			}

			Assert.assertEquals(1, identites.size());
			Assert.assertEquals(1, evenements.size());

			Evenement evt = evenements.iterator().next();
			Collection<ComplementEvenement> complements = evt.getComplements();
			Assert.assertEquals(2, complements.size());
		});
	}

	@Test
	public void evenementCreePuisMisAJourPuisStock() {
		// Act
		String nomFichier = "NDOD_EVT_DELTA_10807_RCT_190313-180000.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(1, tousTiers.size());

			Tiers tiers = tousTiers.get(0);
			Collection<IdentiteTiers> identites = tiers.getIdentites();
			Collection<Evenement> evenements = new ArrayList<>();
			for (IdentiteTiers identite : identites) {
				evenements.addAll(findEvenementByIdentiteTiers(identite.getId()));
			}

			Assert.assertEquals(1, identites.size());
			Assert.assertEquals(1, evenements.size());

			Evenement evt = evenements.iterator().next();
			Collection<ComplementEvenement> complements = evt.getComplements();
			Assert.assertEquals(2, complements.size());
		});

		// Act - bis
		String nomFichier1 = "NDOD_EVT_DELTA_10807_RCT_190313-180001.txt";
		importFile(nomFichier1);

		// Assert - bis : la mise à jour de l'evt identique à sa première version est
		// prise en compte.
		doInTransaction(() -> {

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(1, tousTiers.size());

			Tiers tiers = tousTiers.get(0);
			Collection<IdentiteTiers> identites = tiers.getIdentites();
			Collection<Evenement> evenements = new ArrayList<>();
			for (IdentiteTiers identite : identites) {
				evenements.addAll(findEvenementByIdentiteTiers(identite.getId()));
			}

			Assert.assertEquals(1, identites.size());
			Assert.assertEquals(1, evenements.size());

			Evenement evt = evenements.iterator().next();
			Collection<ComplementEvenement> complements = evt.getComplements();
			Assert.assertEquals(3, complements.size());
		});

		// Act - ter
		String nomFichier2 = "NDOD_EVT_DELTA_10807_RCT_190313-180002.txt";
		importFile(nomFichier2);

		// Assert - ter : rien n'a changé. Le stock avec même contenu mais date photo
		// différente n'a pas créé de nouvelle ligne en base.
		doInTransaction(() -> {

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(1, tousTiers.size());

			Tiers tiers = tousTiers.get(0);
			Collection<IdentiteTiers> identites = tiers.getIdentites();
			Collection<Evenement> evenements = new ArrayList<>();
			for (IdentiteTiers identite : identites) {
				evenements.addAll(findEvenementByIdentiteTiers(identite.getId()));
			}

			Assert.assertEquals(1, identites.size());
			Assert.assertEquals(1, evenements.size());

			Evenement evt = evenements.iterator().next();
			Collection<ComplementEvenement> complements = evt.getComplements();
			Assert.assertEquals(3, complements.size());
		});
	}

	@Test
	public void evenementCreePuisMisAJourPuisStockAvecMajEvt() {
		// Act
		String nomFichier = "NDOD_EVT_DELTA_10807_RCT_190313-180003.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(1, tousTiers.size());

			Tiers tiers = tousTiers.get(0);
			Collection<IdentiteTiers> identites = tiers.getIdentites();
			Collection<Evenement> evenements = new ArrayList<>();
			for (IdentiteTiers identite : identites) {
				evenements.addAll(findEvenementByIdentiteTiers(identite.getId()));
			}

			Assert.assertEquals(1, identites.size());
			Assert.assertEquals(1, evenements.size());

			Evenement evt = evenements.iterator().next();
			Collection<ComplementEvenement> complements = evt.getComplements();
			Assert.assertEquals(2, complements.size());
		});

		// Act - bis
		String nomFichier1 = "NDOD_EVT_DELTA_10807_RCT_190313-180004.txt";
		importFile(nomFichier1);

		// Assert - bis : la mise à jour de l'evt identique à sa première version est
		// prise en compte.
		doInTransaction(() -> {

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(1, tousTiers.size());

			Tiers tiers = tousTiers.get(0);
			Collection<IdentiteTiers> identites = tiers.getIdentites();
			Collection<Evenement> evenements = new ArrayList<>();
			for (IdentiteTiers identite : identites) {
				evenements.addAll(findEvenementByIdentiteTiers(identite.getId()));
			}

			Assert.assertEquals(1, identites.size());
			Assert.assertEquals(1, evenements.size());

			Evenement evt = evenements.iterator().next();
			Collection<ComplementEvenement> complements = evt.getComplements();
			Assert.assertEquals(3, complements.size());
		});

		// Act - ter
		String nomFichier2 = "NDOD_EVT_DELTA_10807_RCT_190313-180005.txt";
		importFile(nomFichier2);

		// Assert - ter : rien n'a changé. Le stock avec même contenu mais date photo
		// différente n'a pas créé de nouvelle ligne en base.
		doInTransaction(() -> {

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(1, tousTiers.size());

			Tiers tiers = tousTiers.get(0);
			Collection<IdentiteTiers> identites = tiers.getIdentites();
			Collection<Evenement> evenements = new ArrayList<>();
			for (IdentiteTiers identite : identites) {
				evenements.addAll(findEvenementByIdentiteTiers(identite.getId()));
			}

			Assert.assertEquals(1, identites.size());
			Assert.assertEquals(1, evenements.size());

			Evenement evt = evenements.iterator().next();
			Collection<ComplementEvenement> complements = evt.getComplements();
			Assert.assertEquals(4, complements.size());
		});
	}

	@Test
	public void fichierOKAvecLignesRejetees() {
		// Act
		String nomFichier = "NDOD_EVT_DELTA_12128_RCT_190224-180000.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(22, fichier.getNbLignes());
			Assert.assertEquals(11, fichier.getNbLignesRejet());
		});
	}

	@Test
	public void fichierAvecImxActPuisAnnulePuisAct() {
		// Act
		String nomFichier = "NDOD_EVT_DELTA_12128_RCT_190225-180001.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(2, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
		});

		// Act 2
		String nomFichier2 = "NDOD_EVT_DELTA_12128_RCT_190225-180002.txt";
		importFile(nomFichier2);

		// Assert 2
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier2);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
		});

		// Act 3
		String nomFichier3 = "NDOD_EVT_DELTA_12128_RCT_190225-180003.txt";
		importFile(nomFichier3);

		// Assert 3
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier3);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(1, fichier.getNbLignesRejet());

			Set<AuditLignesImport> auditLignesImport = fichier.getLignes();
			Assert.assertEquals(1, auditLignesImport.size());
			for (AuditLignesImport auditLigneImport : auditLignesImport) {
				Assert.assertEquals(Controles.CF010, auditLigneImport.getCodeAudit());
			}
		});
	}

	@Test
	public void memeIdLocalEvtAnd2CodeDifferentsDansLeMemeFichier() {
		// Act
		String nomFichier = "NDOD_EVT_INIT1_12128_RCT_190224-180013.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(2, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(1, tousTiers.size());

			Tiers tiers = tousTiers.get(0);
			Collection<IdentiteTiers> identites = tiers.getIdentites();
			Collection<Evenement> evenements = new ArrayList<>();
			for (IdentiteTiers identite : identites) {
				evenements.addAll(findEvenementByIdentiteTiers(identite.getId()));
			}

			Assert.assertEquals(1, identites.size());
			Assert.assertEquals(2, evenements.size());

			for (Evenement evt : evenements) {
				Collection<ComplementEvenement> complements = evt.getComplements();
				Assert.assertEquals(1, complements.size());
			}
		});
	}

	@Test
	public void memeIdLocalEvtAnd2CodeDifferentsDans2Fichiers() {
		// Act
		String nomFichier = "NDOD_EVT_INIT1_12128_RCT_190224-180016.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(1, tousTiers.size());

			Tiers tiers = tousTiers.get(0);
			Collection<IdentiteTiers> identites = tiers.getIdentites();
			Collection<Evenement> evenements = new ArrayList<>();
			for (IdentiteTiers identite : identites) {
				evenements.addAll(findEvenementByIdentiteTiers(identite.getId()));
			}

			Assert.assertEquals(1, identites.size());
			Assert.assertEquals(1, evenements.size());

			for (Evenement evt : evenements) {
				Collection<ComplementEvenement> complements = evt.getComplements();
				Assert.assertEquals(1, complements.size());
			}
		});

		// Act
		String nomFichier2 = "NDOD_EVT_INIT1_12128_RCT_190224-180017.txt";
		importFile(nomFichier2);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier2);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(1, tousTiers.size());

			Tiers tiers = tousTiers.get(0);
			Collection<IdentiteTiers> identites = tiers.getIdentites();
			Collection<Evenement> evenements = new ArrayList<>();
			for (IdentiteTiers identite : identites) {
				evenements.addAll(findEvenementByIdentiteTiers(identite.getId()));
			}

			Assert.assertEquals(1, identites.size());
			Assert.assertEquals(2, evenements.size());

			for (Evenement evt : evenements) {
				Collection<ComplementEvenement> complements = evt.getComplements();
				Assert.assertEquals(1, complements.size());
			}
		});
	}

	@Test
	public void memeIdLocalEvtAnd2IdLocalTiersDansLeMemeFichier() {
		// Act
		String nomFichier = "NDOD_EVT_INIT1_12128_RCT_190224-180012.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(2, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(2, tousTiers.size());

			for (Tiers tiers : tousTiers) {
				Collection<IdentiteTiers> identites = tiers.getIdentites();
				Collection<Evenement> evenements = new ArrayList<>();
				for (IdentiteTiers identite : identites) {
					evenements.addAll(findEvenementByIdentiteTiers(identite.getId()));
				}

				Assert.assertEquals(1, identites.size());
				Assert.assertEquals(1, evenements.size());

				for (Evenement evt : evenements) {
					Collection<ComplementEvenement> complements = evt.getComplements();
					Assert.assertEquals(1, complements.size());
				}
			}
		});
	}

	@Test
	public void memeIdLocalEvtAnd2IdLocalTiersCreesPuisModifies() {
		// Act
		String nomFichier = "NDOD_EVT_INIT1_12128_RCT_190224-180020.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(2, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(2, tousTiers.size());

			for (Tiers tiers : tousTiers) {
				Collection<IdentiteTiers> identites = tiers.getIdentites();
				Collection<Evenement> evenements = new ArrayList<>();
				for (IdentiteTiers identite : identites) {
					evenements.addAll(findEvenementByIdentiteTiers(identite.getId()));
				}

				Assert.assertEquals(1, identites.size());
				Assert.assertEquals(1, evenements.size());

				for (Evenement evt : evenements) {
					Collection<ComplementEvenement> complements = evt.getComplements();
					Assert.assertEquals(1, complements.size());
				}
			}
		});

		// Act
		String nomFichier2 = "NDOD_EVT_INIT1_12128_RCT_190224-180021.txt";
		importFile(nomFichier2);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier2);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(2, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(2, tousTiers.size());

			for (Tiers tiers : tousTiers) {
				Collection<IdentiteTiers> identites = tiers.getIdentites();
				Collection<Evenement> evenements = new ArrayList<>();
				for (IdentiteTiers identite : identites) {
					evenements.addAll(findEvenementByIdentiteTiers(identite.getId()));
				}

				Assert.assertEquals(1, identites.size());
				Assert.assertEquals(1, evenements.size());

				for (Evenement evt : evenements) {
					Collection<ComplementEvenement> complements = evt.getComplements();
					Assert.assertEquals(2, complements.size());
				}
			}
		});
	}

	@Test
	public void memeIdLocalEvtAnd2IdLocalTiersDans2FichiersDifferents() {
		// Act
		String nomFichier = "NDOD_EVT_INIT1_12128_RCT_190224-180018.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(1, tousTiers.size());

			for (Tiers tiers : tousTiers) {
				Collection<IdentiteTiers> identites = tiers.getIdentites();
				Collection<Evenement> evenements = new ArrayList<>();
				for (IdentiteTiers identite : identites) {
					evenements.addAll(findEvenementByIdentiteTiers(identite.getId()));
				}

				Assert.assertEquals(1, identites.size());
				Assert.assertEquals(1, evenements.size());

				for (Evenement evt : evenements) {
					Collection<ComplementEvenement> complements = evt.getComplements();
					Assert.assertEquals(1, complements.size());
				}
			}
		});

		// Act
		String nomFichier2 = "NDOD_EVT_INIT1_12128_RCT_190224-180019.txt";
		importFile(nomFichier2);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier2);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(2, tousTiers.size());

			for (Tiers tiers : tousTiers) {
				Collection<IdentiteTiers> identites = tiers.getIdentites();
				Collection<Evenement> evenements = new ArrayList<>();
				for (IdentiteTiers identite : identites) {
					evenements.addAll(findEvenementByIdentiteTiers(identite.getId()));
				}

				Assert.assertEquals(1, identites.size());
				Assert.assertEquals(1, evenements.size());

				for (Evenement evt : evenements) {
					Collection<ComplementEvenement> complements = evt.getComplements();
					Assert.assertEquals(1, complements.size());
				}
			}
		});
	}

	@Test
	public void complementEvenementInsereDansLePasse() {
		// Act
		String nomFichier = "NDOD_EVT_INIT1_12128_RCT_190224-180014.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(2, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(1, tousTiers.size());

			for (Tiers tiers : tousTiers) {
				Collection<IdentiteTiers> identites = tiers.getIdentites();
				Collection<Evenement> evenements = new ArrayList<>();
				for (IdentiteTiers identite : identites) {
					evenements.addAll(findEvenementByIdentiteTiers(identite.getId()));
				}

				Assert.assertEquals(1, identites.size());
				Assert.assertEquals(1, evenements.size());

				for (Evenement evt : evenements) {
					Collection<ComplementEvenement> complements = evt.getComplements();
					Assert.assertEquals(2, complements.size());
				}
			}
		});

		// Act2
		String nomFichier2 = "NDOD_EVT_INIT1_12128_RCT_190224-180015.txt";
		importFile(nomFichier2);

		// Assert2
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier2);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(1, tousTiers.size());

			for (Tiers tiers : tousTiers) {
				Collection<IdentiteTiers> identites = tiers.getIdentites();
				Collection<Evenement> evenements = new ArrayList<>();
				for (IdentiteTiers identite : identites) {
					evenements.addAll(findEvenementByIdentiteTiers(identite.getId()));
				}

				Assert.assertEquals(1, identites.size());
				Assert.assertEquals(1, evenements.size());

				for (Evenement evt : evenements) {
					Collection<ComplementEvenement> complements = evt.getComplements();
					Assert.assertEquals(3, complements.size());
					for (ComplementEvenement cmpl : complements) {
						if (cmpl.getDatePhoto().equals(LocalDate.of(2018, 07, 02))) {
							Assert.assertEquals(LocalDate.of(2018, 07, 01), cmpl.getDateFin());
						} else if (cmpl.getDatePhoto().equals(LocalDate.of(2018, 07, 01))) {
							Assert.assertEquals(LocalDate.of(2018, 07, 03), cmpl.getDateFin());
						} else {
							Assert.assertNull(cmpl.getDateFin());
						}
					}
				}
			}
		});
	}

	@Test
	public void identiteInsereDansLePasse() {
		// Act
		String nomFichier = "NDOD_EVT_INIT1_12128_RCT_190224-180024.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(1, tousTiers.size());

			for (Tiers tiers : tousTiers) {
				Collection<IdentiteTiers> identites = tiers.getIdentites();
				Collection<Evenement> evenements = new ArrayList<>();
				for (IdentiteTiers identite : identites) {
					evenements.addAll(findEvenementByIdentiteTiers(identite.getId()));
				}

				Assert.assertEquals(1, identites.size());
				Assert.assertEquals(1, evenements.size());

				for (Evenement evt : evenements) {
					Collection<ComplementEvenement> complements = evt.getComplements();
					Assert.assertEquals(1, complements.size());
				}
			}
		});

		// Act2
		String nomFichier2 = "NDOD_EVT_INIT1_12128_RCT_190224-180025.txt";
		importFile(nomFichier2);

		// Assert2
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier2);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(1, tousTiers.size());

			for (Tiers tiers : tousTiers) {
				Collection<IdentiteTiers> identites = tiers.getIdentites();
				Collection<Evenement> evenements = new ArrayList<>();
				for (IdentiteTiers identite : identites) {
					evenements.addAll(findEvenementByIdentiteTiers(identite.getId()));
				}

				Assert.assertEquals(2, identites.size());
				Assert.assertEquals(1, evenements.size());

				for (IdentiteTiers ident : identites) {
					if (ident.getDateDebut().equals(LocalDate.of(2018, 07, 03))) {
						Assert.assertEquals(LocalDate.of(2018, 07, 05), ident.getDateFin());
						Assert.assertNotNull(ident.getSuivante());
					} else {
						Assert.assertNull(ident.getDateFin());
						Assert.assertNull(ident.getSuivante());
					}
				}
			}
		});

		// Act3
		String nomFichier3 = "NDOD_EVT_INIT1_12128_RCT_190224-180026.txt";
		importFile(nomFichier3);

		// Assert3
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier3);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(1, tousTiers.size());

			for (Tiers tiers : tousTiers) {
				Collection<IdentiteTiers> identites = tiers.getIdentites();
				Collection<Evenement> evenements = new ArrayList<>();
				for (IdentiteTiers identite : identites) {
					evenements.addAll(findEvenementByIdentiteTiers(identite.getId()));
				}

				Assert.assertEquals(3, identites.size());
				Assert.assertEquals(1, evenements.size());

				for (IdentiteTiers ident : identites) {
					if (ident.getDateDebut().equals(LocalDate.of(2018, 07, 05))) {
						Assert.assertNull(ident.getDateFin());
						Assert.assertNull(ident.getSuivante());
					} else {
						Assert.assertEquals(LocalDate.of(2018, 07, 05), ident.getDateFin());
						Assert.assertNotNull(ident.getSuivante());
					}
				}
			}
		});
	}

	@Test
	public void evolutionIdentite() {
		// Act
		String nomFichier = "NDOD_EVT_INIT1_12128_RCT_190224-180022.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(1, tousTiers.size());

			for (Tiers tiers : tousTiers) {
				Collection<IdentiteTiers> identites = tiers.getIdentites();
				Collection<Evenement> evenements = new ArrayList<>();
				for (IdentiteTiers identite : identites) {
					evenements.addAll(findEvenementByIdentiteTiers(identite.getId()));
				}

				Assert.assertEquals(1, identites.size());
				Assert.assertEquals(1, evenements.size());

				for (Evenement evt : evenements) {
					Collection<ComplementEvenement> complements = evt.getComplements();
					Assert.assertEquals(1, complements.size());
				}
			}
		});

		// Act2
		String nomFichier2 = "NDOD_EVT_INIT1_12128_RCT_190224-180023.txt";
		importFile(nomFichier2);

		// Assert2
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier2);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(1, tousTiers.size());

			for (Tiers tiers : tousTiers) {
				Collection<IdentiteTiers> identites = tiers.getIdentites();
				Collection<Evenement> evenements = new ArrayList<>();
				for (IdentiteTiers identite : identites) {
					evenements.addAll(findEvenementByIdentiteTiers(identite.getId()));
				}

				Assert.assertEquals(2, identites.size());
				Assert.assertEquals(1, evenements.size());

				for (IdentiteTiers ident : identites) {
					if (ident.getDateDebut().equals(LocalDate.of(2018, 06, 30))) {
						Assert.assertEquals(LocalDate.of(2018, 07, 03), ident.getDateFin());
						Assert.assertNotNull(ident.getSuivante());
					} else {
						Assert.assertNull(ident.getDateFin());
						Assert.assertNull(ident.getSuivante());
					}
				}
			}
		});
	}

	@Test
	public void memeEvenementAvecDateDebutDifferenteDansLeMemeFichier() {
		// Act
		String nomFichier = "NDOD_EVT_INIT1_12128_RCT_190224-180027.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(2, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(1, tousTiers.size());

			for (Tiers tiers : tousTiers) {
				Collection<IdentiteTiers> identites = tiers.getIdentites();
				Collection<Evenement> evenements = new ArrayList<>();
				for (IdentiteTiers identite : identites) {
					evenements.addAll(findEvenementByIdentiteTiers(identite.getId()));
				}

				Assert.assertEquals(1, identites.size());
				Assert.assertEquals(2, evenements.size());

				for (Evenement evt : evenements) {
					Collection<ComplementEvenement> complements = evt.getComplements();
					Assert.assertEquals(1, complements.size());
				}
			}
		});
	}

	@Test
	public void memeEvenementAvecDateDebutDifferenteDansDeuxFichiers() {
		// Act
		String nomFichier = "NDOD_EVT_INIT1_12128_RCT_190224-180028.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(1, tousTiers.size());

			for (Tiers tiers : tousTiers) {
				Collection<IdentiteTiers> identites = tiers.getIdentites();
				Collection<Evenement> evenements = new ArrayList<>();
				for (IdentiteTiers identite : identites) {
					evenements.addAll(findEvenementByIdentiteTiers(identite.getId()));
				}

				Assert.assertEquals(1, identites.size());
				Assert.assertEquals(1, evenements.size());

				for (Evenement evt : evenements) {
					Collection<ComplementEvenement> complements = evt.getComplements();
					Assert.assertEquals(1, complements.size());
				}
			}
		});

		// Act 2
		String nomFichier1 = "NDOD_EVT_INIT1_12128_RCT_190224-180029.txt";
		importFile(nomFichier1);

		// Assert 2
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier1);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(1, tousTiers.size());

			for (Tiers tiers : tousTiers) {
				Collection<IdentiteTiers> identites = tiers.getIdentites();
				Collection<Evenement> evenements = new ArrayList<>();
				for (IdentiteTiers identite : identites) {
					evenements.addAll(findEvenementByIdentiteTiers(identite.getId()));
				}

				Assert.assertEquals(1, identites.size());
				Assert.assertEquals(2, evenements.size());

				for (Evenement evt : evenements) {
					Collection<ComplementEvenement> complements = evt.getComplements();
					Assert.assertEquals(1, complements.size());
				}
			}
		});
	}
}
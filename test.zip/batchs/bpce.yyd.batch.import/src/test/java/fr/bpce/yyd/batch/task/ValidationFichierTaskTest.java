package fr.bpce.yyd.batch.task;

import org.junit.Assert;
import org.junit.Test;

import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.util.ControleTechniqueUtil;

public class ValidationFichierTaskTest {

	@Test
	public void controleTypeLineEnteteOK() {
		// Arrange
		String line = "*12018070110107MDC001";

		// Act
		boolean res = ControleTechniqueUtil.controleTypeLigne(line, Constant.TYPE_LIGNE_ENTETE);

		// Assert
		Assert.assertTrue(res);
	}

	@Test
	public void controleTypeLineEnteteKO() {
		// Arrange
		String line = "*42018070110107MDC001";

		// Act
		boolean res = ControleTechniqueUtil.controleTypeLigne(line, Constant.TYPE_LIGNE_ENTETE);

		// Assert
		Assert.assertFalse(res);
	}


}

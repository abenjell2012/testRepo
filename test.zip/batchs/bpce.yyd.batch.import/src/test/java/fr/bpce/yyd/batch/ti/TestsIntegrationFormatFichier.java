package fr.bpce.yyd.batch.ti;

import java.security.Permission;

import org.junit.Assert;
import org.junit.Test;

import fr.bpce.yyd.commun.enums.Controles;
import fr.bpce.yyd.commun.model.AuditFichiers;

public class TestsIntegrationFormatFichier extends AbstractIntegrationTest {

	@Test
	public void formatsDeFichierIncorrect() {
		// Act
		String nomFichiers[] = new String[] { "NDAD_EVT_DELTA_10107_RCT_190224-170000.txt",
				"NDOD_EVT_DELTA_10107_RCT_190224-170A01.txt" };
		for (String nomFichier : nomFichiers) {
			importFile(nomFichier);

			// Assert
			doInTransaction(() -> {

				AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
				Assert.assertNotNull(fichier);
				Assert.assertEquals(Controles.CT002, fichier.getCodAudit());
				Assert.assertEquals(3, fichier.getNbLignes());
				Assert.assertEquals(0, fichier.getNbLignesRejet());
			});
		}
	}

	@Test
	public void codeBanqueDansNomDeFichier() {
		// Act
		String nomFichier = "NDOD_EVT_DELTA_90109_RCT_190224-170002.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.CF004, fichier.getCodAudit());
			Assert.assertEquals(3, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
		});
	}

	@Test
	public void fichierVide() {
		// Act
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-170003.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.CT003, fichier.getCodAudit());
			Assert.assertEquals(0, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
		});
	}

	@Test
	public void debutLigneEnqueue() {
		// Act
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-170008.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.CT008, fichier.getCodAudit());
			Assert.assertEquals(3, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
		});
	}

	@Test
	public void dateDansLigneEnqueue() {
		// Act
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-170009.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.CT009, fichier.getCodAudit());
			Assert.assertEquals(3, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
		});
	}

	@Test
	public void codeBanqueDansLigneEnqueue() {
		// Act
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-170010.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.CT032, fichier.getCodAudit());
			Assert.assertEquals(3, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
		});
	}

	@Test
	public void codeAppliDansLigneEntete() {
		// Act
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-170007.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.CT029, fichier.getCodAudit());
			Assert.assertEquals(3, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
		});
	}

	@Test
	public void debutLigneEntete() {
		// Act
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-170004.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.CT005, fichier.getCodAudit());
			Assert.assertEquals(3, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
		});
	}

	@Test
	public void dateDansLigneEntete() {
		//save the initial security manager (probably null)
		SecurityManager initialSecurityManger = System.getSecurityManager();

		// Act
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-170005.txt";
		importFile(nomFichier);

		try {
			// set security manager
			System.setSecurityManager(new NoExitSecurityManager());
			// Act
			// Assert
			doInTransaction(() -> {

				AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
				Assert.assertNotNull(fichier);
				Assert.assertEquals(Controles.CT006, fichier.getCodAudit());
				Assert.assertEquals(3, fichier.getNbLignes());
				Assert.assertEquals(0, fichier.getNbLignesRejet());
			});		} catch (ExitException e) {
		} finally {
			// restore initial security manager (otherwise a new ExitException will be thrown when the JVM will actually exit)
			System.setSecurityManager(initialSecurityManger);
		}
	}

	// exception to be thrown by security manager when System.exit is called
	public static class ExitException extends SecurityException {
		private static final long serialVersionUID = 1L;
		public final long status;

		public ExitException(long status) {
			this.status = status;
		}
	}

	// custom security manager
	public static class NoExitSecurityManager extends SecurityManager {
		@Override
		public void checkPermission(Permission perm) {
		}

		@Override
		public void checkPermission(Permission perm, Object context) {
		}

		@Override
		public void checkExit(int status) {
			super.checkExit(status);
			throw new ExitException(status);
		}
	}
	
	@Test
	public void codeBanqueDansLigneEntete() {
		// Act
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-170006.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.CT031, fichier.getCodAudit());
			Assert.assertEquals(3, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
		});
	}

	@Test
	public void codeAppliDansLigneEnqueue() {
		// Act
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-170011.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.CT029, fichier.getCodAudit());
			Assert.assertEquals(3, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
		});
	}

	@Test
	public void formatNbLignesDansLigneEnqueue() {
		// Act
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-170012.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.CT011, fichier.getCodAudit());
			Assert.assertEquals(3, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
		});
	}

	@Test
	public void nbLignesDansLigneEnqueue() {
		// Act
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-170013.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.CT012, fichier.getCodAudit());
			Assert.assertEquals(3, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
		});
	}
}

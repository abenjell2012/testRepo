package fr.bpce.yyd.batch.ti;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.batch.core.BatchStatus;

import fr.bpce.yyd.commun.enums.Controles;
import fr.bpce.yyd.commun.model.AuditFichiers;

public class TestsPremiersFichiersIBP extends AbstractIntegrationTest {

	@Test
	public void fichierAvecEnteteTropLongue() {
		// Act
		String nomFichier = "NDOD_EVT_DELTA_10807_RCT_190312-193001.txt";
		BatchStatus status = importFile(nomFichier);

		Assert.assertEquals(BatchStatus.FAILED, status);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.CT039, fichier.getCodAudit());
		});
	}

	@Test
	public void fichierAvecEnqueueTropLongue() {
		// Act
		String nomFichier = "NDOD_EVT_DELTA_10807_RCT_190312-193002.txt";
		BatchStatus status = importFile(nomFichier);

		Assert.assertEquals(BatchStatus.FAILED, status);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.CT040, fichier.getCodAudit());
		});
	}
}

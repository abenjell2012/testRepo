package bpce.yyd.batch.declencheur.ti;

import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.commun.utils.AbstractTestIntegration;
import fr.bpce.yyd.commun.enums.StatutEvenement;
import fr.bpce.yyd.commun.enums.StatutTiers;
import fr.bpce.yyd.commun.model.*;
import fr.bpce.yyd.commun.model.restitution.*;
import fr.bpce.yyd.commun.model.reference.ParGravite;
import org.junit.After;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;

import javax.persistence.TypedQuery;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class DeclencheurChangementPallierTest extends AbstractTestIntegration {


	@Test
	public void testDeclencheurChangementPallier() throws Exception{

		// ARRANGE
		initData();
		// ACT
		lauchBatchDeclencheur("20150110");
		// VERIFY
		TypedQuery<Declencheur> q = getEntityManager().createQuery(
				" SELECT d from Declencheur d where d.dateDeclencheur = :dateDec order by idLocal ", Declencheur.class);
		q.setParameter("dateDec", Date.valueOf(LocalDate.of(2015, 1, 10)));
		List<Declencheur> results = q.getResultList();
		assertNotNull(results);
		assertEquals(1L, results.size());
		assertEquals("STCL", results.get(0).getMotifDeclencheur()); // PLEF dans l'ancienne version


	}

	private static void initData() {

		doInTransaction(() -> {

			ParGravite parMdcGraviteCX = new ParGravite();
			parMdcGraviteCX.setGravite("CX");
			parMdcGraviteCX.setOrdre(1);
			getEntityManager().persist(parMdcGraviteCX);

			ParGravite parMdcGraviteDX = new ParGravite();
			parMdcGraviteDX.setGravite("DX");
			parMdcGraviteDX.setOrdre(2);
			getEntityManager().persist(parMdcGraviteDX);

			ParGravite parMdcGraviteRX = new ParGravite();
			parMdcGraviteRX.setGravite("RX");
			parMdcGraviteRX.setOrdre(3);
			getEntityManager().persist(parMdcGraviteRX);

			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeSegment("1010");
			id.setCodeBanque("10107");
			id.setIdLocal("ID-TIERS-LOCAL-0009");
			id.setDateDebut(LocalDate.of(2015, 1, 1));
			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			AuditFichiers auditFichiers = new AuditFichiers();
			getEntityManager().persist(auditFichiers);

			StatutHistorise statusTiersDx = new StatutHistorise();
			statusTiersDx.setStatut(StatutTiers.DEFAUT);
			statusTiersDx.setGravite("DX");
			statusTiersDx.setAnnule(Boolean.FALSE);
			statusTiersDx.setDateDeb(LocalDate.of(2015, 1, 1));
			statusTiersDx.setTiers(tiers);
			getEntityManager().persist(statusTiersDx);

			StatutHistorise statusTiersRX = new StatutHistorise();
			statusTiersRX.setStatut(StatutTiers.DEFAUT);
			statusTiersRX.setGravite("RX");
			statusTiersRX.setAnnule(Boolean.FALSE);
			statusTiersRX.setDateDeb(LocalDate.of(2015, 1, 3));
			statusTiersRX.setTiers(tiers);
			getEntityManager().persist(statusTiersRX);

			StatutHistorise statusTiersCX = new StatutHistorise();
			statusTiersCX.setStatut(StatutTiers.DEFAUT);
			statusTiersCX.setGravite("CX");
			statusTiersCX.setAnnule(Boolean.FALSE);
			statusTiersCX.setDateDeb(LocalDate.of(2015, 1, 5));
			statusTiersCX.setTiers(tiers);
			getEntityManager().persist(statusTiersCX);
			
			RestTiersLocal Local = new RestTiersLocal();
			Local.setCodeBanque("10107");
			Local.setIdLocal("ID-TIERS-LOCAL-0009");
			Local.setCodeSegment("1010");
			Local.setDateDebut(LocalDate.of(2015, 1, 3));
			Local.setType("MDC");
			getEntityManager().persist(Local);

			
			RestSynthTierLocalStatus Status = new RestSynthTierLocalStatus();
			Status.setRestRechTiersLocal(Local);
			Status.setStatutEffectif("D");
			Status.setDatePhoto(LocalDate.of(2015, 1, 3));
			Status.setPalierEffectif("RX");
			getEntityManager().persist(Status);
		});
	}


	private JobExecution lauchBatchDeclencheur(String dateLaunch) throws Exception {

		Job job = (Job) context.getBean(Constant.JOB_DECLENCHEUR);
		JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");
		Long guid = java.util.UUID.randomUUID().getMostSignificantBits();
		JobParameters jobParameters = new JobParametersBuilder().addString("date", dateLaunch).addLong("guid", guid)
				.toJobParameters();

		return jobLauncher.run(job, jobParameters);

	}

	@BeforeClass
	public static void initSpringContext() throws NoSuchFieldException, IllegalAccessException, IOException {
		initSpring();
	}

	/**
	 * Vider les tables après chaque test
	 */
	@After
	public void resetData() {
		deleteAllTables();

	}

}

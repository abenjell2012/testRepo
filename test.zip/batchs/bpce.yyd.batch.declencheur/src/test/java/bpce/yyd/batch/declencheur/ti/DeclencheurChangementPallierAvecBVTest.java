package bpce.yyd.batch.declencheur.ti;

import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.commun.utils.AbstractTestIntegration;
import fr.bpce.yyd.commun.enums.StatutTiers;
import fr.bpce.yyd.commun.model.*;
import fr.bpce.yyd.commun.model.reference.ParGravite;
import fr.bpce.yyd.commun.model.restitution.RestSynthTierLocalStatus;
import fr.bpce.yyd.commun.model.restitution.RestTiersLocal;
import org.junit.After;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;

import javax.persistence.TypedQuery;
import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class DeclencheurChangementPallierAvecBVTest extends AbstractTestIntegration {


	@Test
	public void testCxACx() throws Exception{

		// ARRANGE
		doInTransaction(() -> {

			ParGravite parMdcGraviteCX = new ParGravite();
			parMdcGraviteCX.setGravite("CX");
			parMdcGraviteCX.setOrdre(1);
			getEntityManager().persist(parMdcGraviteCX);

			ParGravite parMdcGraviteDX = new ParGravite();
			parMdcGraviteDX.setGravite("DX");
			parMdcGraviteDX.setOrdre(2);
			getEntityManager().persist(parMdcGraviteDX);

			ParGravite parMdcGraviteRX = new ParGravite();
			parMdcGraviteRX.setGravite("RX");
			parMdcGraviteRX.setOrdre(3);
			getEntityManager().persist(parMdcGraviteRX);

			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("IDLOC1");
			id.setDateDebut(LocalDate.of(2015, 1, 1));
			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			RestTiersLocal restTiersLocal = new RestTiersLocal();
			restTiersLocal.setIdLocal("IDLOC1");
			restTiersLocal.setCodeBanque("10107");
			restTiersLocal.setDateDebut(LocalDate.of(2015, 1, 1));
			getEntityManager().persist(restTiersLocal);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(restTiersLocal);
			photoTiers.setDatePhoto(LocalDate.of(2015, 1, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("D");
			photoTiers.setPalierEffectif("CX");
			photoTiers.setStatutCalcule("D");
			photoTiers.setPalierCalcule("CX");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);


			StatutHistorise statusTiersCX1 = new StatutHistorise();
			statusTiersCX1.setStatut(StatutTiers.DEFAUT);
			statusTiersCX1.setGravite("CX");
			statusTiersCX1.setAnnule(false);
			statusTiersCX1.setDateDeb(LocalDate.of(2015, 1, 1));
			statusTiersCX1.setTiers(tiers);
			getEntityManager().persist(statusTiersCX1);

			StatutSbv statutForceDefaut = new StatutSbv();
			statutForceDefaut.setStatutForce("D");
			statutForceDefaut.setGravite("CX");
			statutForceDefaut.setDateDebut(LocalDate.of(2015, 1, 2));
			statutForceDefaut.setIdLocal("IDLOC1");
			statutForceDefaut.setCodeBanque("10107");
			statutForceDefaut.setCommentaire("Forcage defaut BV");
			getEntityManager().persist(statutForceDefaut);


		});


		// ACT
		lauchBatchDeclencheur("20150105");
		// VERIFY
		TypedQuery<Declencheur> q = getEntityManager().createQuery(
				" SELECT d from Declencheur d where d.dateDeclencheur = :dateDec order by idLocal ", Declencheur.class);
		q.setParameter("dateDec", Date.valueOf(LocalDate.of(2015, 1, 5)));
		List<Declencheur> results = q.getResultList();
		assertNotNull(results);
		assertEquals(1L, results.size());
		assertEquals("STEF", results.get(0).getMotifDeclencheur());

	}

	@Test
	public void testCxADx() throws Exception{


		// ARRANGE
		doInTransaction(() -> {

			ParGravite parMdcGraviteCX = new ParGravite();
			parMdcGraviteCX.setGravite("CX");
			parMdcGraviteCX.setOrdre(1);
			getEntityManager().persist(parMdcGraviteCX);

			ParGravite parMdcGraviteDX = new ParGravite();
			parMdcGraviteDX.setGravite("DX");
			parMdcGraviteDX.setOrdre(2);
			getEntityManager().persist(parMdcGraviteDX);

			ParGravite parMdcGraviteRX = new ParGravite();
			parMdcGraviteRX.setGravite("RX");
			parMdcGraviteRX.setOrdre(3);
			getEntityManager().persist(parMdcGraviteRX);

			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("IDLOC1");
			id.setDateDebut(LocalDate.of(2015, 1, 1));
			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			RestTiersLocal restTiersLocal = new RestTiersLocal();
			restTiersLocal.setIdLocal("IDLOC1");
			restTiersLocal.setCodeBanque("10107");
			restTiersLocal.setDateDebut(LocalDate.of(2015, 1, 1));
			getEntityManager().persist(restTiersLocal);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(restTiersLocal);
			photoTiers.setDatePhoto(LocalDate.of(2015, 1, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("D");
			photoTiers.setPalierEffectif("CX");
			photoTiers.setStatutCalcule("D");
			photoTiers.setPalierCalcule("CX");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);



			StatutHistorise statusTiersCX = new StatutHistorise();
			statusTiersCX.setStatut(StatutTiers.DEFAUT);
			statusTiersCX.setGravite("CX");
			statusTiersCX.setAnnule(false);
			statusTiersCX.setDateDeb(LocalDate.of(2015, 1, 1));
			statusTiersCX.setTiers(tiers);
			getEntityManager().persist(statusTiersCX);

			StatutSbv statutForceDefaut = new StatutSbv();
			statutForceDefaut.setStatutForce("D");
			statutForceDefaut.setGravite("DX");
			statutForceDefaut.setDateDebut(LocalDate.of(2015, 1, 2));
			statutForceDefaut.setIdLocal("IDLOC1");
			statutForceDefaut.setCodeBanque("10107");
			statutForceDefaut.setCommentaire("Forcage defaut BV");
			getEntityManager().persist(statutForceDefaut);
		});


		// ACT
		lauchBatchDeclencheur("20150104");
		// VERIFY
		TypedQuery<Declencheur> q = getEntityManager().createQuery(
				" SELECT d from Declencheur d where d.dateDeclencheur = :dateDec order by idLocal ", Declencheur.class);
		q.setParameter("dateDec", Date.valueOf(LocalDate.of(2015, 1, 4)));
		List<Declencheur> results = q.getResultList();
		assertNotNull(results);
		assertEquals(1L, results.size());
		assertEquals("STEF", results.get(0).getMotifDeclencheur());

	}

	@Test
	public void testCxARx() throws Exception{

		// ARRANGE
		doInTransaction(() -> {

			ParGravite parMdcGraviteCX = new ParGravite();
			parMdcGraviteCX.setGravite("CX");
			parMdcGraviteCX.setOrdre(1);
			getEntityManager().persist(parMdcGraviteCX);

			ParGravite parMdcGraviteDX = new ParGravite();
			parMdcGraviteDX.setGravite("DX");
			parMdcGraviteDX.setOrdre(2);
			getEntityManager().persist(parMdcGraviteDX);

			ParGravite parMdcGraviteRX = new ParGravite();
			parMdcGraviteRX.setGravite("RX");
			parMdcGraviteRX.setOrdre(3);
			getEntityManager().persist(parMdcGraviteRX);

			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("IDLOC1");
			id.setDateDebut(LocalDate.of(2015, 1, 1));
			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			RestTiersLocal restTiersLocal = new RestTiersLocal();
			restTiersLocal.setIdLocal("IDLOC1");
			restTiersLocal.setCodeBanque("10107");
			restTiersLocal.setDateDebut(LocalDate.of(2015, 1, 1));
			getEntityManager().persist(restTiersLocal);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(restTiersLocal);
			photoTiers.setDatePhoto(LocalDate.of(2015, 1, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("D");
			photoTiers.setPalierEffectif("CX");
			photoTiers.setStatutCalcule("D");
			photoTiers.setPalierCalcule("CX");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);

			StatutHistorise statusTiersCX = new StatutHistorise();
			statusTiersCX.setStatut(StatutTiers.DEFAUT);
			statusTiersCX.setGravite("CX");
			statusTiersCX.setAnnule(false);
			statusTiersCX.setDateDeb(LocalDate.of(2015, 1, 1));
			statusTiersCX.setTiers(tiers);
			getEntityManager().persist(statusTiersCX);

			StatutSbv statutForceDefaut = new StatutSbv();
			statutForceDefaut.setStatutForce("D");
			statutForceDefaut.setGravite("RX");
			statutForceDefaut.setDateDebut(LocalDate.of(2015, 1, 2));
			statutForceDefaut.setIdLocal("IDLOC1");
			statutForceDefaut.setCodeBanque("10107");
			statutForceDefaut.setCommentaire("Forcage defaut BV");
			getEntityManager().persist(statutForceDefaut);
		});


		// ACT
		lauchBatchDeclencheur("20150104");
		// VERIFY
		TypedQuery<Declencheur> q = getEntityManager().createQuery(
				" SELECT d from Declencheur d where d.dateDeclencheur = :dateDec order by idLocal ", Declencheur.class);
		q.setParameter("dateDec", Date.valueOf(LocalDate.of(2015, 1, 4)));
		List<Declencheur> results = q.getResultList();
		assertNotNull(results);
		assertEquals(1L, results.size());
		assertEquals("STEF", results.get(0).getMotifDeclencheur());

	}

	@Test
	public void testDxACx() throws Exception{

		// ARRANGE
		doInTransaction(() -> {

			ParGravite parMdcGraviteCX = new ParGravite();
			parMdcGraviteCX.setGravite("CX");
			parMdcGraviteCX.setOrdre(1);
			getEntityManager().persist(parMdcGraviteCX);

			ParGravite parMdcGraviteDX = new ParGravite();
			parMdcGraviteDX.setGravite("DX");
			parMdcGraviteDX.setOrdre(2);
			getEntityManager().persist(parMdcGraviteDX);

			ParGravite parMdcGraviteRX = new ParGravite();
			parMdcGraviteRX.setGravite("RX");
			parMdcGraviteRX.setOrdre(3);
			getEntityManager().persist(parMdcGraviteRX);

			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("IDLOC1");
			id.setDateDebut(LocalDate.of(2015, 1, 1));
			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			RestTiersLocal restTiersLocal = new RestTiersLocal();
			restTiersLocal.setIdLocal("IDLOC1");
			restTiersLocal.setCodeBanque("10107");
			restTiersLocal.setDateDebut(LocalDate.of(2015, 1, 1));
			getEntityManager().persist(restTiersLocal);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(restTiersLocal);
			photoTiers.setDatePhoto(LocalDate.of(2015, 1, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("D");
			photoTiers.setPalierEffectif("DX");
			photoTiers.setStatutCalcule("D");
			photoTiers.setPalierCalcule("DX");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);


			StatutHistorise statusTiersDX = new StatutHistorise();
			statusTiersDX.setStatut(StatutTiers.DEFAUT);
			statusTiersDX.setGravite("DX");
			statusTiersDX.setAnnule(false);
			statusTiersDX.setDateDeb(LocalDate.of(2015, 1, 1));
			statusTiersDX.setTiers(tiers);
			getEntityManager().persist(statusTiersDX);

			StatutSbv statutForceDefaut = new StatutSbv();
			statutForceDefaut.setStatutForce("D");
			statutForceDefaut.setGravite("CX");
			statutForceDefaut.setDateDebut(LocalDate.of(2015, 1, 2));
			statutForceDefaut.setIdLocal("IDLOC1");
			statutForceDefaut.setCodeBanque("10107");
			statutForceDefaut.setCommentaire("Forcage defaut BV");
			getEntityManager().persist(statutForceDefaut);
		});


		// ACT
		lauchBatchDeclencheur("20150104");
		// VERIFY
		TypedQuery<Declencheur> q = getEntityManager().createQuery(
				" SELECT d from Declencheur d where d.dateDeclencheur = :dateDec order by idLocal ", Declencheur.class);
		q.setParameter("dateDec", Date.valueOf(LocalDate.of(2015, 1, 4)));
		List<Declencheur> results = q.getResultList();
		assertNotNull(results);
		assertEquals(1L, results.size());
		assertEquals("STEF", results.get(0).getMotifDeclencheur());

	}

	@Test
	public void testDxADx() throws Exception{

		// ARRANGE
		doInTransaction(() -> {

			ParGravite parMdcGraviteCX = new ParGravite();
			parMdcGraviteCX.setGravite("CX");
			parMdcGraviteCX.setOrdre(1);
			getEntityManager().persist(parMdcGraviteCX);

			ParGravite parMdcGraviteDX = new ParGravite();
			parMdcGraviteDX.setGravite("DX");
			parMdcGraviteDX.setOrdre(2);
			getEntityManager().persist(parMdcGraviteDX);

			ParGravite parMdcGraviteRX = new ParGravite();
			parMdcGraviteRX.setGravite("RX");
			parMdcGraviteRX.setOrdre(3);
			getEntityManager().persist(parMdcGraviteRX);

			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("IDLOC1");
			id.setDateDebut(LocalDate.of(2015, 1, 1));
			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			RestTiersLocal restTiersLocal = new RestTiersLocal();
			restTiersLocal.setIdLocal("IDLOC1");
			restTiersLocal.setCodeBanque("10107");
			restTiersLocal.setDateDebut(LocalDate.of(2015, 1, 1));
			getEntityManager().persist(restTiersLocal);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(restTiersLocal);
			photoTiers.setDatePhoto(LocalDate.of(2015, 1, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("D");
			photoTiers.setPalierEffectif("DX");
			photoTiers.setStatutCalcule("D");
			photoTiers.setPalierCalcule("DX");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);


			StatutHistorise statusTiersDX = new StatutHistorise();
			statusTiersDX.setStatut(StatutTiers.DEFAUT);
			statusTiersDX.setGravite("DX");
			statusTiersDX.setAnnule(false);
			statusTiersDX.setDateDeb(LocalDate.of(2015, 1, 1));
			statusTiersDX.setTiers(tiers);
			getEntityManager().persist(statusTiersDX);

			StatutSbv statutForceDefaut = new StatutSbv();
			statutForceDefaut.setStatutForce("D");
			statutForceDefaut.setGravite("DX");
			statutForceDefaut.setDateDebut(LocalDate.of(2015, 1, 2));
			statutForceDefaut.setIdLocal("IDLOC1");
			statutForceDefaut.setCodeBanque("10107");
			statutForceDefaut.setCommentaire("Forcage defaut BV");
			getEntityManager().persist(statutForceDefaut);
		});


		// ACT
		lauchBatchDeclencheur("20150104");
		// VERIFY
		TypedQuery<Declencheur> q = getEntityManager().createQuery(
				" SELECT d from Declencheur d where d.dateDeclencheur = :dateDec order by idLocal ", Declencheur.class);
		q.setParameter("dateDec", Date.valueOf(LocalDate.of(2015, 1, 4)));
		List<Declencheur> results = q.getResultList();
		assertNotNull(results);
		assertEquals(1L, results.size());
		assertEquals("STEF", results.get(0).getMotifDeclencheur());

	}

	@Test
	public void testDxARx() throws Exception{

		// ARRANGE
		doInTransaction(() -> {

			ParGravite parMdcGraviteCX = new ParGravite();
			parMdcGraviteCX.setGravite("CX");
			parMdcGraviteCX.setOrdre(1);
			getEntityManager().persist(parMdcGraviteCX);

			ParGravite parMdcGraviteDX = new ParGravite();
			parMdcGraviteDX.setGravite("DX");
			parMdcGraviteDX.setOrdre(2);
			getEntityManager().persist(parMdcGraviteDX);

			ParGravite parMdcGraviteRX = new ParGravite();
			parMdcGraviteRX.setGravite("RX");
			parMdcGraviteRX.setOrdre(3);
			getEntityManager().persist(parMdcGraviteRX);

			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("IDLOC1");
			id.setDateDebut(LocalDate.of(2015, 1, 1));
			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			RestTiersLocal restTiersLocal = new RestTiersLocal();
			restTiersLocal.setIdLocal("IDLOC1");
			restTiersLocal.setCodeBanque("10107");
			restTiersLocal.setDateDebut(LocalDate.of(2015, 1, 1));
			getEntityManager().persist(restTiersLocal);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(restTiersLocal);
			photoTiers.setDatePhoto(LocalDate.of(2015, 1, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("D");
			photoTiers.setPalierEffectif("DX");
			photoTiers.setStatutCalcule("D");
			photoTiers.setPalierCalcule("DX");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);

			StatutHistorise statusTiersDX = new StatutHistorise();
			statusTiersDX.setStatut(StatutTiers.DEFAUT);
			statusTiersDX.setGravite("DX");
			statusTiersDX.setAnnule(false);
			statusTiersDX.setDateDeb(LocalDate.of(2015, 1, 1));
			statusTiersDX.setDateFin(LocalDate.of(2015, 1, 2));
			statusTiersDX.setTiers(tiers);
			getEntityManager().persist(statusTiersDX);

			StatutSbv statutForceDefaut = new StatutSbv();
			statutForceDefaut.setStatutForce("D");
			statutForceDefaut.setGravite("RX");
			statutForceDefaut.setDateDebut(LocalDate.of(2015, 1, 2));
			statutForceDefaut.setIdLocal("IDLOC1");
			statutForceDefaut.setCodeBanque("10107");
			statutForceDefaut.setCommentaire("Forcage defaut BV");
			getEntityManager().persist(statutForceDefaut);
		});


		// ACT
		lauchBatchDeclencheur("20150104");
		// VERIFY
		TypedQuery<Declencheur> q = getEntityManager().createQuery(
				" SELECT d from Declencheur d where d.dateDeclencheur = :dateDec order by idLocal ", Declencheur.class);
		q.setParameter("dateDec", Date.valueOf(LocalDate.of(2015, 1, 4)));
		List<Declencheur> results = q.getResultList();
		assertNotNull(results);
		assertEquals(1L, results.size());
		assertEquals("STCL", results.get(0).getMotifDeclencheur());

	}

	@Test
	public void testRxACx() throws Exception{

		// ARRANGE
		doInTransaction(() -> {

			ParGravite parMdcGraviteCX = new ParGravite();
			parMdcGraviteCX.setGravite("CX");
			parMdcGraviteCX.setOrdre(1);
			getEntityManager().persist(parMdcGraviteCX);

			ParGravite parMdcGraviteDX = new ParGravite();
			parMdcGraviteDX.setGravite("DX");
			parMdcGraviteDX.setOrdre(2);
			getEntityManager().persist(parMdcGraviteDX);

			ParGravite parMdcGraviteRX = new ParGravite();
			parMdcGraviteRX.setGravite("RX");
			parMdcGraviteRX.setOrdre(3);
			getEntityManager().persist(parMdcGraviteRX);

			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("IDLOC1");
			id.setDateDebut(LocalDate.of(2015, 1, 1));
			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			RestTiersLocal restTiersLocal = new RestTiersLocal();
			restTiersLocal.setIdLocal("IDLOC1");
			restTiersLocal.setCodeBanque("10107");
			restTiersLocal.setDateDebut(LocalDate.of(2015, 1, 1));
			getEntityManager().persist(restTiersLocal);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(restTiersLocal);
			photoTiers.setDatePhoto(LocalDate.of(2015, 1, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("D");
			photoTiers.setPalierEffectif("RX");
			photoTiers.setStatutCalcule("D");
			photoTiers.setPalierCalcule("RX");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);

			StatutHistorise statusTiersRX = new StatutHistorise();
			statusTiersRX.setStatut(StatutTiers.DEFAUT);
			statusTiersRX.setGravite("RX");
			statusTiersRX.setAnnule(false);
			statusTiersRX.setDateDeb(LocalDate.of(2015, 1, 1));
			statusTiersRX.setTiers(tiers);
			getEntityManager().persist(statusTiersRX);

			StatutSbv statutForceDefaut = new StatutSbv();
			statutForceDefaut.setStatutForce("D");
			statutForceDefaut.setGravite("CX");
			statutForceDefaut.setDateDebut(LocalDate.of(2015, 1, 2));
			statutForceDefaut.setIdLocal("IDLOC1");
			statutForceDefaut.setCodeBanque("10107");
			statutForceDefaut.setCommentaire("Forcage defaut BV");
			getEntityManager().persist(statutForceDefaut);
		});


		// ACT
		lauchBatchDeclencheur("20150104");
		// VERIFY
		TypedQuery<Declencheur> q = getEntityManager().createQuery(
				" SELECT d from Declencheur d where d.dateDeclencheur = :dateDec order by idLocal ", Declencheur.class);
		q.setParameter("dateDec", Date.valueOf(LocalDate.of(2015, 1, 4)));
		List<Declencheur> results = q.getResultList();
		assertNotNull(results);
		assertEquals(1L, results.size());
		assertEquals("STEF", results.get(0).getMotifDeclencheur());

	}

	@Test
	public void testRxADx() throws Exception{

		// ARRANGE
		doInTransaction(() -> {

			ParGravite parMdcGraviteCX = new ParGravite();
			parMdcGraviteCX.setGravite("CX");
			parMdcGraviteCX.setOrdre(1);
			getEntityManager().persist(parMdcGraviteCX);

			ParGravite parMdcGraviteDX = new ParGravite();
			parMdcGraviteDX.setGravite("DX");
			parMdcGraviteDX.setOrdre(2);
			getEntityManager().persist(parMdcGraviteDX);

			ParGravite parMdcGraviteRX = new ParGravite();
			parMdcGraviteRX.setGravite("RX");
			parMdcGraviteRX.setOrdre(3);
			getEntityManager().persist(parMdcGraviteRX);

			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("IDLOC1");
			id.setDateDebut(LocalDate.of(2015, 1, 1));
			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			RestTiersLocal restTiersLocal = new RestTiersLocal();
			restTiersLocal.setIdLocal("IDLOC1");
			restTiersLocal.setCodeBanque("10107");
			restTiersLocal.setDateDebut(LocalDate.of(2015, 1, 1));
			getEntityManager().persist(restTiersLocal);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(restTiersLocal);
			photoTiers.setDatePhoto(LocalDate.of(2015, 1, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("D");
			photoTiers.setPalierEffectif("RX");
			photoTiers.setStatutCalcule("D");
			photoTiers.setPalierCalcule("RX");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);

			StatutHistorise statusTiersRX = new StatutHistorise();
			statusTiersRX.setStatut(StatutTiers.DEFAUT);
			statusTiersRX.setGravite("RX");
			statusTiersRX.setAnnule(false);
			statusTiersRX.setDateDeb(LocalDate.of(2015, 1, 1));
			statusTiersRX.setTiers(tiers);
			getEntityManager().persist(statusTiersRX);

			StatutSbv statutForceDefaut = new StatutSbv();
			statutForceDefaut.setStatutForce("D");
			statutForceDefaut.setGravite("DX");
			statutForceDefaut.setDateDebut(LocalDate.of(2015, 1, 2));
			statutForceDefaut.setIdLocal("IDLOC1");
			statutForceDefaut.setCodeBanque("10107");
			statutForceDefaut.setCommentaire("Forcage defaut BV");
			getEntityManager().persist(statutForceDefaut);
		});


		// ACT
		lauchBatchDeclencheur("20150104");
		// VERIFY
		TypedQuery<Declencheur> q = getEntityManager().createQuery(
				" SELECT d from Declencheur d where d.dateDeclencheur = :dateDec order by idLocal ", Declencheur.class);
		q.setParameter("dateDec", Date.valueOf(LocalDate.of(2015, 1, 4)));
		List<Declencheur> results = q.getResultList();
		assertNotNull(results);
		assertEquals(1L, results.size());
		assertEquals("STEF", results.get(0).getMotifDeclencheur());

	}

	@Test
	public void testRxARx() throws Exception{

		// ARRANGE
		doInTransaction(() -> {

			ParGravite parMdcGraviteCX = new ParGravite();
			parMdcGraviteCX.setGravite("CX");
			parMdcGraviteCX.setOrdre(1);
			getEntityManager().persist(parMdcGraviteCX);

			ParGravite parMdcGraviteDX = new ParGravite();
			parMdcGraviteDX.setGravite("DX");
			parMdcGraviteDX.setOrdre(2);
			getEntityManager().persist(parMdcGraviteDX);

			ParGravite parMdcGraviteRX = new ParGravite();
			parMdcGraviteRX.setGravite("RX");
			parMdcGraviteRX.setOrdre(3);
			getEntityManager().persist(parMdcGraviteRX);

			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("IDLOC1");
			id.setDateDebut(LocalDate.of(2015, 1, 1));
			tiers.addIdentite(id);
			getEntityManager().persist(tiers);


			RestTiersLocal restTiersLocal = new RestTiersLocal();
			restTiersLocal.setIdLocal("IDLOC1");
			restTiersLocal.setCodeBanque("10107");
			restTiersLocal.setDateDebut(LocalDate.of(2015, 1, 1));
			getEntityManager().persist(restTiersLocal);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(restTiersLocal);
			photoTiers.setDatePhoto(LocalDate.of(2015, 1, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("D");
			photoTiers.setPalierEffectif("RX");
			photoTiers.setStatutCalcule("D");
			photoTiers.setPalierCalcule("RX");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);

			StatutHistorise statusTiersRX = new StatutHistorise();
			statusTiersRX.setStatut(StatutTiers.DEFAUT);
			statusTiersRX.setGravite("RX");
			statusTiersRX.setAnnule(false);
			statusTiersRX.setDateDeb(LocalDate.of(2015, 1, 1));
			statusTiersRX.setTiers(tiers);
			getEntityManager().persist(statusTiersRX);

			StatutSbv statutForceDefaut = new StatutSbv();
			statutForceDefaut.setStatutForce("D");
			statutForceDefaut.setGravite("RX");
			statutForceDefaut.setDateDebut(LocalDate.of(2015, 1, 2));
			statutForceDefaut.setIdLocal("IDLOC1");
			statutForceDefaut.setCodeBanque("10107");
			statutForceDefaut.setCommentaire("Forcage defaut BV");
			getEntityManager().persist(statutForceDefaut);
		});


		// ACT
		lauchBatchDeclencheur("20150104");
		// VERIFY
		TypedQuery<Declencheur> q = getEntityManager().createQuery(
				" SELECT d from Declencheur d where d.dateDeclencheur = :dateDec order by idLocal ", Declencheur.class);
		q.setParameter("dateDec", Date.valueOf(LocalDate.of(2015, 1, 4)));
		List<Declencheur> results = q.getResultList();
		assertNotNull(results);
		assertEquals(1L, results.size());
		assertEquals("STEF", results.get(0).getMotifDeclencheur());

	}

	private JobExecution lauchBatchDeclencheur(String dateLaunch) throws Exception {

		Job job = (Job) context.getBean(Constant.JOB_DECLENCHEUR);
		JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");
		Long guid = java.util.UUID.randomUUID().getMostSignificantBits();
		JobParameters jobParameters = new JobParametersBuilder().addString("date", dateLaunch).addLong("guid", guid)
				.toJobParameters();

		return jobLauncher.run(job, jobParameters);

	}

	@BeforeClass
	public static void initSpringContext() throws NoSuchFieldException, IllegalAccessException, IOException {
		initSpring();
	}

	/**
	 * Vider les tables après chaque test
	 */
	@After
	public void resetData() {
		deleteAllTables();

	}

}

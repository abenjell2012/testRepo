package bpce.yyd.batch.declencheur.ti;

import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.commun.utils.AbstractTestIntegration;
import fr.bpce.yyd.commun.enums.EvenementArriereSignificatif;
import fr.bpce.yyd.commun.model.*;
import org.junit.After;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;

import javax.persistence.TypedQuery;
import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class DeclencheurPALASTest extends AbstractTestIntegration {


	@Test
	public void testDeclencheurPALAS() throws Exception{

		// ARRANGE
		initData();
		// ACT
		lauchBatchDeclencheur("20150104");
		// VERIFY
		TypedQuery<Declencheur> q = getEntityManager().createQuery(
				" SELECT d from Declencheur d where d.dateDeclencheur = :dateDec order by idLocal ", Declencheur.class);
		q.setParameter("dateDec", Date.valueOf(LocalDate.of(2015, 1, 4)));
		List<Declencheur> results = q.getResultList();
		assertNotNull(results);
		assertEquals(1L, results.size());
		assertEquals("TOPAS", results.get(0).getMotifDeclencheur()); // PALAS dans l'ancienne version

	}

	private static void initData() {

		doInTransaction(() -> {

			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("IDLOC1");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.of(2015, 1, 1));
			id.setDateFin(null);

			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			ElementsDeCalcul edcAR0 = new ElementsDeCalcul();
			edcAR0.setTiers(tiers);
			getEntityManager().persist(edcAR0);

			ComplementArriere complAR0= new ComplementArriere();
			complAR0.setEntree(edcAR0);
			complAR0.setDernierEvenementEnvoye(EvenementArriereSignificatif.AR0);

			ArriereSignificatif ar0 = new ArriereSignificatif();
			ar0.setTiers(tiers);
			ar0.setDateDebut(LocalDate.of(2015, 1, 1));
			ar0.setDateFin(LocalDate.of(2015, 1, 2));
			ar0.setComplement(complAR0);

			getEntityManager().persist(ar0);

			ElementsDeCalcul edcAR1 = new ElementsDeCalcul();
			edcAR1.setTiers(tiers);
			getEntityManager().persist(edcAR1);

			ComplementArriere complAR1 = new ComplementArriere();
			complAR1.setEntree(edcAR1);
			complAR1.setDernierEvenementEnvoye(EvenementArriereSignificatif.AR1);

			ArriereSignificatif ar1 = new ArriereSignificatif();
			ar1.setTiers(tiers);
			ar1.setDateDebut(LocalDate.of(2015, 1, 3));
			ar1.setComplement(complAR1);

			getEntityManager().persist(ar1);


		});
	}


	private JobExecution lauchBatchDeclencheur(String dateLaunch) throws Exception {

		Job job = (Job) context.getBean(Constant.JOB_DECLENCHEUR);
		JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");
		Long guid = java.util.UUID.randomUUID().getMostSignificantBits();
		JobParameters jobParameters = new JobParametersBuilder().addString("date", dateLaunch).addLong("guid", guid)
				.toJobParameters();

		return jobLauncher.run(job, jobParameters);

	}

	@BeforeClass
	public static void initSpringContext() throws NoSuchFieldException, IllegalAccessException, IOException {
		initSpring();
	}

	/**
	 * Vider les tables après chaque test
	 */
	@After
	public void resetData() {
		deleteAllTables();

	}

}

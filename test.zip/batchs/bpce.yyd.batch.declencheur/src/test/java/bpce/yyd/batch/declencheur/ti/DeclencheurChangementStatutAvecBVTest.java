package bpce.yyd.batch.declencheur.ti;

import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.commun.utils.AbstractTestIntegration;
import fr.bpce.yyd.commun.enums.StatutTiers;
import fr.bpce.yyd.commun.model.*;
import fr.bpce.yyd.commun.model.reference.ParGravite;
import fr.bpce.yyd.commun.model.restitution.RestSynthTierLocalStatus;
import fr.bpce.yyd.commun.model.restitution.RestTiersLocal;
import org.junit.After;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;

import javax.persistence.TypedQuery;
import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class DeclencheurChangementStatutAvecBVTest extends AbstractTestIntegration {


	@Test
	public void testCXaSain() throws Exception{

		// ARRANGE
		doInTransaction(() -> {

			ParGravite parMdcGraviteCX = new ParGravite();
			parMdcGraviteCX.setGravite("CX");
			parMdcGraviteCX.setOrdre(1);
			getEntityManager().persist(parMdcGraviteCX);

			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("IDLOC1");
			id.setDateDebut(LocalDate.of(2015, 1, 1));
			id.setDateFin(null);

			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			RestTiersLocal restTiersLocal = new RestTiersLocal();
			restTiersLocal.setIdLocal("IDLOC1");
			restTiersLocal.setCodeBanque("10107");
			restTiersLocal.setDateDebut(LocalDate.of(2015, 1, 1));
			getEntityManager().persist(restTiersLocal);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(restTiersLocal);
			photoTiers.setDatePhoto(LocalDate.of(2015, 1, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("D");
			photoTiers.setPalierEffectif("CX");
			photoTiers.setStatutCalcule("D");
			photoTiers.setPalierCalcule("CX");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);

			StatutHistorise statusTiersCX = new StatutHistorise();
			statusTiersCX.setStatut(StatutTiers.DEFAUT);
			statusTiersCX.setGravite("CX");
			statusTiersCX.setAnnule(Boolean.FALSE);
			statusTiersCX.setDateDeb(LocalDate.of(2015, 1, 1));
			statusTiersCX.setTiers(tiers);
			getEntityManager().persist(statusTiersCX);

			StatutSbv statutForceSain = new StatutSbv();
			statutForceSain.setStatutForce("ND");
			statutForceSain.setDateDebut(LocalDate.of(2015, 1, 2));
			statutForceSain.setIdLocal("IDLOC1");
			statutForceSain.setCodeBanque("10107");
			statutForceSain.setCommentaire("Forcage Sain BV");
			getEntityManager().persist(statutForceSain);

		});
		// ACT
		lauchBatchDeclencheur("20150110");
		// VERIFY
		TypedQuery<Declencheur> q = getEntityManager().createQuery(
				" SELECT d from Declencheur d where d.dateDeclencheur = :dateDec order by idLocal ", Declencheur.class);
		q.setParameter("dateDec", Date.valueOf(LocalDate.of(2015, 1, 10)));
		List<Declencheur> results = q.getResultList();
		assertNotNull(results);
		assertEquals(1L, results.size());
		assertEquals("STEF", results.get(0).getMotifDeclencheur());

	}

	@Test
	public void testDXaSain() throws Exception{

		// ARRANGE
		doInTransaction(() -> {

			ParGravite parMdcGraviteCX = new ParGravite();
			parMdcGraviteCX.setGravite("CX");
			parMdcGraviteCX.setOrdre(1);
			getEntityManager().persist(parMdcGraviteCX);

			ParGravite parMdcGraviteDX = new ParGravite();
			parMdcGraviteDX.setGravite("DX");
			parMdcGraviteDX.setOrdre(2);
			getEntityManager().persist(parMdcGraviteDX);

			ParGravite parMdcGraviteRX = new ParGravite();
			parMdcGraviteRX.setGravite("RX");
			parMdcGraviteRX.setOrdre(3);
			getEntityManager().persist(parMdcGraviteRX);

			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("IDLOC1");
			id.setDateDebut(LocalDate.of(2015, 1, 1));
			id.setDateFin(null);

			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			RestTiersLocal restTiersLocal = new RestTiersLocal();
			restTiersLocal.setIdLocal("IDLOC1");
			restTiersLocal.setCodeBanque("10107");
			restTiersLocal.setDateDebut(LocalDate.of(2015, 1, 1));
			getEntityManager().persist(restTiersLocal);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(restTiersLocal);
			photoTiers.setDatePhoto(LocalDate.of(2015, 1, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("D");
			photoTiers.setPalierEffectif("DX");
			photoTiers.setStatutCalcule("D");
			photoTiers.setPalierCalcule("DX");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);

			StatutHistorise statusTiersDX = new StatutHistorise();
			statusTiersDX.setStatut(StatutTiers.DEFAUT);
			statusTiersDX.setGravite("DX");
			statusTiersDX.setAnnule(Boolean.FALSE);
			statusTiersDX.setDateDeb(LocalDate.of(2015, 1, 1));
			statusTiersDX.setTiers(tiers);
			getEntityManager().persist(statusTiersDX);

			StatutSbv statutForceSain = new StatutSbv();
			statutForceSain.setStatutForce("ND");
			statutForceSain.setDateDebut(LocalDate.of(2015, 1, 2));
			statutForceSain.setIdLocal("IDLOC1");
			statutForceSain.setCodeBanque("10107");
			statutForceSain.setCommentaire("Forcage Sain BV");
			getEntityManager().persist(statutForceSain);

		});
		// ACT
		lauchBatchDeclencheur("20150110");
		// VERIFY
		TypedQuery<Declencheur> q = getEntityManager().createQuery(
				" SELECT d from Declencheur d where d.dateDeclencheur = :dateDec order by idLocal ", Declencheur.class);
		q.setParameter("dateDec", Date.valueOf(LocalDate.of(2015, 1, 10)));
		List<Declencheur> results = q.getResultList();
		assertNotNull(results);
		assertEquals(1L, results.size());
		assertEquals("STEF", results.get(0).getMotifDeclencheur());

	}

	@Test
	public void testRXaSain() throws Exception{

		// ARRANGE
		doInTransaction(() -> {

			ParGravite parMdcGraviteCX = new ParGravite();
			parMdcGraviteCX.setGravite("CX");
			parMdcGraviteCX.setOrdre(1);
			getEntityManager().persist(parMdcGraviteCX);

			ParGravite parMdcGraviteDX = new ParGravite();
			parMdcGraviteCX.setGravite("DX");
			parMdcGraviteCX.setOrdre(2);
			getEntityManager().persist(parMdcGraviteDX);

			ParGravite parMdcGraviteRX = new ParGravite();
			parMdcGraviteCX.setGravite("RX");
			parMdcGraviteCX.setOrdre(3);
			getEntityManager().persist(parMdcGraviteRX);

			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("IDLOC1");
			id.setDateDebut(LocalDate.of(2015, 1, 1));
			id.setDateFin(null);

			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			RestTiersLocal restTiersLocal = new RestTiersLocal();
			restTiersLocal.setIdLocal("IDLOC1");
			restTiersLocal.setCodeBanque("10107");
			restTiersLocal.setDateDebut(LocalDate.of(2015, 1, 1));
			getEntityManager().persist(restTiersLocal);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(restTiersLocal);
			photoTiers.setDatePhoto(LocalDate.of(2015, 1, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("D");
			photoTiers.setPalierEffectif("RX");
			photoTiers.setStatutCalcule("D");
			photoTiers.setPalierCalcule("RX");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);

			StatutHistorise statusTiersRX = new StatutHistorise();
			statusTiersRX.setStatut(StatutTiers.DEFAUT);
			statusTiersRX.setGravite("RX");
			statusTiersRX.setAnnule(Boolean.FALSE);
			statusTiersRX.setDateDeb(LocalDate.of(2015, 1, 1));
			statusTiersRX.setTiers(tiers);
			getEntityManager().persist(statusTiersRX);

			StatutSbv statutForceSain = new StatutSbv();
			statutForceSain.setStatutForce("ND");
			statutForceSain.setDateDebut(LocalDate.of(2015, 1, 2));
			statutForceSain.setIdLocal("IDLOC1");
			statutForceSain.setCodeBanque("10107");
			statutForceSain.setCommentaire("Forcage Sain BV");
			getEntityManager().persist(statutForceSain);

		});
		// ACT
		lauchBatchDeclencheur("20150110");
		// VERIFY
		TypedQuery<Declencheur> q = getEntityManager().createQuery(
				" SELECT d from Declencheur d where d.dateDeclencheur = :dateDec order by idLocal ", Declencheur.class);
		q.setParameter("dateDec", Date.valueOf(LocalDate.of(2015, 1, 10)));
		List<Declencheur> results = q.getResultList();
		assertNotNull(results);
		assertEquals(1L, results.size());
		assertEquals("STEF", results.get(0).getMotifDeclencheur());

	}

	@Test
	public void testDaD() throws Exception{

		// ARRANGE
		doInTransaction(() -> {

			ParGravite parMdcGraviteCX = new ParGravite();
			parMdcGraviteCX.setGravite("CX");
			parMdcGraviteCX.setOrdre(1);
			getEntityManager().persist(parMdcGraviteCX);

			ParGravite parMdcGraviteDX = new ParGravite();
			parMdcGraviteDX.setGravite("DX");
			parMdcGraviteDX.setOrdre(2);
			getEntityManager().persist(parMdcGraviteDX);

			ParGravite parMdcGraviteRX = new ParGravite();
			parMdcGraviteRX.setGravite("RX");
			parMdcGraviteRX.setOrdre(3);
			getEntityManager().persist(parMdcGraviteRX);

			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("IDLOC1");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.of(2015, 1, 1));
			id.setDateFin(null);

			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			RestTiersLocal restTiersLocal = new RestTiersLocal();
			restTiersLocal.setIdLocal("IDLOC1");
			restTiersLocal.setCodeBanque("10107");
			restTiersLocal.setCodeSegment("1010");
			restTiersLocal.setDateDebut(LocalDate.of(2015, 1, 1));
			getEntityManager().persist(restTiersLocal);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(restTiersLocal);
			photoTiers.setDatePhoto(LocalDate.of(2015, 1, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("D");
			photoTiers.setPalierEffectif("CX");
			photoTiers.setStatutCalcule("D");
			photoTiers.setPalierCalcule("CX");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);

			StatutSbv statutForceCX = new StatutSbv();
			statutForceCX.setStatutForce("D");
			statutForceCX.setGravite("CX");
			statutForceCX.setDateDebut(LocalDate.of(2015, 1, 2));
			statutForceCX.setIdLocal("IDLOC1");
			statutForceCX.setCodeBanque("10107");
			statutForceCX.setCommentaire("Statut pré Forcage defaut BV");
			getEntityManager().persist(statutForceCX);

			StatutSbv statutForceD = new StatutSbv();
			statutForceD.setStatutForce("D");
			statutForceD.setDateDebut(LocalDate.of(2015, 1, 3));
			statutForceD.setIdLocal("IDLOC1");
			statutForceD.setCodeBanque("10107");
			statutForceD.setCommentaire("Forcage D BV");
			statutForceD.setGravite("CX");
			getEntityManager().persist(statutForceD);

		});

		// ACT
		lauchBatchDeclencheur("20150104");
		// VERIFY
		TypedQuery<Declencheur> q = getEntityManager().createQuery(
				" SELECT d from Declencheur d where d.dateDeclencheur = :dateDec order by idLocal ", Declencheur.class);
		q.setParameter("dateDec", Date.valueOf(LocalDate.of(2015, 1, 4)));

		List<Declencheur> results = q.getResultList();
		assertNotNull(results);
		assertEquals(1L, results.size());
		assertEquals("STCL", results.get(0).getMotifDeclencheur());
	}

	@Test
	public void testSainACx() throws Exception{

		// ARRANGE
		doInTransaction(() -> {

			ParGravite parMdcGraviteCX = new ParGravite();
			parMdcGraviteCX.setGravite("CX");
			parMdcGraviteCX.setOrdre(1);
			getEntityManager().persist(parMdcGraviteCX);

			ParGravite parMdcGraviteDX = new ParGravite();
			parMdcGraviteDX.setGravite("DX");
			parMdcGraviteDX.setOrdre(2);
			getEntityManager().persist(parMdcGraviteDX);

			ParGravite parMdcGraviteRX = new ParGravite();
			parMdcGraviteRX.setGravite("RX");
			parMdcGraviteRX.setOrdre(3);
			getEntityManager().persist(parMdcGraviteRX);

			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("IDLOC1");
			id.setDateDebut(LocalDate.of(2015, 1, 1));
			id.setDateFin(null);

			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			RestTiersLocal restTiersLocal = new RestTiersLocal();
			restTiersLocal.setIdLocal("IDLOC1");
			restTiersLocal.setCodeBanque("10107");
			restTiersLocal.setDateDebut(LocalDate.of(2015, 1, 1));
			getEntityManager().persist(restTiersLocal);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(restTiersLocal);
			photoTiers.setDatePhoto(LocalDate.of(2015, 1, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("ND");
			photoTiers.setStatutCalcule("ND");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);

			StatutHistorise statusSain= new StatutHistorise();
			statusSain.setStatut(StatutTiers.SAIN);
			statusSain.setAnnule(Boolean.FALSE);
			statusSain.setDateDeb(LocalDate.of(2015, 1, 1));
			statusSain.setTiers(tiers);
			getEntityManager().persist(statusSain);

			StatutSbv statutForceCX = new StatutSbv();
			statutForceCX.setStatutForce("D");
			statutForceCX.setGravite("CX");
			statutForceCX.setDateDebut(LocalDate.of(2015, 1, 2));
			statutForceCX.setIdLocal("IDLOC1");
			statutForceCX.setCodeBanque("10107");
			statutForceCX.setCommentaire("Forcage defaut BV");
			getEntityManager().persist(statutForceCX);

		});
		// ACT
		lauchBatchDeclencheur("20150110");
		// VERIFY
		TypedQuery<Declencheur> q = getEntityManager().createQuery(
				" SELECT d from Declencheur d where d.dateDeclencheur = :dateDec order by idLocal ", Declencheur.class);
		q.setParameter("dateDec", Date.valueOf(LocalDate.of(2015, 1, 10)));
		List<Declencheur> results = q.getResultList();
		assertNotNull(results);
		assertEquals(1L, results.size());
		assertEquals("STEF", results.get(0).getMotifDeclencheur());

	}

	@Test
	public void testSainADx() throws Exception{

		// ARRANGE
		doInTransaction(() -> {

			ParGravite parMdcGraviteCX = new ParGravite();
			parMdcGraviteCX.setGravite("CX");
			parMdcGraviteCX.setOrdre(1);
			getEntityManager().persist(parMdcGraviteCX);

			ParGravite parMdcGraviteDX = new ParGravite();
			parMdcGraviteDX.setGravite("DX");
			parMdcGraviteDX.setOrdre(2);
			getEntityManager().persist(parMdcGraviteDX);

			ParGravite parMdcGraviteRX = new ParGravite();
			parMdcGraviteRX.setGravite("RX");
			parMdcGraviteRX.setOrdre(3);
			getEntityManager().persist(parMdcGraviteRX);

			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("IDLOC1");
			id.setDateDebut(LocalDate.of(2015, 1, 1));
			id.setDateFin(null);

			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			RestTiersLocal restTiersLocal = new RestTiersLocal();
			restTiersLocal.setIdLocal("IDLOC1");
			restTiersLocal.setCodeBanque("10107");
			restTiersLocal.setDateDebut(LocalDate.of(2015, 1, 1));
			getEntityManager().persist(restTiersLocal);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(restTiersLocal);
			photoTiers.setDatePhoto(LocalDate.of(2015, 1, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("ND");
			photoTiers.setStatutCalcule("ND");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);

			StatutHistorise statusSain= new StatutHistorise();
			statusSain.setStatut(StatutTiers.SAIN);
			statusSain.setAnnule(Boolean.FALSE);
			statusSain.setDateDeb(LocalDate.of(2015, 1, 1));
			statusSain.setTiers(tiers);
			getEntityManager().persist(statusSain);

			StatutSbv statutForceDX = new StatutSbv();
			statutForceDX.setStatutForce("D");
			statutForceDX.setGravite("DX");
			statutForceDX.setDateDebut(LocalDate.of(2015, 1, 2));
			statutForceDX.setIdLocal("IDLOC1");
			statutForceDX.setCodeBanque("10107");
			statutForceDX.setCommentaire("Forcage defaut BV");
			getEntityManager().persist(statutForceDX);

		});
		// ACT
		lauchBatchDeclencheur("20150110");
		// VERIFY
		TypedQuery<Declencheur> q = getEntityManager().createQuery(
				" SELECT d from Declencheur d where d.dateDeclencheur = :dateDec order by idLocal ", Declencheur.class);
		q.setParameter("dateDec", Date.valueOf(LocalDate.of(2015, 1, 10)));
		List<Declencheur> results = q.getResultList();
		assertNotNull(results);
		assertEquals(1L, results.size());
		assertEquals("STEF", results.get(0).getMotifDeclencheur());

	}

	@Test
	public void testSainARx() throws Exception{

		// ARRANGE
		doInTransaction(() -> {

			ParGravite parMdcGraviteCX = new ParGravite();
			parMdcGraviteCX.setGravite("CX");
			parMdcGraviteCX.setOrdre(1);
			getEntityManager().persist(parMdcGraviteCX);

			ParGravite parMdcGraviteDX = new ParGravite();
			parMdcGraviteDX.setGravite("DX");
			parMdcGraviteDX.setOrdre(2);
			getEntityManager().persist(parMdcGraviteDX);

			ParGravite parMdcGraviteRX = new ParGravite();
			parMdcGraviteRX.setGravite("RX");
			parMdcGraviteRX.setOrdre(3);
			getEntityManager().persist(parMdcGraviteRX);

			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("IDLOC1");
			id.setDateDebut(LocalDate.of(2015, 1, 1));
			id.setDateFin(null);

			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			RestTiersLocal restTiersLocal = new RestTiersLocal();
			restTiersLocal.setIdLocal("IDLOC1");
			restTiersLocal.setCodeBanque("10107");
			restTiersLocal.setDateDebut(LocalDate.of(2015, 1, 1));
			getEntityManager().persist(restTiersLocal);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(restTiersLocal);
			photoTiers.setDatePhoto(LocalDate.of(2015, 1, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("ND");
			photoTiers.setStatutCalcule("ND");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);

			StatutHistorise statusSain= new StatutHistorise();
			statusSain.setStatut(StatutTiers.SAIN);
			statusSain.setAnnule(Boolean.FALSE);
			statusSain.setDateDeb(LocalDate.of(2015, 1, 1));
			statusSain.setTiers(tiers);
			getEntityManager().persist(statusSain);

			StatutSbv statutForceRX = new StatutSbv();
			statutForceRX.setStatutForce("D");
			statutForceRX.setGravite("RX");
			statutForceRX.setDateDebut(LocalDate.of(2015, 1, 2));
			statutForceRX.setIdLocal("IDLOC1");
			statutForceRX.setCodeBanque("10107");
			statutForceRX.setCommentaire("Forcage defaut BV");
			getEntityManager().persist(statutForceRX);

		});
		// ACT
		lauchBatchDeclencheur("20150110");
		// VERIFY
		TypedQuery<Declencheur> q = getEntityManager().createQuery(
				" SELECT d from Declencheur d where d.dateDeclencheur = :dateDec order by idLocal ", Declencheur.class);
		q.setParameter("dateDec", Date.valueOf(LocalDate.of(2015, 1, 10)));
		List<Declencheur> results = q.getResultList();
		assertNotNull(results);
		assertEquals(1L, results.size());
		assertEquals("STEF", results.get(0).getMotifDeclencheur());

	}

	@Test
	public void testNdaNd() throws Exception{

		// ARRANGE
		doInTransaction(() -> {

			ParGravite parMdcGraviteCX = new ParGravite();
			parMdcGraviteCX.setGravite("CX");
			parMdcGraviteCX.setOrdre(1);
			getEntityManager().persist(parMdcGraviteCX);

			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("IDLOC1");
			id.setDateDebut(LocalDate.of(2015, 1, 1));
			id.setDateFin(null);

			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			RestTiersLocal restTiersLocal = new RestTiersLocal();
			restTiersLocal.setIdLocal("IDLOC1");
			restTiersLocal.setCodeBanque("10107");
			restTiersLocal.setDateDebut(LocalDate.of(2015, 1, 1));
			getEntityManager().persist(restTiersLocal);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(restTiersLocal);
			photoTiers.setDatePhoto(LocalDate.of(2015, 1, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("ND");
			photoTiers.setStatutCalcule("ND");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);

			StatutHistorise statusSain = new StatutHistorise();
			statusSain.setStatut(StatutTiers.SAIN);
			statusSain.setDateDeb(LocalDate.of(2015, 1, 1));
			statusSain.setAnnule(false);
			statusSain.setTiers(tiers);
			getEntityManager().persist(statusSain);

			StatutSbv statutForceNd = new StatutSbv();
			statutForceNd.setStatutForce("ND");
			statutForceNd.setDateDebut(LocalDate.of(2015, 1, 3));
			statutForceNd.setIdLocal("IDLOC1");
			statutForceNd.setCodeBanque("10107");
			statutForceNd.setCommentaire("Forcage Sain BV");
			getEntityManager().persist(statutForceNd);

		});
		// ACT
		lauchBatchDeclencheur("20150104");
		// VERIFY
		TypedQuery<Declencheur> q = getEntityManager().createQuery(
				" SELECT d from Declencheur d where d.dateDeclencheur = :dateDec order by idLocal ", Declencheur.class);
		q.setParameter("dateDec", Date.valueOf(LocalDate.of(2015, 1, 4)));
		List<Declencheur> results = q.getResultList();
		assertNotNull(results);
		assertEquals(1L, results.size());
		assertEquals("STEF", results.get(0).getMotifDeclencheur());
	}

	private JobExecution lauchBatchDeclencheur(String dateLaunch) throws Exception {

		Job job = (Job) context.getBean(Constant.JOB_DECLENCHEUR);
		JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");
		Long guid = java.util.UUID.randomUUID().getMostSignificantBits();
		JobParameters jobParameters = new JobParametersBuilder().addString("date", dateLaunch).addLong("guid", guid)
				.toJobParameters();

		return jobLauncher.run(job, jobParameters);

	}

	@BeforeClass
	public static void initSpringContext() throws NoSuchFieldException, IllegalAccessException, IOException {
		initSpring();
	}

	/**
	 * Vider les tables après chaque test
	 */
	@After
	public void resetData() {
		deleteAllTables();

	}

}

package bpce.yyd.batch.declencheur.ti;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.junit.After;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;

import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.commun.utils.AbstractTestIntegration;
import fr.bpce.yyd.commun.enums.CodeParamMdc;
import fr.bpce.yyd.commun.enums.StatutEvenement;
import fr.bpce.yyd.commun.enums.StatutTiers;
import fr.bpce.yyd.commun.model.ArriereSignificatif;
import fr.bpce.yyd.commun.model.AuditFichiers;
import fr.bpce.yyd.commun.model.ComplementArriere;
import fr.bpce.yyd.commun.model.ComplementEvenement;
import fr.bpce.yyd.commun.model.Declencheur;
import fr.bpce.yyd.commun.model.ElementsDeCalcul;
import fr.bpce.yyd.commun.model.Evenement;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.MotifStatutTiers;
import fr.bpce.yyd.commun.model.ParMdcSeg;
import fr.bpce.yyd.commun.model.PeriodeProbatoire;
import fr.bpce.yyd.commun.model.RestCliDecl;
import fr.bpce.yyd.commun.model.StatutHistorise;
import fr.bpce.yyd.commun.model.StatutSbv;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.commun.model.TiersRFT;
import fr.bpce.yyd.commun.model.reference.ParGravite;
import fr.bpce.yyd.commun.model.restitution.RestAssociateRftSiren;
import fr.bpce.yyd.commun.model.restitution.RestSynthTierLocalStatus;
import fr.bpce.yyd.commun.model.restitution.RestTiersIdRft;
import fr.bpce.yyd.commun.model.restitution.RestTiersLocal;
import fr.bpce.yyd.commun.model.restitution.RestTiersSiren;

public class DeclencheursWithPhotoPrecedenteTest extends AbstractTestIntegration {

	@Test
	public void declencheurStatutEffectifSain() {
		// Arrange - On crée le tiers + identite
		doInTransaction(() -> {
			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("ID-TIERS-LOCAL-0001");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.of(2018, 12, 1));
			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			StatutHistorise statusTiers = new StatutHistorise();
			statusTiers.setStatut(StatutTiers.SAIN);
			statusTiers.setAnnule(Boolean.FALSE);
			statusTiers.setDateDeb(LocalDate.of(2018, 12, 1));
			statusTiers.setTiers(tiers);
			getEntityManager().persist(statusTiers);

			RestTiersLocal tiersLoc = new RestTiersLocal();
			tiersLoc.setIdLocal("ID-TIERS-LOCAL-0001");
			tiersLoc.setCodeBanque("10107");
			tiersLoc.setCodeSegment("1010");
			tiersLoc.setDateDebut(LocalDate.of(2018, 12, 1));
			getEntityManager().persist(tiersLoc);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(tiersLoc);
			photoTiers.setDatePhoto(LocalDate.of(2018, 11, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("D");
			photoTiers.setPalierEffectif("DX");
			photoTiers.setStatutCalcule("ND");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);
		});

		// Act
		lauchBatchDeclencheur("20181201");

		// Assert
		doInTransaction(() -> {
			List<Declencheur> declencheurs = findAllDeclencheurs();
			Assert.assertEquals(1, declencheurs.size());
			Assert.assertEquals("10107", declencheurs.get(0).getCodeBanque());
			Assert.assertEquals("ID-TIERS-LOCAL-0001", declencheurs.get(0).getIdLocal());
			Assert.assertEquals("STEF", declencheurs.get(0).getMotifDeclencheur());
		});
	}

	@Test
	public void declencheurStatutEffectifAvecAnnulationDefaut() {
		// Arrange - On crée le tiers + identite
		doInTransaction(() -> {
			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("ID-TIERS-LOCAL-0001");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.of(2018, 11, 1));
			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			StatutHistorise statusTiers = new StatutHistorise();
			statusTiers.setStatut(StatutTiers.DEFAUT);
			statusTiers.setGravite("DX");
			statusTiers.setAnnule(Boolean.TRUE);
			statusTiers.setDateDeb(LocalDate.of(2018, 11, 1));
			statusTiers.setDateFin(LocalDate.of(2018, 12, 1));
			statusTiers.setTiers(tiers);
			getEntityManager().persist(statusTiers);

			ParGravite parMdcGravite = new ParGravite();
			parMdcGravite.setGravite("DX");
			parMdcGravite.setOrdre(1);
			getEntityManager().persist(parMdcGravite);

			StatutHistorise statusTiers2 = new StatutHistorise();
			statusTiers2.setStatut(StatutTiers.SAIN);
			statusTiers2.setAnnule(Boolean.FALSE);
			statusTiers2.setDateDeb(LocalDate.of(2018, 12, 1));
			statusTiers2.setTiers(tiers);
			getEntityManager().persist(statusTiers2);

			RestTiersLocal tiersLoc = new RestTiersLocal();
			tiersLoc.setIdLocal("ID-TIERS-LOCAL-0001");
			tiersLoc.setCodeBanque("10107");
			tiersLoc.setCodeSegment("1010");
			tiersLoc.setDateDebut(LocalDate.of(2018, 11, 1));
			getEntityManager().persist(tiersLoc);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(tiersLoc);
			photoTiers.setDatePhoto(LocalDate.of(2018, 11, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("D");
			photoTiers.setPalierEffectif("DX");
			photoTiers.setStatutCalcule("D");
			photoTiers.setPalierCalcule("DX");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);
		});

		// Act
		lauchBatchDeclencheur("20181201");

		// Assert
		doInTransaction(() -> {
			List<Declencheur> declencheurs = findAllDeclencheurs();
			Assert.assertEquals(1, declencheurs.size());
			Assert.assertEquals("10107", declencheurs.get(0).getCodeBanque());
			Assert.assertEquals("ID-TIERS-LOCAL-0001", declencheurs.get(0).getIdLocal());
			Assert.assertEquals("STCL", declencheurs.get(0).getMotifDeclencheur());
		});
	}

	@Test
	public void declencheurStatutEffectifMultiDefaut() {
		// Arrange - On crée le tiers + identite
		doInTransaction(() -> {
			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("ID-TIERS-LOCAL-0001");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.of(2018, 11, 1));
			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			StatutHistorise statusTiers = new StatutHistorise();
			statusTiers.setStatut(StatutTiers.DEFAUT);
			statusTiers.setGravite("DX");
			statusTiers.setAnnule(Boolean.FALSE);
			statusTiers.setDateDeb(LocalDate.of(2018, 11, 1));
			statusTiers.setTiers(tiers);
			getEntityManager().persist(statusTiers);

			ParGravite parMdcGravite = new ParGravite();
			parMdcGravite.setGravite("DX");
			parMdcGravite.setOrdre(2);
			getEntityManager().persist(parMdcGravite);

			StatutHistorise statusTiers2 = new StatutHistorise();
			statusTiers2.setStatut(StatutTiers.DEFAUT);
			statusTiers2.setGravite("CX");
			statusTiers2.setAnnule(Boolean.TRUE);
			statusTiers2.setDateDeb(LocalDate.of(2018, 11, 1));
			statusTiers2.setDateFin(LocalDate.of(2018, 12, 1));
			statusTiers2.setTiers(tiers);
			getEntityManager().persist(statusTiers2);

			ParGravite parMdcGravite2 = new ParGravite();
			parMdcGravite2.setGravite("CX");
			parMdcGravite2.setOrdre(1);
			getEntityManager().persist(parMdcGravite2);

			RestTiersLocal tiersLoc = new RestTiersLocal();
			tiersLoc.setIdLocal("ID-TIERS-LOCAL-0001");
			tiersLoc.setCodeBanque("10107");
			tiersLoc.setCodeSegment("1010");
			tiersLoc.setDateDebut(LocalDate.of(2018, 11, 1));
			getEntityManager().persist(tiersLoc);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(tiersLoc);
			photoTiers.setDatePhoto(LocalDate.of(2018, 11, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("D");
			photoTiers.setPalierEffectif("CX");
			photoTiers.setStatutCalcule("D");
			photoTiers.setPalierCalcule("CX");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);
		});

		// Act
		lauchBatchDeclencheur("20181201");

		// Assert
		doInTransaction(() -> {
			List<Declencheur> declencheurs = findAllDeclencheurs();
			Assert.assertEquals(1, declencheurs.size());
			Assert.assertEquals("10107", declencheurs.get(0).getCodeBanque());
			Assert.assertEquals("ID-TIERS-LOCAL-0001", declencheurs.get(0).getIdLocal());
			Assert.assertEquals("STCL", declencheurs.get(0).getMotifDeclencheur());
		});
	}

	@Test
	public void nonDeclenchementStatutEffectifSainInchange() {
		// Arrange - On crée le tiers + identite
		doInTransaction(() -> {
			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("ID-TIERS-LOCAL-0001");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.of(2018, 12, 1));
			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			StatutHistorise statusTiers = new StatutHistorise();
			statusTiers.setStatut(StatutTiers.SAIN);
			statusTiers.setAnnule(Boolean.FALSE);
			statusTiers.setDateDeb(LocalDate.of(2018, 12, 1));
			statusTiers.setTiers(tiers);
			getEntityManager().persist(statusTiers);

			RestTiersLocal tiersLoc = new RestTiersLocal();
			tiersLoc.setIdLocal("ID-TIERS-LOCAL-0001");
			tiersLoc.setCodeBanque("10107");
			tiersLoc.setCodeSegment("1010");
			tiersLoc.setDateDebut(LocalDate.of(2018, 12, 1));
			getEntityManager().persist(tiersLoc);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(tiersLoc);
			photoTiers.setDatePhoto(LocalDate.of(2018, 11, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("ND");
			photoTiers.setStatutCalcule("ND");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);
		});

		// Act
		lauchBatchDeclencheur("20181201");

		// Assert
		doInTransaction(() -> {
			List<Declencheur> declencheurs = findAllDeclencheurs();
			Assert.assertTrue(declencheurs.isEmpty());
		});
	}

	@Test
	public void declencheurStatutEffectifDefaut() {
		// Arrange - On crée le tiers + identite
		doInTransaction(() -> {
			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("ID-TIERS-LOCAL-0002");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.of(2018, 12, 1));
			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			StatutHistorise statusTiers = new StatutHistorise();
			statusTiers.setStatut(StatutTiers.DEFAUT);
			statusTiers.setGravite("DX");
			statusTiers.setAnnule(Boolean.FALSE);
			statusTiers.setDateDeb(LocalDate.of(2018, 12, 1));
			statusTiers.setTiers(tiers);
			getEntityManager().persist(statusTiers);

			ParGravite parMdcGravite = new ParGravite();
			parMdcGravite.setGravite("DX");
			parMdcGravite.setOrdre(1);
			getEntityManager().persist(parMdcGravite);

			RestTiersLocal tiersLoc = new RestTiersLocal();
			tiersLoc.setIdLocal("ID-TIERS-LOCAL-0002");
			tiersLoc.setCodeBanque("10107");
			tiersLoc.setCodeSegment("1010");
			tiersLoc.setDateDebut(LocalDate.of(2018, 12, 1));
			getEntityManager().persist(tiersLoc);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(tiersLoc);
			photoTiers.setDatePhoto(LocalDate.of(2018, 11, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("ND");
			photoTiers.setStatutCalcule("D");
			photoTiers.setPalierCalcule("DX");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);
		});

		// Act
		lauchBatchDeclencheur("20181201");

		// Assert
		doInTransaction(() -> {
			List<Declencheur> declencheurs = findAllDeclencheurs();
			Assert.assertEquals(1, declencheurs.size());
			Assert.assertEquals("10107", declencheurs.get(0).getCodeBanque());
			Assert.assertEquals("ID-TIERS-LOCAL-0002", declencheurs.get(0).getIdLocal());
			Assert.assertEquals("STEF", declencheurs.get(0).getMotifDeclencheur());
		});
	}

	@Test
	public void nonDeclenchementStatutEffectifDefautInchange() {
		// Arrange - On crée le tiers + identite
		doInTransaction(() -> {
			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("ID-TIERS-LOCAL-0002");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.of(2018, 12, 1));
			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			StatutHistorise statusTiers = new StatutHistorise();
			statusTiers.setStatut(StatutTiers.DEFAUT);
			statusTiers.setGravite("DX");
			statusTiers.setAnnule(Boolean.FALSE);
			statusTiers.setDateDeb(LocalDate.of(2018, 12, 1));
			statusTiers.setTiers(tiers);
			getEntityManager().persist(statusTiers);

			ParGravite parMdcGravite = new ParGravite();
			parMdcGravite.setGravite("DX");
			parMdcGravite.setOrdre(1);
			getEntityManager().persist(parMdcGravite);

			RestTiersLocal tiersLoc = new RestTiersLocal();
			tiersLoc.setIdLocal("ID-TIERS-LOCAL-0002");
			tiersLoc.setCodeBanque("10107");
			tiersLoc.setCodeSegment("1010");
			tiersLoc.setDateDebut(LocalDate.of(2018, 12, 1));
			getEntityManager().persist(tiersLoc);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(tiersLoc);
			photoTiers.setDatePhoto(LocalDate.of(2018, 11, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("D");
			photoTiers.setPalierEffectif("DX");
			photoTiers.setStatutCalcule("D");
			photoTiers.setPalierCalcule("DX");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);
		});

		// Act
		lauchBatchDeclencheur("20181201");

		// Assert
		doInTransaction(() -> {
			List<Declencheur> declencheurs = findAllDeclencheurs();
			Assert.assertTrue(declencheurs.isEmpty());
		});
	}

	@Test
	public void declencheurStatutCalculeSain() {
		// Arrange - On crée le tiers + identite
		doInTransaction(() -> {
			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("ID-TIERS-LOCAL-0003");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.of(2018, 12, 1));
			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			StatutHistorise statusTiers = new StatutHistorise();
			statusTiers.setStatut(StatutTiers.SAIN);
			statusTiers.setAnnule(Boolean.FALSE);
			statusTiers.setDateDeb(LocalDate.of(2018, 12, 1));
			statusTiers.setTiers(tiers);
			getEntityManager().persist(statusTiers);

			RestTiersLocal tiersLoc = new RestTiersLocal();
			tiersLoc.setIdLocal("ID-TIERS-LOCAL-0003");
			tiersLoc.setCodeBanque("10107");
			tiersLoc.setCodeSegment("1010");
			tiersLoc.setDateDebut(LocalDate.of(2018, 12, 1));
			getEntityManager().persist(tiersLoc);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(tiersLoc);
			photoTiers.setDatePhoto(LocalDate.of(2018, 11, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("D");
			photoTiers.setPalierEffectif("DX");
			photoTiers.setStatutCalcule("D");
			photoTiers.setStatutCalcule("DX");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);
		});

		// Act
		lauchBatchDeclencheur("20181201");

		// Assert
		doInTransaction(() -> {
			List<Declencheur> declencheurs = findAllDeclencheurs();
			Assert.assertEquals(1, declencheurs.size());
			Assert.assertEquals("10107", declencheurs.get(0).getCodeBanque());
			Assert.assertEquals("ID-TIERS-LOCAL-0003", declencheurs.get(0).getIdLocal());
			Assert.assertEquals("STCL", declencheurs.get(0).getMotifDeclencheur());
		});
	}

	@Test
	public void declencheurStatutCalculeDefaut() {
		// Arrange - On crée le tiers + identite
		doInTransaction(() -> {
			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("ID-TIERS-LOCAL-0004");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.of(2018, 12, 1));
			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			StatutHistorise statusTiers = new StatutHistorise();
			statusTiers.setStatut(StatutTiers.DEFAUT);
			statusTiers.setGravite("DX");
			statusTiers.setAnnule(Boolean.FALSE);
			statusTiers.setDateDeb(LocalDate.of(2018, 12, 1));
			statusTiers.setTiers(tiers);
			getEntityManager().persist(statusTiers);

			ParGravite parMdcGravite = new ParGravite();
			parMdcGravite.setGravite("DX");
			parMdcGravite.setOrdre(1);
			getEntityManager().persist(parMdcGravite);

			RestTiersLocal tiersLoc = new RestTiersLocal();
			tiersLoc.setIdLocal("ID-TIERS-LOCAL-0004");
			tiersLoc.setCodeBanque("10107");
			tiersLoc.setCodeSegment("1010");
			tiersLoc.setDateDebut(LocalDate.of(2018, 12, 1));
			getEntityManager().persist(tiersLoc);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(tiersLoc);
			photoTiers.setDatePhoto(LocalDate.of(2018, 11, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("ND");
			photoTiers.setStatutCalcule("ND");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);
		});

		// Act
		lauchBatchDeclencheur("20181201");

		// Assert
		doInTransaction(() -> {
			List<Declencheur> declencheurs = findAllDeclencheurs();
			Assert.assertEquals(1, declencheurs.size());
			Assert.assertEquals("10107", declencheurs.get(0).getCodeBanque());
			Assert.assertEquals("ID-TIERS-LOCAL-0004", declencheurs.get(0).getIdLocal());
			Assert.assertEquals("STCL", declencheurs.get(0).getMotifDeclencheur());
		});
	}

	@Test
	public void declencheurSurChangementDuPalierCalcule() {

		doInTransaction(() -> {
			ParGravite parMdcGraviteCX = new ParGravite();
			parMdcGraviteCX.setGravite("CX");
			parMdcGraviteCX.setOrdre(1);
			getEntityManager().persist(parMdcGraviteCX);

			ParGravite parMdcGraviteDX = new ParGravite();
			parMdcGraviteDX.setGravite("DX");
			parMdcGraviteDX.setOrdre(2);
			getEntityManager().persist(parMdcGraviteDX);

			ParGravite parMdcGraviteRX = new ParGravite();
			parMdcGraviteRX.setGravite("RX");
			parMdcGraviteRX.setOrdre(3);
			getEntityManager().persist(parMdcGraviteRX);

			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeSegment("1010");
			id.setCodeBanque("10107");
			id.setIdLocal("ID-TIERS-LOCAL-0005");
			id.setDateDebut(LocalDate.of(2018, 12, 1));
			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			Evenement evtRad = new Evenement();
			evtRad.setCode("RAD");
			evtRad.setDateDebut(LocalDate.of(2018, 12, 1));
			evtRad.setIdentiteInitiale(id);

			AuditFichiers af = new AuditFichiers();
			getEntityManager().persist(af);

			ComplementEvenement ceRad = new ComplementEvenement();
			ceRad.setDatePhoto(LocalDate.of(2018, 12, 1));
			ceRad.setDateMaj(LocalDate.of(2018, 12, 1));
			ceRad.setStatutEvt(StatutEvenement.ACT);
			ceRad.setArriereLitige(false);
			ceRad.setArriereTech(false);
			ceRad.setAuditFichier(af);
			ceRad.setIdentiteInitiale(id);
			evtRad.addComplement(ceRad);
			getEntityManager().persist(evtRad);

			Evenement evtPco = new Evenement();
			evtPco.setCode("PCO");
			evtPco.setDateDebut(LocalDate.of(2018, 12, 3));
			evtPco.setIdentiteInitiale(id);

			ComplementEvenement cePco = new ComplementEvenement();
			cePco.setDatePhoto(LocalDate.of(2018, 12, 3));
			cePco.setDateMaj(LocalDate.of(2018, 12, 3));
			cePco.setStatutEvt(StatutEvenement.ACT);
			cePco.setArriereLitige(false);
			cePco.setArriereTech(false);
			cePco.setAuditFichier(af);
			cePco.setIdentiteInitiale(id);
			evtPco.addComplement(cePco);
			getEntityManager().persist(evtPco);

			Evenement evtPc1 = new Evenement();
			evtPc1.setCode("PC1");
			evtPc1.setDateDebut(LocalDate.of(2018, 12, 5));
			evtPc1.setIdentiteInitiale(id);

			ComplementEvenement cePc1 = new ComplementEvenement();
			cePc1.setDatePhoto(LocalDate.of(2018, 12, 5));
			cePc1.setDateMaj(LocalDate.of(2018, 12, 5));
			cePc1.setStatutEvt(StatutEvenement.ACT);
			cePc1.setArriereLitige(false);
			cePc1.setArriereTech(false);
			cePc1.setAuditFichier(af);
			cePc1.setIdentiteInitiale(id);
			evtPc1.addComplement(cePc1);
			getEntityManager().persist(evtPc1);

			StatutHistorise statusTiersDx = new StatutHistorise();
			statusTiersDx.setStatut(StatutTiers.DEFAUT);
			statusTiersDx.setMotif(new MotifStatutTiers(ceRad));
			statusTiersDx.setGravite("DX");
			statusTiersDx.setAnnule(Boolean.FALSE);
			statusTiersDx.setDateDeb(LocalDate.of(2018, 12, 1));
			statusTiersDx.setTiers(tiers);
			getEntityManager().persist(statusTiersDx);

			StatutHistorise statusTiersRX = new StatutHistorise();
			statusTiersRX.setStatut(StatutTiers.DEFAUT);
			statusTiersRX.setMotif(new MotifStatutTiers(cePco));
			statusTiersRX.setGravite("RX");
			statusTiersRX.setAnnule(Boolean.FALSE);
			statusTiersRX.setDateDeb(LocalDate.of(2018, 12, 3));
			statusTiersRX.setTiers(tiers);
			getEntityManager().persist(statusTiersRX);

			StatutHistorise statusTiersCX = new StatutHistorise();
			statusTiersCX.setStatut(StatutTiers.DEFAUT);
			statusTiersCX.setMotif(new MotifStatutTiers(cePc1));
			statusTiersCX.setGravite("CX");
			statusTiersCX.setAnnule(Boolean.FALSE);
			statusTiersCX.setDateDeb(LocalDate.of(2018, 12, 5));
			statusTiersCX.setTiers(tiers);
			getEntityManager().persist(statusTiersCX);

			RestTiersLocal tiersLoc = new RestTiersLocal();
			tiersLoc.setIdLocal("ID-TIERS-LOCAL-0005");
			tiersLoc.setCodeBanque("10107");
			tiersLoc.setCodeSegment("1010");
			tiersLoc.setDateDebut(LocalDate.of(2018, 12, 1));
			getEntityManager().persist(tiersLoc);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(tiersLoc);
			photoTiers.setDatePhoto(LocalDate.of(2018, 11, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("D");
			photoTiers.setPalierEffectif("DX");
			photoTiers.setStatutCalcule("D");
			photoTiers.setPalierCalcule("DX");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);
		});

		// Act
		lauchBatchDeclencheur("20181210");

		// Assert
		doInTransaction(() -> {
			List<Declencheur> declencheurs = findAllDeclencheurs();
			Assert.assertEquals(1, declencheurs.size());
			Assert.assertEquals("10107", declencheurs.get(0).getCodeBanque());
			Assert.assertEquals("ID-TIERS-LOCAL-0005", declencheurs.get(0).getIdLocal());
			Assert.assertEquals("STCL", declencheurs.get(0).getMotifDeclencheur());
		});

	}

	@Test
	public void declencheurOrigineBV() {
		doInTransaction(() -> {
			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeSegment("1010");
			id.setCodeBanque("10107");
			id.setIdLocal("ID-TIERS-LOCAL-0006");
			id.setDateDebut(LocalDate.of(2018, 12, 1));
			tiers.addIdentite(id);

			getEntityManager().persist(tiers);

			StatutHistorise statusTiers = new StatutHistorise();
			statusTiers.setStatut(StatutTiers.DEFAUT);
			statusTiers.setGravite("DX");
			statusTiers.setAnnule(Boolean.FALSE);
			statusTiers.setDateDeb(LocalDate.of(2018, 12, 1));
			statusTiers.setTiers(tiers);
			getEntityManager().persist(statusTiers);

			ParGravite parMdcGravite = new ParGravite();
			parMdcGravite.setGravite("DX");
			parMdcGravite.setOrdre(1);
			getEntityManager().persist(parMdcGravite);

			StatutSbv sbv = new StatutSbv();
			sbv.setCodeBanque("10107");
			sbv.setIdLocal("ID-TIERS-LOCAL-0006");
			sbv.setStatutForce("D");
			sbv.setGravite("DX");
			sbv.setDateDebut(LocalDate.of(2018, 12, 15));
			sbv.setUtilisateurModif("ndod");
			sbv.setCodificationMotif("motif1");
			sbv.setCommentaire("commentaire1");
			getEntityManager().persist(sbv);

			RestTiersLocal tiersLoc = new RestTiersLocal();
			tiersLoc.setIdLocal("ID-TIERS-LOCAL-0006");
			tiersLoc.setCodeBanque("10107");
			tiersLoc.setCodeSegment("1010");
			tiersLoc.setDateDebut(LocalDate.of(2018, 12, 1));
			getEntityManager().persist(tiersLoc);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(tiersLoc);
			photoTiers.setDatePhoto(LocalDate.of(2018, 11, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("D");
			photoTiers.setPalierEffectif("DX");
			photoTiers.setStatutCalcule("D");
			photoTiers.setPalierCalcule("DX");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);
		});

		// Act
		lauchBatchDeclencheur("20181220");

		// Assert
		doInTransaction(() -> {
			List<Declencheur> declencheurs = findAllDeclencheurs();
			Assert.assertEquals(1, declencheurs.size());
			Assert.assertEquals("10107", declencheurs.get(0).getCodeBanque());
			Assert.assertEquals("ID-TIERS-LOCAL-0006", declencheurs.get(0).getIdLocal());
			Assert.assertEquals("STEF", declencheurs.get(0).getMotifDeclencheur());
		});
	}

	@Test
	public void declencheurOrigineSTC() {

		doInTransaction(() -> {
			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeSegment("1010");
			id.setCodeBanque("10107");
			id.setIdLocal("ID-TIERS-LOCAL-0007");
			id.setDateDebut(LocalDate.of(2018, 12, 1));
			tiers.addIdentite(id);

			getEntityManager().persist(tiers);

			StatutHistorise statusTiers = new StatutHistorise();
			statusTiers.setStatut(StatutTiers.DEFAUT);
			statusTiers.setGravite("DX");
			statusTiers.setAnnule(Boolean.FALSE);
			statusTiers.setDateDeb(LocalDate.of(2018, 12, 15));
			statusTiers.setTiers(tiers);
			getEntityManager().persist(statusTiers);

			ParGravite parMdcGravite = new ParGravite();
			parMdcGravite.setGravite("DX");
			parMdcGravite.setOrdre(1);
			getEntityManager().persist(parMdcGravite);

			StatutSbv sbv = new StatutSbv();
			sbv.setCodeBanque("10107");
			sbv.setIdLocal("ID-TIERS-LOCAL-0007");
			sbv.setStatutForce("D");
			sbv.setGravite("DX");
			sbv.setDateDebut(LocalDate.of(2018, 12, 1));
			sbv.setDateFin(LocalDate.of(2018, 12, 10));
			getEntityManager().persist(sbv);

			RestTiersLocal tiersLoc = new RestTiersLocal();
			tiersLoc.setIdLocal("ID-TIERS-LOCAL-0007");
			tiersLoc.setCodeBanque("10107");
			tiersLoc.setCodeSegment("1010");
			tiersLoc.setDateDebut(LocalDate.of(2018, 12, 1));
			getEntityManager().persist(tiersLoc);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(tiersLoc);
			photoTiers.setDatePhoto(LocalDate.of(2018, 11, 1));
			photoTiers.setOrigineStatutEffectif("BV");
			photoTiers.setStatutEffectif("D");
			photoTiers.setPalierEffectif("DX");
			photoTiers.setStatutCalcule("D");
			photoTiers.setPalierCalcule("DX");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);
		});

		// Act
		lauchBatchDeclencheur("20181220");

		// Assert
		doInTransaction(() -> {
			List<Declencheur> declencheurs = findAllDeclencheurs();
			Assert.assertEquals(1, declencheurs.size());
			Assert.assertEquals("10107", declencheurs.get(0).getCodeBanque());
			Assert.assertEquals("ID-TIERS-LOCAL-0007", declencheurs.get(0).getIdLocal());
			Assert.assertEquals("STEF", declencheurs.get(0).getMotifDeclencheur());
		});
	}

	@Test
	public void declecheurTopAsOui() {
		// Arrange - On crée le tiers + identite
		doInTransaction(() -> {
			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setCodeSegment("1010");
			id.setIdLocal("ID-TIERS-LOCAL-0008");
			id.setDateDebut(LocalDate.of(2018, 12, 1));
			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			ElementsDeCalcul eltCalc = new ElementsDeCalcul();
			eltCalc.setTiers(tiers);
			getEntityManager().persist(eltCalc);

			ComplementArriere cmplArr = new ComplementArriere();
			cmplArr.setIdTiers(tiers.getId());
			cmplArr.setEntree(eltCalc);
			ArriereSignificatif as = new ArriereSignificatif();
			as.setDateDebut(LocalDate.of(2018, 12, 1));
			as.setTiers(tiers);
			as.setComplement(cmplArr);
			getEntityManager().persist(as);

			RestTiersLocal tiersLoc = new RestTiersLocal();
			tiersLoc.setIdLocal("ID-TIERS-LOCAL-0008");
			tiersLoc.setCodeBanque("10107");
			tiersLoc.setCodeSegment("1010");
			tiersLoc.setDateDebut(LocalDate.of(2018, 12, 1));
			getEntityManager().persist(tiersLoc);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(tiersLoc);
			photoTiers.setDatePhoto(LocalDate.of(2018, 11, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("ND");
			photoTiers.setStatutCalcule("ND");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);
		});

		// Act
		lauchBatchDeclencheur("20181204");

		// Assert
		doInTransaction(() -> {
			List<Declencheur> declencheurs = findAllDeclencheurs();
			Assert.assertEquals(1, declencheurs.size());
			Assert.assertEquals("10107", declencheurs.get(0).getCodeBanque());
			Assert.assertEquals("ID-TIERS-LOCAL-0008", declencheurs.get(0).getIdLocal());
			Assert.assertEquals("TOPAS", declencheurs.get(0).getMotifDeclencheur());
		});
	}

	@Test
	public void nonDeclechementTopAsOuiInchange() {
		// Arrange - On crée le tiers + identite
		doInTransaction(() -> {
			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setCodeSegment("1010");
			id.setIdLocal("ID-TIERS-LOCAL-0008");
			id.setDateDebut(LocalDate.of(2018, 12, 1));
			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			ElementsDeCalcul eltCalc = new ElementsDeCalcul();
			eltCalc.setTiers(tiers);
			getEntityManager().persist(eltCalc);

			ComplementArriere cmplArr = new ComplementArriere();
			cmplArr.setIdTiers(tiers.getId());
			cmplArr.setEntree(eltCalc);
			ArriereSignificatif as = new ArriereSignificatif();
			as.setDateDebut(LocalDate.of(2018, 12, 1));
			as.setTiers(tiers);
			as.setComplement(cmplArr);
			getEntityManager().persist(as);

			RestTiersLocal tiersLoc = new RestTiersLocal();
			tiersLoc.setIdLocal("ID-TIERS-LOCAL-0008");
			tiersLoc.setCodeBanque("10107");
			tiersLoc.setCodeSegment("1010");
			tiersLoc.setDateDebut(LocalDate.of(2018, 12, 1));
			getEntityManager().persist(tiersLoc);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(tiersLoc);
			photoTiers.setDatePhoto(LocalDate.of(2018, 11, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("ND");
			photoTiers.setStatutCalcule("ND");
			photoTiers.setTopAS(true);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);
		});

		// Act
		lauchBatchDeclencheur("20181204");

		// Assert
		doInTransaction(() -> {
			List<Declencheur> declencheurs = findAllDeclencheurs();
			Assert.assertTrue(declencheurs.isEmpty());
		});
	}

	@Test
	public void declencheurTopAsNon() {
		// Arrange - On crée le tiers + identite
		doInTransaction(() -> {
			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setCodeSegment("1010");
			id.setIdLocal("ID-TIERS-LOCAL-0009");
			id.setDateDebut(LocalDate.of(2018, 12, 1));
			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			ElementsDeCalcul eltCalc1 = new ElementsDeCalcul();
			eltCalc1.setTiers(tiers);
			getEntityManager().persist(eltCalc1);

			ElementsDeCalcul eltCalc2 = new ElementsDeCalcul();
			eltCalc2.setTiers(tiers);
			getEntityManager().persist(eltCalc2);

			ComplementArriere cmplArr = new ComplementArriere();
			cmplArr.setIdTiers(tiers.getId());
			cmplArr.setEntree(eltCalc1);
			cmplArr.setSortie(eltCalc2);

			ArriereSignificatif as = new ArriereSignificatif();
			as.setDateDebut(LocalDate.of(2018, 12, 1));
			as.setDateFin(LocalDate.of(2018, 12, 3));
			as.setTiers(tiers);
			as.setComplement(cmplArr);
			getEntityManager().persist(as);

			RestTiersLocal tiersLoc = new RestTiersLocal();
			tiersLoc.setIdLocal("ID-TIERS-LOCAL-0009");
			tiersLoc.setCodeBanque("10107");
			tiersLoc.setCodeSegment("1010");
			tiersLoc.setDateDebut(LocalDate.of(2018, 12, 1));
			getEntityManager().persist(tiersLoc);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(tiersLoc);
			photoTiers.setDatePhoto(LocalDate.of(2018, 11, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("ND");
			photoTiers.setStatutCalcule("ND");
			photoTiers.setTopAS(true);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);
		});

		// Act
		lauchBatchDeclencheur("20181204");

		// Assert
		doInTransaction(() -> {
			List<Declencheur> declencheurs = findAllDeclencheurs();
			Assert.assertEquals(1, declencheurs.size());
			Assert.assertEquals("10107", declencheurs.get(0).getCodeBanque());
			Assert.assertEquals("ID-TIERS-LOCAL-0009", declencheurs.get(0).getIdLocal());
			Assert.assertEquals("TOPAS", declencheurs.get(0).getMotifDeclencheur());
		});
	}

	@Test
	public void declencheurTopFOui() {
		// Arrange - On crée le tiers + identite
		doInTransaction(() -> {
			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("ID-TIERS-LOCAL-0010");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.of(2018, 12, 1));
			tiers.addIdentite(id);

			Evenement evtF = new Evenement();
			evtF.setCode("F");
			evtF.setDateDebut(LocalDate.of(2018, 12, 1));
			evtF.setIdentiteInitiale(id);

			AuditFichiers af = new AuditFichiers();
			getEntityManager().persist(af);

			ComplementEvenement ceF = new ComplementEvenement();
			ceF.setDatePhoto(LocalDate.of(2018, 12, 1));
			ceF.setDateMaj(LocalDate.of(2018, 12, 1));
			ceF.setStatutEvt(StatutEvenement.ACT);
			ceF.setArriereLitige(false);
			ceF.setArriereTech(false);
			ceF.setAuditFichier(af);
			ceF.setIdentiteInitiale(id);
			evtF.addComplement(ceF);

			getEntityManager().persist(tiers);
			getEntityManager().persist(evtF);

			RestTiersLocal tiersLoc = new RestTiersLocal();
			tiersLoc.setIdLocal("ID-TIERS-LOCAL-0010");
			tiersLoc.setCodeBanque("10107");
			tiersLoc.setCodeSegment("1010");
			tiersLoc.setDateDebut(LocalDate.of(2018, 12, 1));
			getEntityManager().persist(tiersLoc);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(tiersLoc);
			photoTiers.setDatePhoto(LocalDate.of(2018, 11, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("ND");
			photoTiers.setStatutCalcule("ND");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);
		});

		// Act
		lauchBatchDeclencheur("20181201");

		// Assert
		doInTransaction(() -> {
			List<Declencheur> declencheurs = findAllDeclencheurs();
			Assert.assertEquals(1, declencheurs.size());
			Assert.assertEquals("10107", declencheurs.get(0).getCodeBanque());
			Assert.assertEquals("ID-TIERS-LOCAL-0010", declencheurs.get(0).getIdLocal());
			Assert.assertEquals("TOPF", declencheurs.get(0).getMotifDeclencheur());
		});
	}

	@Test
	public void nonDeclenchementTopFOuiInchange() {
		// Arrange - On crée le tiers + identite
		doInTransaction(() -> {
			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("ID-TIERS-LOCAL-0010");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.of(2018, 12, 1));
			tiers.addIdentite(id);

			Evenement evtF = new Evenement();
			evtF.setCode("F");
			evtF.setDateDebut(LocalDate.of(2018, 12, 1));
			evtF.setIdentiteInitiale(id);

			AuditFichiers af = new AuditFichiers();
			getEntityManager().persist(af);

			ComplementEvenement ceF = new ComplementEvenement();
			ceF.setDatePhoto(LocalDate.of(2018, 12, 1));
			ceF.setDateMaj(LocalDate.of(2018, 12, 1));
			ceF.setStatutEvt(StatutEvenement.ACT);
			ceF.setArriereLitige(false);
			ceF.setArriereTech(false);
			ceF.setAuditFichier(af);
			ceF.setIdentiteInitiale(id);
			evtF.addComplement(ceF);

			getEntityManager().persist(tiers);
			getEntityManager().persist(evtF);

			RestTiersLocal tiersLoc = new RestTiersLocal();
			tiersLoc.setIdLocal("ID-TIERS-LOCAL-0010");
			tiersLoc.setCodeBanque("10107");
			tiersLoc.setCodeSegment("1010");
			tiersLoc.setDateDebut(LocalDate.of(2018, 12, 1));
			getEntityManager().persist(tiersLoc);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(tiersLoc);
			photoTiers.setDatePhoto(LocalDate.of(2018, 11, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("ND");
			photoTiers.setStatutCalcule("ND");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(true);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);
		});

		// Act
		lauchBatchDeclencheur("20181201");

		// Assert
		doInTransaction(() -> {
			List<Declencheur> declencheurs = findAllDeclencheurs();
			Assert.assertTrue(declencheurs.isEmpty());
		});
	}

	@Test
	public void declencheurTopFNon() {
		// Arrange - On crée le tiers + identite
		doInTransaction(() -> {
			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("ID-TIERS-LOCAL-0011");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.of(2018, 12, 1));
			tiers.addIdentite(id);

			Evenement evtF = new Evenement();
			evtF.setCode("F");
			evtF.setDateDebut(LocalDate.of(2018, 12, 1));
			evtF.setIdentiteInitiale(id);

			AuditFichiers af = new AuditFichiers();
			getEntityManager().persist(af);

			ComplementEvenement ceF = new ComplementEvenement();
			ceF.setDatePhoto(LocalDate.of(2018, 12, 1));
			ceF.setDateMaj(LocalDate.of(2018, 12, 1));
			ceF.setStatutEvt(StatutEvenement.CLO);
			ceF.setArriereLitige(false);
			ceF.setArriereTech(false);
			ceF.setAuditFichier(af);
			ceF.setIdentiteInitiale(id);
			evtF.addComplement(ceF);

			getEntityManager().persist(tiers);
			getEntityManager().persist(evtF);

			RestTiersLocal tiersLoc = new RestTiersLocal();
			tiersLoc.setIdLocal("ID-TIERS-LOCAL-0011");
			tiersLoc.setCodeBanque("10107");
			tiersLoc.setCodeSegment("1010");
			tiersLoc.setDateDebut(LocalDate.of(2018, 12, 1));
			getEntityManager().persist(tiersLoc);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(tiersLoc);
			photoTiers.setDatePhoto(LocalDate.of(2018, 11, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("ND");
			photoTiers.setStatutCalcule("ND");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(true);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);
		});

		// Act
		lauchBatchDeclencheur("20181201");

		// Assert
		doInTransaction(() -> {
			List<Declencheur> declencheurs = findAllDeclencheurs();
			Assert.assertEquals(1, declencheurs.size());
			Assert.assertEquals("10107", declencheurs.get(0).getCodeBanque());
			Assert.assertEquals("ID-TIERS-LOCAL-0011", declencheurs.get(0).getIdLocal());
			Assert.assertEquals("TOPF", declencheurs.get(0).getMotifDeclencheur());
		});
	}

	@Test
	public void declencheurTopAOui() {
		// Arrange - On crée le tiers + identite
		doInTransaction(() -> {
			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("ID-TIERS-LOCAL-0012");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.of(2018, 12, 1));
			tiers.addIdentite(id);

			AuditFichiers af = new AuditFichiers();
			getEntityManager().persist(af);

			Evenement evtImx = new Evenement();
			evtImx.setCode("IMX");
			evtImx.setDateDebut(LocalDate.of(2018, 12, 1));
			evtImx.setIdentiteInitiale(id);
			ComplementEvenement ceImx = new ComplementEvenement();
			ceImx.setDatePhoto(LocalDate.of(2018, 12, 1));
			ceImx.setDateMaj(LocalDate.of(2018, 12, 1));
			ceImx.setStatutEvt(StatutEvenement.ACT);
			ceImx.setArriereLitige(false);
			ceImx.setArriereTech(false);
			ceImx.setAuditFichier(af);
			ceImx.setMontantArriere(BigDecimal.valueOf(100000l));
			ceImx.setIdentiteInitiale(id);
			evtImx.addComplement(ceImx);

			Evenement evtDax = new Evenement();
			evtDax.setCode("DAX");
			evtDax.setDateDebut(LocalDate.of(2018, 12, 1));
			evtDax.setIdentiteInitiale(id);
			ComplementEvenement ceDax = new ComplementEvenement();
			ceDax.setDatePhoto(LocalDate.of(2018, 12, 1));
			ceDax.setDateMaj(LocalDate.of(2018, 12, 1));
			ceDax.setStatutEvt(StatutEvenement.ACT);
			ceDax.setArriereLitige(false);
			ceDax.setArriereTech(false);
			ceDax.setAuditFichier(af);
			ceDax.setMontantArriere(BigDecimal.valueOf(100000l));
			ceDax.setIdentiteInitiale(id);
			evtDax.addComplement(ceDax);

			getEntityManager().persist(tiers);
			getEntityManager().persist(evtImx);
			getEntityManager().persist(evtDax);

			RestTiersLocal tiersLoc = new RestTiersLocal();
			tiersLoc.setIdLocal("ID-TIERS-LOCAL-0012");
			tiersLoc.setCodeBanque("10107");
			tiersLoc.setCodeSegment("1010");
			tiersLoc.setDateDebut(LocalDate.of(2018, 12, 1));
			getEntityManager().persist(tiersLoc);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(tiersLoc);
			photoTiers.setDatePhoto(LocalDate.of(2018, 11, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("ND");
			photoTiers.setStatutCalcule("ND");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);
		});

		// Act
		lauchBatchDeclencheur("20181205");

		// Assert
		doInTransaction(() -> {
			List<Declencheur> declencheurs = findAllDeclencheurs();
			Assert.assertEquals(1, declencheurs.size());
			Assert.assertEquals("10107", declencheurs.get(0).getCodeBanque());
			Assert.assertEquals("ID-TIERS-LOCAL-0012", declencheurs.get(0).getIdLocal());
			Assert.assertEquals("TOPA", declencheurs.get(0).getMotifDeclencheur());
		});
	}

	@Test
	public void nonDeclenchementTopAOuiInchange() {
		// Arrange - On crée le tiers + identite
		doInTransaction(() -> {
			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("ID-TIERS-LOCAL-0012");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.of(2018, 12, 1));
			tiers.addIdentite(id);

			AuditFichiers af = new AuditFichiers();
			getEntityManager().persist(af);

			Evenement evtImx = new Evenement();
			evtImx.setCode("IMX");
			evtImx.setDateDebut(LocalDate.of(2018, 12, 1));
			evtImx.setIdentiteInitiale(id);
			ComplementEvenement ceImx = new ComplementEvenement();
			ceImx.setDatePhoto(LocalDate.of(2018, 12, 1));
			ceImx.setDateMaj(LocalDate.of(2018, 12, 1));
			ceImx.setStatutEvt(StatutEvenement.ACT);
			ceImx.setArriereLitige(false);
			ceImx.setArriereTech(false);
			ceImx.setAuditFichier(af);
			ceImx.setMontantArriere(BigDecimal.valueOf(100000l));
			ceImx.setIdentiteInitiale(id);
			evtImx.addComplement(ceImx);

			Evenement evtDax = new Evenement();
			evtDax.setCode("DAX");
			evtDax.setDateDebut(LocalDate.of(2018, 12, 1));
			evtDax.setIdentiteInitiale(id);
			ComplementEvenement ceDax = new ComplementEvenement();
			ceDax.setDatePhoto(LocalDate.of(2018, 12, 1));
			ceDax.setDateMaj(LocalDate.of(2018, 12, 1));
			ceDax.setStatutEvt(StatutEvenement.ACT);
			ceDax.setArriereLitige(false);
			ceDax.setArriereTech(false);
			ceDax.setAuditFichier(af);
			ceDax.setMontantArriere(BigDecimal.valueOf(100000l));
			ceDax.setIdentiteInitiale(id);
			evtDax.addComplement(ceDax);

			getEntityManager().persist(tiers);
			getEntityManager().persist(evtImx);
			getEntityManager().persist(evtDax);

			RestTiersLocal tiersLoc = new RestTiersLocal();
			tiersLoc.setIdLocal("ID-TIERS-LOCAL-0012");
			tiersLoc.setCodeBanque("10107");
			tiersLoc.setCodeSegment("1010");
			tiersLoc.setDateDebut(LocalDate.of(2018, 12, 1));
			getEntityManager().persist(tiersLoc);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(tiersLoc);
			photoTiers.setDatePhoto(LocalDate.of(2018, 11, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("ND");
			photoTiers.setStatutCalcule("ND");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(true);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);
		});

		// Act
		lauchBatchDeclencheur("20181205");

		// Assert
		doInTransaction(() -> {
			List<Declencheur> declencheurs = findAllDeclencheurs();
			Assert.assertTrue(declencheurs.isEmpty());
		});
	}

	@Test
	public void declencheurTopANon() {
		// Arrange - On crée le tiers + identite
		doInTransaction(() -> {
			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("ID-TIERS-LOCAL-0013");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.of(2018, 12, 1));
			tiers.addIdentite(id);

			AuditFichiers af = new AuditFichiers();
			getEntityManager().persist(af);

			Evenement evtImx = new Evenement();
			evtImx.setCode("IMX");
			evtImx.setDateDebut(LocalDate.of(2018, 12, 1));
			evtImx.setIdentiteInitiale(id);
			ComplementEvenement ceImx = new ComplementEvenement();
			ceImx.setDatePhoto(LocalDate.of(2018, 12, 1));
			ceImx.setDateMaj(LocalDate.of(2018, 12, 1));
			ceImx.setStatutEvt(StatutEvenement.ANN);
			ceImx.setArriereLitige(false);
			ceImx.setArriereTech(false);
			ceImx.setAuditFichier(af);
			ceImx.setMontantArriere(BigDecimal.valueOf(100000l));
			ceImx.setIdentiteInitiale(id);
			evtImx.addComplement(ceImx);

			Evenement evtDax = new Evenement();
			evtDax.setCode("DAX");
			evtDax.setDateDebut(LocalDate.of(2018, 12, 1));
			evtDax.setIdentiteInitiale(id);
			ComplementEvenement ceDax = new ComplementEvenement();
			ceDax.setDatePhoto(LocalDate.of(2018, 12, 1));
			ceDax.setDateMaj(LocalDate.of(2018, 12, 1));
			ceDax.setStatutEvt(StatutEvenement.ANN);
			ceDax.setArriereLitige(false);
			ceDax.setArriereTech(false);
			ceDax.setAuditFichier(af);
			ceDax.setMontantArriere(BigDecimal.valueOf(100000l));
			ceDax.setIdentiteInitiale(id);
			evtDax.addComplement(ceDax);

			getEntityManager().persist(tiers);
			getEntityManager().persist(evtImx);
			getEntityManager().persist(evtDax);

			RestTiersLocal tiersLoc = new RestTiersLocal();
			tiersLoc.setIdLocal("ID-TIERS-LOCAL-0013");
			tiersLoc.setCodeBanque("10107");
			tiersLoc.setCodeSegment("1010");
			tiersLoc.setDateDebut(LocalDate.of(2018, 12, 1));
			getEntityManager().persist(tiersLoc);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(tiersLoc);
			photoTiers.setDatePhoto(LocalDate.of(2018, 11, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("ND");
			photoTiers.setStatutCalcule("ND");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(true);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);
		});

		// Act
		lauchBatchDeclencheur("20181205");

		// Assert
		doInTransaction(() -> {
			List<Declencheur> declencheurs = findAllDeclencheurs();
			Assert.assertEquals(1, declencheurs.size());
			Assert.assertEquals("10107", declencheurs.get(0).getCodeBanque());
			Assert.assertEquals("ID-TIERS-LOCAL-0013", declencheurs.get(0).getIdLocal());
			Assert.assertEquals("TOPA", declencheurs.get(0).getMotifDeclencheur());
		});
	}

	@Test
	public void declencheurTopPpOui() {
		// Arrange - On crée le tiers + identite
		doInTransaction(() -> {
			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("ID-TIERS-LOCAL-0014");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.of(2018, 12, 1));
			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			PeriodeProbatoire pp = new PeriodeProbatoire();
			pp.setDateDebut(LocalDate.of(2018, 12, 1));
			pp.setTiers(tiers);
			getEntityManager().persist(pp);

			ParMdcSeg parMdcSeg = new ParMdcSeg();
			parMdcSeg.setCodeParam(CodeParamMdc.DELAI_RAZ_PP);
			parMdcSeg.setCodeSegment(Constant.CHAMP_ETOILE);
			parMdcSeg.setDateDebut(LocalDate.of(2018, 12, 1));
			parMdcSeg.setValeurParam("15");
			getEntityManager().persist(parMdcSeg);

			RestTiersLocal tiersLoc = new RestTiersLocal();
			tiersLoc.setIdLocal("ID-TIERS-LOCAL-0014");
			tiersLoc.setCodeBanque("10107");
			tiersLoc.setCodeSegment("1010");
			tiersLoc.setDateDebut(LocalDate.of(2018, 12, 1));
			getEntityManager().persist(tiersLoc);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(tiersLoc);
			photoTiers.setDatePhoto(LocalDate.of(2018, 11, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("ND");
			photoTiers.setStatutCalcule("ND");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);
		});

		// Act
		lauchBatchDeclencheur("20181225");

		// Assert
		doInTransaction(() -> {
			List<Declencheur> declencheurs = findAllDeclencheurs();
			Assert.assertEquals(1, declencheurs.size());
			Assert.assertEquals("10107", declencheurs.get(0).getCodeBanque());
			Assert.assertEquals("ID-TIERS-LOCAL-0014", declencheurs.get(0).getIdLocal());
			Assert.assertEquals("TOPPP", declencheurs.get(0).getMotifDeclencheur());
		});
	}

	@Test
	public void nonDeclenchementTopPpOuiInchange() {
		// Arrange - On crée le tiers + identite
		doInTransaction(() -> {
			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("ID-TIERS-LOCAL-0014");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.of(2018, 12, 1));
			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			PeriodeProbatoire pp = new PeriodeProbatoire();
			pp.setDateDebut(LocalDate.of(2018, 12, 1));
			pp.setTiers(tiers);
			getEntityManager().persist(pp);

			ParMdcSeg parMdcSeg = new ParMdcSeg();
			parMdcSeg.setCodeParam(CodeParamMdc.DELAI_RAZ_PP);
			parMdcSeg.setCodeSegment(Constant.CHAMP_ETOILE);
			parMdcSeg.setDateDebut(LocalDate.of(2018, 12, 1));
			parMdcSeg.setValeurParam("15");
			getEntityManager().persist(parMdcSeg);

			RestTiersLocal tiersLoc = new RestTiersLocal();
			tiersLoc.setIdLocal("ID-TIERS-LOCAL-0014");
			tiersLoc.setCodeBanque("10107");
			tiersLoc.setCodeSegment("1010");
			tiersLoc.setDateDebut(LocalDate.of(2018, 12, 1));
			getEntityManager().persist(tiersLoc);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(tiersLoc);
			photoTiers.setDatePhoto(LocalDate.of(2018, 11, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("ND");
			photoTiers.setStatutCalcule("ND");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(true);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);
		});

		// Act
		lauchBatchDeclencheur("20181225");

		// Assert
		doInTransaction(() -> {
			List<Declencheur> declencheurs = findAllDeclencheurs();
			Assert.assertTrue(declencheurs.isEmpty());
		});
	}

	@Test
	public void declencheurTopPpNon() {
		// Arrange - On crée le tiers + identite
		doInTransaction(() -> {
			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("ID-TIERS-LOCAL-0015");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.of(2018, 12, 1));
			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			PeriodeProbatoire pp = new PeriodeProbatoire();
			pp.setDateDebut(LocalDate.of(2018, 12, 1));
			pp.setDateFin(LocalDate.of(2018, 12, 15));
			pp.setTiers(tiers);
			getEntityManager().persist(pp);

			ParMdcSeg parMdcSeg = new ParMdcSeg();
			parMdcSeg.setCodeParam(CodeParamMdc.DELAI_RAZ_PP);
			parMdcSeg.setCodeSegment(Constant.CHAMP_ETOILE);
			parMdcSeg.setDateDebut(LocalDate.of(2018, 12, 1));
			parMdcSeg.setValeurParam("15");
			getEntityManager().persist(parMdcSeg);

			RestTiersLocal tiersLoc = new RestTiersLocal();
			tiersLoc.setIdLocal("ID-TIERS-LOCAL-0015");
			tiersLoc.setCodeBanque("10107");
			tiersLoc.setCodeSegment("1010");
			tiersLoc.setDateDebut(LocalDate.of(2018, 12, 1));
			getEntityManager().persist(tiersLoc);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(tiersLoc);
			photoTiers.setDatePhoto(LocalDate.of(2018, 11, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("ND");
			photoTiers.setStatutCalcule("ND");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(true);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);
		});

		// Act
		lauchBatchDeclencheur("20181225");

		// Assert
		doInTransaction(() -> {
			List<Declencheur> declencheurs = findAllDeclencheurs();
			Assert.assertEquals(1, declencheurs.size());
			Assert.assertEquals("10107", declencheurs.get(0).getCodeBanque());
			Assert.assertEquals("ID-TIERS-LOCAL-0015", declencheurs.get(0).getIdLocal());
			Assert.assertEquals("TOPPP", declencheurs.get(0).getMotifDeclencheur());
		});
	}

	@Test
	public void declenchementW3() {
		// Arrange - On crée le tiers + identite
		doInTransaction(() -> {
			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("ID-TIERS-LOCAL-0016");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.of(2018, 12, 1));
			tiers.addIdentite(id);

			Evenement evtRad = new Evenement();
			evtRad.setCode("RAD");
			evtRad.setDateDebut(LocalDate.of(2018, 12, 1));
			evtRad.setIdentiteInitiale(id);

			AuditFichiers af = new AuditFichiers();
			af.setDateAudit(Date.valueOf(LocalDate.of(2018, 12, 5)));
			af.setDatePhoto(LocalDate.of(2018, 12, 5));
			getEntityManager().persist(af);

			ComplementEvenement ceRad = new ComplementEvenement();
			ceRad.setDatePhoto(LocalDate.of(2018, 12, 1));
			ceRad.setDateMaj(LocalDate.of(2018, 12, 1));
			ceRad.setStatutEvt(StatutEvenement.ACT);
			ceRad.setArriereLitige(false);
			ceRad.setArriereTech(false);
			ceRad.setAuditFichier(af);
			ceRad.setIdentiteInitiale(id);
			evtRad.addComplement(ceRad);

			getEntityManager().persist(tiers);
			getEntityManager().persist(evtRad);

			RestTiersLocal tiersLoc = new RestTiersLocal();
			tiersLoc.setIdLocal("ID-TIERS-LOCAL-0016");
			tiersLoc.setCodeBanque("10107");
			tiersLoc.setCodeSegment("1010");
			tiersLoc.setDateDebut(LocalDate.of(2018, 12, 1));
			getEntityManager().persist(tiersLoc);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(tiersLoc);
			photoTiers.setDatePhoto(LocalDate.of(2018, 11, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("ND");
			photoTiers.setStatutCalcule("ND");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);
		});

		// Act
		lauchBatchDeclencheur("20181205");

		// Assert
		doInTransaction(() -> {
			List<Declencheur> declencheurs = findAllDeclencheurs();
			Assert.assertEquals(1, declencheurs.size());
			Assert.assertEquals("10107", declencheurs.get(0).getCodeBanque());
			Assert.assertEquals("ID-TIERS-LOCAL-0016", declencheurs.get(0).getIdLocal());
			Assert.assertEquals("W3", declencheurs.get(0).getMotifDeclencheur());
		});
	}

	@Test
	public void nonDeclechementW3() {
		// Arrange - On crée le tiers + identite
		doInTransaction(() -> {
			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("ID-TIERS-LOCAL-0017");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.of(2018, 12, 1));
			tiers.addIdentite(id);

			Evenement evtRad = new Evenement();
			evtRad.setCode("RAD");
			evtRad.setDateDebut(LocalDate.of(2018, 12, 1));
			evtRad.setIdentiteInitiale(id);

			AuditFichiers af = new AuditFichiers();
			af.setDateAudit(Date.valueOf(LocalDate.of(2018, 12, 4)));
			af.setDatePhoto(LocalDate.of(2018, 12, 4));
			getEntityManager().persist(af);

			ComplementEvenement ceRad = new ComplementEvenement();
			ceRad.setDatePhoto(LocalDate.of(2018, 12, 1));
			ceRad.setDateMaj(LocalDate.of(2018, 12, 1));
			ceRad.setStatutEvt(StatutEvenement.ACT);
			ceRad.setArriereLitige(false);
			ceRad.setArriereTech(false);
			ceRad.setAuditFichier(af);
			ceRad.setIdentiteInitiale(id);
			evtRad.addComplement(ceRad);

			getEntityManager().persist(tiers);
			getEntityManager().persist(evtRad);

			RestTiersLocal tiersLoc = new RestTiersLocal();
			tiersLoc.setIdLocal("ID-TIERS-LOCAL-0017");
			tiersLoc.setCodeBanque("10107");
			tiersLoc.setCodeSegment("1010");
			tiersLoc.setDateDebut(LocalDate.of(2018, 12, 1));
			getEntityManager().persist(tiersLoc);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(tiersLoc);
			photoTiers.setDatePhoto(LocalDate.of(2018, 11, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("ND");
			photoTiers.setStatutCalcule("ND");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);
		});

		// Act
		lauchBatchDeclencheur("20181205");

		// Assert
		doInTransaction(() -> {
			List<Declencheur> declencheurs = findAllDeclencheurs();
			Assert.assertTrue(declencheurs.isEmpty());
		});
	}

	@Test
	public void declenchementW10() {
		// Arrange - On crée le tiers + identite
		doInTransaction(() -> {
			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("ID-TIERS-LOCAL-0018");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.of(2018, 12, 1));
			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			Evenement evtF = new Evenement();
			evtF.setCode("F");
			evtF.setDateDebut(LocalDate.of(2018, 12, 1));
			evtF.setIdContrat("contrat1");
			evtF.setIdentiteInitiale(id);

			AuditFichiers af = new AuditFichiers();
			af.setDateAudit(Date.valueOf(LocalDate.of(2018, 12, 5)));
			af.setDatePhoto(LocalDate.of(2018, 12, 5));
			getEntityManager().persist(af);

			ComplementEvenement ceF = new ComplementEvenement();
			ceF.setDatePhoto(LocalDate.of(2018, 12, 1));
			ceF.setDateMaj(LocalDate.of(2018, 12, 1));
			ceF.setStatutEvt(StatutEvenement.ACT);
			ceF.setArriereLitige(false);
			ceF.setArriereTech(false);
			ceF.setAuditFichier(af);
			ceF.setIdentiteInitiale(id);
			evtF.addComplement(ceF);
			getEntityManager().persist(evtF);

			Evenement evtImx = new Evenement();
			evtImx.setCode("IMX");
			evtImx.setDateDebut(LocalDate.of(2018, 12, 5));
			evtImx.setIdContrat("contrat1");
			evtImx.setIdentiteInitiale(id);
			ComplementEvenement ceImx = new ComplementEvenement();
			ceImx.setDatePhoto(LocalDate.of(2018, 12, 5));
			ceImx.setDateMaj(LocalDate.of(2018, 12, 5));
			ceImx.setStatutEvt(StatutEvenement.ACT);
			ceImx.setArriereLitige(false);
			ceImx.setArriereTech(false);
			ceImx.setAuditFichier(af);
			ceImx.setMontantArriere(BigDecimal.valueOf(100000l));
			ceImx.setIdentiteInitiale(id);
			evtImx.addComplement(ceImx);
			getEntityManager().persist(evtImx);

			RestTiersLocal tiersLoc = new RestTiersLocal();
			tiersLoc.setIdLocal("ID-TIERS-LOCAL-0018");
			tiersLoc.setCodeBanque("10107");
			tiersLoc.setCodeSegment("1010");
			tiersLoc.setDateDebut(LocalDate.of(2018, 12, 1));
			getEntityManager().persist(tiersLoc);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(tiersLoc);
			photoTiers.setDatePhoto(LocalDate.of(2018, 11, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("ND");
			photoTiers.setStatutCalcule("ND");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(true);
			photoTiers.setTopF(true);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);
		});

		// Act
		lauchBatchDeclencheur("20181205");

		// Assert
		doInTransaction(() -> {
			List<Declencheur> declencheurs = findAllDeclencheurs();
			Assert.assertEquals(1, declencheurs.size());
			Assert.assertEquals("10107", declencheurs.get(0).getCodeBanque());
			Assert.assertEquals("ID-TIERS-LOCAL-0018", declencheurs.get(0).getIdLocal());
			Assert.assertEquals("W10", declencheurs.get(0).getMotifDeclencheur());
		});
	}

	@Test
	public void nonDeclenchementW10() {
		// Arrange - On crée le tiers + identite
		doInTransaction(() -> {
			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("ID-TIERS-LOCAL-0019");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.of(2018, 12, 1));
			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			Evenement evtF = new Evenement();
			evtF.setCode("F");
			evtF.setDateDebut(LocalDate.of(2018, 12, 1));
			evtF.setIdContrat("contrat1");
			evtF.setIdentiteInitiale(id);

			AuditFichiers af = new AuditFichiers();
			af.setDateAudit(Date.valueOf(LocalDate.of(2018, 12, 4)));
			af.setDatePhoto(LocalDate.of(2018, 12, 4));
			getEntityManager().persist(af);

			ComplementEvenement ceF = new ComplementEvenement();
			ceF.setDatePhoto(LocalDate.of(2018, 12, 1));
			ceF.setDateMaj(LocalDate.of(2018, 12, 1));
			ceF.setStatutEvt(StatutEvenement.ACT);
			ceF.setArriereLitige(false);
			ceF.setArriereTech(false);
			ceF.setAuditFichier(af);
			ceF.setIdentiteInitiale(id);
			evtF.addComplement(ceF);
			getEntityManager().persist(evtF);

			Evenement evtImx = new Evenement();
			evtImx.setCode("IMX");
			evtImx.setDateDebut(LocalDate.of(2018, 12, 5));
			evtImx.setIdContrat("contrat1");
			evtImx.setIdentiteInitiale(id);
			ComplementEvenement ceImx = new ComplementEvenement();
			ceImx.setDatePhoto(LocalDate.of(2018, 12, 5));
			ceImx.setDateMaj(LocalDate.of(2018, 12, 5));
			ceImx.setStatutEvt(StatutEvenement.ACT);
			ceImx.setArriereLitige(false);
			ceImx.setArriereTech(false);
			ceImx.setAuditFichier(af);
			ceImx.setMontantArriere(BigDecimal.valueOf(100000l));
			ceImx.setIdentiteInitiale(id);
			evtImx.addComplement(ceImx);
			getEntityManager().persist(evtImx);

			RestTiersLocal tiersLoc = new RestTiersLocal();
			tiersLoc.setIdLocal("ID-TIERS-LOCAL-0019");
			tiersLoc.setCodeBanque("10107");
			tiersLoc.setCodeSegment("1010");
			tiersLoc.setDateDebut(LocalDate.of(2018, 12, 1));
			getEntityManager().persist(tiersLoc);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(tiersLoc);
			photoTiers.setDatePhoto(LocalDate.of(2018, 11, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("ND");
			photoTiers.setStatutCalcule("ND");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(true);
			photoTiers.setTopF(true);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);
		});

		// Act
		lauchBatchDeclencheur("20181205");

		// Assert
		doInTransaction(() -> {
			List<Declencheur> declencheurs = findAllDeclencheurs();
			Assert.assertTrue(declencheurs.isEmpty());
		});
	}

	@Test
	public void declencheurAvecPropagationRFT() {
		// Arrange - On crée le tiers + identite
		doInTransaction(() -> {
			TiersRFT rft1 = new TiersRFT();
			rft1.setCodeBanque("10107");
			rft1.setIdFederal("idFederal1");
			rft1.setIdLocal("ID-TIERS-LOCAL-0020");
			rft1.setDate(LocalDate.of(2018, 12, 1));
			getEntityManager().persist(rft1);

			TiersRFT rft2 = new TiersRFT();
			rft2.setCodeBanque("10107");
			rft2.setIdFederal("idFederal1");
			rft2.setIdLocal("ID-TIERS-LOCAL-0021");
			rft2.setDate(LocalDate.of(2018, 12, 1));
			getEntityManager().persist(rft2);

			Tiers tiers = new Tiers();
			tiers.setIdFederal("idFederal1");
			IdentiteTiers id1 = new IdentiteTiers();
			id1.setCodeBanque("10107");
			id1.setIdLocal("ID-TIERS-LOCAL-0020");
			id1.setCodeSegment("1010");
			id1.setDateDebut(LocalDate.of(2018, 12, 1));
			tiers.addIdentite(id1);
			getEntityManager().persist(tiers);

			StatutHistorise statusTiers = new StatutHistorise();
			statusTiers.setStatut(StatutTiers.SAIN);
			statusTiers.setAnnule(Boolean.FALSE);
			statusTiers.setDateDeb(LocalDate.of(2018, 12, 1));
			statusTiers.setTiers(tiers);
			getEntityManager().persist(statusTiers);
		});

		// Act
		lauchBatchDeclencheur("20181201");

		// Assert
		doInTransaction(() -> {
			List<Declencheur> declencheurs = findAllDeclencheurs();
			Assert.assertEquals(2, declencheurs.size());
			Assert.assertEquals("idFederal1", declencheurs.get(0).getIdRFT());
			Assert.assertEquals("ID-TIERS-LOCAL-0020", declencheurs.get(0).getIdLocal());
			Assert.assertEquals("STCL", declencheurs.get(0).getMotifDeclencheur());
			Assert.assertEquals("idFederal1", declencheurs.get(1).getIdRFT());
			Assert.assertEquals("ID-TIERS-LOCAL-0021", declencheurs.get(1).getIdLocal());
			Assert.assertEquals("RFTCA", declencheurs.get(1).getMotifDeclencheur());
		});
	}

	@Test
	public void declencheurTiersBvInconnuMDC() {
		doInTransaction(() -> {
			StatutSbv sbv = new StatutSbv();
			sbv.setCodeBanque("10107");
			sbv.setIdLocal("ID-TIERS-LOCAL-0022");
			sbv.setStatutForce("D");
			sbv.setGravite("CX");
			sbv.setDateDebut(LocalDate.of(2018, 12, 15));
			sbv.setUtilisateurModif("ndod");
			sbv.setCodificationMotif("motif1");
			sbv.setCommentaire("commentaire1");
			getEntityManager().persist(sbv);
		});

		// Act
		lauchBatchDeclencheur("20181220");

		// Assert
		doInTransaction(() -> {
			List<Declencheur> declencheurs = findAllDeclencheurs();
			Assert.assertEquals(1, declencheurs.size());
			Assert.assertEquals("10107", declencheurs.get(0).getCodeBanque());
			Assert.assertEquals("ID-TIERS-LOCAL-0022", declencheurs.get(0).getIdLocal());
			Assert.assertEquals("SBVNR", declencheurs.get(0).getMotifDeclencheur());
		});
	}

	@Test
	public void nonDeclenchementTiersBvInconnuMDCInchange() {
		doInTransaction(() -> {
			StatutSbv sbv = new StatutSbv();
			sbv.setCodeBanque("10107");
			sbv.setIdLocal("ID-TIERS-LOCAL-0022");
			sbv.setStatutForce("D");
			sbv.setGravite("CX");
			sbv.setDateDebut(LocalDate.of(2018, 12, 15));
			sbv.setUtilisateurModif("ndod");
			sbv.setCodificationMotif("motif1");
			sbv.setCommentaire("commentaire1");
			getEntityManager().persist(sbv);

			RestTiersLocal tiersLoc = new RestTiersLocal();
			tiersLoc.setIdLocal("ID-TIERS-LOCAL-0022");
			tiersLoc.setCodeBanque("10107");
			tiersLoc.setCodeSegment("1010");
			tiersLoc.setDateDebut(LocalDate.of(2018, 12, 1));
			getEntityManager().persist(tiersLoc);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(tiersLoc);
			photoTiers.setDatePhoto(LocalDate.of(2018, 11, 1));
			photoTiers.setOrigineStatutEffectif("BV");
			photoTiers.setStatutEffectif("D");
			photoTiers.setPalierEffectif("CX");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(true);
			photoTiers.setTopF(true);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);
		});

		// Act
		lauchBatchDeclencheur("20181220");

		// Assert
		doInTransaction(() -> {
			List<Declencheur> declencheurs = findAllDeclencheurs();
			Assert.assertTrue(declencheurs.isEmpty());
		});
	}

	@Test
	public void declencheurCodeSegmentDifferent() {
		// Arrange - On crée le tiers + identite
		doInTransaction(() -> {
			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("ID-TIERS-LOCAL-0001");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.of(2018, 12, 1));
			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			StatutHistorise statusTiers = new StatutHistorise();
			statusTiers.setStatut(StatutTiers.SAIN);
			statusTiers.setAnnule(Boolean.FALSE);
			statusTiers.setDateDeb(LocalDate.of(2018, 12, 1));
			statusTiers.setTiers(tiers);
			getEntityManager().persist(statusTiers);

			RestTiersLocal tiersLoc = new RestTiersLocal();
			tiersLoc.setIdLocal("ID-TIERS-LOCAL-0001");
			tiersLoc.setCodeBanque("10107");
			tiersLoc.setCodeSegment("1020");
			tiersLoc.setDateDebut(LocalDate.of(2018, 12, 1));
			getEntityManager().persist(tiersLoc);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(tiersLoc);
			photoTiers.setDatePhoto(LocalDate.of(2018, 11, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("ND");
			photoTiers.setStatutCalcule("ND");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);
		});

		// Act
		lauchBatchDeclencheur("20181201");

		// Assert
		doInTransaction(() -> {
			List<Declencheur> declencheurs = findAllDeclencheurs();
			Assert.assertEquals(1, declencheurs.size());
			Assert.assertEquals("10107", declencheurs.get(0).getCodeBanque());
			Assert.assertEquals("ID-TIERS-LOCAL-0001", declencheurs.get(0).getIdLocal());
			Assert.assertEquals("SEG", declencheurs.get(0).getMotifDeclencheur());
		});
	}

	@Test
	public void declencheurSirenDifferent() {
		// Arrange - On crée le tiers + identite
		doInTransaction(() -> {
			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("ID-TIERS-LOCAL-0001");
			id.setCodeSegment("1010");
			id.setSiren("siren1");
			id.setDateDebut(LocalDate.of(2018, 12, 1));
			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			StatutHistorise statusTiers = new StatutHistorise();
			statusTiers.setStatut(StatutTiers.SAIN);
			statusTiers.setAnnule(Boolean.FALSE);
			statusTiers.setDateDeb(LocalDate.of(2018, 12, 1));
			statusTiers.setTiers(tiers);
			getEntityManager().persist(statusTiers);

			RestTiersSiren siren = new RestTiersSiren();
			siren.setSiren("siren2");
			getEntityManager().persist(siren);

			RestAssociateRftSiren assoc = new RestAssociateRftSiren();
			assoc.setRestIdSiren(siren);
			getEntityManager().persist(assoc);

			RestTiersLocal tiersLoc = new RestTiersLocal();
			tiersLoc.setIdLocal("ID-TIERS-LOCAL-0001");
			tiersLoc.setCodeBanque("10107");
			tiersLoc.setCodeSegment("1010");
			tiersLoc.setDateDebut(LocalDate.of(2018, 12, 1));
			tiersLoc.setRestAssoRftSiren(assoc);
			getEntityManager().persist(tiersLoc);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(tiersLoc);
			photoTiers.setDatePhoto(LocalDate.of(2018, 11, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("ND");
			photoTiers.setStatutCalcule("ND");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);
		});

		// Act
		lauchBatchDeclencheur("20181201");

		// Assert
		doInTransaction(() -> {
			List<Declencheur> declencheurs = findAllDeclencheurs();
			Assert.assertEquals(1, declencheurs.size());
			Assert.assertEquals("10107", declencheurs.get(0).getCodeBanque());
			Assert.assertEquals("ID-TIERS-LOCAL-0001", declencheurs.get(0).getIdLocal());
			Assert.assertEquals("SIR", declencheurs.get(0).getMotifDeclencheur());
		});
	}

	@Test
	public void declencheurRftDifferent() {
		// Arrange - On crée le tiers + identite
		doInTransaction(() -> {
			Tiers tiers = new Tiers();
			tiers.setIdFederal("idFederal1");

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("ID-TIERS-LOCAL-0001");
			id.setCodeSegment("1010");
			id.setSiren("siren1");
			id.setDateDebut(LocalDate.of(2018, 12, 1));
			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			StatutHistorise statusTiers = new StatutHistorise();
			statusTiers.setStatut(StatutTiers.SAIN);
			statusTiers.setAnnule(Boolean.FALSE);
			statusTiers.setDateDeb(LocalDate.of(2018, 12, 1));
			statusTiers.setTiers(tiers);
			getEntityManager().persist(statusTiers);

			RestTiersSiren siren = new RestTiersSiren();
			siren.setSiren("siren2");
			getEntityManager().persist(siren);

			RestTiersIdRft rft = new RestTiersIdRft();
			rft.setIdRft("idFederal2");
			getEntityManager().persist(rft);

			RestAssociateRftSiren assoc = new RestAssociateRftSiren();
			assoc.setRestIdSiren(siren);
			assoc.setRestIdRFT(rft);
			getEntityManager().persist(assoc);

			RestTiersLocal tiersLoc = new RestTiersLocal();
			tiersLoc.setIdLocal("ID-TIERS-LOCAL-0001");
			tiersLoc.setCodeBanque("10107");
			tiersLoc.setCodeSegment("1010");
			tiersLoc.setDateDebut(LocalDate.of(2018, 12, 1));
			tiersLoc.setRestAssoRftSiren(assoc);
			getEntityManager().persist(tiersLoc);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(tiersLoc);
			photoTiers.setDatePhoto(LocalDate.of(2018, 11, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("ND");
			photoTiers.setStatutCalcule("ND");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);
		});

		// Act
		lauchBatchDeclencheur("20181201");

		// Assert
		doInTransaction(() -> {
			List<Declencheur> declencheurs = findAllDeclencheurs();
			Assert.assertEquals(1, declencheurs.size());
			Assert.assertEquals("10107", declencheurs.get(0).getCodeBanque());
			Assert.assertEquals("ID-TIERS-LOCAL-0001", declencheurs.get(0).getIdLocal());
			Assert.assertEquals("RFT", declencheurs.get(0).getMotifDeclencheur());
		});
	}

	@Test
	public void declencheurCodeSegmentDifferentTiersPartage() {
		// Arrange - On crée le tiers + identite
		doInTransaction(() -> {
			TiersRFT rft1 = new TiersRFT();
			rft1.setCodeBanque("10107");
			rft1.setIdFederal("idFederal1");
			rft1.setIdLocal("ID-TIERS-LOCAL-0001");
			rft1.setDate(LocalDate.of(2018, 12, 1));
			getEntityManager().persist(rft1);

			TiersRFT rft2 = new TiersRFT();
			rft2.setCodeBanque("10107");
			rft2.setIdFederal("idFederal1");
			rft2.setIdLocal("ID-TIERS-LOCAL-0002");
			rft2.setDate(LocalDate.of(2018, 12, 1));
			getEntityManager().persist(rft2);

			Tiers tiers = new Tiers();
			tiers.setIdFederal("idFederal1");

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("ID-TIERS-LOCAL-0001");
			id.setCodeSegment("1010");
			id.setSiren("siren1");
			id.setDateDebut(LocalDate.of(2018, 12, 1));
			tiers.addIdentite(id);

			IdentiteTiers id2 = new IdentiteTiers();
			id2.setCodeBanque("10107");
			id2.setIdLocal("ID-TIERS-LOCAL-0002");
			id2.setCodeSegment("1020");
			id2.setSiren("siren1");
			id2.setDateDebut(LocalDate.of(2018, 12, 1));
			tiers.addIdentite(id2);
			getEntityManager().persist(tiers);

			StatutHistorise statusTiers = new StatutHistorise();
			statusTiers.setStatut(StatutTiers.SAIN);
			statusTiers.setAnnule(Boolean.FALSE);
			statusTiers.setDateDeb(LocalDate.of(2018, 12, 1));
			statusTiers.setTiers(tiers);
			getEntityManager().persist(statusTiers);

			RestTiersSiren siren = new RestTiersSiren();
			siren.setSiren("siren1");
			getEntityManager().persist(siren);

			RestTiersIdRft rft = new RestTiersIdRft();
			rft.setIdRft("idFederal1");
			getEntityManager().persist(rft);

			RestAssociateRftSiren assoc = new RestAssociateRftSiren();
			assoc.setRestIdSiren(siren);
			assoc.setRestIdRFT(rft);
			getEntityManager().persist(assoc);

			RestTiersLocal tiersLoc = new RestTiersLocal();
			tiersLoc.setIdLocal("ID-TIERS-LOCAL-0001");
			tiersLoc.setCodeBanque("10107");
			tiersLoc.setCodeSegment("1010");
			tiersLoc.setDateDebut(LocalDate.of(2018, 12, 1));
			tiersLoc.setRestAssoRftSiren(assoc);
			getEntityManager().persist(tiersLoc);

			RestTiersLocal tiersLoc2 = new RestTiersLocal();
			tiersLoc2.setIdLocal("ID-TIERS-LOCAL-0002");
			tiersLoc2.setCodeBanque("10107");
			tiersLoc2.setCodeSegment("1030");
			tiersLoc2.setDateDebut(LocalDate.of(2018, 12, 1));
			tiersLoc2.setRestAssoRftSiren(assoc);
			getEntityManager().persist(tiersLoc2);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(tiersLoc);
			photoTiers.setDatePhoto(LocalDate.of(2018, 11, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("ND");
			photoTiers.setStatutCalcule("ND");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);

			RestSynthTierLocalStatus photoTiers2 = new RestSynthTierLocalStatus();
			photoTiers2.setRestRechTiersLocal(tiersLoc2);
			photoTiers2.setDatePhoto(LocalDate.of(2018, 11, 1));
			photoTiers2.setOrigineStatutEffectif("STC");
			photoTiers2.setStatutEffectif("ND");
			photoTiers2.setStatutCalcule("ND");
			photoTiers2.setTopAS(false);
			photoTiers2.setTopPP(false);
			photoTiers2.setTopA(false);
			photoTiers2.setTopF(false);
			photoTiers2.setWarning3(false);
			photoTiers2.setWarning10(false);
			getEntityManager().persist(photoTiers2);
		});

		// Act
		lauchBatchDeclencheur("20181201");

		// Assert
		doInTransaction(() -> {
			List<Declencheur> declencheurs = findAllDeclencheurs();
			Assert.assertEquals(2, declencheurs.size());
			Assert.assertEquals("10107", declencheurs.get(0).getCodeBanque());
			Assert.assertEquals("ID-TIERS-LOCAL-0002", declencheurs.get(0).getIdLocal());
			Assert.assertEquals("SEG", declencheurs.get(0).getMotifDeclencheur());
			Assert.assertEquals("10107", declencheurs.get(1).getCodeBanque());
			Assert.assertEquals("ID-TIERS-LOCAL-0001", declencheurs.get(1).getIdLocal());
			Assert.assertEquals("RFTCA", declencheurs.get(1).getMotifDeclencheur());
			Assert.assertEquals("1010", declencheurs.get(1).getCodeSegment());
		});
	}

	private BatchStatus lauchBatchDeclencheur(String dateLaunch) {
		Job job = (Job) context.getBean(Constant.JOB_DECLENCHEUR);
		JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");
		Long guid = java.util.UUID.randomUUID().getMostSignificantBits();
		JobParameters jobParameters = new JobParametersBuilder().addString("date", dateLaunch).addLong("guid", guid)
				.toJobParameters();
		try {
			JobExecution execution = jobLauncher.run(job, jobParameters);
			return execution.getStatus();
		} catch (Exception e) {
			e.printStackTrace();
			return BatchStatus.UNKNOWN;
		}
	}

	@BeforeClass
	public static void initSpringContext() throws NoSuchFieldException, IllegalAccessException, IOException {
		initSpring();
	}

	/**
	 * Vider les tables après chaque test
	 */
	@After
	public void resetData() {
		deleteAllTables();

	}

	/**
	 * Utilitaire pour assertions : retourne liste de Declencheur
	 *
	 * @return List<Declencheur>
	 */
	public List<Declencheur> findAllDeclencheurs() {
		EntityManager entityManager = getEntityManager();
		TypedQuery<Declencheur> query = entityManager.createQuery("select s from Declencheur s", Declencheur.class);
		return query.getResultList();
	}

	public List<RestCliDecl> findAllCli() {
		EntityManager entityManager = getEntityManager();
		TypedQuery<RestCliDecl> query = entityManager.createQuery("select s from RestCliDecl s", RestCliDecl.class);
		return query.getResultList();
	}
}
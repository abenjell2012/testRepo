package bpce.yyd.batch.declencheur.writer;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;

import bpce.yyd.batch.declencheur.beans.DataTableCli;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Setter
@Slf4j
public class WriterTableCli implements ItemWriter<DataTableCli> {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	private static final String INSERT_QUERY_REST_CLI_DECL = "insert into REST_CLI_DECL "
			+ "(TIERS_ID, ID_RFT, ID_LOCAL, CODE_BANQUE, SIREN, CODE_SEGMENT) " 
			+ "values (?,?,?,?,?,?)";
	
	@Override
	public void write(List<? extends DataTableCli> items) throws Exception {

		log.info("Début de chargement de: " + items.size() + " lignes");

		jdbcTemplate.batchUpdate(INSERT_QUERY_REST_CLI_DECL, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				
				ps.setString(1, items.get(i).getTiersID());
				ps.setString(2, items.get(i).getIdRFT());
				ps.setString(3, items.get(i).getIdLocal());
				ps.setString(4, items.get(i).getCodeBanque());
				ps.setString(5, items.get(i).getSiren());
				ps.setString(6, items.get(i).getCodeSegment());
			}

			@Override
			public int getBatchSize() {
				return items.size();
			}
		});
	}
}
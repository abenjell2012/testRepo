package bpce.yyd.batch.declencheur.writer;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;

import bpce.yyd.batch.declencheur.beans.DataTableTemp;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Setter
@Slf4j
public class WriterTableTemp implements ItemWriter<DataTableTemp> {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	private static final String INSERT_QUERY_REST_DECL_LAST_SYNTH = "insert into REST_DECL_LAST_SYNTH "
			+ "(ID_RFT,ID_LOCAL,CODE_BANQUE,CODE_SEGMENT,SIREN,DATE_PHOTO,STATUT_EFFECTIF,PALIER_EFFECTIF,ORIGINE_STATUT_EFFECTIF,STATUT_CALCULE,PALIER_CALCULE,TOP_PP,TOP_F,TOP_A,TOP_AS) "
			+ "values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

	@Override
	public void write(List<? extends DataTableTemp> items) throws Exception {

		log.info("Début de chargement de: " + items.size() + " lignes");

		jdbcTemplate.batchUpdate(INSERT_QUERY_REST_DECL_LAST_SYNTH, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {

				ps.setString(1, items.get(i).getIdRFT());
				ps.setString(2, items.get(i).getIdLocal());
				ps.setString(3, items.get(i).getCodeBanque());
				ps.setString(4, items.get(i).getCodeSegment());
				ps.setString(5, items.get(i).getSiren());
				ps.setDate(6, items.get(i).getDatePhoto());
				ps.setString(7, items.get(i).getStatutEffectif());
				ps.setString(8, items.get(i).getPalierEffectif());
				ps.setString(9, items.get(i).getOrigineStatutEffectif());
				ps.setString(10, items.get(i).getStatutCalcule());
				ps.setString(11, items.get(i).getPalierCalcule());
				ps.setBoolean(12, items.get(i).isTopPP());
				ps.setBoolean(13, items.get(i).isTopF());
				ps.setBoolean(14, items.get(i).isTopA());
				ps.setBoolean(15, items.get(i).isTopAS());
			}

			@Override
			public int getBatchSize() {
				return items.size();
			}
		});
	}
}
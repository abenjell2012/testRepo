package bpce.yyd.batch.declencheur.processor;

import java.sql.Date;
import java.time.LocalDate;

import org.springframework.batch.item.ItemProcessor;

import bpce.yyd.batch.declencheur.beans.DataDeclencheur;
import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.commun.model.Declencheur;
import lombok.Setter;

@Setter
public class CalculDeclencheurProcessor implements ItemProcessor<DataDeclencheur, Declencheur> {

	private String date;

	@Override
	public Declencheur process(DataDeclencheur data) throws Exception {
		LocalDate dateBatch = LocalDate.parse(date, Constant.YYYYMMDD_FORMATTER);
		Date dateDebut = Date.valueOf(dateBatch);

		Declencheur declencheur = new Declencheur();
		declencheur.setTiers(data.getTiersId());
		declencheur.setIdLocal(data.getIdLocal());
		declencheur.setCodeBanque(data.getCodeBanque());
		declencheur.setCodeSegment(data.getCodeSegment());
		declencheur.setSiren(data.getSiren());
		declencheur.setIdRFT(data.getIdRFT());
		declencheur.setDateDernierePhoto(data.getDateDernierePhoto());
		declencheur.setDateDeclencheur(dateDebut);
		declencheur.setMotifDeclencheur(data.getMotifDeclencheur());

		return declencheur;
	}

}

package bpce.yyd.batch.declencheur.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import bpce.yyd.batch.declencheur.beans.DataDeclencheur;

public class DataDeclencheurIndexRowMapper implements RowMapper<DataDeclencheur> {

	@Override
	public DataDeclencheur mapRow(ResultSet rs, int rowNum) throws SQLException {

		DataDeclencheur data = new DataDeclencheur();

		data.setTiersId(rs.getLong(1));
		data.setIdRFT(rs.getString(2));
		data.setSiren(rs.getString(3));
		data.setIdLocal(rs.getString(4));
		data.setCodeBanque(rs.getString(5));
		data.setCodeSegment(rs.getString(6));
		data.setDateDernierePhoto(rs.getDate(7));
		data.setMotifDeclencheur(rs.getString(8));
		return data;
	}
}

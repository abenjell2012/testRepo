package bpce.yyd.batch.declencheur.task;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.stereotype.Service;

import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.commun.utils.SpringBatchUtil;

@Service
public class VidageDeclencheurADate implements Tasklet {

	private static final String DELETE_QUERY_DECLENCHEURS = "DELETE from REST_DECLENCHEURS where DATE_DECLENCHEUR = ?";

	private String date;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		LocalDate dateBatch = LocalDate.parse(date, Constant.YYYYMMDD_FORMATTER);
		Date dateDebut = Date.valueOf(dateBatch);

		int retour = jdbcTemplate.update(DELETE_QUERY_DECLENCHEURS, new PreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setDate(1, dateDebut);
			}
		});
		StepExecution stepExec = SpringBatchUtil.getStepExecution(chunkContext);
		stepExec.setWriteCount(retour);
		return RepeatStatus.FINISHED;
	}

	public void setDate(String date) {
		this.date = date;
	}
}

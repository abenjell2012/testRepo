package bpce.yyd.batch.declencheur.beans;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DataTableCli {
	private String tiersID;

	private String idRFT;

	private String idLocal;

	private String codeBanque;

	private String codeSegment;

	private String siren;
}

package bpce.yyd.batch.declencheur.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import bpce.yyd.batch.declencheur.beans.DataTableCli;

public class DataTableCliIndexRowMapper implements RowMapper<DataTableCli> {

	@Override
	public DataTableCli mapRow(ResultSet rs, int rowNum) throws SQLException {

		DataTableCli data = new DataTableCli();
        data.setTiersID(rs.getString(1));
		data.setIdRFT(rs.getString(2));
		data.setIdLocal(rs.getString(3));
		data.setCodeBanque(rs.getString(4));
		data.setSiren(rs.getString(5));
		data.setCodeSegment(rs.getString(6));

		return data;
	}
}

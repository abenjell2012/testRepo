package bpce.yyd.batch.declencheur.launch;

import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.batchStatus;
import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.exitWithErrorCode;
import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.finaliserTraitement;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import org.apache.log4j.PropertyConfigurator;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import fr.bpce.yyd.batch.commun.constantes.Constant;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class Launcher {

	private ApplicationContext context = null;

	public void setApplicationContext(ApplicationContext newContext) {
		context = newContext;
	}

	public ApplicationContext getApplicationContext() {
		if (context == null) {
			context = new ClassPathXmlApplicationContext("classpath:JobLauncher-context.xml");
		}
		return context;
	}

	public void runBatch(String date) {

		log.info("Debut BATCH NDOD : declencheur");

		String dateLaunch;
		if (date != null) {
			dateLaunch = date;
		} else {
			dateLaunch = LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE);
		}

		try {
			Job job = (Job) getApplicationContext().getBean(Constant.JOB_DECLENCHEUR);
			JobLauncher jobLauncher = (JobLauncher) getApplicationContext().getBean("jobLauncher");
			runJob(dateLaunch, job, jobLauncher);
		} catch (Exception err) {
			log.error("Erreur inattendue : " + err.getMessage(), err);
			exitWithErrorCode(1);
		}
		log.info("Fin BATCH NDOD");

	}

	private void runJob(String dateLaunch, Job job, JobLauncher jobLauncher) {
		JobExecution execution = null;
		Long guid = java.util.UUID.randomUUID().getMostSignificantBits();
		JobParameters jobParameters = new JobParametersBuilder().addString("date", dateLaunch).addLong("guid", guid)
				.toJobParameters();
		try {
			execution = jobLauncher.run(job, jobParameters);
		} catch (Exception err) {
			log.error("Erreur inattendue : " + err.getMessage(), err);
			exitWithErrorCode(1);
		} finally {
			finaliserTraitement(batchStatus(execution));
		}
	}

	public static void main(String[] args) {

		PropertyConfigurator.configure(ClassLoader.getSystemClassLoader().getResource("log4j-declencheur.properties"));
		Launcher launcher = new Launcher();
		String date = LocalDate.now().format(DateTimeFormatter.BASIC_ISO_DATE);

		if (args == null || args.length == 0) {
			log.info("Auncun parametre date en paremetre, on prend la date du jour <" + date + ">");
			launcher.runBatch(date);
		} else if (args.length == 1) {
			String dateArgs = args[0];
			log.info("Parametre date passe en paremetre  <" + dateArgs + ">");
			try {
				LocalDate.parse(dateArgs, DateTimeFormatter.BASIC_ISO_DATE);
				date = dateArgs; // Le format est bon
				log.info("Parametre date formate <" + date + ">");
			} catch (DateTimeParseException dtpe) {
				log.error("Erreur le format de la date passe en parametre est incorrect " + args[0]);
				exitWithErrorCode(1);
			}
			launcher.runBatch(date);
		} else if (args.length > 1) {
			log.error("Erreur - mauvais paramètres en entrée, on attend pas plus d'1 paramètre");
			exitWithErrorCode(1);
		}
	}
}
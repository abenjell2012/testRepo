package bpce.yyd.batch.restit_evenement_mensuel;

import org.junit.Assert;
import org.junit.Test;

public class UnitBidonTest {

	@Test
	public void test() {
		int value = 10;
		Assert.assertEquals(10, value);
	}
}

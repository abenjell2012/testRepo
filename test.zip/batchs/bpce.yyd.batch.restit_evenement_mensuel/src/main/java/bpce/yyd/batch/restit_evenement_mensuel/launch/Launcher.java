package bpce.yyd.batch.restit_evenement_mensuel.launch;

import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.batchStatus;
import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.exitWithErrorCode;
import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.finaliserTraitement;

import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import org.apache.log4j.PropertyConfigurator;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import fr.bpce.yyd.batch.commun.constantes.Constant;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class Launcher {

	private ApplicationContext context = null;

	public void setApplicationContext(ApplicationContext newContext) {
		context = newContext;
	}

	public ApplicationContext getApplicationContext() {
		if (context == null) {
			context = new ClassPathXmlApplicationContext("classpath:JobLauncher-context.xml");
		}
		return context;
	}

	public void runBatch(String strDateCalcul) {

		log.info("Debut BATCH NDOD : Evenement Mensuel");

		JobExecution execution = null;
		try {

			Job job = (Job) getApplicationContext().getBean(Constant.JOB_EVENEMENT_MENSUEL);
			JobLauncher jobLauncher = (JobLauncher) getApplicationContext().getBean("jobLauncher");
			JobParameters jobParameters = new JobParametersBuilder().addString("dateCalcul", strDateCalcul)
					.addDate("dateSql", Date.valueOf(LocalDate.parse(strDateCalcul, Constant.YYYYMMDD_FORMATTER)))
					.addLong("time", System.currentTimeMillis()).toJobParameters();

			execution = jobLauncher.run(job, jobParameters);
		} catch (Exception err) {
			log.error("Erreur inattendue pour le batch " + Constant.JOB_EVENEMENT_MENSUEL + " " + err.getMessage(),
					err);
			exitWithErrorCode(1);
		} finally {
			finaliserTraitement(batchStatus(execution));
		}
	}

	public static void main(String[] args) {
		PropertyConfigurator.configure(
				ClassLoader.getSystemClassLoader().getResource("log4j-synthese-evenements-mensuel.properties"));
		// Paramètre (éventuel) : date pour laquelle on calcule.
		// Sinon, ce sera la date du jour.
		String strDateCalcul = LocalDate.now().format(DateTimeFormatter.BASIC_ISO_DATE);
		if (args != null && args.length == 1) {
			String date = args[0];
			try {
				LocalDate.parse(date, DateTimeFormatter.BASIC_ISO_DATE);
				strDateCalcul = date; // Le format est bon
			} catch (DateTimeParseException dtpe) {
				log.error("Erreur le format de la date passe en parametre est incorrect " + args[0]);
				exitWithErrorCode(1);		
			}
		} else if (args != null && args.length > 1) {
			log.error("Erreur - mauvais paramètres en entrée, on attend pas plus d'1 paramètre");
			exitWithErrorCode(1);
		}

		Launcher launcher = new Launcher();
		launcher.runBatch(strDateCalcul);
	}
}
package bpce.yyd.batch.restit_evenement_mensuel.task;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import fr.bpce.yyd.batch.commun.utils.CalculStatsUtils;

public class CalculStatsInitTasklet implements Tasklet {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

		// tables moteurs/collecte
		CalculStatsUtils.calculStatTable(jdbcTemplate, "COMPLEMENT_EVENEMENT", 8);
		CalculStatsUtils.calculStatTable(jdbcTemplate, "AUDIT_FICHIERS", 4);
		CalculStatsUtils.calculStatTable(jdbcTemplate, "EVENEMENT", 4);
		CalculStatsUtils.calculStatTable(jdbcTemplate, "IDENTITE_TIERS", 4);
		CalculStatsUtils.calculStatTable(jdbcTemplate, "TIERS", 4);
		CalculStatsUtils.calculStatTable(jdbcTemplate, "EVENEMENT_CALCULE", 4);
		CalculStatsUtils.calculStatTable(jdbcTemplate, "AUDIT_CALCUL", 4);

		// tables SYNTHESE
		CalculStatsUtils.calculStatTable(jdbcTemplate, "REST_TIERS_ID_LOCAL", 4);
		CalculStatsUtils.calculStatTable(jdbcTemplate, "REST_TIERS_ID_RFT", 4);
		CalculStatsUtils.calculStatTable(jdbcTemplate, "REST_TIERS_SIREN", 4);
		CalculStatsUtils.calculStatTable(jdbcTemplate, "REST_ASSOC_RFT_SIREN", 4);
		CalculStatsUtils.calculStatTable(jdbcTemplate, "REST_SYNTH_TIERS_LOCAL_DAR", 4);

		return RepeatStatus.FINISHED;
	}

}

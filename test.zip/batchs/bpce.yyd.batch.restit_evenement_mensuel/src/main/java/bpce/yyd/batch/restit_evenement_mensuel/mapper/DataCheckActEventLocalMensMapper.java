package bpce.yyd.batch.restit_evenement_mensuel.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fr.bpce.yyd.batch.commun.beans.DataEventLocal;

public class DataCheckActEventLocalMensMapper implements RowMapper<DataEventLocal> {

	@Override
	public DataEventLocal mapRow(ResultSet rs, int rowNum) throws SQLException {

		DataEventLocal dataEvt = new DataEventLocal();
		dataEvt.setIdSynthese((rs.getBigDecimal(1) == null) ? null : rs.getLong(1));
		dataEvt.setCodeBq(rs.getString(2));
		dataEvt.setIdLocal(rs.getString(3));
		dataEvt.setCode(rs.getString(4));
		dataEvt.setType(rs.getString(5));
		dataEvt.setDateDebut(rs.getDate(6));
		dataEvt.setDatePhoto(rs.getDate(7));
		dataEvt.setStatutEvenement(rs.getString(8));
		dataEvt.setDateMaj(rs.getDate(9));
		dataEvt.setCommentaire(rs.getString(10));
		dataEvt.setArriereTech(rs.getBoolean(11));
		dataEvt.setArriereLitige(rs.getBoolean(12));
		dataEvt.setMontantArriere(rs.getBigDecimal(13));
		dataEvt.setIdContrat(rs.getString(14));
		dataEvt.setDar(rs.getDate(15));
		return dataEvt;
	}

}

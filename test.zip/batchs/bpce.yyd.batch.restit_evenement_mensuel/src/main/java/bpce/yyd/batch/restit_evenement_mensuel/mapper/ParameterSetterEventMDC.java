package bpce.yyd.batch.restit_evenement_mensuel.mapper;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.jdbc.core.PreparedStatementSetter;

import bpce.yyd.batch.restit_evenement_mensuel.beans.DataDate;

public class ParameterSetterEventMDC implements PreparedStatementSetter {

	private Date datedebut;
	private Date dateFin;

	public ParameterSetterEventMDC(Date date, DataDate data) {
		this.datedebut = data.getDateDebut();
		this.dateFin = date;
	}

	@Override
	public void setValues(PreparedStatement ps) throws SQLException {
		ps.setDate(1, datedebut);
		ps.setDate(2, dateFin);
		ps.setDate(3, datedebut);
		ps.setDate(4, dateFin);
		ps.setDate(5, datedebut);
		ps.setDate(6, dateFin);
		ps.setDate(7, datedebut);
		ps.setDate(8, dateFin);
	}

}

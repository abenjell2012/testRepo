package bpce.yyd.batch.restit_evenement_mensuel.mapper;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.jdbc.core.PreparedStatementSetter;

import bpce.yyd.batch.restit_evenement_mensuel.beans.DataDate;

public class ParameterSetterCheckACTEventLocal implements PreparedStatementSetter {

	private Date dateM_1;
	private Date dateM;
	

	public ParameterSetterCheckACTEventLocal(DataDate data) {
		this.dateM_1 = data.getDateM_1();
		this.dateM = data.getDateM();
	}

	@Override
	public void setValues(PreparedStatement ps) throws SQLException {
		ps.setDate(1, dateM_1);
		ps.setDate(2, dateM);
	}
}

package bpce.yyd.batch.restit_evenement_mensuel.task;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.stereotype.Service;

import bpce.yyd.batch.restit_evenement_mensuel.beans.DataDate;
import fr.bpce.yyd.batch.commun.constantes.Constant;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Setter
@Service
public class VidageEvenementMensuelADate implements Tasklet{

	private static final String DELETE_QUERY_EVENT_MDC = "delete from  REST_SYNTH_EVT_MDC_DAR " +
			"where DAR_MDC = ? ";

	private static final String DELETE_QUERY_EVENT_LOCAL = "delete from  REST_SYNTH_EVT_LOCAL_DAR " +
			"where DAR_EVT = ?";

	private static final String FIND_DATE_MAX_EVT =" select max(dateDar) as dateDar" +
			" from (" +
			"      select MAX(DAR_MDC) as dateDar from REST_SYNTH_EVT_MDC_DAR" +
			"      union" +
			"      select max(DAR_EVT) as dateDar from REST_SYNTH_EVT_LOCAL_DAR" +
			")";

	private String date;

	private DataDate dataDate;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		Date dateBatch = Date.valueOf(LocalDate.parse(date,Constant.YYYYMMDD_FORMATTER));

		deleteEvent(DELETE_QUERY_EVENT_MDC,dateBatch);
		deleteEvent(DELETE_QUERY_EVENT_LOCAL,dateBatch);

		Date dateDebut=findMaxDate(FIND_DATE_MAX_EVT);
		if(dateDebut == null) {
			dateDebut= Date.valueOf(LocalDate.of(1970, 01, 01));
			log.info("cas init date debut : "+dateDebut);
		}else {
			log.info("date debut : " +dateDebut);
		}
		dataDate.setDateDebut(dateDebut);
		dataDate.setDateM(dateBatch);
		log.info("date photo synthse m-1 : "+dataDate.getDateM_1());
		log.info("date photo synthse m : "+dataDate.getDateM());
		return RepeatStatus.FINISHED;
	}

	private Date findMaxDate(String sql) {
		Date dateDebut = jdbcTemplate.queryForObject(sql, Date.class);
		dataDate.setDateM_1(dateDebut);
		if(dateDebut == null) { return null;}
		return Date.valueOf(dateDebut.toLocalDate().plusDays(1));
	}

	private void deleteEvent(String sql,Date date) {
		jdbcTemplate.update(sql, new PreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setDate(1, date);
			}
		});
	}
}
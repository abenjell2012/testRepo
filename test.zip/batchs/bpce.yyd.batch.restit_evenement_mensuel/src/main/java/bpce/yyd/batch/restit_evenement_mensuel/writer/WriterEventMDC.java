package bpce.yyd.batch.restit_evenement_mensuel.writer;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;

import fr.bpce.yyd.batch.commun.beans.DataEventMDC;
import fr.bpce.yyd.batch.commun.constantes.Constant;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Setter
@Slf4j
public class WriterEventMDC implements ItemWriter<DataEventMDC> {

	private String date;

	private static final String INSERT_QUERY_EVENT_MDC = "insert into REST_SYNTH_EVT_MDC_DAR ("
			+ "ID_SYNTH_TIERS_LOCAL_DAR, CODE_BANQUE_MDC, ID_MDC_EVT,CODE_MDC,DATE_CREATION_EVT,"
			+ "STATUT_EVT,DATE_MAJ_STATUT, DATE_CLOTURE, DAR_MDC) VALUES (?,?,?,?,?,?,?,?,?)";

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public void write(List<? extends DataEventMDC> dataEventMDCs) throws Exception {

		log.info("Début de chargement de: " + dataEventMDCs.size() + " Event  MDC");

		dataEventMDCs.stream().filter(x -> x.getIdSynthese() == null).forEach(x -> log.info(x.toString()));

		List<DataEventMDC> dataForInsert = dataEventMDCs.stream().filter(x -> x.getIdSynthese() != null)
				.collect(Collectors.toList());

		jdbcTemplate.batchUpdate(INSERT_QUERY_EVENT_MDC, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {

				ps.setLong(1, dataForInsert.get(i).getIdSynthese());
				ps.setString(2, "MDC");
				ps.setObject(3, dataForInsert.get(i).getIdEvt());
				ps.setString(4, dataForInsert.get(i).getCodeEvt());
				ps.setDate(5, dataForInsert.get(i).getDateDebut());
				ps.setString(6, dataForInsert.get(i).getStatut());
				ps.setDate(7, dataForInsert.get(i).getDateEffet());
				ps.setDate(8, dataForInsert.get(i).getDateCloture());
				ps.setDate(9, Date.valueOf(LocalDate.parse(date, Constant.YYYYMMDD_FORMATTER)));
			}

			@Override
			public int getBatchSize() {
				return dataForInsert.size();
			}
		});
	}
}

package bpce.yyd.batch.restit_evenement_mensuel.mapper;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;

import org.springframework.jdbc.core.PreparedStatementSetter;

import bpce.yyd.batch.restit_evenement_mensuel.beans.DataDate;
import fr.bpce.yyd.batch.commun.constantes.Constant;

public class ParameterSetterEventLocal implements PreparedStatementSetter {

	private LocalDate dateFin;
	private Date datedebut;

	public ParameterSetterEventLocal(String dateCalcul,DataDate data) {
		this.datedebut=data.getDateDebut();
		this.dateFin = LocalDate.parse(dateCalcul,Constant.YYYYMMDD_FORMATTER);
	}

	@Override
	public void setValues(PreparedStatement ps) throws SQLException {
		ps.setDate(1, datedebut);
		ps.setDate(2, Date.valueOf(dateFin));
		ps.setDate(3, Date.valueOf(dateFin));
	}

}

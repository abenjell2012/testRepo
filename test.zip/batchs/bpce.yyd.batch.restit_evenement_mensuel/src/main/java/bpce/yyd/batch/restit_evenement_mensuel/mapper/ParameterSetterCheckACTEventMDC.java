package bpce.yyd.batch.restit_evenement_mensuel.mapper;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.jdbc.core.PreparedStatementSetter;

import bpce.yyd.batch.restit_evenement_mensuel.beans.DataDate;

public class ParameterSetterCheckACTEventMDC implements PreparedStatementSetter {

	private Date dateM_1;
	private Date dateM;

	public ParameterSetterCheckACTEventMDC(DataDate data) {
		this.dateM_1 = data.getDateM_1();
		this.dateM = data.getDateM();
	}

	@Override
	public void setValues(PreparedStatement ps) throws SQLException {
		ps.setDate(1, dateM);
		ps.setDate(2, dateM_1);
	}
}

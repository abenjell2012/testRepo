package bpce.yyd.batch.restit_evenement_mensuel.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import fr.bpce.yyd.batch.commun.beans.DataEventLocal;

/**
 * Mapper
 *
 * @author TOUNAKTI Riadh
 *
 */

public class DataDupEventLocalMensMapper extends DataEventLocalMensMapper {

	@Override
	public DataEventLocal mapRow(ResultSet rs, int rowNum) throws SQLException {

		DataEventLocal dataEvt = super.mapRow(rs, rowNum);
		dataEvt.setDar(rs.getDate(16));
		return dataEvt;
	}

}

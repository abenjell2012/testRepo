package bpce.yyd.batch.restit_evenement_mensuel.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import fr.bpce.yyd.batch.commun.beans.DataEventMDC;

/**
 * Mapper
 *
 * @author TOUNAKTI Riadh
 *
 */

public class DataDupEventMdcMensMapper extends DataEventMdcMensMapper {

	@Override
	public DataEventMDC mapRow(ResultSet rs, int rowNum) throws SQLException {

		DataEventMDC dataEvt = super.mapRow(rs, rowNum);
		dataEvt.setDar(rs.getDate(8));
		return dataEvt;
	}

}

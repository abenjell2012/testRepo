package bpce.yyd.batch.restit_evenement_mensuel.beans;

import java.sql.Date;

import lombok.Data;

@Data
public class DataDate {

	private Date dateDebut;

	private Date dateM_1;

	private Date dateM;

}

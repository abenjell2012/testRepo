package fr.bpce.yyd.batch.flux_quotidien.partitioner;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.partition.support.Partitioner;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.util.CollectionUtils;

public class FluxEvtsCodeBqPartitioner implements Partitioner {

	private static final Logger LOGGER = Logger.getLogger(FluxEvtsCodeBqPartitioner.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;
	private String datePhoto;

	private static final String QUERY_COD_BQ = "WITH TIERS_PERIM as ("
		+	" select /*+parallel(4)*/ synthse.id_p_synthese, tiers.code_banque from rest_synth_tiers_local_status synthse"
		+	" left join REST_TIERS_ID_LOCAL tiers on synthse.id_tiers_id_local = tiers.id_p_id_local"
		+	" where synthse.DATE_PHOTO = to_date(?,'YYYYMMdd') and tiers.date_fin is null)"
		+	" select distinct tiers.code_banque"
		+	" from REST_SYNTH_EVT_LOCAL_STATUS event"
		+	" inner join TIERS_PERIM tiers on tiers.id_p_synthese = event.id_synth_tiers_local_status"
		+	" UNION"
		+	" select distinct tiers.code_banque"
		+	" from REST_SYNTH_EVT_MDC_STATUS event"
		+	" inner join TIERS_PERIM tiers on tiers.id_p_synthese = event.id_synth_tiers_local_status"
		+	" UNION"
		+	" select distinct(CODE_BQ)"
		+	" from AUDIT_FICHIERS"
		+	" where CODE_AUDIT = 'FICOK'"
		+	" and NOM_FIchier like '%FULL%'"
		+	" and date_audit >= ADD_MONTHS(to_date(?,'YYYYMMdd'),-3)";

	@Override
	public Map<String, ExecutionContext> partition(int gridSize) {

		List<String> codeBqList = jdbcTemplate.queryForList(QUERY_COD_BQ, String.class, datePhoto,datePhoto);

		Map<String, ExecutionContext> result = new HashMap<>();

		if (!CollectionUtils.isEmpty(codeBqList)) {
			for (String codeBanque : codeBqList) {
				ExecutionContext executionContext = new ExecutionContext();
				executionContext.putString("codeBanque", codeBanque);
				result.put("codeBanque " + codeBanque, executionContext);
			}

		} else {
			LOGGER.warn("L'extraction des donnees evenements n'est faite pour aucun établissement");
		}

		return result;

	}

	public String getDatePhoto() {
		return datePhoto;
	}

	public void setDatePhoto(String datePhoto) {
		this.datePhoto = datePhoto;
	}

}

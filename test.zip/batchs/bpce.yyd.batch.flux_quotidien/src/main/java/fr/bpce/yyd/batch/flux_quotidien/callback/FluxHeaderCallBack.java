package fr.bpce.yyd.batch.flux_quotidien.callback;

import java.io.IOException;
import java.io.Writer;

import org.springframework.batch.item.file.FlatFileHeaderCallback;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.util.Assert;

import fr.bpce.yyd.batch.commun.utils.RestitSyntheseUtils;

public class FluxHeaderCallBack implements FlatFileHeaderCallback, InitializingBean {

	private String dateGeneration;
	private String codeBq;

	@Override
	public void writeHeader(Writer writer) throws IOException {
		writer.write(
				RestitSyntheseUtils.generateEnteteFic(codeBq, dateGeneration));

	}

	@Override
	public void afterPropertiesSet() throws Exception {
		Assert.hasText(dateGeneration);
		Assert.hasText(codeBq);
	}

	public void setDateGeneration(String dateGeneration) {
		this.dateGeneration = dateGeneration;
	}

	public void setCodeBq(String codeBq) {
		this.codeBq = codeBq;
	}

}

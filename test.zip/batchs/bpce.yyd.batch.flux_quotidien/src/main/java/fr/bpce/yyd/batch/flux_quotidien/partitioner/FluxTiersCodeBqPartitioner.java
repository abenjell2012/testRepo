package fr.bpce.yyd.batch.flux_quotidien.partitioner;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.partition.support.Partitioner;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.util.CollectionUtils;

public class FluxTiersCodeBqPartitioner implements Partitioner {

	private static final Logger LOGGER = Logger.getLogger(FluxTiersCodeBqPartitioner.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;
	private String datePhoto;

	private static final String QUERY_COD_BQ = "select /*+parallel(4)*/ distinct tiers.code_banque from REST_TIERS_ID_LOCAL tiers"
			+ " inner join REST_SYNTH_TIERS_LOCAL_STATUS syt on syt.id_tiers_id_local = tiers.id_p_id_local"
			+ " where syt.DATE_PHOTO = to_date(?,'YYYYMMdd') and tiers.date_fin is null"
			+ " UNION"
			+ " select distinct(CODE_BQ)"
			+ " from AUDIT_FICHIERS"
			+ " where CODE_AUDIT = 'FICOK'"
			+ " and NOM_FIchier like '%FULL%'"
			+ " and date_audit >= ADD_MONTHS(to_date(?,'YYYYMMdd'),-3)";

	@Override
	public Map<String, ExecutionContext> partition(int gridSize) {

		List<String> codeBqList = jdbcTemplate.queryForList(QUERY_COD_BQ, String.class, datePhoto,datePhoto);

		Map<String, ExecutionContext> result = new HashMap<>();

		if (!CollectionUtils.isEmpty(codeBqList)) {
			for (String codeBanque : codeBqList) {
				ExecutionContext executionContext = new ExecutionContext();
				executionContext.putString("codeBanque", codeBanque);
				result.put("codeBanque " + codeBanque, executionContext);
			}

		} else {
			LOGGER.warn("L'extraction des donnees tiers n'est faite pour aucun établissement");
		}

		return result;

	}

	public String getDatePhoto() {
		return datePhoto;
	}

	public void setDatePhoto(String datePhoto) {
		this.datePhoto = datePhoto;
	}

}

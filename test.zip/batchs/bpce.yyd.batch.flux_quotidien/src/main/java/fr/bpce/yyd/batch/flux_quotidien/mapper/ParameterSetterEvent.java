package fr.bpce.yyd.batch.flux_quotidien.mapper;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.jdbc.core.PreparedStatementSetter;

public class ParameterSetterEvent implements PreparedStatementSetter {

	private Date date;

	public ParameterSetterEvent(Date date) {
		this.date = date;
	}

	@Override
	public void setValues(PreparedStatement ps) throws SQLException {
		ps.setDate(1, date);
		ps.setDate(2, date);
	}
}

package fr.bpce.yyd.batch.commun.messages;

public interface ConsommateurMessages {

	public interface Consommateur<C> {
		void consomme(C objet);
	}

	/**
	 * Démarrage du service d'écoute des message sur le topic paramètre, service qui
	 * traitera les messages en les désérialisants et les passant au consommateur
	 * paramètre.
	 *
	 * @param topic
	 * @param name
	 * @param classeMessage
	 * @param consommateur
	 */
	<C> void demarre(Topic topic, String name, Class<C> classeMessage, Consommateur<C> consommateur);

}

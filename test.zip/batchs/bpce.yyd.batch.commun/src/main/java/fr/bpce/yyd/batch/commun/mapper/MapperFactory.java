package fr.bpce.yyd.batch.commun.mapper;

import java.time.LocalDate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;

/**
 * MapperFactory
 *
 * Factory pour créer des ObjectMapper ayant les bonnes caractéristiques.
 *
 * @author zgud
 *
 */
public class MapperFactory {
	private MapperFactory() {
		// La seule méthode est statique
	}

	/**
	 * Création d'un ObjectMapper prenant en charge toutes les spécificités
	 * nécessaires.
	 *
	 * @return
	 */
	public static ObjectMapper getMapper() {
		SimpleModule module = new SimpleModule("TimeObjectsHelper");
		module.addDeserializer(LocalDate.class, new LocalDateDeserializer());
		module.addSerializer(new LocalDateSerializer());
		ObjectMapper mapper = new ObjectMapper();
		mapper.registerModule(module);

		return mapper;
	}
}

package fr.bpce.yyd.batch.commun.messages;

import java.util.Iterator;
import java.util.ServiceLoader;

/**
 * Factory permettant d'obtenir un ProducteurMessages ou un
 * ConsommateurMessages.
 *
 * @author zgud
 *
 */
public class MessagesFactory {

	private MessagesFactory() {
		// Méthodes statiques uniquement.
	}

	/**
	 * Retourne la première implémentation trouvée pour ProducteurMessages.
	 *
	 * @return
	 */
	public static ProducteurMessages getProducteur() {
		Iterator<ProducteurMessages> it = ServiceLoader.load(ProducteurMessages.class).iterator();
		return it.next();
	}

	/**
	 * Retourne la première implémentation trouvée pour ConsommateurMessages.
	 *
	 * @return
	 */
	public static ConsommateurMessages getConsommateur() {
		Iterator<ConsommateurMessages> it = ServiceLoader.load(ConsommateurMessages.class).iterator();
		return it.next();
	}
}

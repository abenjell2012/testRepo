package fr.bpce.yyd.batch.tu;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.time.DateTimeException;
import java.time.LocalDate;

import org.junit.Before;
import org.junit.Test;

import bpce.yyd.batch.restit_synthese_tiers_quotidienne.processor.CalculSyntheseTiersProcessor;

public class TestIdSituation {

	private CalculSyntheseTiersProcessor calcul;

	@Before
	public void init() {
		calcul = new CalculSyntheseTiersProcessor();
	}

	@Test
	public void testConstructor() {
		assertNotNull(calcul);
	}

	@Test
	public void testFormatIdSituationPassant() {
		// Arange
		LocalDate dateCalcul = LocalDate.of(2019, 10, 1);
		String idRft = "123456";
		String expected = "19274123456";

		// Act
		String situtation = calcul.formatIdSituation(dateCalcul, idRft);

		// Assert
		assertEquals(situtation, expected);
	}

	@Test
	public void testFormatIdSituationDateCalculNullPassant() {
		// Arange
		LocalDate dateCalcul = null;
		String idRft = "123456";
		String expected = null;

		// Act
		String situtation = calcul.formatIdSituation(dateCalcul, idRft);

		// Assert
		assertEquals(situtation, expected);
	}

	@Test
	public void testFormatIdSituationIdRftNullPassant() {
		// Arange
		LocalDate dateCalcul = LocalDate.of(2019, 10, 1);
		String idRft = null;
		String expected = "19274null";

		// Act
		String situtation = calcul.formatIdSituation(dateCalcul, idRft);

		// Assert
		assertEquals(situtation, expected);
	}

	@Test(expected = DateTimeException.class)
	public void testFormatDateCalculMalFormeNonPassant() {
		// Arange
		LocalDate dateCalcul = LocalDate.of(2019, 13, 1);
		String idRft = "123456";

		// Act
		calcul.formatIdSituation(dateCalcul, idRft);
	}

	@Test
	public void testFormatStringToLongPassant() {
		// Arange
		String chaine = "123456";
		Long expected = 123456l;

		// Act
		Long chaineLong = calcul.formatStrintToLong(chaine);

		assertNotNull(chaineLong);
		assertEquals(chaineLong, expected);
	}

	@Test(expected = NumberFormatException.class)
	public void testFormatStringToLongNullNonPassant() {
		// Arange
		String chaine = "19274null";

		// Act
		calcul.formatStrintToLong(chaine);
	}

	@Test(expected = NumberFormatException.class)
	public void testFormatStringToLongCaracteresNonPassant() {
		// Arange
		String chaine = "1245ABCD";

		// Act
		calcul.formatStrintToLong(chaine);

	}

}
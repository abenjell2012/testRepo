package fr.bpce.yyd.batch.ti;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.TypedQuery;

import org.junit.After;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;

import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.commun.utils.AbstractTestIntegration;
import fr.bpce.yyd.commun.enums.StatutAuditEvenement;
import fr.bpce.yyd.commun.enums.StatutEvenement;
import fr.bpce.yyd.commun.enums.StatutTiers;
import fr.bpce.yyd.commun.model.ArriereSignificatif;
import fr.bpce.yyd.commun.model.AuditCalcul;
import fr.bpce.yyd.commun.model.AuditFichiers;
import fr.bpce.yyd.commun.model.ComplementArriere;
import fr.bpce.yyd.commun.model.ComplementEvenement;
import fr.bpce.yyd.commun.model.Declencheur;
import fr.bpce.yyd.commun.model.ElementsDeCalcul;
import fr.bpce.yyd.commun.model.Evenement;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.MotifStatutTiers;
import fr.bpce.yyd.commun.model.StatutHistorise;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.commun.model.restitution.RestSynthTierLocalStatus;
import fr.bpce.yyd.commun.model.restitution.RestTiersLocal;

@Ignore
public class SyntheseTiersQuotTest extends AbstractTestIntegration {

	@Test
	public void testSyntheseTiersSainAvecAR0() throws Exception {

		// ARRANGE
		initDataCasSainAvecAR0();
		// ACT
		lauchBatchSTQ("20200601");
		// VERIFY
		TypedQuery<RestTiersLocal> q1 = getEntityManager()
				.createQuery(" SELECT t from RestTiersLocal t  order by idLocal ", RestTiersLocal.class);
		List<RestTiersLocal> tiersLocals = q1.getResultList();
		assertNotNull(tiersLocals);
		assertEquals(1L, tiersLocals.size());
		assertEquals("11128", tiersLocals.get(0).getCodeBanque());
		assertEquals("3200", tiersLocals.get(0).getCodeSegment());
		assertEquals(LocalDate.of(2020, 6, 1), tiersLocals.get(0).getDateDebut());
		assertEquals("IDLOC1", tiersLocals.get(0).getIdLocal());
		// VERIFY
		TypedQuery<RestSynthTierLocalStatus> q2 = getEntityManager()
				.createQuery(" SELECT t from RestSynthTierLocalStatus t ", RestSynthTierLocalStatus.class);
		List<RestSynthTierLocalStatus> syntheseTiersStatus = q2.getResultList();
		assertNotNull(syntheseTiersStatus);
		assertEquals(1L, syntheseTiersStatus.size());
		assertEquals(Long.valueOf(1L), syntheseTiersStatus.get(0).getCompteurA());
		assertEquals(Long.valueOf(1L), syntheseTiersStatus.get(0).getCompteurAS());
		assertEquals(LocalDate.of(2020, 6, 1), syntheseTiersStatus.get(0).getDateTopA());
		assertEquals(LocalDate.of(2020, 6, 1), syntheseTiersStatus.get(0).getDateTopAS());
		assertEquals("AR0", syntheseTiersStatus.get(0).getPalierAS());
		assertEquals(new BigDecimal("59863.32"), syntheseTiersStatus.get(0).getMontantTotalArriere());
		assertEquals("STC", syntheseTiersStatus.get(0).getOrigineStatutEffectif());
		assertEquals("ND", syntheseTiersStatus.get(0).getStatutCalcule());
		assertEquals("ND", syntheseTiersStatus.get(0).getStatutEffectif());
		assertEquals(LocalDate.of(2020, 6, 1), syntheseTiersStatus.get(0).getDateMAJStatutEffectif());
		assertEquals(LocalDate.of(2020, 6, 1), syntheseTiersStatus.get(0).getDateStatutCalcule());
		assertEquals(tiersLocals.get(0).getId(), syntheseTiersStatus.get(0).getRestRechTiersLocal().getId());

	}

	@Test
	public void testSyntheseTiersDefautAvecAR3() throws Exception {

		// ARRANGE
		initDataCasDefautAvecAR3();
		// ACT
		lauchBatchSTQ("20200601");
		// VERIFY
		TypedQuery<RestTiersLocal> q1 = getEntityManager()
				.createQuery(" SELECT t from RestTiersLocal t  order by idLocal ", RestTiersLocal.class);
		List<RestTiersLocal> tiersLocals = q1.getResultList();
		assertNotNull(tiersLocals);
		assertEquals(1L, tiersLocals.size());
		assertEquals("10107", tiersLocals.get(0).getCodeBanque());
		assertEquals("3200", tiersLocals.get(0).getCodeSegment());
		assertEquals(LocalDate.of(2020, 6, 1), tiersLocals.get(0).getDateDebut());
		assertEquals("IDLOC2", tiersLocals.get(0).getIdLocal());
		// VERIFY
		TypedQuery<RestSynthTierLocalStatus> q2 = getEntityManager()
				.createQuery(" SELECT t from RestSynthTierLocalStatus t ", RestSynthTierLocalStatus.class);
		List<RestSynthTierLocalStatus> syntheseTiersStatus = q2.getResultList();
		assertNotNull(syntheseTiersStatus);
		assertEquals(1L, syntheseTiersStatus.size());
		assertEquals(Long.valueOf(1L), syntheseTiersStatus.get(0).getCompteurA());
		assertEquals(Long.valueOf(122L), syntheseTiersStatus.get(0).getCompteurAS());
		assertEquals(LocalDate.of(2020, 6, 1), syntheseTiersStatus.get(0).getDateTopA());
		assertEquals(LocalDate.of(2020, 2, 1), syntheseTiersStatus.get(0).getDateTopAS());
		assertEquals("AR3", syntheseTiersStatus.get(0).getPalierAS());
		assertEquals(new BigDecimal("59863.32"), syntheseTiersStatus.get(0).getMontantTotalArriere());
		assertEquals("STC", syntheseTiersStatus.get(0).getOrigineStatutEffectif());
		// assertEquals("D", syntheseTiersStatus.get(0).getStatutCalcule());
		// assertEquals("D", syntheseTiersStatus.get(0).getStatutEffectif());
		// assertEquals(LocalDate.of(2020, 6, 1),
		// syntheseTiersStatus.get(0).getDateMAJStatutEffectif());
		// assertEquals(LocalDate.of(2020, 6, 1),
		// syntheseTiersStatus.get(0).getDateStatutCalcule());
		assertEquals(tiersLocals.get(0).getId(), syntheseTiersStatus.get(0).getRestRechTiersLocal().getId());

	}

	private static void initDataCasSainAvecAR0() {

		doInTransaction(() -> {
			// tiers et statut tiers
			Tiers tiers = new Tiers();
			IdentiteTiers ident = new IdentiteTiers();
			ident.setCodeBanque("11128");
			ident.setCodeSegment("3200");
			ident.setIdLocal("IDLOC1");
			ident.setDateDebut(LocalDate.of(2020, 6, 1));
			tiers.addIdentite(ident);

			StatutHistorise statut = new StatutHistorise();
			statut.setDateDeb(LocalDate.of(2020, 6, 1));
			statut.setStatut(StatutTiers.SAIN);
			statut.setDateFin(null);
			statut.setAnnule(false);
			statut.setTiers(tiers);
			tiers.addStatut(statut);

			getEntityManager().persist(tiers);

			// Declenchement
			Declencheur decl = new Declencheur();
			decl.setCodeBanque(ident.getCodeBanque());
			decl.setIdLocal(ident.getIdLocal());
			decl.setCodeSegment(ident.getCodeSegment());
			decl.setDateDeclencheur(Date.valueOf(LocalDate.of(2020, 6, 1)));
			decl.setMotifDeclencheur("AS");
			decl.setTiers(tiers.getId());
			getEntityManager().persist(decl);
			// AuditFichier , Evenement et complement du tiers
			AuditFichiers fic = new AuditFichiers();
			getEntityManager().persist(fic);

			ComplementEvenement complementEvt = new ComplementEvenement();
			complementEvt.setAuditFichier(fic);
			complementEvt.setArriereLitige(false);
			complementEvt.setArriereTech(false);
			complementEvt.setIdentiteInitiale(ident);
			complementEvt.setDatePhoto(LocalDate.of(2020, 6, 1));
			complementEvt.setDateMaj(LocalDate.of(2020, 6, 1));
			complementEvt.setStatutEvt(StatutEvenement.ACT);
			complementEvt.setMiseAJour(false);
			complementEvt.setMontantArriere(new BigDecimal("59863.32"));
			Evenement evt = new Evenement();
			evt.setCode("DAX");
			evt.setDateDebut(LocalDate.of(2020, 6, 1));
			evt.setIdContrat("CONTRATAZ");
			evt.setIdLocal("EVTIDLOCAL1");
			evt.setIdentiteInitiale(ident);
			evt.addComplement(complementEvt);
			getEntityManager().persist(evt);

			ElementsDeCalcul edc = new ElementsDeCalcul();
			edc.setTiers(tiers);
			getEntityManager().persist(edc);

			ArriereSignificatif as = new ArriereSignificatif();
			as.setTiers(tiers);
			as.setDateDebut(LocalDate.of(2020, 06, 01));
			ComplementArriere complAS = new ComplementArriere();
			complAS.setEntree(edc);
			as.setComplement(complAS);
			getEntityManager().persist(as);

		});
	}

	private static void initDataCasDefautAvecAR3() {

		doInTransaction(() -> {
			// tiers et statut tiers
			Tiers tiers = new Tiers();
			IdentiteTiers ident = new IdentiteTiers();
			ident.setCodeBanque("10107");
			ident.setCodeSegment("3200");
			ident.setIdLocal("IDLOC2");
			ident.setDateDebut(LocalDate.of(2020, 6, 1));
			tiers.addIdentite(ident);
			getEntityManager().persist(tiers);

			// Declenchement tiers
			Declencheur decl = new Declencheur();
			decl.setCodeBanque(ident.getCodeBanque());
			decl.setIdLocal(ident.getIdLocal());
			decl.setCodeSegment(ident.getCodeSegment());
			decl.setDateDeclencheur(Date.valueOf(LocalDate.of(2020, 6, 1)));
			decl.setMotifDeclencheur("AS");
			decl.setTiers(tiers.getId());
			getEntityManager().persist(decl);
			// AuditFichier , Evenement et complement du tiers
			AuditFichiers fic = new AuditFichiers();
			getEntityManager().persist(fic);

			ComplementEvenement complementEvt = new ComplementEvenement();
			complementEvt.setAuditFichier(fic);
			complementEvt.setArriereLitige(false);
			complementEvt.setArriereTech(false);
			complementEvt.setIdentiteInitiale(ident);
			complementEvt.setDatePhoto(LocalDate.of(2020, 6, 1));
			complementEvt.setDateMaj(LocalDate.of(2020, 6, 1));
			complementEvt.setStatutEvt(StatutEvenement.ACT);
			complementEvt.setMiseAJour(false);
			complementEvt.setMontantArriere(new BigDecimal("59863.32"));
			Evenement evt = new Evenement();
			evt.setCode("IMX");
			evt.setDateDebut(LocalDate.of(2020, 6, 1));
			evt.setIdContrat("CONTRATAB");
			evt.setIdLocal("EVTIDLOCAL2");
			evt.setIdentiteInitiale(ident);
			evt.addComplement(complementEvt);
			getEntityManager().persist(evt);

			ElementsDeCalcul edc = new ElementsDeCalcul();
			edc.setTiers(tiers);
			getEntityManager().persist(edc);

			// SAVE EVENEMENT_CALCULE
			ArriereSignificatif as = new ArriereSignificatif();
			as.setTiers(tiers);
			as.setDateDebut(LocalDate.of(2020, 02, 01));
			ComplementArriere complAS = new ComplementArriere();
			complAS.setEntree(edc);
			as.setComplement(complAS);
			getEntityManager().persist(as);
			// SAVE AUDIT CALCUL
			AuditCalcul auditCalcul = new AuditCalcul();
			auditCalcul.setCode("AR3");
			auditCalcul.setDateGeneration(LocalDateTime.now());
			auditCalcul.setDateEffet(LocalDate.of(2020, 6, 1));
			auditCalcul.setEvenementCalcule(as);
			auditCalcul.setStatut(StatutAuditEvenement.ACT);
			auditCalcul.setDatePhoto(LocalDate.of(2020, 6, 1));
			getEntityManager().persist(auditCalcul);
			// SAVE STATUT TIERS
			StatutHistorise statut = new StatutHistorise();
			statut.setDateDeb(LocalDate.of(2020, 6, 1));
			statut.setStatut(StatutTiers.DEFAUT);
			statut.setMotif(new MotifStatutTiers(as));
			statut.setGravite("DX");
			statut.setDateFin(null);
			statut.setAnnule(false);
			statut.setTiers(tiers);
			getEntityManager().persist(statut);

		});
	}

	/**
	 * Initialiser le contexte Spring avant le démarrage des tests
	 *
	 * @throws NoSuchFieldException
	 * @throws IllegalAccessException
	 * @throws IOException
	 */
	@BeforeClass
	public static void initSpringContext() throws NoSuchFieldException, IllegalAccessException, IOException {
		initSpring();
	}

	/**
	 * Vider les tables après chaque test
	 */
	@After
	public void resetData() {
		deleteAllTables();

	}

	private JobExecution lauchBatchSTQ(String strDateCalcul) throws Exception {

		Job job = (Job) getContext().getBean(Constant.JOB_SYNTHESE_TIERS_QUOTIDIENNE);
		JobLauncher jobLauncher = (JobLauncher) getContext().getBean("jobLauncher");
		JobParameters jobParameters = new JobParametersBuilder().addString("dateCalcul", strDateCalcul)
				.addDate("dateSql", Date.valueOf(LocalDate.parse(strDateCalcul, Constant.YYYYMMDD_FORMATTER)))
				.addLong("time", System.currentTimeMillis()).toJobParameters();
		return jobLauncher.run(job, jobParameters);

	}

}

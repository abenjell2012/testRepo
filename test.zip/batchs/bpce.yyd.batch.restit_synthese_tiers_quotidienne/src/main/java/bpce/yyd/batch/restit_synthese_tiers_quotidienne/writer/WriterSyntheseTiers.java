package bpce.yyd.batch.restit_synthese_tiers_quotidienne.writer;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;

import bpce.yyd.batch.restit_synthese_tiers_quotidienne.beans.DataSyntheseTiers;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Setter
@Slf4j
public class WriterSyntheseTiers implements ItemWriter<DataSyntheseTiers> {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	private static final String INSERT_QUERY_SITUATION = "insert into REST_SYNTH_TIERS_LOCAL_STATUS ("
			+ "ID_TIERS_ID_LOCAL," + "DATE_PHOTO," + "STATUT_EFFECTIF," + "PALIER_EFFECTIF,"
			+ "DATE_MAJ_STATUT_EFFECTIF," + "ORIGINE_STATUT_EFFECTIF," + "DATE_METIER_ENTREE_DEFAUT,"
			+ "CODE_EVT_ENTREE_DEFAUT," + "ID_EVT_ENTREE_DEFAUT," + "DATE_DEFAUT_PLUS_RECENT," + "CODE_EVT_PLUS_RECENT,"
			+ "STATUT_CALCULE," + "DATE_STATUT_CALCULE," + "PALIER_CALCULE," + "DATE_PALIER_CALCULE,"
			+ "DATE_DEB_FORCAGE_BV," + "DATE_FIN_FORCAGE_BV," + "STATUT_BV," + "PALIER_BV," + "ETABLISSEMENT_BV,"
			+ "UTILISATEUR_BV," + "CODE_MOTIF_BV," + "COMMENTAIRE_BV," + "TOP_PP," + "DATE_TOP_PP," + "COMPTEUR_PP,"
			+ "DATE_PREVISIONNELLE_FIN_PP," + "TOP_F," + "DATE_TOP_F," + "TOP_A," + "DATE_TOP_A," + "TOP_AS,"
			+ "COMPTEUR_AS," + "DATE_TOP_AS," + "PALIER_AS," + "WARNING_1_1," + "WARNING_1_2," + "WARNING_1_3,"
			+ "WARNING_1_4," + "WARNING_2," + "WARNING_3," + "WARNING_4," + "WARNING_5_1," + "WARNING_5_2,"
			+ "WARNING_5_3," + "WARNING_6," + "WARNING_7," + "WARNING_8," + "WARNING_9," + "WARNING_10,"
			+ "MONTANT_TOTAL_ARRIERE," + "MONTANT_ENCOURS," + "DAR_ENCOURS," + "SEUIL_ABSOLU," + "MONTANT_TOTAL_IMX,"
			+ "MONTANT_TOTAL_DAX," + "COMPTEUR_A," + "ID_SITUATION_TIERS) "
			+ " values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

	@Override
	public void write(List<? extends DataSyntheseTiers> items) throws Exception {
		log.info("Début de chargement de: " + items.size() + " lignes");

		jdbcTemplate.batchUpdate(INSERT_QUERY_SITUATION, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {

				ps.setLong(1, items.get(i).getIdTiersSyn());
				ps.setDate(2, items.get(i).getDatePhoto());
				ps.setString(3, items.get(i).getStatutEffectif());
				ps.setString(4, items.get(i).getPalierEffectif());
				ps.setDate(5, items.get(i).getDateMajStatutEffectif());
				ps.setString(6, items.get(i).getOrigineStatutEffectif());
				ps.setDate(7, items.get(i).getDateMetierEntreeDefaut());
				ps.setString(8, items.get(i).getCodeEvtEntreeDefaut());
				ps.setString(9, items.get(i).getIdEvtEntreeDefaut());
				ps.setDate(10, items.get(i).getDateDefautPlusRecent());
				ps.setString(11, items.get(i).getCodeDefautPlusRecent());
				ps.setString(12, items.get(i).getStatutCalcule());
				ps.setDate(13, items.get(i).getDateStatutCalcule());
				ps.setString(14, items.get(i).getPalierCalcule());
				ps.setDate(15, items.get(i).getDatePalierCalcule());
				ps.setDate(16, items.get(i).getDateDebForcageBv());
				ps.setDate(17, items.get(i).getDateFinForcageBv());
				ps.setString(18, items.get(i).getStatutBv());
				ps.setString(19, items.get(i).getPalierBv());
				ps.setString(20, items.get(i).getEtablissementBv());
				ps.setString(21, items.get(i).getUtilisateurBv());
				ps.setString(22, items.get(i).getCodeMotifBv());
				ps.setString(23, items.get(i).getCommentaireBv());
				ps.setBoolean(24, items.get(i).isTopPp());
				ps.setDate(25, items.get(i).getDateTopPp());
				ps.setObject(26, items.get(i).getCompteurPp());
				ps.setDate(27, items.get(i).getDatePrevisionnelleFinPp());
				ps.setBoolean(28, items.get(i).isTopF());
				ps.setDate(29, items.get(i).getDateTopF());
				ps.setBoolean(30, items.get(i).isTopA());
				ps.setDate(31, items.get(i).getDateTopA());
				ps.setBoolean(32, items.get(i).isTopAs());
				ps.setObject(33, items.get(i).getCompteurAs());
				ps.setDate(34, items.get(i).getDateTopAs());
				ps.setString(35, items.get(i).getPalierAs());
				ps.setBoolean(36, items.get(i).isWarning11());
				ps.setBoolean(37, items.get(i).isWarning12());
				ps.setBoolean(38, items.get(i).isWarning13());
				ps.setBoolean(39, items.get(i).isWarning14());
				ps.setBoolean(40, items.get(i).isWarning2());
				ps.setBoolean(41, items.get(i).isWarning3());
				ps.setBoolean(42, items.get(i).isWarning4());
				ps.setBoolean(43, items.get(i).isWarning51());
				ps.setBoolean(44, items.get(i).isWarning52());
				ps.setBoolean(45, items.get(i).isWarning53());
				ps.setBoolean(46, items.get(i).isWarning6());
				ps.setBoolean(47, items.get(i).isWarning7());
				ps.setBoolean(48, items.get(i).isWarning8());
				ps.setBoolean(49, items.get(i).isWarning9());
				ps.setBoolean(50, items.get(i).isWarning10());
				ps.setObject(51, items.get(i).getMontantTotalArriere());
				ps.setObject(52, items.get(i).getMontantEncours());
				ps.setTimestamp(53, items.get(i).getDarEncours());
				ps.setObject(54, items.get(i).getSeuilAbsolu());
				ps.setObject(55, items.get(i).getMontantTotalImx());
				ps.setObject(56, items.get(i).getMontantTotalDax());
				ps.setObject(57, items.get(i).getCompteurA());
				if (items.get(i).getIdSyntheseTiers() != null) {
					ps.setLong(58, items.get(i).getIdSyntheseTiers());
				} else {
					ps.setNull(58, Types.INTEGER);
				}
			}

			@Override
			public int getBatchSize() {
				return items.size();
			}
		});
	}
}

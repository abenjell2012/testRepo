package bpce.yyd.batch.restit_synthese_tiers_quotidienne.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import bpce.yyd.batch.restit_synthese_tiers_quotidienne.beans.DataSyntheseTiers;

public class DataSyntheseTiersRowMapper implements RowMapper<DataSyntheseTiers> {

	@Override
	public DataSyntheseTiers mapRow(ResultSet rs, int rowNum) throws SQLException {

		DataSyntheseTiers data = new DataSyntheseTiers();
		data.setIdTiersSyn((rs.getBigDecimal(1) == null) ? null : rs.getLong(1));
		data.setIdRft(rs.getString(2));
		data.setIdLocal(rs.getString(3));
		data.setCodeBanque(rs.getString(4));
		data.setCodeSegment(rs.getString(5));
		data.setDateDernierePhoto(rs.getDate(6));
		data.setStatutEffectif(rs.getString(7));
		data.setPalierEffectif(rs.getString(8));
		data.setOrigineStatutEffectif(rs.getString(9));
		data.setDateMajStatutEffectif(rs.getDate(10));
		data.setStatutCalcule(rs.getString(11));
		data.setPalierCalcule(rs.getString(12));
		data.setDateStatutCalcule(rs.getDate(13));
		data.setDatePalierCalcule(rs.getDate(14));

		data.setTopPp(rs.getBoolean(15));
		data.setDateTopPp(rs.getDate(16));
		data.setTopF(rs.getBoolean(17));
		data.setDateTopF(rs.getDate(18));

		data.setTopA(rs.getBoolean(19));
		data.setDateTopA(rs.getDate(20));
		data.setTopAs(rs.getBoolean(21));
		data.setDateTopAs(rs.getDate(22));

		data.setDateMetierEntreeDefaut(rs.getDate(23));
		data.setCodeEvtEntreeDefaut(rs.getString(24));
		data.setEvtIdLocalEntreeDefaut(rs.getString(25));
		data.setEvtIdCalEntreeDefaut(rs.getBigDecimal(26) == null ? null : rs.getLong(26));
		data.setDateDefautPlusRecent(rs.getDate(27));
		data.setCodeDefautPlusRecent(rs.getString(28));
		data.setDateDebForcageBv(rs.getDate(29));
		data.setDateFinForcageBv(rs.getDate(30));
		data.setStatutBv(rs.getString(31));
		data.setPalierBv(rs.getString(32));
		data.setEtablissementBv(rs.getString(33));
		data.setUtilisateurBv(rs.getString(34));
		data.setCodeMotifBv(rs.getString(35));
		data.setCommentaireBv(rs.getString(36));

		data.setMontantTotalArriere(rs.getBigDecimal(37));
		data.setMontantEncours(rs.getBigDecimal(38));
		data.setDarEncours(rs.getTimestamp(39));
		data.setSeuilAbsolu(rs.getBigDecimal(40) == null ? null : rs.getLong(40));
		data.setMontantTotalImx(rs.getBigDecimal(41));
		data.setMontantTotalDax(rs.getBigDecimal(42));
		data.setWarning3(rs.getBoolean(43));
		data.setWarning10(rs.getBoolean(44));
		data.setOldStatutEffectif(rs.getString(45));
		data.setOldPalierEffectif(rs.getString(46));
		data.setOldPalierAs(rs.getString(47));
		data.setOldTopF(rs.getBoolean(48));
		data.setOldTopPp(rs.getBoolean(49));
		data.setOldTopAs(rs.getBoolean(50));
		data.setOldPhoto(rs.getBoolean(51));

		return data;
	}

}

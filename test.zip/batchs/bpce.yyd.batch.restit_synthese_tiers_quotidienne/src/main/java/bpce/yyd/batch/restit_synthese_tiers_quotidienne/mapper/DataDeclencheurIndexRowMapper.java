package bpce.yyd.batch.restit_synthese_tiers_quotidienne.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import bpce.yyd.batch.restit_synthese_tiers_quotidienne.beans.DataDeclencheur;

public class DataDeclencheurIndexRowMapper implements RowMapper<DataDeclencheur> {

	@Override
	public DataDeclencheur mapRow(ResultSet rs, int rowNum) throws SQLException {

		DataDeclencheur data = new DataDeclencheur();
		data.setTiersId(rs.getLong(1));
		data.setCodeBanque(rs.getString(2));
		data.setIdLocal(rs.getString(3));
		data.setIdRFT(rs.getString(4));
		data.setOldRft(rs.getString(5));
		data.setCodeSegment(rs.getString(6));
		data.setOldCodeSegment(rs.getString(7));
		data.setSiren(rs.getString(8));
		data.setOldSiren(rs.getString(9));
		data.setIdSynthTiersLocal(rs.getLong(10) == 0 ? null : rs.getLong(10));
		data.setIdSynthSiren(rs.getLong(11) == 0 ? null : rs.getLong(11));
		data.setIdSynthRft(rs.getLong(12) == 0 ? null : rs.getLong(12));
		data.setType(rs.getString(13));
		data.setOldType(rs.getString(14));
		data.setIdSynthAsso(rs.getLong(15) == 0 ? null : rs.getLong(15));
		data.setRaisonSociale(rs.getString(16));
		data.setCodeBanqueReferente(rs.getString(17));

		return data;
	}
}
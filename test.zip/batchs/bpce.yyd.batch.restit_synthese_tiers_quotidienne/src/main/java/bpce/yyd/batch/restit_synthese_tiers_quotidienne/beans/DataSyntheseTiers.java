package bpce.yyd.batch.restit_synthese_tiers_quotidienne.beans;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DataSyntheseTiers {

	private Long idTiersSyn;

	private Date datePhoto;

	private String idRft;

	private String codeBanque;

	private String idLocal;

	private String siren;

	private String codeSegment;

	private String statutEffectif;

	private String palierEffectif;

	private Date datePalierEffectif;

	private Date dateMajStatutEffectif;

	private String origineStatutEffectif;

	private String statutCalcule;

	private Date dateStatutCalcule;

	private String palierCalcule;

	private Date datePalierCalcule;

	private boolean topPp;

	private Date dateTopPp;

	private Long compteurPp;

	private Date datePrevisionnelleFinPp;

	private boolean topF;

	private Date dateTopF;

	private boolean topA;

	private Long compteurA;

	private Date dateTopA;

	private boolean topAs;

	private Date dateTopAs;

	private Long compteurAs;

	private String palierAs;

	private Date dateMetierEntreeDefaut;

	private String codeEvtEntreeDefaut;

	private Long evtIdCalEntreeDefaut;

	private String evtIdLocalEntreeDefaut;

	private String idEvtEntreeDefaut;

	private Date dateDefautPlusRecent;

	private String codeDefautPlusRecent;

	private Date dateDebForcageBv;

	private Date dateFinForcageBv;

	private String statutBv;

	private String palierBv;

	private String etablissementBv;

	private String utilisateurBv;

	private String codeMotifBv;

	private String commentaireBv;

	private BigDecimal montantTotalArriere;

	private BigDecimal montantEncours;

	private Timestamp darEncours;

	private Long seuilAbsolu;

	private BigDecimal montantTotalImx;

	private BigDecimal montantTotalDax;

	private boolean warning11;

	private boolean warning12;

	private boolean warning13;

	private boolean warning14;

	private boolean warning2;

	private boolean warning3;

	private boolean warning4;

	private boolean warning51;

	private boolean warning52;

	private boolean warning53;

	private boolean warning6;

	private boolean warning7;

	private boolean warning8;

	private boolean warning9;

	private boolean warning10;

	private Date dateDernierePhoto;

	private Long idSyntheseTiers;

	private String oldStatutEffectif;

	private String oldPalierEffectif;

	private String oldPalierAs;

	private boolean oldTopF;

	private boolean oldTopPp;

	private boolean oldTopAs;

	private boolean oldPhoto;
}
package bpce.yyd.batch.restit_synthese_tiers_quotidienne.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import bpce.yyd.batch.restit_synthese_tiers_quotidienne.beans.DataDeclencheur;

public class DataDeclencheurRowMapper implements RowMapper<DataDeclencheur> {

	@Override
	public DataDeclencheur mapRow(ResultSet rs, int rowNum) throws SQLException {

		DataDeclencheur data = new DataDeclencheur();

		data.setTiersId(rs.getLong("TIERS_ID"));
		data.setIdRFT(rs.getString("ID_RFT"));
		data.setOldRft(rs.getString("OLD_RFT"));
		data.setIdLocal(rs.getString("ID_LOCAL"));
		data.setCodeBanque(rs.getString("CODE_BANQUE"));
		data.setCodeSegment(rs.getString("CODE_SEGMENT"));
		data.setOldCodeSegment(rs.getString("OLD_CODE_SEGMENT"));
		data.setSiren(rs.getString("SIREN"));
		data.setOldSiren(rs.getString("OLD_SIREN"));
		data.setType(rs.getString("TYPE"));
		data.setOldType(rs.getString("OLD_TYPE"));
		data.setCodeBanqueReferente(rs.getString("CODE_BANQUE_REF"));
		data.setRaisonSociale(rs.getString("RAISON_SOCIAL"));
		data.setIdSynthTiersLocal(rs.getLong("id_tiers_local")== 0 ? null : rs.getLong("id_tiers_local"));
		data.setIdSynthAsso(rs.getLong("id_asoo_id")== 0 ? null : rs.getLong("id_asoo_id"));
		data.setIdSynthRft(rs.getLong("id_rft_id")== 0 ? null : rs.getLong("id_rft_id"));
		data.setIdSynthSiren(rs.getLong("id_siren_id") == 0 ? null : rs.getLong("id_siren_id"));
		return data;
	}
}
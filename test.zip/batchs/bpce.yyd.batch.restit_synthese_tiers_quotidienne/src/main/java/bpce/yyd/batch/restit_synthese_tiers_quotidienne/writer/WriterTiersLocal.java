package bpce.yyd.batch.restit_synthese_tiers_quotidienne.writer;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;

import bpce.yyd.batch.restit_synthese_tiers_quotidienne.beans.DataDeclencheur;
import fr.bpce.yyd.batch.commun.beans.DataForUpdateDateTiers;
import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.commun.model.restitution.RestAssociateRftSiren;
import fr.bpce.yyd.commun.model.restitution.RestTiersIdRft;
import fr.bpce.yyd.commun.model.restitution.RestTiersLocal;
import fr.bpce.yyd.commun.model.restitution.RestTiersSiren;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Setter
@Slf4j
public class WriterTiersLocal implements ItemWriter<DataDeclencheur> {

	private String date;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	private JobExecution jobExecution;

	private static final String ID_P_RFT_SIREN = "ID_P_RFT_SIREN";
	private static final String NB_INS_REST_TIERS_ID_LOCAL = "NB_INS_REST_TIERS_ID_LOCAL";
	private static final String NB_MAJ_REST_TIERS_ID_LOCAL = "NB_MAJ_REST_TIERS_ID_LOCAL";
	private static final String NB_INS_REST_TIERS_SIREN = "NB_INS_REST_TIERS_SIREN";
	private static final String NB_INS_REST_TIERS_ID_RFT = "NB_INS_REST_TIERS_ID_RFT";
	private static final String NB_INS_REST_ASSOC_RFT_SIREN = "NB_INS_REST_ASSOC_RFT_SIREN";

	private static Map<String, RestTiersSiren> mapSiren = new HashMap<>();
	private static Map<String, RestTiersIdRft> mapRft = new HashMap<>();
	private static Map<String, RestAssociateRftSiren> mapAsso = new HashMap<>();
	private static List<DataForUpdateDateTiers> tiersForUpdate = new ArrayList<>();
	// Set globale contenant tout les tiers, utilisé pour le controle des
	// doublons
	private static Set<RestTiersLocal> tiersLocalAll = new HashSet<>();
	// liste contenant uniquement les tiers du paquet traité de
	// 10000=commit-interval,
	// cette liste est vidée à chaque appel au write
	private static List<RestTiersLocal> tiersLocals = new ArrayList<>();

	@BeforeStep
	public void beforeStep(StepExecution stepExecution) {
		stepExecution.getJobExecution().getExecutionContext().put(NB_INS_REST_TIERS_ID_LOCAL, 0L);
		stepExecution.getJobExecution().getExecutionContext().put(NB_MAJ_REST_TIERS_ID_LOCAL, 0L);
		stepExecution.getJobExecution().getExecutionContext().put(NB_INS_REST_TIERS_SIREN, 0L);
		stepExecution.getJobExecution().getExecutionContext().put(NB_INS_REST_TIERS_ID_RFT, 0L);
		stepExecution.getJobExecution().getExecutionContext().put(NB_INS_REST_ASSOC_RFT_SIREN, 0L);
		this.jobExecution = stepExecution.getJobExecution();

	}

	@Override
	public void write(List<? extends DataDeclencheur> dataDeclencheurs) throws Exception {

		log.info("Début de chargement de: " + dataDeclencheurs.size() + " tiers");

		for (int i = 0; i < dataDeclencheurs.size(); i++) {
			DataDeclencheur dataDeclencheur = dataDeclencheurs.get(i);
			checkDataSirenAndRft(dataDeclencheur);
			if (dataDeclencheur.getIdSynthTiersLocal() == null || checkChangementRftSegmentSiren(dataDeclencheur)) {
				RestTiersLocal tiersLocal = new RestTiersLocal(dataDeclencheur.getCodeBanque(),
						dataDeclencheur.getIdLocal(), dataDeclencheur.getCodeSegment(),
						LocalDate.parse(date, Constant.YYYYMMDD_FORMATTER), dataDeclencheur.getType());
				String keyAsso = dataDeclencheur.getIdRFT() + "-" + dataDeclencheur.getSiren();
				if (mapAsso.containsKey(keyAsso)) {
					tiersLocal.setRestAssoRftSiren(mapAsso.get(keyAsso));
				}
				if (tiersLocal.getCodeBanque() != null && !tiersLocalAll.contains(tiersLocal)) {
					tiersLocals.add(tiersLocal);
					tiersLocalAll.add(tiersLocal);
				}
			}
		}
		updateDateFinOfTiers();
		insertSiren();
		insertRft();
		insertAssoRftSiren();
		insertTiersLocal();
		tiersForUpdate.clear();
		tiersLocals.clear();
	}

	private void insertTiersLocal() {

		String query = "INSERT INTO REST_TIERS_ID_LOCAL (ID_ASSOC_ID,CODE_BANQUE,ID_LOCAL,CODE_SEGMENT,DATE_DEBUT,DATE_FIN,TYPE) VALUES (?,?,?,?,?,?,?)";
		int[] nbInsert = jdbcTemplate.batchUpdate(query, new BatchPreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setObject(1,
						tiersLocals.get(i).getRestAssoRftSiren() != null
								? tiersLocals.get(i).getRestAssoRftSiren().getId()
								: null);
				ps.setString(2, tiersLocals.get(i).getCodeBanque());
				ps.setString(3, tiersLocals.get(i).getIdLocal());
				ps.setString(4, tiersLocals.get(i).getCodeSegment());
				ps.setDate(5, Date.valueOf(tiersLocals.get(i).getDateDebut()));
				ps.setObject(6, null);
				ps.setString(7, tiersLocals.get(i).getType());
			}

			@Override
			public int getBatchSize() {
				return tiersLocals.size();
			}
		});
		Long nbInsertPrec = jobExecution.getExecutionContext().getLong(NB_INS_REST_TIERS_ID_LOCAL);
		jobExecution.getExecutionContext().put(NB_INS_REST_TIERS_ID_LOCAL,
				nbInsertPrec + Arrays.stream(nbInsert).sum());
	}

	private void insertAssoRftSiren() {
		List<RestAssociateRftSiren> checkAsso = mapAsso.values().stream().filter(x -> x.getId() == null)
				.collect(Collectors.toList());
		for (int i = 0; i < checkAsso.size(); i++) {
			Long rft = checkAsso.get(i).getRestIdRFT() != null ? checkAsso.get(i).getRestIdRFT().getId() : null;
			Long siren = checkAsso.get(i).getRestIdSiren() != null ? checkAsso.get(i).getRestIdSiren().getId() : null;
			Long key = findKeyAssoIfExist(rft, siren);
			checkAsso.get(i).setId(key);
		}

		List<RestAssociateRftSiren> insertAsso = checkAsso.stream().filter(x -> x.getId() == null)
				.collect(Collectors.toList());

		String query = "INSERT INTO REST_ASSOC_RFT_SIREN (ID_RFT,ID_SIREN) VALUES (?,?)";
		int[] nbInsert = jdbcTemplate.batchUpdate(query, new BatchPreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setObject(1,
						insertAsso.get(i).getRestIdRFT() != null ? insertAsso.get(i).getRestIdRFT().getId() : null);
				ps.setObject(2,
						insertAsso.get(i).getRestIdSiren() != null ? insertAsso.get(i).getRestIdSiren().getId() : null);
			}

			@Override
			public int getBatchSize() {
				return insertAsso.size();
			}
		});
		Long nbInsertPrec = jobExecution.getExecutionContext().getLong(NB_INS_REST_ASSOC_RFT_SIREN);
		jobExecution.getExecutionContext().put(NB_INS_REST_ASSOC_RFT_SIREN,
				nbInsertPrec + Arrays.stream(nbInsert).sum());
		for (int i = 0; i < insertAsso.size(); i++) {
			Long rft = insertAsso.get(i).getRestIdRFT() != null ? insertAsso.get(i).getRestIdRFT().getId() : null;
			Long siren = insertAsso.get(i).getRestIdSiren() != null ? insertAsso.get(i).getRestIdSiren().getId() : null;
			Long key = findKeyAsso(rft, siren);
			insertAsso.get(i).setId(key);
		}
	}

	private Long findKeyAssoIfExist(Long rft, Long siren) {
		if (siren != null && rft != null) {
			List<Long> items = jdbcTemplate.query(
					"Select ID_P_RFT_SIREN from REST_ASSOC_RFT_SIREN where ID_RFT = ? and ID_SIREN = ?",
					new Object[] { rft, siren }, (rs, rowNum) -> rs.getLong(ID_P_RFT_SIREN));
			if (!items.isEmpty()) {
				return items.get(0);
			}

		} else if (siren == null && rft != null) {
			List<Long> items = jdbcTemplate.query(
					"Select ID_P_RFT_SIREN from REST_ASSOC_RFT_SIREN where ID_RFT = ? and ID_SIREN is null",
					new Object[] { rft }, (rs, rowNum) -> rs.getLong(ID_P_RFT_SIREN));
			if (!items.isEmpty()) {
				return items.get(0);
			}
		} else if (siren != null) {
			List<Long> items = jdbcTemplate.query(
					"Select ID_P_RFT_SIREN from REST_ASSOC_RFT_SIREN where ID_RFT is null and ID_SIREN = ?",
					new Object[] { siren }, (rs, rowNum) -> rs.getLong(ID_P_RFT_SIREN));
			if (!items.isEmpty()) {
				return items.get(0);
			}
		}
		return null;
	}

	private Long findKeyAsso(Long rft, Long siren) {
		if (siren != null && rft != null) {
			return jdbcTemplate.queryForObject(
					"Select ID_P_RFT_SIREN from REST_ASSOC_RFT_SIREN where ID_RFT = ? and ID_SIREN = ?",
					new Object[] { rft, siren }, (rs, rowNum) -> rs.getLong(ID_P_RFT_SIREN));

		} else if (siren == null && rft != null) {
			return jdbcTemplate.queryForObject(
					"Select ID_P_RFT_SIREN from REST_ASSOC_RFT_SIREN where ID_RFT = ? and ID_SIREN is null",
					new Object[] { rft }, (rs, rowNum) -> rs.getLong(ID_P_RFT_SIREN));
		} else if (siren != null) {
			return jdbcTemplate.queryForObject(
					"Select ID_P_RFT_SIREN from REST_ASSOC_RFT_SIREN where ID_RFT is null and ID_SIREN = ?",
					new Object[] { siren }, (rs, rowNum) -> rs.getLong(ID_P_RFT_SIREN));
		}
		return null;

	}

	private void insertRft() {
		List<RestTiersIdRft> insertRft = mapRft.values().stream().filter(x -> x.getId() == null)
				.collect(Collectors.toList());
		if (insertRft.isEmpty()) {
			return;
		}
		String query = "INSERT INTO REST_TIERS_ID_RFT (ID_RFT,CD_BANQUE_REFERENTE,RAISON_SOCIALE) VALUES (?,?,?)";
		int[] nbInsert = jdbcTemplate.batchUpdate(query, new BatchPreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setString(1, insertRft.get(i).getIdRft());
				ps.setString(2, insertRft.get(i).getCodeBanqueReferente());
				ps.setString(3, insertRft.get(i).getRaisonSociale());
			}

			@Override
			public int getBatchSize() {
				return insertRft.size();
			}
		});
		Long nbInsertPrec = jobExecution.getExecutionContext().getLong(NB_INS_REST_TIERS_ID_RFT);
		jobExecution.getExecutionContext().put(NB_INS_REST_TIERS_ID_RFT, nbInsertPrec + Arrays.stream(nbInsert).sum());
		for (int i = 0; i < insertRft.size(); i++) {
			Long key = jdbcTemplate.queryForObject("Select ID_P_RFT from REST_TIERS_ID_RFT where ID_RFT = ?",
					new Object[] { insertRft.get(i).getIdRft() }, (rs, rowNum) -> rs.getLong("ID_P_RFT"));
			insertRft.get(i).setId(key);
		}
	}

	private void insertSiren() {

		List<RestTiersSiren> insertSiren = mapSiren.values().stream().filter(x -> x.getId() == null)
				.collect(Collectors.toList());
		if (insertSiren.isEmpty()) {
			return;
		}
		String query = "INSERT INTO REST_TIERS_SIREN (SIREN) VALUES (?)";
		int[] nbInsert = jdbcTemplate.batchUpdate(query, new BatchPreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setString(1, insertSiren.get(i).getSiren());
			}

			@Override
			public int getBatchSize() {
				return insertSiren.size();
			}
		});

		Long nbInsertPrec = jobExecution.getExecutionContext().getLong(NB_INS_REST_TIERS_SIREN);
		jobExecution.getExecutionContext().put(NB_INS_REST_TIERS_SIREN, nbInsertPrec + Arrays.stream(nbInsert).sum());
		for (int i = 0; i < insertSiren.size(); i++) {
			Long key = jdbcTemplate.queryForObject("Select ID_P_SIREN from REST_TIERS_SIREN where SIREN = ?",
					new Object[] { insertSiren.get(i).getSiren() }, (rs, rowNum) -> rs.getLong("ID_P_SIREN"));
			insertSiren.get(i).setId(key);
		}
	}

	private void updateDateFinOfTiers() {
		if (tiersForUpdate.isEmpty()) {
			return;
		}
		String query = "update rest_tiers_id_local set date_fin = ? where id_p_id_local = ?";
		int[] nbInsert = jdbcTemplate.batchUpdate(query, new BatchPreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setDate(1, tiersForUpdate.get(i).getDateFin());
				ps.setLong(2, tiersForUpdate.get(i).getIdTiers());
			}

			@Override
			public int getBatchSize() {
				return tiersForUpdate.size();
			}
		});
		Long nbInsertPrec = jobExecution.getExecutionContext().getLong(NB_MAJ_REST_TIERS_ID_LOCAL);
		jobExecution.getExecutionContext().put(NB_MAJ_REST_TIERS_ID_LOCAL,
				nbInsertPrec + Arrays.stream(nbInsert).sum());

	}

	private void checkDataSirenAndRft(DataDeclencheur dataDeclencheur) {

		String siren = dataDeclencheur.getSiren();
		String rft = dataDeclencheur.getIdRFT();

		if (siren != null && !mapSiren.containsKey(siren)) {
			mapSiren.put(siren, new RestTiersSiren(dataDeclencheur.getIdSynthSiren(), siren));
		}
		if (rft != null && !mapRft.containsKey(rft)) {
			mapRft.put(rft, new RestTiersIdRft(dataDeclencheur.getIdSynthRft(), rft,
					dataDeclencheur.getCodeBanqueReferente(), dataDeclencheur.getRaisonSociale()));
		}
		String keyAsso = rft + "-" + siren;
		if ((rft != null || siren != null) && !mapAsso.containsKey(keyAsso)) {
			mapAsso.put(keyAsso,
					new RestAssociateRftSiren(dataDeclencheur.getIdSynthAsso(), mapRft.get(rft), mapSiren.get(siren)));
		}

	}

	private boolean checkChangementRftSegmentSiren(DataDeclencheur dataDeclencheur) {
		if (!Objects.equals(dataDeclencheur.getCodeSegment(), dataDeclencheur.getOldCodeSegment())
				|| !Objects.equals(dataDeclencheur.getIdRFT(), dataDeclencheur.getOldRft())
				|| !Objects.equals(dataDeclencheur.getSiren(), dataDeclencheur.getOldSiren())
				|| !Objects.equals(dataDeclencheur.getType(), dataDeclencheur.getOldType())) {
			tiersForUpdate
					.add(new DataForUpdateDateTiers(Date.valueOf(LocalDate.parse(date, Constant.YYYYMMDD_FORMATTER)),
							dataDeclencheur.getIdSynthTiersLocal()));
			return true;
		}
		return false;
	}
}
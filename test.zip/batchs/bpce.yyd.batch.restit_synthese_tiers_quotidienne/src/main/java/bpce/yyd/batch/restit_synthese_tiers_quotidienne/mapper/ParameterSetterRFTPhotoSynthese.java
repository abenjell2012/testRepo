package bpce.yyd.batch.restit_synthese_tiers_quotidienne.mapper;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.jdbc.core.PreparedStatementSetter;

public class ParameterSetterRFTPhotoSynthese implements PreparedStatementSetter {

	private Date date;

	public ParameterSetterRFTPhotoSynthese(Date date) {
		this.date = date;
	}

	@Override
	public void setValues(PreparedStatement ps) throws SQLException {

		for (int i = 1; i < 46; i++) {
			ps.setDate(i, date);
		}
	}
}

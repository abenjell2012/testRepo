package bpce.yyd.batch.restit_synthese_tiers_quotidienne.beans;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DataDeclencheur {

	private Long tiersId;

	private String idRFT;

	private String oldRft;

	private String siren;

	private String oldSiren;

	private String idLocal;

	private String codeBanque;

	private String codeSegment;

	private String oldCodeSegment;

	private String type;

	private String oldType;

	private Long idSynthTiersLocal;

	private Long idSynthSiren;

	private Long idSynthRft;

	private Long idSynthAsso;

	private String codeBanqueReferente;

	private String raisonSociale;

}
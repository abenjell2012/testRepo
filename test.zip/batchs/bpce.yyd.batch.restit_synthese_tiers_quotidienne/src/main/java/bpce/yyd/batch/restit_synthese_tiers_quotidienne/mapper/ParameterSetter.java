package bpce.yyd.batch.restit_synthese_tiers_quotidienne.mapper;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.jdbc.core.PreparedStatementSetter;

public class ParameterSetter implements PreparedStatementSetter {

	private Date date;

	public ParameterSetter(Date date) {
		this.date = date;
	}

	@Override
	public void setValues(PreparedStatement ps) throws SQLException {
		ps.setDate(1, date);
	}
}

package bpce.yyd.batch.restit_synthese_tiers_quotidienne.task;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.stereotype.Service;

import lombok.Setter;

@Setter
@Service
public class UpdateIDSyntheseRetail implements Tasklet {

	private static final String SQL = "UPDATE REST_SYNTH_TIERS_LOCAL_STATUS SET ID_SITUATION_TIERS = ID_P_SYNTHESE where DATE_PHOTO = ? and ID_SITUATION_TIERS IS NULL";

	@Autowired
	private JdbcTemplate jdbcTemplate;

	private Date date;

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

		jdbcTemplate.update(SQL, new PreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setDate(1, date);
			}
		});

		return RepeatStatus.FINISHED;
	}
}
package bpce.yyd.batch.restit_synthese_tiers_quotidienne.task;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import fr.bpce.yyd.batch.commun.utils.CalculStatsUtils;

public class CalculStatsTaskletFindSynthese implements Tasklet {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

		// tables moteurs/collecte

		CalculStatsUtils.calculStatTable(jdbcTemplate, "STATUT_SBV", 4);
		CalculStatsUtils.calculStatTable(jdbcTemplate, "EVENEMENT", 4);
		CalculStatsUtils.calculStatTable(jdbcTemplate, "EVENEMENT_CALCULE", 4);
		CalculStatsUtils.calculStatTable(jdbcTemplate, "COMPLEMENT_EVENEMENT", 8);
		CalculStatsUtils.calculStatTable(jdbcTemplate, "TIERS", 4);
		CalculStatsUtils.calculStatTable(jdbcTemplate, "ENCOURS_TIERS", 4);
		CalculStatsUtils.calculStatTable(jdbcTemplate, "IDENTITE_TIERS", 4);
		CalculStatsUtils.calculStatTable(jdbcTemplate, "STATUT_TIERS", 4);

		// tables SYNTHESE

		CalculStatsUtils.calculStatTable(jdbcTemplate, "REST_DECLENCHEURS", 4);
		CalculStatsUtils.calculStatTable(jdbcTemplate, "REST_TIERS_ID_LOCAL", 4);

		return RepeatStatus.FINISHED;
	}

}

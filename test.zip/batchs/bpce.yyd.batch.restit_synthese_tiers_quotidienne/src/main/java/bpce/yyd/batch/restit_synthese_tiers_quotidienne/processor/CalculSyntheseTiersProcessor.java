package bpce.yyd.batch.restit_synthese_tiers_quotidienne.processor;

import static fr.bpce.yyd.batch.commun.utils.CalculSyntheseTiersUtils.calculCompteurA;
import static fr.bpce.yyd.batch.commun.utils.CalculSyntheseTiersUtils.calculCompteurAS;
import static fr.bpce.yyd.batch.commun.utils.CalculSyntheseTiersUtils.calculCompteurPP;
import static fr.bpce.yyd.batch.commun.utils.CalculSyntheseTiersUtils.calculDatePrevisionnelleFinPP;
import static fr.bpce.yyd.batch.commun.utils.CalculSyntheseTiersUtils.calculWarningAR0;
import static fr.bpce.yyd.batch.commun.utils.CalculSyntheseTiersUtils.calculWarningAR1;
import static fr.bpce.yyd.batch.commun.utils.CalculSyntheseTiersUtils.calculWarningAR2;
import static fr.bpce.yyd.batch.commun.utils.CalculSyntheseTiersUtils.calculWarningAR3;
import static fr.bpce.yyd.batch.commun.utils.CalculSyntheseTiersUtils.calculWarningCX;
import static fr.bpce.yyd.batch.commun.utils.CalculSyntheseTiersUtils.calculWarningDX;
import static fr.bpce.yyd.batch.commun.utils.CalculSyntheseTiersUtils.calculWarningDefaut;
import static fr.bpce.yyd.batch.commun.utils.CalculSyntheseTiersUtils.calculWarningForbearance;
import static fr.bpce.yyd.batch.commun.utils.CalculSyntheseTiersUtils.calculWarningPP;
import static fr.bpce.yyd.batch.commun.utils.CalculSyntheseTiersUtils.calculWarningPPWithAS;
import static fr.bpce.yyd.batch.commun.utils.CalculSyntheseTiersUtils.calculWarningPPWithF;
import static fr.bpce.yyd.batch.commun.utils.CalculSyntheseTiersUtils.calculWarningRX;
import static fr.bpce.yyd.batch.commun.utils.CalculSyntheseTiersUtils.calculWarningSain;
import static fr.bpce.yyd.batch.commun.utils.CalculSyntheseTiersUtils.checkCompteur;
import static fr.bpce.yyd.batch.commun.utils.CalculSyntheseTiersUtils.findTiersId;

import java.sql.Date;
import java.time.LocalDate;

import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import bpce.yyd.batch.restit_synthese_tiers_quotidienne.beans.DataSyntheseTiers;
import lombok.Setter;

@Setter
public class CalculSyntheseTiersProcessor implements ItemProcessor<DataSyntheseTiers, DataSyntheseTiers> {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	private Date date;

	@Override
	public DataSyntheseTiers process(DataSyntheseTiers item) throws Exception {

		LocalDate dateCalcul = date.toLocalDate();

		item.setDatePhoto(date);
		if (item.isTopAs()) {
			Long compteurAs = calculCompteurAS(item.getDateTopAs().toLocalDate(), dateCalcul);
			item.setCompteurAs(checkCompteur(compteurAs));

			if (compteurAs > 90l) {
				item.setPalierAs("AR3");
			} else if (compteurAs > 60l) {
				item.setPalierAs("AR2");
			} else if (compteurAs > 30l) {
				item.setPalierAs("AR1");
			} else {
				item.setPalierAs("AR0");
			}

			item.setWarning11(calculWarningAR0(item.getOldPalierAs(), item.getPalierAs()));
			item.setWarning12(calculWarningAR1(item.getOldPalierAs(), item.getPalierAs()));
			item.setWarning13(calculWarningAR2(item.getOldPalierAs(), item.getPalierAs()));
			item.setWarning14(calculWarningAR3(item.getOldPalierAs(), item.getPalierAs()));
		}

		if (item.isTopA()) {
			Long compteurA = calculCompteurA(item.getDateTopA().toLocalDate(), dateCalcul);
			item.setCompteurA(checkCompteur(compteurA));
		}

		if (item.isTopPp()) {

			item.setDatePrevisionnelleFinPp(
					calculDatePrevisionnelleFinPP(item.getDateTopPp().toLocalDate(), item.isTopF()));
			Long tiersId = findTiersId(item.getCodeBanque(), item.getIdLocal(), jdbcTemplate);
			item.setCompteurPp(checkCompteur(calculCompteurPP(tiersId, item.getDateTopPp().toLocalDate(), dateCalcul,
					item.getCodeSegment(), jdbcTemplate)));
		}

		item.setWarning2(calculWarningForbearance(item.isOldTopF(), item.isTopF()));

		item.setWarning4(calculWarningDefaut(item.getOldStatutEffectif(), item.getStatutEffectif()));

		// a verifier
		item.setWarning51(calculWarningRX(item.getOldPalierEffectif(), item.getPalierEffectif()));

		item.setWarning52(calculWarningDX(item.getOldPalierEffectif(), item.getPalierEffectif()));

		item.setWarning53(calculWarningCX(item.getOldPalierEffectif(), item.getPalierEffectif()));

		item.setWarning6(calculWarningPP(item.isOldTopPp(), item.isTopPp()));

		item.setWarning7(calculWarningPPWithAS(item.isTopPp(), item.isTopAs(), item.isOldTopAs(), item.isOldPhoto()));

		item.setWarning8(calculWarningSain(item.getOldStatutEffectif(), item.getStatutEffectif()));

		item.setWarning9(
				calculWarningPPWithF(item.getStatutEffectif(), item.isWarning2(), item.isTopF(), item.isWarning8()));

		// warning 10 = 1 si top F = 1
		item.setWarning10(item.isTopF() && item.isWarning10());

		if (item.getIdRft() != null) {
			String situation = formatIdSituation(dateCalcul, item.getIdRft());
			long idSituation = formatStrintToLong(situation);
			item.setIdSyntheseTiers(idSituation);
		}

		if (item.getEvtIdCalEntreeDefaut() != null) {
			item.setIdEvtEntreeDefaut(item.getEvtIdCalEntreeDefaut().toString());
		} else {
			item.setIdEvtEntreeDefaut(item.getEvtIdLocalEntreeDefaut());
		}
		return item;
	}

	public String formatIdSituation(LocalDate dateCalcul, String idRft) {
		if (dateCalcul == null) {
			return null;
		}
		String day = String.valueOf(dateCalcul.getDayOfYear());
		String yy = String.valueOf(dateCalcul.getYear());
		return yy.substring(2) + StringUtils.leftPad(day, 3, '0') + idRft;
	}

	public long formatStrintToLong(String chaine) {
		return Long.parseLong(chaine);
	}

}
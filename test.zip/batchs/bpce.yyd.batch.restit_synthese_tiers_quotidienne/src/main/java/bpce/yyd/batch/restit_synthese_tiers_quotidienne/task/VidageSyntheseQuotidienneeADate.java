package bpce.yyd.batch.restit_synthese_tiers_quotidienne.task;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.stereotype.Service;

import fr.bpce.yyd.batch.commun.constantes.Constant;
import lombok.Setter;

@Setter
@Service
public class VidageSyntheseQuotidienneeADate implements Tasklet{

	private static final String DELETE_QUERY_EVENT_MDC = "delete from  REST_SYNTH_EVT_MDC_STATUS " +
			"where date_generation_mdc >= ? and date_generation_mdc < ?";

	private static final String DELETE_QUERY_EVENT_LOCAL = "delete from  REST_SYNTH_EVT_LOCAL_STATUS " +
			"where date_generation_evt >= ? and date_generation_evt < ?";

	private static final String DELETE_QUERY_SYNTHESE = "delete from REST_SYNTH_TIERS_LOCAL_STATUS  where date_photo = ?";

	private String date;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		LocalDate dateBatch = LocalDate.parse(date,Constant.YYYYMMDD_FORMATTER);
		Date dateDebut = Date.valueOf(dateBatch);
		Date dateFin = Date.valueOf(dateBatch.plusDays(1));

		deleteEvent(DELETE_QUERY_EVENT_MDC,dateDebut,dateFin);
		deleteEvent(DELETE_QUERY_EVENT_LOCAL,dateDebut,dateFin);

		runQuery(DELETE_QUERY_SYNTHESE,dateDebut);


		return RepeatStatus.FINISHED;
	}

	private void runQuery(String sql, Date dateDebut) {
		jdbcTemplate.update(sql, new PreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setDate(1, dateDebut);
			}
		});

	}

	private void deleteEvent(String sql,Date dateDebut,Date dateFin) {
		jdbcTemplate.update(sql, new PreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setDate(1, dateDebut);
				ps.setDate(2, dateFin);
			}
		});
	}
}

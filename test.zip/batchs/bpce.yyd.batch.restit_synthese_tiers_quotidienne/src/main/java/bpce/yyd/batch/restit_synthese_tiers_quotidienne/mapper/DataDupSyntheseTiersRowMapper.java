package bpce.yyd.batch.restit_synthese_tiers_quotidienne.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import bpce.yyd.batch.restit_synthese_tiers_quotidienne.beans.DataSyntheseTiers;

public class DataDupSyntheseTiersRowMapper implements RowMapper<DataSyntheseTiers> {

	@Override
	public DataSyntheseTiers mapRow(ResultSet rs, int rowNum) throws SQLException {
		DataSyntheseTiers data = new DataSyntheseTiers();
		data.setIdTiersSyn((rs.getBigDecimal(1) == null) ? null : rs.getLong(1));
		// 2, 3, 4, 5 champs inutiles
		data.setCodeBanque(rs.getString(6));
		data.setIdLocal(rs.getString(7));
		// 8 champ inutile
		data.setIdRft(rs.getString(9));
		data.setDatePhoto(rs.getDate(10));
		data.setStatutEffectif(rs.getString(11));
		data.setPalierEffectif(rs.getString(12));
		data.setDateMajStatutEffectif(rs.getDate(13));
		data.setOrigineStatutEffectif(rs.getString(14));

		data.setDateMetierEntreeDefaut(rs.getDate(15));
		data.setCodeEvtEntreeDefaut(rs.getString(16));
		data.setIdEvtEntreeDefaut(rs.getString(17));
		data.setDateDefautPlusRecent(rs.getDate(18));
		data.setCodeDefautPlusRecent(rs.getString(19));
		data.setStatutCalcule(rs.getString(20));
		data.setDateStatutCalcule(rs.getDate(21));
		data.setPalierCalcule(rs.getString(22));
		data.setDatePalierCalcule(rs.getDate(23));
		data.setDateDebForcageBv(rs.getDate(24));
		data.setDateFinForcageBv(rs.getDate(25));
		data.setStatutBv(rs.getString(26));
		data.setPalierBv(rs.getString(27));
		data.setEtablissementBv(rs.getString(28));
		data.setUtilisateurBv(rs.getString(29));
		data.setCodeMotifBv(rs.getString(30));
		data.setCommentaireBv(rs.getString(31));
		data.setTopPp(rs.getBoolean(32));
		data.setDateTopPp(rs.getDate(33));
		data.setCompteurPp(rs.getLong(34));
		data.setDatePrevisionnelleFinPp(rs.getDate(35));
		data.setTopF(rs.getBoolean(36));
		data.setDateTopF(rs.getDate(37));
		data.setTopA(rs.getBoolean(38));
		data.setCompteurA(rs.getLong(39));

		data.setDateTopA(rs.getDate(40));
		data.setTopAs(rs.getBoolean(41));
		data.setCompteurAs(rs.getLong(42));
		data.setDateTopAs(rs.getDate(43));
		data.setPalierAs(rs.getString(44));
		data.setWarning11(rs.getBoolean(45));
		data.setWarning12(rs.getBoolean(46));
		data.setWarning13(rs.getBoolean(47));
		data.setWarning14(rs.getBoolean(48));
		data.setWarning2(rs.getBoolean(49));
		data.setWarning3(rs.getBoolean(50));
		data.setWarning4(rs.getBoolean(51));

		data.setWarning51(rs.getBoolean(52));
		data.setWarning52(rs.getBoolean(53));
		data.setWarning53(rs.getBoolean(54));
		data.setWarning6(rs.getBoolean(55));
		data.setWarning7(rs.getBoolean(56));
		data.setWarning8(rs.getBoolean(57));
		data.setWarning9(rs.getBoolean(58));
		data.setWarning10(rs.getBoolean(59));

		data.setMontantTotalArriere(rs.getBigDecimal(60));
		data.setMontantEncours(rs.getBigDecimal(61));
		data.setDarEncours(rs.getTimestamp(62));
		data.setSeuilAbsolu(rs.getBigDecimal(63) == null ? null : rs.getLong(63));
		data.setMontantTotalImx(rs.getBigDecimal(64));
		data.setMontantTotalDax(rs.getBigDecimal(65));
		data.setIdSyntheseTiers(rs.getBigDecimal(66) == null ? null : rs.getLong(66));

		return data;
	}

}

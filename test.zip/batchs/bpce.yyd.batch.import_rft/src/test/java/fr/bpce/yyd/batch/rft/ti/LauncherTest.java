package fr.bpce.yyd.batch.rft.ti;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import fr.bpce.yyd.batch.rft.launch.Launcher;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.commun.model.TiersRFT;

public class LauncherTest extends AbstractIntegrationTest {

	@BeforeClass
	public static void initProperties() throws Exception {
		initContextAndProperties();
	}

	@Before
	public void cleanFoldersBeforeTest() throws IOException {
		cleanFolders();
		// init TiersRFT
		doInTransaction(() -> {
			EntityManager entityManager = getEntityManager();
			TiersRFT tiersRFT = new TiersRFT();
			tiersRFT.setCodeBanque("12345");
			tiersRFT.setDate(LocalDate.of(2019, 01, 01));
			tiersRFT.setIdFederal("0000012345");
			tiersRFT.setIdLocal("IDLOCAL12345");
			tiersRFT.setSiren("SIREN1234");
			entityManager.persist(tiersRFT);

		});
	}

	@AfterClass
	public static void cleanFoldersAfterClass() throws IOException {
		cleanFolders();
	}

	@Test
	public void fichierOK() throws IOException {
		// save the initial security manager (probably null)
		SecurityManager initialSecurityManger = System.getSecurityManager();

		// Arrange
		Launcher launcher = new Launcher();
		launcher.setApplicationContext(getContext());
		String nomFichier = "NDOD_P_REF_TIERS_20190512.dat";
		copyFilenameToInFolder(nomFichier);

		try {
			// set security manager
			System.setSecurityManager(new NoExitSecurityManager());
			// Act
			launcher.runBatch(properties.getProperty("rep.rft.in") + nomFichier);
		} catch (ExitException e) {
			// Assert
			Assert.assertEquals(0, e.status);
			// Assert
			Assert.assertTrue(new File(properties.getProperty("rep.rft.ok") + nomFichier).exists());
		} finally {
			// restore initial security manager (otherwise a new ExitException will be
			// thrown when the JVM will actually exit)
			System.setSecurityManager(initialSecurityManger);
		}
	}

	@Test
	public void doublePassage() throws IOException {
		// save the initial security manager (probably null)
		SecurityManager initialSecurityManger = System.getSecurityManager();

		// Arrange
		Launcher launcher = new Launcher();
		launcher.setApplicationContext(getContext());
		String nomFichier = "NDOD_P_REF_TIERS_20190512.dat";
		copyFilenameToInFolder(nomFichier);

		try {
			// set security manager
			System.setSecurityManager(new NoExitSecurityManager());
			// Act
			launcher.runBatch(properties.getProperty("rep.rft.in") + nomFichier);
		} catch (ExitException e) {

		}

		// Prend les marques
		final List<TiersRFT> listeTiersRFT1erPassage = new ArrayList<>();
		doInTransaction(() -> {

			EntityManager entityManager = getEntityManager();
			TypedQuery<TiersRFT> query = entityManager.createQuery("select t from TiersRFT t", TiersRFT.class);
			listeTiersRFT1erPassage.addAll(query.getResultList());
		});

		// Arrange 2
		removeAllFilesInFolder(properties.getProperty("rep.rft.ok"));
		copyFilenameToInFolder(nomFichier);

		try {
			// Act 2
			launcher.runBatch(properties.getProperty("rep.rft.in") + nomFichier);

		} catch (ExitException e) {
			// Assert
			Assert.assertEquals(0, e.status);
			// Assert
			final List<TiersRFT> listeTiersRFT2ndPassage = new ArrayList<>();
			doInTransaction(() -> {

				EntityManager entityManager = getEntityManager();
				TypedQuery<TiersRFT> query = entityManager.createQuery("select t from TiersRFT t", TiersRFT.class);
				listeTiersRFT2ndPassage.addAll(query.getResultList());
			});
			Assert.assertEquals(listeTiersRFT1erPassage.size(), listeTiersRFT2ndPassage.size());

		} finally {
			// restore initial security manager (otherwise a new ExitException will be
			// thrown when the JVM will actually exit)
			System.setSecurityManager(initialSecurityManger);
		}
	}

	@Test
	public void fichierKO() throws IOException {
		// save the initial security manager (probably null)
		SecurityManager initialSecurityManger = System.getSecurityManager();

		// Arrange
		Launcher launcher = new Launcher();
		launcher.setApplicationContext(getContext());
		String nomFichier = "NDOD_FORMAT_KO_TIERS_20190513.dat";
		copyFilenameToInFolder(nomFichier);

		try {
			// set security manager
			System.setSecurityManager(new NoExitSecurityManager());
			// Act
			launcher.runBatch(properties.getProperty("rep.rft.in") + nomFichier);
		} catch (ExitException e) {
			// Assert
			Assert.assertEquals(1, e.status);
			// Assert
			Assert.assertTrue(new File(properties.getProperty("rep.rft.ko") + nomFichier).exists());
		} finally {
			// restore initial security manager (otherwise a new ExitException will be
			// thrown when the JVM will actually exit)
			System.setSecurityManager(initialSecurityManger);
		}
	}

	@Test
	public void miseAJourTiers_WhenTiersNonFederalEtNonPresentRFT() throws IOException {
		// save the initial security manager (probably null)
		SecurityManager initialSecurityManger = System.getSecurityManager();

		// Arrange
		Launcher launcher = new Launcher();
		launcher.setApplicationContext(getContext());
		String nomFichier = "NDOD_P_REF_TIERS_20190803.dat";
		copyFilenameToInFolder(nomFichier);

		// init data
		doInTransaction(() -> {
			EntityManager entityManager = getEntityManager();
			Tiers tiersNonFederal = new Tiers();
			IdentiteTiers identiteTiers = new IdentiteTiers("megane", "20019", "1100", "024050676");
			identiteTiers.setDateDebut(LocalDate.of(2019, 5, 1));
			entityManager.persist(tiersNonFederal);
			identiteTiers.setTiers(tiersNonFederal);
			entityManager.persist(identiteTiers);
		});

		try {
			// set security manager
			System.setSecurityManager(new NoExitSecurityManager());
			// Act
			launcher.runBatch(properties.getProperty("rep.rft.in") + nomFichier);

		} catch (ExitException e) {
			// Assert
			Assert.assertEquals(0, e.status);
			// Assert
			Assert.assertTrue(new File(properties.getProperty("rep.rft.ok") + nomFichier).exists());
			doInTransaction(() -> {
				List<Tiers> tousTiers = findAllTiers();
				Assert.assertEquals(1, tousTiers.size());
				Tiers tiers = tousTiers.get(0);
				Assert.assertNull(tiers.getIdFederal());
				Assert.assertEquals(1, tiers.getIdentites().size());
				IdentiteTiers identitiersTiers = tiers.getIdentites().iterator().next();
				Assert.assertEquals("megane", identitiersTiers.getIdLocal());
				Assert.assertEquals("1100", identitiersTiers.getCodeSegment());
				Assert.assertEquals("20019", identitiersTiers.getCodeBanque());
				Assert.assertNotNull(identitiersTiers.getDateDebut());
				Assert.assertNull(identitiersTiers.getDateFin());
				Assert.assertNull(identitiersTiers.getSuivante());
			});
		} finally {
			// restore initial security manager (otherwise a new ExitException will be
			// thrown when the JVM will actually exit)
			System.setSecurityManager(initialSecurityManger);
		}
	}

	@Test
	public void miseAJourTiers_WhenTiersFederalEtEgaleRFT() throws IOException {
		// save the initial security manager (probably null)
		SecurityManager initialSecurityManger = System.getSecurityManager();

		// Arrange
		Launcher launcher = new Launcher();
		launcher.setApplicationContext(getContext());
		String nomFichier = "NDOD_P_REF_TIERS_20190803.dat";
		copyFilenameToInFolder(nomFichier);

		// init data
		doInTransaction(() -> {
			EntityManager entityManager = getEntityManager();
			Tiers tiersFederal = new Tiers();
			tiersFederal.setIdFederal("0000005500");
			IdentiteTiers identiteTiers = new IdentiteTiers("polo", "20019", "1100", "024050676");
			identiteTiers.setDateDebut(LocalDate.of(2019, 5, 1));
			entityManager.persist(tiersFederal);
			identiteTiers.setTiers(tiersFederal);
			entityManager.persist(identiteTiers);
		});

		try {
			// set security manager
			System.setSecurityManager(new NoExitSecurityManager());
			// Act
			launcher.runBatch(properties.getProperty("rep.rft.in") + nomFichier);

		} catch (ExitException e) {
			// Assert
			Assert.assertEquals(0, e.status);
			// Assert
			Assert.assertTrue(new File(properties.getProperty("rep.rft.ok") + nomFichier).exists());
			doInTransaction(() -> {
				List<Tiers> tousTiers = findAllTiers();
				Assert.assertEquals(1, tousTiers.size());
				Tiers tiers = tousTiers.get(0);
				Assert.assertEquals("0000005500", tiers.getIdFederal());
				Assert.assertEquals(1, tiers.getIdentites().size());
				IdentiteTiers identitiersTiers = tiers.getIdentites().iterator().next();
				Assert.assertEquals("polo", identitiersTiers.getIdLocal());
				Assert.assertEquals("1100", identitiersTiers.getCodeSegment());
				Assert.assertEquals("20019", identitiersTiers.getCodeBanque());
				Assert.assertNotNull(identitiersTiers.getDateDebut());
				Assert.assertNull(identitiersTiers.getDateFin());
				Assert.assertNull(identitiersTiers.getSuivante());
			});
		} finally {
			// restore initial security manager (otherwise a new ExitException will be
			// thrown when the JVM will actually exit)
			System.setSecurityManager(initialSecurityManger);
		}
	}

	@Test
	public void miseAJourTiers_WhenTiersNonFederalEtPresentRFTetNonExistInTableTiers() throws IOException {
		// save the initial security manager (probably null)
		SecurityManager initialSecurityManger = System.getSecurityManager();
		// Arrange
		Launcher launcher = new Launcher();
		launcher.setApplicationContext(getContext());
		String nomFichier = "NDOD_P_REF_TIERS_20190803.dat";
		copyFilenameToInFolder(nomFichier);

		// init data
		doInTransaction(() -> {
			EntityManager entityManager = getEntityManager();
			Tiers tiersNonFederal = new Tiers();
			IdentiteTiers identiteTiers = new IdentiteTiers("polo", "20019", "1100", "024050676");
			identiteTiers.setDateDebut(LocalDate.of(2019, 5, 1));
			entityManager.persist(tiersNonFederal);
			identiteTiers.setTiers(tiersNonFederal);
			entityManager.persist(identiteTiers);
		});

		try {
			// set security manager
			System.setSecurityManager(new NoExitSecurityManager());
			// Act
			launcher.runBatch(properties.getProperty("rep.rft.in") + nomFichier);

		} catch (ExitException e) {
			// Assert
			Assert.assertEquals(0, e.status);
			// Assert
			Assert.assertTrue(new File(properties.getProperty("rep.rft.ok") + nomFichier).exists());
			doInTransaction(() -> {
				List<Tiers> tousTiers = findAllTiers();
				Assert.assertEquals(1, tousTiers.size());
				Tiers tiers = tousTiers.get(0);
				Assert.assertEquals("0000005500", tiers.getIdFederal());
				Assert.assertEquals(1, tiers.getIdentites().size());
				IdentiteTiers identitiersTiers = tiers.getIdentites().iterator().next();
				Assert.assertEquals("polo", identitiersTiers.getIdLocal());
				Assert.assertEquals("1100", identitiersTiers.getCodeSegment());
				Assert.assertEquals("20019", identitiersTiers.getCodeBanque());
				Assert.assertNotNull(identitiersTiers.getDateDebut());
				Assert.assertNull(identitiersTiers.getDateFin());
				Assert.assertNull(identitiersTiers.getSuivante());
			});
		} finally {
			// restore initial security manager (otherwise a new ExitException will be
			// thrown when the JVM will actually exit)
			System.setSecurityManager(initialSecurityManger);
		}
	}

	@Test
	public void miseAJourTiers_WhenTiersNonFederalEtPresentRFTetExistInTableTiers() throws IOException {
		// save the initial security manager (probably null)
		SecurityManager initialSecurityManger = System.getSecurityManager();
		// Arrange
		Launcher launcher = new Launcher();
		launcher.setApplicationContext(getContext());
		String nomFichier = "NDOD_P_REF_TIERS_20190803.dat";
		copyFilenameToInFolder(nomFichier);

		// init data
		doInTransaction(() -> {
			EntityManager entityManager = getEntityManager();
			Tiers tiersFederal = new Tiers();
			tiersFederal.setIdFederal("0000005500");
			entityManager.persist(tiersFederal);
			Tiers tiersNonFederal = new Tiers();
			IdentiteTiers identiteTiers = new IdentiteTiers("polo", "20019", "1100", "024050676");
			identiteTiers.setDateDebut(LocalDate.of(2019, 5, 1));
			entityManager.persist(tiersNonFederal);
			identiteTiers.setTiers(tiersNonFederal);
			entityManager.persist(identiteTiers);
		});
		try {
			// set security manager
			System.setSecurityManager(new NoExitSecurityManager());
			// Act
			launcher.runBatch(properties.getProperty("rep.rft.in") + nomFichier);

		} catch (ExitException e) {
			// Assert
			Assert.assertEquals(0, e.status);
			// Assert
			Assert.assertTrue(new File(properties.getProperty("rep.rft.ok") + nomFichier).exists());
			doInTransaction(() -> {
				List<Tiers> tousTiers = findAllTiers();
				Assert.assertEquals(2, tousTiers.size());
				for (Tiers tiers : tousTiers) {
					Assert.assertEquals(1, tiers.getIdentites().size());
					IdentiteTiers identitiersTiers = tiers.getIdentites().iterator().next();
					Assert.assertEquals("polo", identitiersTiers.getIdLocal());
					Assert.assertEquals("1100", identitiersTiers.getCodeSegment());
					Assert.assertEquals("20019", identitiersTiers.getCodeBanque());
					if (tiers.getIdFederal() != null) {
						Assert.assertEquals("0000005500", tiers.getIdFederal());
						Assert.assertNull(identitiersTiers.getDateFin());
						Assert.assertNull(identitiersTiers.getSuivante());
						Assert.assertEquals(LocalDate.of(2019, 8, 3), identitiersTiers.getDateDebut());
					} else {
						Assert.assertNotNull(identitiersTiers.getSuivante());
						Assert.assertEquals(LocalDate.of(2019, 5, 1), identitiersTiers.getDateDebut());
						Assert.assertEquals(LocalDate.of(2019, 8, 3), identitiersTiers.getDateFin());
					}
				}
			});
		} finally {
			// restore initial security manager (otherwise a new ExitException will be
			// thrown when the JVM will actually exit)
			System.setSecurityManager(initialSecurityManger);
		}

	}

	@Test
	public void miseAJourTiers_WhenTiersFederalEtNonPresentRFT() throws IOException {
		// save the initial security manager (probably null)
		SecurityManager initialSecurityManger = System.getSecurityManager();
		// Arrange
		Launcher launcher = new Launcher();
		launcher.setApplicationContext(getContext());
		String nomFichier = "NDOD_P_REF_TIERS_20190803.dat";
		copyFilenameToInFolder(nomFichier);

		// init data
		doInTransaction(() -> {
			EntityManager entityManager = getEntityManager();
			Tiers tiersFederal = new Tiers();
			tiersFederal.setIdFederal("0000005555");
			entityManager.persist(tiersFederal);
			IdentiteTiers identiteTiers = new IdentiteTiers("Golf", "20019", "1100", "024050676");
			identiteTiers.setDateDebut(LocalDate.of(2019, 5, 1));
			entityManager.persist(tiersFederal);
			identiteTiers.setTiers(tiersFederal);
			entityManager.persist(identiteTiers);
		});

		try {
			// set security manager
			System.setSecurityManager(new NoExitSecurityManager());
			// Act
			launcher.runBatch(properties.getProperty("rep.rft.in") + nomFichier);
		} catch (ExitException e) {
			// Assert
			Assert.assertEquals(0, e.status);
			// Assert
			Assert.assertTrue(new File(properties.getProperty("rep.rft.ok") + nomFichier).exists());
			doInTransaction(() -> {
				List<Tiers> tousTiers = findAllTiers();
				Assert.assertEquals(1, tousTiers.size());
				Tiers tiers = tousTiers.get(0);
				Assert.assertEquals(2, tiers.getIdentites().size());
				IdentiteTiers identitiersTiers = tiers.getIdentites().iterator().next().getSuivante();
				Assert.assertEquals("Golf", identitiersTiers.getIdLocal());
				Assert.assertEquals("1100", identitiersTiers.getCodeSegment());
				Assert.assertEquals("20019", identitiersTiers.getCodeBanque());
				Assert.assertNull(identitiersTiers.getSuivante());
				Assert.assertNull(identitiersTiers.getDateFin());
				Assert.assertEquals(LocalDate.of(2019, 8, 3), identitiersTiers.getDateDebut());
			});
		} finally {
			// restore initial security manager (otherwise a new ExitException will be
			// thrown when the JVM will actually exit)
			System.setSecurityManager(initialSecurityManger);
		}

	}

	@Test
	public void miseAJourTiers_WhenTiersFederalNonPartageEtNoNegaleRFTPresent() throws IOException {
		// save the initial security manager (probably null)
		SecurityManager initialSecurityManger = System.getSecurityManager();
		// Arrange
		Launcher launcher = new Launcher();
		launcher.setApplicationContext(getContext());
		String nomFichier = "NDOD_P_REF_TIERS_20190803.dat";
		copyFilenameToInFolder(nomFichier);

		// init data
		doInTransaction(() -> {
			EntityManager entityManager = getEntityManager();
			Tiers tiersFederal = new Tiers();
			tiersFederal.setIdFederal("0000005555");
			entityManager.persist(tiersFederal);
			IdentiteTiers identiteTiers = new IdentiteTiers("polo", "20019", "1100", "024050676");
			identiteTiers.setDateDebut(LocalDate.of(2019, 5, 1));
			entityManager.persist(tiersFederal);
			identiteTiers.setTiers(tiersFederal);
			entityManager.persist(identiteTiers);
		});

		try {
			// set security manager
			System.setSecurityManager(new NoExitSecurityManager());
			// Act
			launcher.runBatch(properties.getProperty("rep.rft.in") + nomFichier);
		} catch (ExitException e) {
			// Assert
			Assert.assertEquals(0, e.status);
			// Assert
			Assert.assertTrue(new File(properties.getProperty("rep.rft.ok") + nomFichier).exists());
			doInTransaction(() -> {
				List<Tiers> tousTiers = findAllTiers();
				Assert.assertEquals(1, tousTiers.size());
				Tiers tiers = tousTiers.get(0);
				Assert.assertEquals(1, tiers.getIdentites().size());
				Assert.assertEquals("0000005500", tiers.getIdFederal());
				IdentiteTiers identitiersTiers = tiers.getIdentites().iterator().next();
				Assert.assertEquals("polo", identitiersTiers.getIdLocal());
				Assert.assertEquals("1100", identitiersTiers.getCodeSegment());
				Assert.assertEquals("20019", identitiersTiers.getCodeBanque());
				Assert.assertNull(identitiersTiers.getSuivante());
				Assert.assertEquals(LocalDate.of(2019, 5, 1), identitiersTiers.getDateDebut());
				Assert.assertNull(identitiersTiers.getDateFin());
			});
		} finally {
			// restore initial security manager (otherwise a new ExitException will be
			// thrown when the JVM will actually exit)
			System.setSecurityManager(initialSecurityManger);
		}
	}

	@Test
	public void miseAJourTiers_WhenTiersFederalPartageEtNoNegaleRFTPresentEtNonExistDansTableTiers()
			throws IOException {
		// save the initial security manager (probably null)
		SecurityManager initialSecurityManger = System.getSecurityManager();

		// Arrange
		Launcher launcher = new Launcher();
		launcher.setApplicationContext(getContext());
		String nomFichier = "NDOD_P_REF_TIERS_20190803.dat";
		copyFilenameToInFolder(nomFichier);

		// init data
		doInTransaction(() -> {
			EntityManager entityManager = getEntityManager();
			Tiers tiersFederalPartage = new Tiers();
			tiersFederalPartage.setIdFederal("0000005500");
			entityManager.persist(tiersFederalPartage);

			IdentiteTiers identiteTiersPolo = new IdentiteTiers("polo", "20019", "1100", "024050676");
			identiteTiersPolo.setDateDebut(LocalDate.of(2019, 5, 1));
			identiteTiersPolo.setTiers(tiersFederalPartage);
			entityManager.persist(identiteTiersPolo);

			IdentiteTiers identiteTiersBmw = new IdentiteTiers("bmw", "20019", "1100", "024050676");
			identiteTiersBmw.setDateDebut(LocalDate.of(2019, 5, 1));
			identiteTiersBmw.setTiers(tiersFederalPartage);
			entityManager.persist(identiteTiersBmw);
		});

		try {
			// set security manager
			System.setSecurityManager(new NoExitSecurityManager());
			// Act
			launcher.runBatch(properties.getProperty("rep.rft.in") + nomFichier);
		} catch (ExitException e) {
			// Assert
			Assert.assertEquals(0, e.status);
			// Assert
			Assert.assertTrue(new File(properties.getProperty("rep.rft.ok") + nomFichier).exists());
			doInTransaction(() -> {
				List<Tiers> tousTiers = findAllTiers();
				Assert.assertEquals(2, tousTiers.size());
				for (Tiers tiers : tousTiers) {
					Assert.assertNotNull(tiers.getIdFederal());
					if ("0000005500".equals(tiers.getIdFederal())) {
						Assert.assertEquals(2, tiers.getIdentites().size());
						for (IdentiteTiers identitiersTiers : tiers.getIdentites()) {
							Assert.assertEquals("1100", identitiersTiers.getCodeSegment());
							Assert.assertEquals("20019", identitiersTiers.getCodeBanque());
							Assert.assertEquals(LocalDate.of(2019, 5, 1), identitiersTiers.getDateDebut());
							if ("bmw".equals(identitiersTiers.getIdLocal())) {
								Assert.assertNotNull(identitiersTiers.getSuivante());
								Assert.assertEquals(LocalDate.of(2019, 8, 3), identitiersTiers.getDateFin());
							} else {
								Assert.assertNull(identitiersTiers.getSuivante());
								Assert.assertEquals("polo", identitiersTiers.getIdLocal());
							}
						}
					} else {
						Assert.assertEquals("0000006500", tiers.getIdFederal());
						Assert.assertEquals(1, tiers.getIdentites().size());
						IdentiteTiers identitiersTiers = tiers.getIdentites().iterator().next();
						Assert.assertEquals("bmw", identitiersTiers.getIdLocal());
						Assert.assertNull(identitiersTiers.getSuivante());
						Assert.assertEquals(LocalDate.of(2019, 8, 3), identitiersTiers.getDateDebut());
						Assert.assertNull(identitiersTiers.getDateFin());
					}

				}
			});
		} finally {
			// restore initial security manager (otherwise a new ExitException will be
			// thrown when the JVM will actually exit)
			System.setSecurityManager(initialSecurityManger);
		}
	}

}

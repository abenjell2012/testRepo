package fr.bpce.yyd.batch.rft.ti;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import fr.bpce.yyd.batch.rft.launch.Launcher;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.commun.model.TiersRFT;
import fr.bpce.yyd.commun.model.restitution.RestAssociateRftSiren;
import fr.bpce.yyd.commun.model.restitution.RestTiersIdRft;
import fr.bpce.yyd.commun.model.restitution.RestTiersLocal;
import fr.bpce.yyd.commun.model.restitution.RestTiersSiren;

public class CreationTiersPropageJira85Test extends AbstractIntegrationTest {

	@BeforeClass
	public static void initProperties() throws Exception {
		initContextAndProperties();
	}

	@Before
	public void cleanFoldersBeforeTest() throws IOException {
		cleanFolders();
		// init TiersRFT
		doInTransaction(() -> {
			EntityManager entityManager = getEntityManager();
			TiersRFT tiersRFT = new TiersRFT();
			tiersRFT.setCodeBanque("11138");
			tiersRFT.setDate(LocalDate.of(2020, 12, 01));
			tiersRFT.setIdFederal("0000561139");
			tiersRFT.setIdLocal("0535367");
			tiersRFT.setSiren("1100");
			entityManager.persist(tiersRFT);

		});

	}

	@AfterClass
	public static void cleanFoldersAfterClass() throws IOException {
		cleanFolders();
	}

	@Test
	public void casTiersSortiRftEnRelationAvec2TiersInconnus() throws IOException {
		// save the initial security manager (probably null)
		SecurityManager initialSecurityManger = System.getSecurityManager();

		// Arrange
		Launcher launcher = new Launcher();
		launcher.setApplicationContext(getContext());
		String nomFichier = "NDOD_P_REF_TIERS_20210119.dat";
		copyFilenameToInFolder(nomFichier);
		String codeSeg = "1100";
		String siren = "425090977";
		String sirenFicRft = "024050676";
		String idRft = "0000561139";
		LocalDate dateFichier = LocalDate.of(2021, 01, 19);
		LocalDate dateDebut = LocalDate.of(2020, 5, 1);

		// init data
		doInTransaction(() -> {
			EntityManager entityManager = getEntityManager();
			// Création TIERS CONNU T1
			Tiers tiersFederal = new Tiers();
			tiersFederal.setIdFederal(idRft);
			entityManager.persist(tiersFederal);
			// IDENTITE_TIERS
			IdentiteTiers iden = new IdentiteTiers("0535367", "11138", codeSeg, siren);
			iden.setDateDebut(dateDebut);
			iden.setTiers(tiersFederal);
			entityManager.persist(iden);
			createRestTiersLocal(iden.getCodeBanque(), iden.getIdLocal(), iden.getCodeSegment(), iden.getSiren(), "",
					"MDC", iden.getDateDebut(), entityManager);
			// Création tiers inconnus en relation commerciales avec T1 (même id_rft)
			createRestTiersLocal("30007", "0535367", codeSeg, siren, tiersFederal.getIdFederal(), "RFT",
					iden.getDateDebut(), entityManager);
			createRestTiersLocal("15007", "425090966", codeSeg, siren, tiersFederal.getIdFederal(), "RFT",
					iden.getDateDebut(), entityManager);

		});

		try {
			// set security manager
			System.setSecurityManager(new NoExitSecurityManager());
			// Act
			launcher.runBatch(properties.getProperty("rep.rft.in") + nomFichier);
		} catch (ExitException e) {
			// Assert
			assertEquals(0, e.status);
			assertTrue(new File(properties.getProperty("rep.rft.ok") + nomFichier).exists());
			List<TiersRFT> listeTiersRFT = new ArrayList<TiersRFT>();
			List<Tiers> tousTiers = new ArrayList<Tiers>();
			doInTransaction(() -> {

				EntityManager entityManager = getEntityManager();
				TypedQuery<TiersRFT> query = entityManager.createQuery("select t from TiersRFT t where t.date=:date",
						TiersRFT.class);
				query.setParameter("date", dateFichier);
				listeTiersRFT.addAll(query.getResultList());
			});
			assertEquals(2L, listeTiersRFT.size());
			doInTransaction(() -> {
				tousTiers.addAll(findAllTiersOrderById());
				assertEquals(2, tousTiers.size());
				// Vérification T2 en relation commerciale avec T1
				Tiers t2 = tousTiers.get(0);
				assertNotNull(t2);
				assertEquals(idRft, t2.getIdFederal());
				List<IdentiteTiers> identites = new ArrayList<>(t2.getIdentites());
				assertEquals(2, identites.size());
				assertEquals("15007", identites.get(0).getCodeBanque());
				assertEquals("425090966", identites.get(0).getIdLocal());
				assertEquals(sirenFicRft, identites.get(0).getSiren());
				assertEquals(codeSeg, identites.get(0).getCodeSegment());
				assertEquals(dateFichier, identites.get(0).getDateDebut());
				assertNull(identites.get(0).getDateFin());
				assertEquals("30007", identites.get(1).getCodeBanque());
				assertEquals("0535367", identites.get(1).getIdLocal());
				assertEquals(sirenFicRft, identites.get(1).getSiren());
				assertEquals(codeSeg, identites.get(1).getCodeSegment());
				assertEquals(dateFichier, identites.get(1).getDateDebut());
				assertNull(identites.get(1).getDateFin());
				// vérification T1 sorti RFT
				Tiers t1 = tousTiers.get(1);
				assertNotNull(t1);
				assertNull(t1.getIdFederal());
				// Vérification RestTiersIdLocal pour T2
				List<RestTiersLocal> listRestTiers = findRestTiersOrderByDateDebut("15007", "425090966");
				assertNotNull(listRestTiers);
				assertEquals(2L, listRestTiers.size());
				// Type RFT fermé
				assertEquals(dateDebut, listRestTiers.get(0).getDateDebut());
				assertEquals(dateFichier, listRestTiers.get(0).getDateFin());
				assertEquals("RFT", listRestTiers.get(0).getType());
				// Type MDC ouverte
				assertEquals(dateFichier, listRestTiers.get(1).getDateDebut());
				assertNull(listRestTiers.get(1).getDateFin());
				assertEquals("MDC", listRestTiers.get(1).getType());
				assertNotNull(listRestTiers.get(1).getRestAssoRftSiren().getRestIdRFT());
				assertEquals(idRft, listRestTiers.get(1).getRestAssoRftSiren().getRestIdRFT().getIdRft());
				// ID ASSOC
				assertEquals(listRestTiers.get(0).getRestAssoRftSiren().getId(),
						listRestTiers.get(1).getRestAssoRftSiren().getId());

				List<RestTiersLocal> listRestTiers2 = findRestTiersOrderByDateDebut("30007", "0535367");
				assertNotNull(listRestTiers2);
				assertEquals(2L, listRestTiers2.size());

				// Type RFT fermé
				assertEquals(dateDebut, listRestTiers2.get(0).getDateDebut());
				assertEquals(dateFichier, listRestTiers2.get(0).getDateFin());
				assertEquals("RFT", listRestTiers2.get(0).getType());
				// Type MDC ouverte
				assertEquals(dateFichier, listRestTiers2.get(1).getDateDebut());
				assertNull(listRestTiers2.get(1).getDateFin());
				assertEquals("MDC", listRestTiers2.get(1).getType());
				assertNotNull(listRestTiers2.get(1).getRestAssoRftSiren().getRestIdRFT());
				assertEquals(idRft, listRestTiers2.get(1).getRestAssoRftSiren().getRestIdRFT().getIdRft());

				// ID ASSOC
				assertEquals(listRestTiers2.get(0).getRestAssoRftSiren().getId(),
						listRestTiers2.get(1).getRestAssoRftSiren().getId());

				// Vérification RestTiersIdLocal pour T1
				List<RestTiersLocal> listRestTiersT1 = findRestTiersOrderByDateDebut("11138", "0535367");
				assertNotNull(listRestTiersT1);
				assertEquals(2L, listRestTiersT1.size());
				// Type MDC fermé
				assertEquals(dateDebut, listRestTiersT1.get(0).getDateDebut());
				assertEquals(dateFichier, listRestTiersT1.get(0).getDateFin());
				assertEquals("MDC", listRestTiersT1.get(0).getType());
				// Type MDC ouverte sans ID_RFT
				assertEquals(dateFichier, listRestTiersT1.get(1).getDateDebut());
				assertNull(listRestTiers2.get(1).getDateFin());
				assertEquals("MDC", listRestTiersT1.get(1).getType());
				assertNotNull(listRestTiersT1.get(1).getRestAssoRftSiren());
				assertNull(listRestTiersT1.get(1).getRestAssoRftSiren().getRestIdRFT());

			});

		} finally {
			// restore initial security manager (otherwise a new ExitException will be
			// thrown when the JVM will actually exit)
			System.setSecurityManager(initialSecurityManger);
		}

	}

	private void createRestTiersLocal(String codBq, String idLocal, String codSeg, String siren, String idRft,
			String type, LocalDate dateDebut, EntityManager entityManager) {
		RestTiersSiren restIdSiren = new RestTiersSiren();
		restIdSiren.setSiren(siren);
		entityManager.persist(restIdSiren);
		// RFT
		RestTiersIdRft restIdRft = new RestTiersIdRft();
		restIdRft.setIdRft(idRft);
		entityManager.persist(restIdRft);
		// ASSOCIATION RFT/SIREN
		RestAssociateRftSiren assoc = new RestAssociateRftSiren();
		assoc.setRestIdRFT(restIdRft);
		assoc.setRestIdSiren(restIdSiren);
		entityManager.persist(assoc);
		// REST_TIERS_ID_LOCAL
		RestTiersLocal newRestTiersLoc = new RestTiersLocal();
		newRestTiersLoc.setRestAssoRftSiren(assoc);
		newRestTiersLoc.setCodeBanque(codBq);
		newRestTiersLoc.setIdLocal(idLocal);
		newRestTiersLoc.setCodeSegment(codSeg);
		newRestTiersLoc.setType(type);
		newRestTiersLoc.setDateDebut(dateDebut);
		entityManager.persist(newRestTiersLoc);

	}

}

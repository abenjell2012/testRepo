package fr.bpce.yyd.batch.rft.ti;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import fr.bpce.yyd.batch.rft.launch.Launcher;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.commun.model.TiersRFT;
import fr.bpce.yyd.commun.model.restitution.RestAssociateRftSiren;
import fr.bpce.yyd.commun.model.restitution.RestTiersIdRft;
import fr.bpce.yyd.commun.model.restitution.RestTiersLocal;
import fr.bpce.yyd.commun.model.restitution.RestTiersSiren;

public class TiersEntreeRFTJira248Test extends AbstractIntegrationTest {

	@BeforeClass
	public static void initProperties() throws Exception {
		initContextAndProperties();
	}

	@Before
	public void cleanFoldersBeforeTest() throws IOException {
		cleanFolders();

	}

	@AfterClass
	public static void cleanFoldersAfterClass() throws IOException {
		cleanFolders();
	}

	@Test
	public void casTiersEntreeRFT() throws IOException {
		// save the initial security manager (probably null)
		SecurityManager initialSecurityManger = System.getSecurityManager();

		Launcher launcher = new Launcher();
		launcher.setApplicationContext(getContext());
		String nomFichier = "NDOD_P_REF_TIERS_20210201.dat";
		copyFilenameToInFolder(nomFichier);
		String codeSeg = "1100";
		String codBq1 = "13825";
		String codBq2 = "10107";
		String idLocal1 = "0535368";
		String idLocal2 = "0535310";
		String siren1 = "000000001";
		String siren2 = "000000002";
		String idRft1 = "0000561139";
		String idRft2 = "0000561120";
		LocalDate dateFichier = LocalDate.of(2021, 02, 01);
		LocalDate dateDebut = LocalDate.of(2021, 01, 01);

		// init TiersRFT
		doInTransaction(() -> {
			EntityManager entityManager = getEntityManager();
			TiersRFT tiersRFT1 = new TiersRFT();
			tiersRFT1.setCodeBanque(codBq1);
			tiersRFT1.setDate(dateDebut);
			tiersRFT1.setIdFederal(idRft1);
			tiersRFT1.setIdLocal(idLocal1);
			tiersRFT1.setSiren(siren1);
			entityManager.persist(tiersRFT1);
			TiersRFT tiersRFT2 = new TiersRFT();
			tiersRFT2.setCodeBanque(codBq2);
			tiersRFT2.setDate(dateDebut);
			tiersRFT2.setIdFederal(idRft2);
			tiersRFT2.setIdLocal(idLocal2);
			tiersRFT2.setSiren(siren2);
			entityManager.persist(tiersRFT2);

		});
		// init Data
		doInTransaction(() -> {
			EntityManager entityManager = getEntityManager();
			// Création TIERS CONNUS
			Tiers tiersFederal1 = new Tiers();
			tiersFederal1.setIdFederal(idRft1);
			entityManager.persist(tiersFederal1);
			Tiers tiersFederal2 = new Tiers();
			tiersFederal2.setIdFederal(idRft2);
			entityManager.persist(tiersFederal2);
			// IDENTITE_TIERS
			IdentiteTiers iden1 = new IdentiteTiers(idLocal1, codBq1, codeSeg, siren1);
			iden1.setDateDebut(dateDebut);
			iden1.setTiers(tiersFederal1);
			entityManager.persist(iden1);
			IdentiteTiers iden2 = new IdentiteTiers(idLocal2, codBq2, codeSeg, siren2);
			iden2.setDateDebut(dateDebut);
			iden2.setTiers(tiersFederal2);
			entityManager.persist(iden2);
			// REST_TIERS_ID_LOCAL
			createRestTiersLocal(iden1.getCodeBanque(), iden1.getIdLocal(), iden1.getCodeSegment(), iden1.getSiren(),
					idRft1, "MDC", iden1.getDateDebut(), entityManager);

			createRestTiersLocal(iden2.getCodeBanque(), iden2.getIdLocal(), iden2.getCodeSegment(), iden2.getSiren(),
					idRft2, "MDC", iden2.getDateDebut(), entityManager);
		});
		try {
			// set security manager
			System.setSecurityManager(new NoExitSecurityManager());
			// Act
			launcher.runBatch(properties.getProperty("rep.rft.in") + nomFichier);
		} catch (ExitException e) {
			// Assertion
			assertEquals(0, e.status);
			assertTrue(new File(properties.getProperty("rep.rft.ok") + nomFichier).exists());
			List<TiersRFT> listeTiersRFT = new ArrayList<TiersRFT>();
			List<Tiers> tousTiers = new ArrayList<Tiers>();
			doInTransaction(() -> {
				EntityManager entityManager = getEntityManager();
				TypedQuery<TiersRFT> query = entityManager.createQuery("select t from TiersRFT t where t.date=:date",
						TiersRFT.class);
				query.setParameter("date", dateFichier);
				listeTiersRFT.addAll(query.getResultList());
			});
			assertEquals(5L, listeTiersRFT.size());
			doInTransaction(() -> {
				tousTiers.addAll(findAllTiersOrderById());
				assertEquals(2, tousTiers.size());
				// tiers 0000561120
				Tiers t2 = tousTiers.get(0);
				assertNotNull(t2);
				assertEquals(idRft2, t2.getIdFederal());
				// Vérification des identités
				List<IdentiteTiers> identites = t2.getIdentites().stream()
						.sorted((i1, i2) -> i1.getIdLocal().compareTo(i2.getIdLocal())).collect(Collectors.toList());
				assertEquals(3, identites.size());
				// Tiers déja existant
				assertEquals("10107", identites.get(0).getCodeBanque());
				assertEquals("0535310", identites.get(0).getIdLocal());
				assertEquals(siren2, identites.get(0).getSiren());
				assertEquals(codeSeg, identites.get(0).getCodeSegment());
				assertEquals(dateDebut, identites.get(0).getDateDebut());
				assertNull(identites.get(0).getDateFin());
				// Tiers entreé dans RFT
				assertEquals("10178", identites.get(1).getCodeBanque());
				assertEquals("0535311", identites.get(1).getIdLocal());
				assertEquals(siren2, identites.get(1).getSiren());
				assertEquals(codeSeg, identites.get(1).getCodeSegment());
				assertEquals(dateFichier, identites.get(1).getDateDebut());
				assertNull(identites.get(1).getDateFin());
				// Tiers entreé dans RFT
				assertEquals("10178", identites.get(2).getCodeBanque());
				assertEquals("0535312", identites.get(2).getIdLocal());
				assertEquals(siren2, identites.get(2).getSiren());
				assertEquals(codeSeg, identites.get(2).getCodeSegment());
				assertEquals(dateFichier, identites.get(2).getDateDebut());
				assertNull(identites.get(2).getDateFin());
				// tiers 0000561139
				Tiers t1 = tousTiers.get(1);
				assertNotNull(t1);
				assertEquals(idRft1, t1.getIdFederal());
				// Vérification des identités
				List<IdentiteTiers> identites1 = t1.getIdentites().stream()
						.sorted((i1, i2) -> i1.getIdLocal().compareTo(i2.getIdLocal())).collect(Collectors.toList());
				assertEquals(2, identites1.size());
				// Tiers déja existant
				assertEquals("13825", identites1.get(0).getCodeBanque());
				assertEquals("0535368", identites1.get(0).getIdLocal());
				assertEquals(siren1, identites1.get(0).getSiren());
				assertEquals(codeSeg, identites1.get(0).getCodeSegment());
				assertEquals(dateDebut, identites1.get(0).getDateDebut());
				assertNull(identites1.get(0).getDateFin());
				// Tiers entreé dans RFT
				assertEquals("12128", identites1.get(1).getCodeBanque());
				assertEquals("0535399", identites1.get(1).getIdLocal());
				assertEquals(siren1, identites1.get(1).getSiren());
				assertEquals(codeSeg, identites1.get(1).getCodeSegment());
				assertEquals(dateFichier, identites1.get(1).getDateDebut());
				assertNull(identites1.get(1).getDateFin());

			});

		} finally {
			// restore initial security manager (otherwise a new ExitException will be
			// thrown when the JVM will actually exit)
			System.setSecurityManager(initialSecurityManger);
		}

	}

	private void createRestTiersLocal(String codBq, String idLocal, String codSeg, String siren, String idRft,
			String type, LocalDate dateDebut, EntityManager entityManager) {
		RestTiersSiren restIdSiren = new RestTiersSiren();
		restIdSiren.setSiren(siren);
		entityManager.persist(restIdSiren);
		// RFT
		RestTiersIdRft restIdRft = new RestTiersIdRft();
		restIdRft.setIdRft(idRft);
		entityManager.persist(restIdRft);
		// ASSOCIATION RFT/SIREN
		RestAssociateRftSiren assoc = new RestAssociateRftSiren();
		assoc.setRestIdRFT(restIdRft);
		assoc.setRestIdSiren(restIdSiren);
		entityManager.persist(assoc);
		// REST_TIERS_ID_LOCAL
		RestTiersLocal newRestTiersLoc = new RestTiersLocal();
		newRestTiersLoc.setRestAssoRftSiren(assoc);
		newRestTiersLoc.setCodeBanque(codBq);
		newRestTiersLoc.setIdLocal(idLocal);
		newRestTiersLoc.setCodeSegment(codSeg);
		newRestTiersLoc.setType(type);
		newRestTiersLoc.setDateDebut(dateDebut);
		entityManager.persist(newRestTiersLoc);

	}

}

package fr.bpce.yyd.batch.rft.ti;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.net.URL;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.Permission;
import java.util.List;
import java.util.Properties;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.junit.After;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import fr.bpce.yyd.batch.commun.configuration.ConfigManager;
import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.commun.model.AuditFichiers;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.commun.model.TiersRFT;
import fr.bpce.yyd.commun.model.reference.RefCliSeg;
import fr.bpce.yyd.commun.model.reference.RefCliSsClass;
import fr.bpce.yyd.commun.model.restitution.RestTiersLocal;

public abstract class AbstractIntegrationTest {

	public static final String TEST_FILES_FOLDER_NAME = "./src/test/resources/ti/fichiers/";

	protected static Properties properties = null;

	@FunctionalInterface
	public interface TransactionCallback {
		void doInTransaction();
	}

	private static ApplicationContext context = null;
	private static TransactionTemplate transactionTemplate = null;

	protected static void initContextAndProperties() throws Exception {
		if (context == null) {
			context = new ClassPathXmlApplicationContext("classpath:JobLauncher-context-ti.xml");
		}
		transactionTemplate = new TransactionTemplate(getTransactionManager());
		// Chargement du fichier de propriétés des TI
		URL url = ClassLoader.getSystemClassLoader().getResource("config-ti.properties");
		String filename = url.getPath();
		properties = new Properties();
		InputStream input = new FileInputStream(filename);
		properties.load(input);
		input.close();

		// Utilisation de ces propriétés pour le ConfigManager
		Field propertiesField = ConfigManager.class.getDeclaredField("properties");
		propertiesField.setAccessible(true);
		propertiesField.set(null, properties);

		// Création des dossiers, s'ils n'existent pas.
		createFolders();

		// Création de la table TIERS_RFT_IMPORT
		doInTransaction(() -> {

			EntityManager entityManager = getEntityManager();
			Query queryDrop = entityManager.createNativeQuery("drop table TIERS_RFT_IMPORT if exists");
			queryDrop.executeUpdate();
			Query queryCreate = entityManager.createNativeQuery(
					"create table TIERS_RFT_IMPORT (TYPE_IDENTIFIANT_EXTERNE VARCHAR2(10), IDENTIFIANT_EXTERNE VARCHAR2(20), IDENTIFIANT_FEDERAL CHAR(10), IDENTIFIANT_LOCAL VARCHAR2(50), ETABLISSEMENT CHAR(5))");
			queryCreate.executeUpdate();
		});

		// Init Ref
		doInTransaction(() -> {

			RefCliSeg ref1 = new RefCliSeg("1100", "libelle6", "COR010");
			ref1.setTopSuppr(Constant.FLAG_NON);
			RefCliSeg ref2 = new RefCliSeg("3120", "libelle11", "RETPRO");
			ref2.setTopSuppr(Constant.FLAG_NON);
			getEntityManager().persist(ref1);
			getEntityManager().persist(ref2);

			RefCliSsClass refSSclassPROF = new RefCliSsClass();
			refSSclassPROF.setCodTypNot("PROF");
			refSSclassPROF.setTopSuppr("N");
			refSSclassPROF.setLibSsClassCli("PROFESSIONNELS");
			refSSclassPROF.setCodClassCli("RET");
			refSSclassPROF.setCodSsClassCli("RETPRO");
			RefCliSsClass refSSclassCORP = new RefCliSsClass();
			refSSclassCORP.setCodTypNot("CORP");
			refSSclassCORP.setTopSuppr("N");
			refSSclassCORP.setLibSsClassCli("ENTITES DU SECTEUR PUBLIC");
			refSSclassCORP.setCodClassCli("COR");
			refSSclassCORP.setCodSsClassCli("COR010");

			getEntityManager().persist(refSSclassPROF);
			getEntityManager().persist(refSSclassCORP);
		});

	}

	public static ApplicationContext getContext() {
		return context;
	}

	public static EntityManager getEntityManager() {
		return (EntityManager) context.getBean("entityManager");
	}

	public static JpaTransactionManager getTransactionManager() {
		return (JpaTransactionManager) context.getBean("transactionManager");
	}

	/**
	 * Exécute la méthode check() du paramètre checker au sein d'une transaction.
	 * Utilisée pour les assertions d'après import. Elles doivent effectivement être
	 * exécutées au sein d'une transaction pour pouvoir parcourir les relations
	 * ayant un chargement à la demande (LAZY).
	 *
	 * @param checker
	 */
	public static void doInTransaction(final TransactionCallback checker) {
		transactionTemplate.execute(new TransactionCallbackWithoutResult() {
			@Override
			protected void doInTransactionWithoutResult(TransactionStatus status) {
				checker.doInTransaction();
			}
		});
	}

	private void deleteEntityData(Class<?> entityClass) {
		EntityManager entityManager = getEntityManager();
		Query delQuery = entityManager.createQuery("delete from " + entityClass.getSimpleName());
		delQuery.executeUpdate();
	}

	/**
	 * Entre chaque test, la base est entièrement vidée.
	 */
	@After
	public void resetData() {
		transactionTemplate.execute(new TransactionCallbackWithoutResult() {
			@Override
			protected void doInTransactionWithoutResult(TransactionStatus status) {
				deleteEntityData(TiersRFT.class);
				deleteEntityData(IdentiteTiers.class);
				deleteEntityData(Tiers.class);
			}
		});
	}

	/**
	 * Utilitaire pour assertions : retourne l'instance d'AuditFichiers
	 * correspondant au nom de fichier paramètre.
	 *
	 * @param nomFichier
	 * @return
	 */
	public AuditFichiers findAuditFichierByNomFichier(String nomFichier) {
		EntityManager entityManager = getEntityManager();
		TypedQuery<AuditFichiers> query = entityManager
				.createQuery("select af from AuditFichiers af where af.nomFichier = :nomFichier", AuditFichiers.class);
		query.setParameter("nomFichier", nomFichier);
		return query.getSingleResult();
	}

	/**
	 * Utilitaire pour assertions : retourne l'ensemble des Tiers en base.
	 *
	 * @return
	 */
	public List<Tiers> findAllTiers() {
		EntityManager entityManager = getEntityManager();
		TypedQuery<Tiers> query = entityManager.createQuery("select t from Tiers t", Tiers.class);
		return query.getResultList();
	}

	public List<Tiers> findAllTiersOrderById() {
		EntityManager entityManager = getEntityManager();
		TypedQuery<Tiers> query = entityManager.createQuery("select t from Tiers t order by id desc", Tiers.class);
		return query.getResultList();
	}

	public List<RestTiersLocal> findRestTiersOrderByDateDebut(String codeBq, String idLocal) {
		EntityManager entityManager = getEntityManager();
		TypedQuery<RestTiersLocal> query = entityManager.createQuery(
				"select r from RestTiersLocal r where r.codeBanque=:codeBq and r.idLocal=:idLocal order by dateDebut",
				RestTiersLocal.class);
		query.setParameter("codeBq", codeBq);
		query.setParameter("idLocal", idLocal);
		return query.getResultList();
	}

	protected static void copyFilenameToInFolder(String nomFichier) throws IOException {
		Path pathFichier = Paths.get(TEST_FILES_FOLDER_NAME, nomFichier);
		Path pathIn = Paths.get(properties.getProperty("rep.rft.in"));
		copyFileToDir(pathFichier, pathIn);
	}

	private static Path copyFileToDir(Path filePath, Path destDirPath) throws IOException {
		return Files.copy(filePath, destDirPath.resolve(filePath.getFileName()), StandardCopyOption.REPLACE_EXISTING);
	}

	protected static void removeAllFilesInFolder(String folderName) throws IOException {
		Path folderPath = Paths.get(folderName);

		DirectoryStream<Path> stream = Files.newDirectoryStream(folderPath);

		for (Path entry : stream) {
			File file = entry.toFile();
			if (file.isFile()) {
				file.delete();
			}
		}
	}

	protected static void createFolderIfAbsent(String folderName) throws IOException {
		File folderAsFile = new File(folderName);
		if (folderAsFile.exists()) {
			if (folderAsFile.isDirectory()) {
				return;
			}
			folderAsFile.delete(); // Si un fichier existe avec ce nom.
		}
		folderAsFile.mkdirs();
	}

	protected static void cleanFolders() throws IOException {
		removeAllFilesInFolder(properties.getProperty("rep.rft.in"));
		removeAllFilesInFolder(properties.getProperty("rep.rft.encours"));
		removeAllFilesInFolder(properties.getProperty("rep.rft.ok"));
		removeAllFilesInFolder(properties.getProperty("rep.rft.ko"));
	}

	protected static void createFolders() throws IOException {
		createFolderIfAbsent(properties.getProperty("rep.rft.in"));
		createFolderIfAbsent(properties.getProperty("rep.rft.encours"));
		createFolderIfAbsent(properties.getProperty("rep.rft.ok"));
		createFolderIfAbsent(properties.getProperty("rep.rft.ko"));
	}

	// exception to be thrown by security manager when System.exit is called
	public static class ExitException extends SecurityException {
		private static final long serialVersionUID = 1L;
		public final long status;

		public ExitException(long status) {
			this.status = status;
		}
	}

	// custom security manager
	public static class NoExitSecurityManager extends SecurityManager {
		@Override
		public void checkPermission(Permission perm) {
		}

		@Override
		public void checkPermission(Permission perm, Object context) {
		}

		@Override
		public void checkExit(int status) {
			super.checkExit(status);
			throw new ExitException(status);
		}
	}
}

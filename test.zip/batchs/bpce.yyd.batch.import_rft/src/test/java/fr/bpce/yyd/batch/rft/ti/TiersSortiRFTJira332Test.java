package fr.bpce.yyd.batch.rft.ti;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import fr.bpce.yyd.batch.rft.launch.Launcher;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.commun.model.TiersRFT;
import fr.bpce.yyd.commun.model.restitution.RestAssociateRftSiren;
import fr.bpce.yyd.commun.model.restitution.RestTiersIdRft;
import fr.bpce.yyd.commun.model.restitution.RestTiersLocal;
import fr.bpce.yyd.commun.model.restitution.RestTiersSiren;

public class TiersSortiRFTJira332Test extends AbstractIntegrationTest {

	@BeforeClass
	public static void initProperties() throws Exception {
		initContextAndProperties();
	}

	@Before
	public void cleanFoldersBeforeTest() throws IOException {
		cleanFolders();

	}

	@AfterClass
	public static void cleanFoldersAfterClass() throws IOException {
		cleanFolders();
	}

	@Test
	public void casTiersSortiRFT() throws IOException {
		// save the initial security manager (probably null)
		SecurityManager initialSecurityManger = System.getSecurityManager();

		Launcher launcher = new Launcher();
		launcher.setApplicationContext(getContext());
		String nomFichier = "NDOD_P_REF_TIERS_20210301.dat";
		copyFilenameToInFolder(nomFichier);
		String codeSeg = "1100";
		String codBq1 = "13825";
		String codBq2 = "10107";
		String idLocal1 = "0535368";
		String idLocal2 = "0535369Sorti";
		String siren = "000000010";
		String idRft = "0000758420";
		LocalDate dateFichier = LocalDate.of(2021, 03, 01);
		LocalDate dateDebut = LocalDate.of(2021, 02, 01);

		// init TiersRFT à la date du 01/02/2021
		doInTransaction(() -> {
			EntityManager entityManager = getEntityManager();
			TiersRFT tiersRFT1 = new TiersRFT();
			tiersRFT1.setCodeBanque(codBq1);
			tiersRFT1.setDate(dateDebut);
			tiersRFT1.setIdFederal(idRft);
			tiersRFT1.setIdLocal(idLocal1);
			tiersRFT1.setSiren(siren);
			entityManager.persist(tiersRFT1);
			TiersRFT tiersRFT2 = new TiersRFT();
			tiersRFT2.setCodeBanque(codBq2);
			tiersRFT2.setDate(dateDebut);
			tiersRFT2.setIdFederal(idRft);
			tiersRFT2.setIdLocal(idLocal2);
			tiersRFT2.setSiren(siren);
			entityManager.persist(tiersRFT2);

		});
		// init Data
		doInTransaction(() -> {
			EntityManager entityManager = getEntityManager();
			// Création TIERS CONNUS
			Tiers tiersFederal1 = new Tiers();
			tiersFederal1.setIdFederal(idRft);
			entityManager.persist(tiersFederal1);
			// IDENTITE_TIERS
			IdentiteTiers iden1 = new IdentiteTiers(idLocal1, codBq1, codeSeg, siren);
			iden1.setDateDebut(dateDebut);
			iden1.setTiers(tiersFederal1);
			entityManager.persist(iden1);
			// REST_TIERS_ID_LOCAL
			RestAssociateRftSiren assoc = createAssocitionSirenFT(siren, idRft, entityManager);
			createRestTiersLocal(codBq1, idLocal1, codeSeg, assoc, "MDC", dateDebut, entityManager);
			createRestTiersLocal(codBq2, idLocal2, codeSeg, assoc, "RFT", dateDebut, entityManager);
		});
		try {
			// set security manager
			System.setSecurityManager(new NoExitSecurityManager());
			// Act
			launcher.runBatch(properties.getProperty("rep.rft.in") + nomFichier);
		} catch (ExitException e) {
			// Assertion
			assertEquals(0, e.status);
			assertTrue(new File(properties.getProperty("rep.rft.ok") + nomFichier).exists());
			List<TiersRFT> listeTiersRFT = new ArrayList<TiersRFT>();
			List<Tiers> tousTiers = new ArrayList<Tiers>();
			doInTransaction(() -> {
				EntityManager entityManager = getEntityManager();
				TypedQuery<TiersRFT> query = entityManager.createQuery("select t from TiersRFT t where t.date=:date",
						TiersRFT.class);
				query.setParameter("date", dateFichier);
				listeTiersRFT.addAll(query.getResultList());
			});
			assertEquals(1L, listeTiersRFT.size());
			doInTransaction(() -> {
				tousTiers.addAll(findAllTiersOrderById());
				assertEquals(2, tousTiers.size());
				// Vérification tiers Sorti idLocal2 = "0535369Sorti"
				Tiers t2 = tousTiers.get(0);
				assertNotNull(t2);
				// => sans id_rft
				assertNull(t2.getIdFederal());
				// Vérification IDENTITE_TIERS
				List<IdentiteTiers> identitesT2 = new ArrayList<IdentiteTiers>(t2.getIdentites());
				assertEquals(1, identitesT2.size());
				assertEquals(codBq2, identitesT2.get(0).getCodeBanque());
				assertEquals(idLocal2, identitesT2.get(0).getIdLocal());
				assertEquals(siren, identitesT2.get(0).getSiren());
				assertEquals(codeSeg, identitesT2.get(0).getCodeSegment());
				assertEquals(dateFichier, identitesT2.get(0).getDateDebut());
				assertNull(identitesT2.get(0).getDateFin());
				// Vérification REST_TIERS_ID_LOCAL pour T2
				List<RestTiersLocal> listRestTiersT2 = findRestTiersOrderByDateDebut(codBq2, idLocal2);
				assertNotNull(listRestTiersT2);
				assertEquals(2L, listRestTiersT2.size());
				// Type RFT fermé
				assertEquals(dateDebut, listRestTiersT2.get(0).getDateDebut());
				assertEquals(dateFichier, listRestTiersT2.get(0).getDateFin());
				assertEquals("RFT", listRestTiersT2.get(0).getType());
				// Type MDC ouverte
				assertEquals(dateFichier, listRestTiersT2.get(1).getDateDebut());
				assertNull(listRestTiersT2.get(1).getDateFin());
				assertEquals("MDC", listRestTiersT2.get(1).getType());
				// sans id_rft
				assertNull(listRestTiersT2.get(1).getRestAssoRftSiren().getRestIdRFT());
				// Vérification tiers RFT idLocal1 = "0535369"
				// rien ne doit bouger pour ce tiers
				Tiers t1 = tousTiers.get(1);
				assertNotNull(t1);
				// => avec id_rft
				assertEquals(idRft, t1.getIdFederal());
				// Vérification IDENTITE_TIERS
				List<IdentiteTiers> identitesT1 = new ArrayList<IdentiteTiers>(t1.getIdentites());
				assertEquals(1, identitesT1.size());
				assertEquals(codBq1, identitesT1.get(0).getCodeBanque());
				assertEquals(idLocal1, identitesT1.get(0).getIdLocal());
				assertEquals(siren, identitesT1.get(0).getSiren());
				assertEquals(codeSeg, identitesT1.get(0).getCodeSegment());
				assertEquals(dateDebut, identitesT1.get(0).getDateDebut());
				assertNull(identitesT1.get(0).getDateFin());
				// vérification REST_TIERS_ID_LOCAL
				List<RestTiersLocal> listRestTiersT1 = findRestTiersOrderByDateDebut(codBq1, idLocal1);
				assertNotNull(listRestTiersT1);
				assertEquals(1L, listRestTiersT1.size());
				// Type MDC
				assertEquals(dateDebut, listRestTiersT1.get(0).getDateDebut());
				assertNull(listRestTiersT1.get(0).getDateFin());
				assertEquals("MDC", listRestTiersT1.get(0).getType());
				assertEquals(idRft, listRestTiersT1.get(0).getRestAssoRftSiren().getRestIdRFT().getIdRft());

			});

		} finally {
			// restore initial security manager (otherwise a new ExitException will be
			// thrown when the JVM will actually exit)
			System.setSecurityManager(initialSecurityManger);
		}

	}

	private RestAssociateRftSiren createAssocitionSirenFT(String siren, String idRft, EntityManager entityManager) {
		RestTiersSiren restIdSiren = new RestTiersSiren();
		restIdSiren.setSiren(siren);
		entityManager.persist(restIdSiren);
		// RFT
		RestTiersIdRft restIdRft = null;
		if (idRft != null) {
			restIdRft = new RestTiersIdRft();
			restIdRft.setIdRft(idRft);
			entityManager.persist(restIdRft);
		}
		// ASSOCIATION RFT/SIREN
		RestAssociateRftSiren assoc = new RestAssociateRftSiren();
		assoc.setRestIdRFT(restIdRft);
		assoc.setRestIdSiren(restIdSiren);
		entityManager.persist(assoc);
		return assoc;
	}

	private void createRestTiersLocal(String codBq, String idLocal, String codSeg, RestAssociateRftSiren assoc,
			String type, LocalDate dateDebut, EntityManager entityManager) {
		// REST_TIERS_ID_LOCAL
		RestTiersLocal newRestTiersLoc = new RestTiersLocal();
		newRestTiersLoc.setRestAssoRftSiren(assoc);
		newRestTiersLoc.setCodeBanque(codBq);
		newRestTiersLoc.setIdLocal(idLocal);
		newRestTiersLoc.setCodeSegment(codSeg);
		newRestTiersLoc.setType(type);
		newRestTiersLoc.setDateDebut(dateDebut);
		entityManager.persist(newRestTiersLoc);

	}

}

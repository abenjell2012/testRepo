package fr.bpce.yyd.batch.rft.bean;

public class TiersRFTImport {

	private String codeBanque;
	private String idLocal;
	private String idFederal;
	private String idExterne;
	private String typeIdentifiantExterne;

	public String getCodeBanque() {
		return codeBanque;
	}

	public void setCodeBanque(String codeBanque) {
		this.codeBanque = codeBanque;
	}

	public String getIdLocal() {
		return idLocal;
	}

	public void setIdLocal(String idLocal) {
		this.idLocal = idLocal;
	}

	public String getIdFederal() {
		return idFederal;
	}

	public void setIdFederal(String idFederal) {
		this.idFederal = idFederal;
	}

	public String getIdExterne() {
		return idExterne;
	}

	public void setIdExterne(String idExterne) {
		this.idExterne = idExterne;
	}

	public String getTypeIdentifiantExterne() {
		return typeIdentifiantExterne;
	}

	public void setTypeIdentifiantExterne(String typeIdentifiantExterne) {
		this.typeIdentifiantExterne = typeIdentifiantExterne;
	}

}

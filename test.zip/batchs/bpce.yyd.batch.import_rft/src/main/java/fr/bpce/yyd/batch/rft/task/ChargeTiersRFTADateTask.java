package fr.bpce.yyd.batch.rft.task;

import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ChargeTiersRFTADateTask implements Tasklet {

	private EntityManager entityManager;

	private String insertQuery;

	private LocalDate date;

	@Autowired
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {

		Query query = entityManager.createNativeQuery(insertQuery);
		query.setParameter("dateImport", Date.valueOf(date));
		query.executeUpdate();

		return RepeatStatus.FINISHED;
	}

	public void setDateFichier(String date) {
		this.date = LocalDate.parse(date, DateTimeFormatter.BASIC_ISO_DATE);
	}

	public void setInsertQuery(String insertQuery) {
		this.insertQuery = insertQuery;
	}

}

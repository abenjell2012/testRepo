package fr.bpce.yyd.batch.rft.task;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import fr.bpce.yyd.batch.commun.configuration.ConfigManager;
import fr.bpce.yyd.batch.commun.messages.MessagesFactory;
import fr.bpce.yyd.batch.commun.messages.ProducteurMessages;
import fr.bpce.yyd.batch.commun.messages.Topic;
import fr.bpce.yyd.batch.commun.repositories.ParMdcRepository;
import fr.bpce.yyd.batch.messages.dto.LotIdTiersDTO;
import fr.bpce.yyd.batch.rft.bean.TiersSendKafka;

public class EnvoiTiersTask implements Tasklet {

	private static final String KAFKA_ENABLE = "enable";

	private static Logger logger = Logger.getLogger(EnvoiTiersTask.class);

	private TiersSendKafka tiersSendKafka;

	private LocalDate dateImport;

	private Long guid;

	private String kafka;

	@Autowired
	private ParMdcRepository parMdcRepo;

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

		if (KAFKA_ENABLE.equals(kafka)) {

			String topicNameCalculListe = ConfigManager.getProperty("kafka.topic.calcul_liste");
			String topicNameClotureListe = ConfigManager.getProperty("kafka.topic.cloture_liste");

			LocalDate dateCalculCourante = parMdcRepo.findDateCalculCourante();
			LocalDate dateCalcul = dateCalculCourante != null ? dateCalculCourante : dateImport;
			logger.info("Début d'envoi des messages kafka");
			LotIdTiersDTO lotIds = new LotIdTiersDTO();
			// date calcul trt-evt égale date calcul compteur + 1
			lotIds.setDateCalcul(dateCalcul.plusDays(1));
			lotIds.setGuid(guid);
			int i = 0;
			logger.info("Début d'envoi des Tiers a calculer pour la date " + dateCalcul);
			for (Long idTiers : tiersSendKafka.getIdsTiersATraiter()) {
				lotIds.addIdTiers(idTiers);
				if (++i % 200 == 0) {
					envoieLotIds(lotIds, topicNameCalculListe, Topic.CALCUL_LISTE);
					lotIds.getIdsTiers().clear();
				}
			}
			envoieLotIds(lotIds, topicNameCalculListe, Topic.CALCUL_LISTE);
			lotIds.getIdsTiers().clear();
			logger.info("Fin d'envoi des Tiers a calculer");

			logger.info("Début d'envoi des Tiers a cloturé");
			for (Long idTiers : tiersSendKafka.getIdsTiersACloturer()) {
				lotIds.addIdTiers(idTiers);
				if (++i % 200 == 0) {
					envoieLotIds(lotIds, topicNameClotureListe, Topic.CLOTURE_LISTE);
					lotIds.getIdsTiers().clear();
				}
			}
			envoieLotIds(lotIds, topicNameClotureListe, Topic.CLOTURE_LISTE);
			lotIds.getIdsTiers().clear();
			logger.info("Fin d'envoi des Tiers a cloturé");

			logger.info("Fin d'envoi des messages kafka");
		} else {
			logger.info("L'envoi kafka est désactivé");
		}
		return RepeatStatus.FINISHED;
	}

	public void setTiersSendKafka(TiersSendKafka tiersSendKafka) {
		this.tiersSendKafka = tiersSendKafka;
	}

	public void setDateFichier(String date) {
		this.dateImport = LocalDate.parse(date, DateTimeFormatter.BASIC_ISO_DATE);
	}

	public void setGuid(Long guid) {
		this.guid = guid;
	}

	public void setKafka(String kafka) {
		this.kafka = kafka;
	}

	private void envoieLotIds(LotIdTiersDTO lotIds, String name, Topic topic) {
		if (!lotIds.getIdsTiers().isEmpty()) {
			ProducteurMessages producteur = MessagesFactory.getProducteur();
			producteur.envoieMessage(topic, name, lotIds);
			// Réinitialisation
			lotIds.getIdsTiers().clear();
		}
	}
}
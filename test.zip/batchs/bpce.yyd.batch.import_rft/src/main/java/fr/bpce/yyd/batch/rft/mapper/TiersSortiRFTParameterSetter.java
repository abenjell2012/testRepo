package fr.bpce.yyd.batch.rft.mapper;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.springframework.jdbc.core.PreparedStatementSetter;

public class TiersSortiRFTParameterSetter implements PreparedStatementSetter {

	private String dateImport;

	private LocalDate dateImportPrecedante;

	public TiersSortiRFTParameterSetter(String dateImport, LocalDate datePrec) {
		this.dateImport = dateImport;
		this.dateImportPrecedante = datePrec;
	}

	@Override
	public void setValues(PreparedStatement ps) throws SQLException {
		LocalDate localDateImport = LocalDate.parse(dateImport, DateTimeFormatter.BASIC_ISO_DATE);
		ps.setDate(1, Date.valueOf(dateImportPrecedante));
		ps.setDate(2, Date.valueOf(localDateImport));
		ps.setDate(3, Date.valueOf(dateImportPrecedante));
		ps.setDate(4, Date.valueOf(localDateImport));

	}
}

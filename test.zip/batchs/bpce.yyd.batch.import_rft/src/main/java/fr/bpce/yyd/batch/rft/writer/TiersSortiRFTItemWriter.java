package fr.bpce.yyd.batch.rft.writer;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;

import fr.bpce.yyd.batch.rft.bean.TiersData;
import fr.bpce.yyd.batch.rft.bean.TiersSendKafka;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.commun.model.restitution.RestAssociateRftSiren;
import fr.bpce.yyd.commun.model.restitution.RestTiersLocal;
import fr.bpce.yyd.commun.model.restitution.RestTiersSiren;

public class TiersSortiRFTItemWriter implements ItemWriter<TiersData> {

	private static Logger logger = Logger.getLogger(TiersSortiRFTItemWriter.class);

	private TiersSendKafka tiersSendKafka;

	private EntityManager entityManager;

	private LocalDate dateImport;

	private Set<Long> idstiersLocalSet = new HashSet<>();

	@Override
	public void write(List<? extends TiersData> items) throws Exception {

		logger.info("Début de chargement de: " + items.size() + " lignes");

		// Nomenclature
		// T1 : tiers RFT connu du MDC
		// T2 : ensemble des tiers (codBq/id_local) inconnus du MDC
		// qui sortent de RFT (en RC avec T1)
		for (TiersData tiersSortiRft : items) {
			if (!idstiersLocalSet.contains(tiersSortiRft.getIdPLocalTiersInconnu())) {
				// création d'un nouveau tiers non fédéral pour T2
				Tiers tiersT2 = new Tiers();
				entityManager.persist(tiersT2);
				createIdentiteTiers(tiersSortiRft, tiersT2);
				// maj de la table REST_TIERS_ID_LOCAL pour T2 (fermeture type RFT et ouverture
				// type MDC)
				createRestTiersIdLocal(tiersSortiRft);
				idstiersLocalSet.add(tiersSortiRft.getIdPLocalTiersInconnu());
				// recalcul du nouveau tiers T2
				tiersSendKafka.addIdTiersATraiter(tiersT2.getId());
			}
		}

	}

	private void createIdentiteTiers(TiersData tiersData, Tiers tiers) {
		IdentiteTiers newIdentitierTiers = new IdentiteTiers(tiersData.getIdLocal(), tiersData.getCodeBanque(),
				tiersData.getCodeSeg(), tiersData.getSiren());
		newIdentitierTiers.setDateDebut(dateImport);
		newIdentitierTiers.setTiers(tiers);
		entityManager.persist(newIdentitierTiers);

	}

	private void createRestTiersIdLocal(TiersData tiersSortiRft) {
		RestTiersLocal restLocalInconnu = entityManager.find(RestTiersLocal.class,
				tiersSortiRft.getIdPLocalTiersInconnu());
		if (restLocalInconnu != null) {
			// fermeture ligne REST_TIERS_ID_LOCAL avec type RFT
			restLocalInconnu.setDateFin(dateImport);
			entityManager.persist(restLocalInconnu);
			// nouvelle relation sans ID_RFT
			RestAssociateRftSiren assoc = null;
			if (tiersSortiRft.getSiren() != null) {
				RestTiersSiren restIdSiren = new RestTiersSiren();
				restIdSiren.setSiren(tiersSortiRft.getSiren());
				entityManager.persist(restIdSiren);
				assoc = new RestAssociateRftSiren();
				assoc.setRestIdRFT(null);
				assoc.setRestIdSiren(restIdSiren);
				entityManager.persist(assoc);
			}
			// nouvelle ligne dans REST_TIERS_ID_LOCAL AVEC TYPE MDC
			RestTiersLocal newRestTiersLoc = new RestTiersLocal();
			newRestTiersLoc.setRestAssoRftSiren(assoc);
			newRestTiersLoc.setCodeBanque(restLocalInconnu.getCodeBanque());
			newRestTiersLoc.setIdLocal(restLocalInconnu.getIdLocal());
			newRestTiersLoc.setCodeSegment(restLocalInconnu.getCodeSegment());
			newRestTiersLoc.setType("MDC");
			newRestTiersLoc.setDateDebut(dateImport);
			entityManager.persist(newRestTiersLoc);
		}
	}

	@Autowired
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public void setDateFichier(String date) {
		this.dateImport = LocalDate.parse(date, DateTimeFormatter.BASIC_ISO_DATE);
	}

	public void setTiersSendKafka(TiersSendKafka tiersSendKafka) {
		this.tiersSendKafka = tiersSendKafka;
	}

}

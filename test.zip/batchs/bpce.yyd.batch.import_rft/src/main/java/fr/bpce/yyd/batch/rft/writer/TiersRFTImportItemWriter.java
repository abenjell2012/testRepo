package fr.bpce.yyd.batch.rft.writer;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;

import fr.bpce.yyd.batch.rft.bean.TiersRFTImport;

public class TiersRFTImportItemWriter implements ItemWriter<TiersRFTImport> {

	private static final String INSERT_QUERY = "insert into TIERS_RFT_IMPORT "
			+ "(TYPE_IDENTIFIANT_EXTERNE, IDENTIFIANT_EXTERNE, IDENTIFIANT_FEDERAL, IDENTIFIANT_LOCAL, ETABLISSEMENT) "
			+ "values (?,?,?,?,?)";

	private static Logger logger = Logger.getLogger(TiersRFTImportItemWriter.class);

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Override
	public void write(List<? extends TiersRFTImport> listeTiersRFTImport) throws Exception {

		logger.info("Début de chargement de: " + listeTiersRFTImport.size() + " lignes");

		jdbcTemplate.batchUpdate(INSERT_QUERY, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setString(1, listeTiersRFTImport.get(i).getTypeIdentifiantExterne());
				ps.setString(2, listeTiersRFTImport.get(i).getIdExterne());
				ps.setString(3, listeTiersRFTImport.get(i).getIdFederal());
				ps.setString(4, listeTiersRFTImport.get(i).getIdLocal());
				ps.setString(5, listeTiersRFTImport.get(i).getCodeBanque());
			}

			@Override
			public int getBatchSize() {
				return listeTiersRFTImport.size();
			}
		});

		logger.info("Nombre de lignes insérées: [" + listeTiersRFTImport.size() + "]");
	}
}

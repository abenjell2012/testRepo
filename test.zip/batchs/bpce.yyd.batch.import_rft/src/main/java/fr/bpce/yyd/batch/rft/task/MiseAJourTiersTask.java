package fr.bpce.yyd.batch.rft.task;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import fr.bpce.yyd.batch.commun.repositories.ParMdcRechercheRFTRepository;
import fr.bpce.yyd.batch.rft.bean.TiersSendKafka;
import fr.bpce.yyd.batch.rft.repositories.TiersRFTRepository;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.ParMdcRechercheRft;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.commun.model.TiersRFT;

public class MiseAJourTiersTask implements Tasklet {

	private static final String SELECT_IDENTITE_QUERY = "select i.* from identite_tiers i "
			+ "inner join REF_MCDN_SEG refseg on i.CODE_SEGMENT = refseg.COD_SEG_CLI "
			+ "inner join REF_CLI_SS_CLASS refSseg on refseg.COD_SS_CLASS_CLI = refSseg.COD_SS_CLASS_CLI "
			+ "where i.date_fin is null and refseg.TOP_SUPPR = 'N' and refSseg.COD_TYP_NOT != 'PROF' "
			+ "and refSseg.COD_TYP_NOT != 'PART' and refSseg.COD_TYP_NOT != 'NSEG' ";

	@Autowired
	private TiersRFTRepository rftRepo;

	@Autowired
	private ParMdcRechercheRFTRepository parMcdRftSearchRepo;

	private TiersSendKafka tiersSendKafka;

	private EntityManager entityManager;

	private LocalDate dateImport;

	private static Map<String, TiersRFT> photoRft;
	private static Map<String, ParMdcRechercheRft> parMcdRftRecherche;

	@Autowired
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

		// initialise RFT
		photoRft = rftRepo.findPhotoRFTByDateImport(dateImport);
		parMcdRftRecherche = parMcdRftSearchRepo.findBqSearchRft();

		Query query = entityManager.createNativeQuery(SELECT_IDENTITE_QUERY, IdentiteTiers.class);
		@SuppressWarnings("unchecked")
		List<IdentiteTiers> identiteTiersList = query.getResultList();
		for (IdentiteTiers identiteTiers : identiteTiersList) {
			Tiers tiers = identiteTiers.getTiers();
			Optional<TiersRFT> tiersRFT = checkPhotoRFT(identiteTiers.getCodeBanque(), identiteTiers.getIdLocal());

			if (isTiersRftNotPresent(tiers, tiersRFT) || isTiersRftPresentAndEquals(tiers, tiersRFT)) {
				// cas 1 : tiers n'a pas federal et n'est pas present dans photo_rft
				// cas 2 : tiers a federal et egale a idfederal present dans photo_rft
				continue;

			} else if (tiers.getIdFederal() == null && tiersRFT.isPresent()) {
				// cas 3 tiers n'a pas idfederal et present dans la photo rft
				Optional<Tiers> tiersExiste = findTiersByIdFederal(tiersRFT.get().getIdFederal());
				if (tiersExiste.isPresent()) {
					IdentiteTiers newIdentitierTiers = new IdentiteTiers(identiteTiers.getIdLocal(),
							identiteTiers.getCodeBanque(), identiteTiers.getCodeSegment(), identiteTiers.getSiren());
					newIdentitierTiers.setDateDebut(dateImport);
					newIdentitierTiers.setTiers(tiersExiste.get());
					entityManager.persist(newIdentitierTiers);
					identiteTiers.setDateFin(dateImport);
					identiteTiers.setSuivante(newIdentitierTiers);
					// send tiersExiste a traiter and tiers a cloturer
					tiersSendKafka.addIdTiersATraiter(tiersExiste.get().getId());
					tiersSendKafka.addIdTiersACloturer(tiers.getId());
				} else {
					tiers.setIdFederal(tiersRFT.get().getIdFederal());
					// send tiers a traiter
					tiersSendKafka.addIdTiersATraiter(tiers.getId());
				}
			} else if (tiers.getIdFederal() != null && !tiersRFT.isPresent()) {
				// cas 4 : tiers a un id federal et n'est pas present dans photo rft
				// check event act
				if (checkTiersPartage(tiers.getId(), identiteTiers.getIdLocal(), identiteTiers.getCodeBanque())) {
					IdentiteTiers newIdentitierTiers = new IdentiteTiers(identiteTiers.getIdLocal(),
							identiteTiers.getCodeBanque(), identiteTiers.getCodeSegment(), identiteTiers.getSiren());
					newIdentitierTiers.setDateDebut(dateImport);
					identiteTiers.setDateFin(dateImport);
					Tiers newtiers = new Tiers();
					entityManager.persist(newtiers);
					newIdentitierTiers.setTiers(newtiers);
					entityManager.persist(newIdentitierTiers);
					identiteTiers.setSuivante(newIdentitierTiers);
					// send newtiers a traiter
					tiersSendKafka.addIdTiersATraiter(newtiers.getId());
					// send tiers a traiter
					tiersSendKafka.addIdTiersATraiter(tiers.getId());
				} else {
					IdentiteTiers newIdentitierTiers = new IdentiteTiers(identiteTiers.getIdLocal(),
							identiteTiers.getCodeBanque(), identiteTiers.getCodeSegment(), identiteTiers.getSiren());
					newIdentitierTiers.setDateDebut(dateImport);
					identiteTiers.setDateFin(dateImport);
					tiers.setIdFederal(null);
					newIdentitierTiers.setTiers(tiers);
					entityManager.persist(newIdentitierTiers);
					identiteTiers.setSuivante(newIdentitierTiers);
					// send tiers a traiter
					tiersSendKafka.addIdTiersATraiter(tiers.getId());
				}
			} else if (tiers.getIdFederal() != null && tiersRFT.isPresent()
					&& !tiersRFT.get().getIdFederal().equals(tiers.getIdFederal())) {
				// cas 5 : tiers a un id federal mais different de iffederal dans rft
				Optional<Tiers> tiersExiste = findTiersByIdFederal(tiersRFT.get().getIdFederal());
				if (tiersExiste.isPresent()) {
					IdentiteTiers newIdentitierTiers = new IdentiteTiers(identiteTiers.getIdLocal(),
							identiteTiers.getCodeBanque(), identiteTiers.getCodeSegment(), identiteTiers.getSiren());
					newIdentitierTiers.setDateDebut(dateImport);
					identiteTiers.setDateFin(dateImport);
					newIdentitierTiers.setTiers(tiersExiste.get());
					entityManager.persist(newIdentitierTiers);
					identiteTiers.setSuivante(newIdentitierTiers);
					tiersSendKafka.addIdTiersATraiter(tiersExiste.get().getId());
					// send tiers existant a traiter
					if (checkTiersPartage(tiers.getId(), identiteTiers.getIdLocal(), identiteTiers.getCodeBanque())) {
						// send tiers a traiter
						tiersSendKafka.addIdTiersATraiter(tiers.getId());
					} else {
						// cloturer tiers
						tiersSendKafka.addIdTiersACloturer(tiers.getId());
					}
				} else {
					if (checkTiersPartage(tiers.getId(), identiteTiers.getIdLocal(), identiteTiers.getCodeBanque())) {
						IdentiteTiers newIdentitierTiers = new IdentiteTiers(identiteTiers.getIdLocal(),
								identiteTiers.getCodeBanque(), identiteTiers.getCodeSegment(),
								identiteTiers.getSiren());
						newIdentitierTiers.setDateDebut(dateImport);
						identiteTiers.setDateFin(dateImport);
						Tiers newTiers = new Tiers();
						newTiers.setIdFederal(tiersRFT.get().getIdFederal());
						newIdentitierTiers.setTiers(newTiers);
						entityManager.persist(newTiers);
						entityManager.persist(newIdentitierTiers);
						identiteTiers.setSuivante(newIdentitierTiers);
						// send newTiers et tiers a traiter
						tiersSendKafka.addIdTiersATraiter(tiers.getId());
						tiersSendKafka.addIdTiersATraiter(newTiers.getId());
					} else {
						tiers.setIdFederal(tiersRFT.get().getIdFederal());
						// send tiers a traiter
						tiersSendKafka.addIdTiersATraiter(tiers.getId());
					}
				}
			}
		}
		return RepeatStatus.FINISHED;
	}

	private boolean isTiersRftPresentAndEquals(Tiers tiers, Optional<TiersRFT> tiersRFT) {
		return tiers.getIdFederal() != null && tiersRFT.isPresent()
				&& tiersRFT.get().getIdFederal().equals(tiers.getIdFederal());
	}

	private boolean isTiersRftNotPresent(Tiers tiers, Optional<TiersRFT> tiersRFT) {
		return tiers.getIdFederal() == null && !tiersRFT.isPresent();
	}

	private Optional<Tiers> findTiersByIdFederal(String idFederal) {
		TypedQuery<Tiers> query = entityManager.createNamedQuery("tiers.par.idFederal", Tiers.class);
		query.setParameter("idFederal", idFederal);
		List<Tiers> listTiers = query.getResultList();
		if (listTiers.isEmpty()) {
			return Optional.empty();
		}
		return Optional.of(listTiers.get(0));
	}

	public boolean checkTiersPartage(Long idTiers, String idLocal, String codeBanque) {
		TypedQuery<Long> query = entityManager.createNamedQuery("tiers.partage", Long.class);
		query.setParameter("idTiers", idTiers);
		query.setParameter("idLocal", idLocal);
		query.setParameter("codebanque", codeBanque);
		Long count = query.getSingleResult();
		return count != 0;
	}

	private Optional<TiersRFT> checkPhotoRFT(String codeBanque, String idLocal) {
		TiersRFT tiersRft = photoRft.get(codeBanque + "-" + idLocal);
		if (tiersRft == null && parMcdRftRecherche.containsKey(codeBanque)) {

			// recherche en forcant le code banque avec la table de paramÃ¨trage
			// PAR_MDC_RECHERCHE_RFT
			ParMdcRechercheRft parBqRerche = parMcdRftRecherche.get(codeBanque);

			if (parBqRerche != null) {
				String codeBqRecherche = parBqRerche.getCodeBqRechercheRft();
				return Optional.ofNullable(photoRft.get(codeBqRecherche + "-" + idLocal));
			}
		}
		return Optional.ofNullable(tiersRft);
	}

	public void setDateFichier(String date) {
		this.dateImport = LocalDate.parse(date, DateTimeFormatter.BASIC_ISO_DATE);
	}

	public void setTiersSendKafka(TiersSendKafka tiersSendKafka) {
		this.tiersSendKafka = tiersSendKafka;
	}
}

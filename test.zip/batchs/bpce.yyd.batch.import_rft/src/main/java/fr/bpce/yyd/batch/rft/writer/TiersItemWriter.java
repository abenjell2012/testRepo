package fr.bpce.yyd.batch.rft.writer;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;

import fr.bpce.yyd.batch.rft.bean.TiersData;
import fr.bpce.yyd.batch.rft.bean.TiersSendKafka;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.commun.model.restitution.RestAssociateRftSiren;
import fr.bpce.yyd.commun.model.restitution.RestTiersLocal;
import fr.bpce.yyd.commun.model.restitution.RestTiersSiren;

public class TiersItemWriter implements ItemWriter<TiersData> {

	private static Logger logger = Logger.getLogger(TiersItemWriter.class);

	private TiersSendKafka tiersSendKafka;

	private EntityManager entityManager;

	private LocalDate dateImport;

	private Map<String, Tiers> mapIdFederauxTiers = new HashMap<>();
	private Set<Long> idstiersLocalSet = new HashSet<>();
	private Set<Long> idstiersLocalConnuSet = new HashSet<>();

	@Override
	public void write(List<? extends TiersData> items) throws Exception {

		logger.info("Début de chargement de: " + items.size() + " lignes");

		// Nomenclature
		// T1 : tiers connu du MDC sorti de RFT,
		// T2 : ensemble des tiers (codBq/id_local) inconnus du MDC en relations
		// commerciales avec T1
		for (TiersData tiersData : items) {
			// si l'id RFT est déja traité cad que le tiers unique a déja été crée pour T2,
			// on ne crée que les identités et les lignes REST_TIERS_ID_LOCAL
			if (mapIdFederauxTiers.containsKey(tiersData.getIdRft())) {
				// pour T2 : création ligne IDENTITE_TIERS
				if (!idstiersLocalSet.contains(tiersData.getIdPLocalTiersInconnu())) {
					createIdentiteTiers(tiersData, mapIdFederauxTiers.get(tiersData.getIdRft()));
					// pour T2 : création ligne REST_TIERS_ID_LOCAL avec type MDC et cloture de la
					// ligne type RFT
					createRestTiersIdLocal(tiersData);
				}
				idstiersLocalSet.add(tiersData.getIdPLocalTiersInconnu());
				// pour T1 : cloture REST_TIERS_ID_LOCAL si ce n'est pas déja fait
				if (!idstiersLocalConnuSet.contains(tiersData.getIdPLocalTiersConnu())) {
					clotureTiersLocalConnu(tiersData);
				}
				idstiersLocalConnuSet.add(tiersData.getIdPLocalTiersConnu());
				continue;
			}
			// pour T2: création d'un nouveau tiers (un seul pour l'ensemble)
			Tiers newtiers = new Tiers();
			newtiers.setIdFederal(tiersData.getIdRft());
			entityManager.persist(newtiers);
			// ajouter dans la map l'id federal traité
			mapIdFederauxTiers.put(tiersData.getIdRft(), newtiers);
			idstiersLocalSet.add(tiersData.getIdPLocalTiersInconnu());
			// pour T2 : création ligne IDENTITE_TIERS
			createIdentiteTiers(tiersData, newtiers);
			// pour T2 : création ligne REST_TIERS_ID_LOCAL avec type MDC et cloture de la
			// ligne type RFT
			createRestTiersIdLocal(tiersData);

			// maj tiers à traiter , à envoyer dans la file kafka
			tiersSendKafka.addIdTiersATraiter(newtiers.getId());
			// pour T1 (sorti de RFT) : Mise a jour de l'id_rft (=> null) faite dans la task
			// MiseAjourTiersTask
			// pour T1 : cloture REST_TIERS_ID_LOCAL
			if (!idstiersLocalConnuSet.contains(tiersData.getIdPLocalTiersConnu())) {
				clotureTiersLocalConnu(tiersData);
			}
			idstiersLocalConnuSet.add(tiersData.getIdPLocalTiersConnu());

		}

	}

	private void clotureTiersLocalConnu(TiersData tiersAPropage) {
		RestTiersLocal restLocal = entityManager.find(RestTiersLocal.class, tiersAPropage.getIdPLocalTiersConnu());
		if (restLocal != null && restLocal.getDateFin() == null) {
			restLocal.setDateFin(dateImport);
			entityManager.persist(restLocal);
			// nouvelle relation sans ID_RFT
			RestAssociateRftSiren assoc = null;
			if (tiersAPropage.getSirenConnu() != null) {
				RestTiersSiren restIdSiren = new RestTiersSiren();
				restIdSiren.setSiren(tiersAPropage.getSirenConnu());
				entityManager.persist(restIdSiren);
				assoc = new RestAssociateRftSiren();
				assoc.setRestIdRFT(null);
				assoc.setRestIdSiren(restIdSiren);
				entityManager.persist(assoc);
			}
			RestTiersLocal newRestTiersLoc = new RestTiersLocal();
			if (assoc != null) {
				newRestTiersLoc.setRestAssoRftSiren(assoc);
			}
			newRestTiersLoc.setCodeBanque(restLocal.getCodeBanque());
			newRestTiersLoc.setIdLocal(restLocal.getIdLocal());
			newRestTiersLoc.setCodeSegment(restLocal.getCodeSegment());
			newRestTiersLoc.setType(restLocal.getType());
			newRestTiersLoc.setDateDebut(restLocal.getDateFin());
			entityManager.persist(newRestTiersLoc);
		}
	}

	private void createIdentiteTiers(TiersData tiersAPropage, Tiers tiers) {
		IdentiteTiers newIdentitierTiers = new IdentiteTiers(tiersAPropage.getIdLocal(), tiersAPropage.getCodeBanque(),
				tiersAPropage.getCodeSeg(), tiersAPropage.getSiren());
		newIdentitierTiers.setDateDebut(dateImport);
		newIdentitierTiers.setTiers(tiers);
		entityManager.persist(newIdentitierTiers);

	}

	private void createRestTiersIdLocal(TiersData tiersAPropage) {
		RestTiersLocal restLocalInconnu = entityManager.find(RestTiersLocal.class,
				tiersAPropage.getIdPLocalTiersInconnu());
		if (restLocalInconnu != null) {
			restLocalInconnu.setDateFin(dateImport);
			entityManager.persist(restLocalInconnu);
			// JIRA 363- Utiliser la meme association id_rft/siren
			RestAssociateRftSiren assoc = null;
			if (tiersAPropage.getIdAssociation() != null) {
				assoc = entityManager.find(RestAssociateRftSiren.class, tiersAPropage.getIdAssociation());
			}
			// nouvelle ligne dans REST_TIERS_ID_LOCAL AVEC TYPE MDC
			RestTiersLocal newRestTiersLoc = new RestTiersLocal();
			newRestTiersLoc.setRestAssoRftSiren(assoc);
			newRestTiersLoc.setCodeBanque(tiersAPropage.getCodeBanque());
			newRestTiersLoc.setIdLocal(tiersAPropage.getIdLocal());
			newRestTiersLoc.setCodeSegment(tiersAPropage.getCodeSeg());
			newRestTiersLoc.setType("MDC");
			newRestTiersLoc.setDateDebut(dateImport);
			entityManager.persist(newRestTiersLoc);
		}
	}

	@Autowired
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public void setDateFichier(String date) {
		this.dateImport = LocalDate.parse(date, DateTimeFormatter.BASIC_ISO_DATE);
	}

	public void setTiersSendKafka(TiersSendKafka tiersSendKafka) {
		this.tiersSendKafka = tiersSendKafka;
	}

}

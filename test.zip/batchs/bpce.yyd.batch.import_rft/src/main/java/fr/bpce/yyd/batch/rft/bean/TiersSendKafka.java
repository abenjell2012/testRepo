package fr.bpce.yyd.batch.rft.bean;

import java.util.HashSet;
import java.util.Set;

public class TiersSendKafka {


	private Set<Long> idsTiersATraiter = new HashSet<>();
	private Set<Long> idsTiersACloturer = new HashSet<>();

	public Set<Long> getIdsTiersATraiter() {
		return idsTiersATraiter;
	}

	public Set<Long> getIdsTiersACloturer(){
		return idsTiersACloturer;
	}

	public boolean addIdTiersATraiter(Long idTiers) {
		return idsTiersATraiter.add(idTiers);
	}

	public boolean addIdTiersACloturer(Long idTiers) {
		return idsTiersACloturer.add(idTiers);
	}

}

package fr.bpce.yyd.batch.rft.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fr.bpce.yyd.batch.rft.bean.TiersData;

public class TiersRowMapper implements RowMapper<TiersData> {

	@Override
	public TiersData mapRow(ResultSet rs, int rowNum) throws SQLException {
		TiersData tiers = new TiersData();
		tiers.setCodeBanque(rs.getString("CODE_BANQUE"));
		tiers.setIdLocal(rs.getString("ID_LOCAL"));
		tiers.setIdRft(rs.getString("ID_FEDERAL"));
		tiers.setCodeSeg(rs.getString("CODE_SEG_C"));
		tiers.setSiren(rs.getString("SIREN"));
		tiers.setIdPLocalTiersInconnu(rs.getLong("ID_P_ID_LOCAL"));
		tiers.setTiersIdConnu(rs.getLong("TIERS_ID_C"));
		tiers.setIdPLocalTiersConnu(rs.getLong("ID_P_REST_LOCAL_C"));
		tiers.setSirenConnu(rs.getString("SIREN_C"));
		tiers.setIdAssociation(rs.getLong("ID_ASSOC_ID"));
		return tiers;
	}

}

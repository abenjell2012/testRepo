package fr.bpce.yyd.batch.rft.bean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TiersData {

	private Long idPLocalTiersInconnu;
	private String codeBanque;
	private String idLocal;
	private String codeSeg;
	private String siren;
	private String idRft;
	private Long tiersIdConnu;
	private String sirenConnu;
	private Long idPLocalTiersConnu;
	private Long idTiers;
	private Long idAssociation;

}

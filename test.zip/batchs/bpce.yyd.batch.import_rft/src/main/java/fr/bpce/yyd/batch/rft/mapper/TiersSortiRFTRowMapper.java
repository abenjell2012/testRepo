package fr.bpce.yyd.batch.rft.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fr.bpce.yyd.batch.rft.bean.TiersData;

public class TiersSortiRFTRowMapper implements RowMapper<TiersData> {

	@Override
	public TiersData mapRow(ResultSet rs, int rowNum) throws SQLException {
		TiersData tiers = new TiersData();
		tiers.setCodeBanque(rs.getString("code_banque"));
		tiers.setIdLocal(rs.getString("id_local"));
		tiers.setIdRft(rs.getString("id_federal"));
		tiers.setCodeSeg(rs.getString("code_seg_c"));
		tiers.setSiren(rs.getString("siren"));
		tiers.setIdPLocalTiersInconnu(rs.getLong("id_p_id_local"));
		return tiers;
	}

}

package fr.bpce.yyd.batch.rft.launch;

import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.exitWithErrorCode;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import fr.bpce.yyd.batch.commun.configuration.ConfigManager;
import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.commun.exception.InvalidFileException;
import fr.bpce.yyd.batch.commun.exception.InvalidInitialisationException;
import fr.bpce.yyd.batch.commun.exception.UnknownPropertyException;
import fr.bpce.yyd.batch.commun.utils.FileCommunUtils;

public class Launcher {

	private static final String REP_RFT_KO = "rep.rft.ko";

	private static final String REP_RFT_OK = "rep.rft.ok";

	private static Logger logger = Logger.getLogger(Launcher.class);

	private ApplicationContext context = null;

	public void setApplicationContext(ApplicationContext newContext) {
		context = newContext;
	}

	public ApplicationContext getApplicationContext() {
		if (context == null) {
			context = new ClassPathXmlApplicationContext("classpath:JobLauncher-context.xml");
		}
		return context;
	}

	public void runBatch(String fileName) throws IOException {

		Path pathOK = null;
		Path pathKO = null;
		Path movedFilePath = null;
		String repertoireEnCours = null;
		JobExecution execution = null;
		String kafkaStatut = null;
		JobParameters jobParameters = null;
		String fichier = null;

		logger.info("Debut BATCH IMPORT RFT");

		Job job = (Job) getApplicationContext().getBean(Constant.JOB_IMPORT_RFT);
		JobLauncher jobLauncher = (JobLauncher) getApplicationContext().getBean("jobLauncher");

		try {
			repertoireEnCours = ConfigManager.getProperty("rep.rft.encours");
			// crée les répertoires s'ils n'existent pas déjà
			checkRepertoires();
			kafkaStatut = ConfigManager.getProperty("import_rft.kafka.statut");
			pathOK = Paths.get(ConfigManager.getProperty(REP_RFT_OK));
			pathKO = Paths.get(ConfigManager.getProperty(REP_RFT_KO));
		} catch (UnknownPropertyException e) {
			logger.error(e.getMessage());
			exitWithErrorCode(1);
		} catch (InvalidInitialisationException e) {
			logger.error("Erreur de parametre " + e.getMessage());
			exitWithErrorCode(1);
		}

		try {
			Path pathEnCours = Paths.get(repertoireEnCours);
			Path pathFileName = Paths.get(fileName);
			movedFilePath = moveFileToDir(pathFileName, pathEnCours);
			String dateFichier = checkNameFileFormatAndGetDate(pathFileName);
			fichier = movedFilePath.toString();

			logger.info("Debut traitement fichier [" + fichier + "]");

			Long guid = java.util.UUID.randomUUID().getMostSignificantBits();

			jobParameters = new JobParametersBuilder().addString("file", fichier).addString("dateFichier", dateFichier)
					.addString("date", LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME))
					.addString("kafka", kafkaStatut).addLong("guid", guid).toJobParameters();
		} catch (InvalidFileException e) {
			logger.error(e);
			finaliserTraitement(null, movedFilePath, pathOK, pathKO);
		} catch (Exception exp) {
			logger.error("Erreur inattendue en import du fichier RFT " + exp.getMessage(), exp);
			exitWithErrorCode(1);
		}

		try {
			execution = jobLauncher.run(job, jobParameters);
		} catch (Exception e) {
			logger.error("Erreur inattendue en traitement du fichier " + fichier, e);
			exitWithErrorCode(1);
		} finally {
			if (fichier != null) {
				Files.deleteIfExists(Paths.get(fichier.substring(0, fichier.length() - 3)));
			}
			finaliserTraitement(batchStatus(execution), movedFilePath, pathOK, pathKO);
		}

		logger.info("Fin BATCH IMPORT RFT");
	}

	private String checkNameFileFormatAndGetDate(Path filePath) throws InvalidFileException {
		String filename = filePath.getFileName().toString();
		Pattern patternRftFile = Pattern.compile(Constant.REG_NDOD_RFT_FILE);
		Matcher matcherRegExpRft = patternRftFile.matcher(filename);
		if (!matcherRegExpRft.matches()) {
			throw new InvalidFileException("Le format du nom du fichier [" + filename + "] est incorrect");
		}
		return matcherRegExpRft.group(1);
	}

	private void checkRepertoires() throws UnknownPropertyException, InvalidInitialisationException {
		// crée les répertoires s'il n'existe pas déjà
		FileCommunUtils.checkRepertoire(ConfigManager.getProperty("rep.rft.in"));
		FileCommunUtils.checkRepertoire(ConfigManager.getProperty("rep.rft.encours"));
		FileCommunUtils.checkRepertoire(ConfigManager.getProperty(REP_RFT_OK));
		FileCommunUtils.checkRepertoire(ConfigManager.getProperty(REP_RFT_KO));
		FileCommunUtils.checkRepertoire(ConfigManager.getProperty("rep.log"));
	}

	public Path moveFileToDir(Path filePath, Path destDirPath) throws IOException {
		return Files.move(filePath, destDirPath.resolve(filePath.getFileName()), StandardCopyOption.REPLACE_EXISTING);
	}

	private BatchStatus batchStatus(JobExecution execution) {
		return execution == null ? BatchStatus.UNKNOWN : execution.getStatus();
	}

	private void finaliserTraitement(BatchStatus statut, Path encours, Path repSucces, Path repRejet)
			throws IOException {
		if (statut == BatchStatus.COMPLETED) {
			logger.info("Fin traitement fichier [" + encours + "] OK");
			moveFileToDir(encours, repSucces);
			exitWithErrorCode(0);
		} else {
			logger.info("Fin traitement fichier [" + encours + "] KO");
			moveFileToDir(encours, repRejet);
			exitWithErrorCode(1);
		}
	}

	public static void main(String[] args) throws IOException {
		PropertyConfigurator.configure(ClassLoader.getSystemClassLoader().getResource("log4j-import-rft.properties"));
		Launcher launcher = new Launcher();
		if (args != null && args.length == 1) {
			String fileName = FileCommunUtils.sanitizePathRft(args[0]);
			try {
				launcher.runBatch(fileName);
			} catch (IOException e) {
				logger.error("Erreur de parametre " + e.getMessage());
				exitWithErrorCode(1);
			}
		} else {
			logger.error(
					"Erreur - mauvais paramètres en entrée, le nom du fichier au bon format avec son chemin attendu");
			exitWithErrorCode(1);
		}
	}
}

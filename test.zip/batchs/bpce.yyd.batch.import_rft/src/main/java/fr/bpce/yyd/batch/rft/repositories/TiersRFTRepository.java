package fr.bpce.yyd.batch.rft.repositories;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import fr.bpce.yyd.commun.model.TiersRFT;

@Repository
public class TiersRFTRepository {

	private EntityManager entityManager;

	@Autowired
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public Map<String, TiersRFT> findPhotoRFTByDateImport(LocalDate datePhoto) {

		if (datePhoto == null) {
			return new HashMap<>();
		}

		Query query = entityManager.createNamedQuery("tiers.rtf.par.dateimport");
		query.setParameter("dateImport", datePhoto);
		Map<String, TiersRFT> ret = new HashMap<>();

		for (Object line : query.getResultList()) {
			Object[] lineAsArray = (Object[]) line;
			TiersRFT tiers = new TiersRFT();
			tiers.setCodeBanque((String) lineAsArray[0]);
			tiers.setIdLocal((String) lineAsArray[1]);
			tiers.setIdFederal((String) lineAsArray[2]);
			tiers.setDate((LocalDate) lineAsArray[3]);

			ret.put((String) lineAsArray[0] + "-" + (String) lineAsArray[1], tiers);
		}
		return ret;
	}

}
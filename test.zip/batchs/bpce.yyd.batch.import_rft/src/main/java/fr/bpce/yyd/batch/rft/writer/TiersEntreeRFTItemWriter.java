package fr.bpce.yyd.batch.rft.writer;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;

import fr.bpce.yyd.batch.rft.bean.TiersData;
import fr.bpce.yyd.batch.rft.bean.TiersSendKafka;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.Tiers;

public class TiersEntreeRFTItemWriter implements ItemWriter<TiersData> {

	private static Logger logger = Logger.getLogger(TiersEntreeRFTItemWriter.class);

	private TiersSendKafka tiersSendKafka;

	private EntityManager entityManager;

	private LocalDate dateImport;

	private Map<Long, Tiers> mapTiers = new HashMap<>();
	private List<String> cleDoublons = new ArrayList<>();

	@Override
	public void write(List<? extends TiersData> items) throws Exception {

		logger.info("Début de chargement de: " + items.size() + " lignes");

		// Nomenclature
		// T1 : tiers connu du MDC et connu de RFT,
		// T2 : ensemble des tiers (codBq/id_local) inconnus du MDC
		// qui entrent dans RFT en RC avec T1
		for (TiersData tiersData : items) {
			String cle = tiersData.getIdTiers() + "." + tiersData.getCodeBanque() + "." + tiersData.getIdLocal();
			if (!cleDoublons.contains(cle)) {
				cleDoublons.add(cle);
				Long idTiers = tiersData.getIdTiers();
				if (!mapTiers.containsKey(idTiers)) {
					// Recherche Tiers T1
					Tiers tiersConnu = entityManager.find(Tiers.class, idTiers);
					mapTiers.put(idTiers, tiersConnu);
				}
				// Creation identite pour tiers T2 et rattachement au tiers T1
				createIdentiteTiers(tiersData, mapTiers.get(idTiers));
				// recalculer le tiers T1 ???
				tiersSendKafka.addIdTiersATraiter(idTiers);
			}
		}

	}

	private void createIdentiteTiers(TiersData tiersData, Tiers tiers) {
		IdentiteTiers newIdentitierTiers = new IdentiteTiers(tiersData.getIdLocal(), tiersData.getCodeBanque(),
				tiersData.getCodeSeg(), tiersData.getSiren());
		newIdentitierTiers.setDateDebut(dateImport);
		newIdentitierTiers.setTiers(tiers);
		entityManager.persist(newIdentitierTiers);

	}

	@Autowired
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public void setDateFichier(String date) {
		this.dateImport = LocalDate.parse(date, DateTimeFormatter.BASIC_ISO_DATE);
	}

	public void setTiersSendKafka(TiersSendKafka tiersSendKafka) {
		this.tiersSendKafka = tiersSendKafka;
	}

}

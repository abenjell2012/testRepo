package fr.bpce.yyd.batch.rft.task;

import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import fr.bpce.yyd.batch.commun.utils.SpringBatchUtil;

@Service
public class SupprimeDonneesADateTask implements Tasklet {

	private EntityManager entityManager;

	private LocalDate date;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {

		Query deleteQuery = entityManager.createQuery("delete from TiersRFT t where t.date = :dateImport");
		deleteQuery.setParameter("dateImport", date);
		deleteQuery.executeUpdate();

		Date dateImportMax = jdbcTemplate.queryForObject("select max(date_import) from tiers_rft", Date.class);
		SpringBatchUtil.putObjectInJobExecutionContext(chunkContext, "dateImportPrec",
				dateImportMax != null ? dateImportMax.toLocalDate() : new Date(0).toLocalDate()); // Date(0) pour ne pas
																									// avoir null on met
																									// 1970-01-01
		// met la date minimum

		return RepeatStatus.FINISHED;
	}

	public void setDateFichier(String date) {
		this.date = LocalDate.parse(date, DateTimeFormatter.BASIC_ISO_DATE);
	}

}

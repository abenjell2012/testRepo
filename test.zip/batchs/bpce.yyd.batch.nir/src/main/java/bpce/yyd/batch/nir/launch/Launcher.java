package bpce.yyd.batch.nir.launch;

import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.batchStatus;
import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.exitWithErrorCode;
import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.finaliserTraitement;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import bpce.yyd.batch.nir.utils.GeneralUtility;

public class Launcher {

	private static final Logger LOGGER = Logger.getLogger(Launcher.class);

	private static String logFile = "log4j-restit-nir.properties";
	private static ApplicationContext context;
	private static String repOut;
	private static boolean isTest;

	public static void setLogFile(String log) {
		logFile = log;
	}

	public static String getLogFile() {
		return logFile;
	}

	public static void setApplicationContext(ApplicationContext newContext) {
		context = newContext;
	}

	public static ApplicationContext getApplicationContext() {
		if (context == null) {
			context = new ClassPathXmlApplicationContext("classpath:JobLauncher-context.xml");
		}
		return context;
	}

	public static void setRepOut(String out) {
		repOut = out;
	}

	public static String getRepOut(LocalDate dateMax) {
		if (repOut == null) {
			repOut = GeneralUtility.generateFilePath(dateMax) + GeneralUtility.generateFileName(dateMax);
		}
		return repOut;
	}

	public static void setIsTest(boolean test) {
		isTest = test;
	}

	public static boolean isTest() {
		return isTest;
	}

	public static void runBatch() {

		JobExecution execution = null;

		try {
			LOGGER.info("Debut BATCH NDOD : Restitution NIR");

			Job job = (Job) getApplicationContext().getBean("RESTITUTION_NIR");
			JobLauncher jobLauncher = (JobLauncher) getApplicationContext().getBean("jobLauncher");
			JdbcTemplate jdbcT = (JdbcTemplate) getApplicationContext().getBean("jdbcTemplate");
			Date date = jdbcT.queryForObject(
					"select max(date_photo) as date_photo from REST_SYNTH_TIERS_LOCAL_STATUS", java.sql.Date.class);

			LocalDate dateMax = Instant.ofEpochMilli(date.getTime()).atZone(ZoneId.systemDefault()).toLocalDate();
			GeneralUtility.initConstants();
			
			JobParameters jobParameters = new JobParametersBuilder().addLong("id", new Date().getTime())
					.addString("repOut", getRepOut(dateMax)).toJobParameters();
			execution = jobLauncher.run(job, jobParameters);

		} catch (Exception err) {
			LOGGER.error("Erreur inattendue : " + err.getMessage(), err);
			if (!isTest()) {
				exitWithErrorCode(1);
			}
		} finally {
			if (!isTest()) {
				finaliserTraitement(batchStatus(execution));
			}
		}
	}

	public static void main(String[] args) {

		PropertyConfigurator.configure(ClassLoader.getSystemClassLoader().getResource(getLogFile()));
		runBatch();
	}
}
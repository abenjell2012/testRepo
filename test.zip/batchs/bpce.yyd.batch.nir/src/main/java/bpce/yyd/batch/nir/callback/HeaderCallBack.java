package bpce.yyd.batch.nir.callback;

import java.io.IOException;
import java.io.Writer;

import org.springframework.batch.item.file.FlatFileHeaderCallback;

public class HeaderCallBack implements FlatFileHeaderCallback {

	@Override
	public void writeHeader(Writer writer) throws IOException {
		writer.write("COD_BQ;ID_CLI;NOTE_DEFAUT;ID_SITUATION_TIERS");

	}

}

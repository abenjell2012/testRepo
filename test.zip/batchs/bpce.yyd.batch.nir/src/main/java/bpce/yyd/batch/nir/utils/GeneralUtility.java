package bpce.yyd.batch.nir.utils;

import java.io.File;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import fr.bpce.yyd.batch.commun.configuration.ConfigManager;
import fr.bpce.yyd.batch.commun.exception.InvalidInitialisationException;
import fr.bpce.yyd.batch.commun.exception.UnknownPropertyException;

public final class GeneralUtility {

	private GeneralUtility() {
	}

	public static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");

	public static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyyMMdd");

	private static String repOut;

	private static String env;

	public static void initConstants() throws UnknownPropertyException, InvalidInitialisationException {

		repOut = ConfigManager.getProperty("nir.rep.out");
		env = ConfigManager.getProperty("env");
	}

	public static String generateFileName(LocalDate dateMax) {

		
		LocalDateTime date = dateMax.atStartOfDay();
		StringBuilder name = new StringBuilder();
		name.append("MDC");
		if (!"PRD".equalsIgnoreCase(env) && !"PROD".equalsIgnoreCase(env)) {
			name.append("R");
		} else {
			name.append("");
		}
		name.append(".SURCHARGE.NIR.");
		name.append(date.format(TIME_FORMATTER));
		name.append(".csv");
		return name.toString();
	}

	public static String generateFilePath(LocalDate dateMax) {

		StringBuilder path = new StringBuilder(repOut);
		path.append(dateMax.format(DATE_FORMATTER));
		path.append(File.separator);
		return path.toString();
	}

	public static String getRepOut() {
		return repOut;
	}

	public static String getEnv() {
		return env;
	}

	public static void setEnv(String env) {
		GeneralUtility.env = env;
	}
	
}

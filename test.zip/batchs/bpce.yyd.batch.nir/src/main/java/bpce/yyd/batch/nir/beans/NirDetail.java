package bpce.yyd.batch.nir.beans;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class NirDetail {

	private String codeBanque;

	private String idLocal;

	private String gravite;

	private String idSituation;
}

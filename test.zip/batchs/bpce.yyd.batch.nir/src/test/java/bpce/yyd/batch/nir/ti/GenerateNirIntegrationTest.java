package bpce.yyd.batch.nir.ti;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import bpce.yyd.batch.nir.launch.Launcher;
import bpce.yyd.batch.nir.utils.GeneralUtility;
import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.commun.model.reference.RefCliSeg;
import fr.bpce.yyd.commun.model.reference.RefCliSsClass;
import fr.bpce.yyd.commun.model.restitution.RestAssociateRftSiren;
import fr.bpce.yyd.commun.model.restitution.RestSynthTierLocalStatus;
import fr.bpce.yyd.commun.model.restitution.RestTiersIdRft;
import fr.bpce.yyd.commun.model.restitution.RestTiersLocal;
import fr.bpce.yyd.commun.model.restitution.RestTiersSiren;

public class GenerateNirIntegrationTest extends AbstractIntegrationTest {

	private static String filePath;

	@BeforeClass
	public static void init() throws Exception {

		GeneralUtility.initConstants();
		initData();
		filePath = getRootPath() + GeneralUtility.generateFilePath(LocalDate.of(2020, 2, 8)) + GeneralUtility.generateFileName(LocalDate.of(2020, 2, 8));

		Launcher.setApplicationContext(context);
		Launcher.setRepOut(filePath);
		Launcher.setIsTest(true);
		Launcher.setLogFile("log4j-restit-nir-ti.properties");
	}

	private static void initData() {
		doInTransaction(() -> {
			initSynthese();
			initRef();
		});
	}

	private static void initRef() {

		RefCliSeg ref = new RefCliSeg("1100", "libelle6", "COR010");
		ref.setTopSuppr(Constant.FLAG_NON);
		getEntityManager().persist(ref);

		ref = new RefCliSeg("3120", "libelle11", "RETPRO");
		ref.setTopSuppr(Constant.FLAG_NON);
		getEntityManager().persist(ref);

		ref = new RefCliSeg("3210", "libelle12", "RETPAR");
		ref.setTopSuppr(Constant.FLAG_NON);
		getEntityManager().persist(ref);

		RefCliSsClass refSSclassPROF = new RefCliSsClass();
		refSSclassPROF.setCodTypNot("PROF");
		refSSclassPROF.setTopSuppr("N");
		refSSclassPROF.setLibSsClassCli("PROFESSIONNELS");
		refSSclassPROF.setCodClassCli("RET");
		refSSclassPROF.setCodSsClassCli("RETPRO");
		getEntityManager().persist(refSSclassPROF);

		RefCliSsClass refSSclassPART = new RefCliSsClass();
		refSSclassPART.setCodTypNot("PART");
		refSSclassPART.setTopSuppr("N");
		refSSclassPART.setLibSsClassCli("RETAIL");
		refSSclassPART.setCodClassCli("RET");
		refSSclassPART.setCodSsClassCli("RETPAR");
		getEntityManager().persist(refSSclassPART);

		RefCliSsClass refSSclassCORP = new RefCliSsClass();
		refSSclassCORP.setCodTypNot("CORP");
		refSSclassCORP.setTopSuppr("N");
		refSSclassCORP.setLibSsClassCli("ENTITES DU SECTEUR PUBLIC");
		refSSclassCORP.setCodClassCli("COR");
		refSSclassCORP.setCodSsClassCli("COR010");
		getEntityManager().persist(refSSclassCORP);
	}

	private static void initSynthese() {

		// idrft : 0000002870 ; cdbq : 10107 ; idlocal : 67936544
		RestTiersIdRft idRft = new RestTiersIdRft();
		idRft.setIdRft("0000002870");
		idRft.setCodeBanqueReferente("10107");
		getEntityManager().persist(idRft);

		RestAssociateRftSiren assoc = new RestAssociateRftSiren();
		assoc.setRestIdRFT(idRft);
		getEntityManager().persist(assoc);

		RestTiersLocal idlocal = new RestTiersLocal();
		idlocal.setRestAssoRftSiren(assoc);
		idlocal.setCodeBanque("10107");
		idlocal.setIdLocal("67936544");
		idlocal.setCodeSegment("1100");
		idlocal.setDateDebut(LocalDate.now().minusMonths(5L));
		getEntityManager().persist(idlocal);

		RestSynthTierLocalStatus status = new RestSynthTierLocalStatus();
		status.setRestRechTiersLocal(idlocal);
		status.setIdSyntheseTiers(1L);
		status.setDatePhoto(LocalDate.of(2019, 11, 10));
		status.setStatutEffectif("D");
		status.setDateMAJStatutEffectif(LocalDate.of(2019, 11, 10));
		status.setPalierEffectif("DX");
		getEntityManager().persist(status);

		status = new RestSynthTierLocalStatus();
		status.setRestRechTiersLocal(idlocal);
		status.setIdSyntheseTiers(2L);
		status.setDatePhoto(LocalDate.of(2020, 2, 8));
		status.setStatutEffectif("D");
		status.setDateMAJStatutEffectif(LocalDate.of(2020, 2, 8));
		status.setPalierEffectif("CX");
		getEntityManager().persist(status);

		// idrft : 0000002870 ; cdbq : 10107 ; idlocal : SI024055352

		idlocal = new RestTiersLocal();
		idlocal.setRestAssoRftSiren(assoc);
		idlocal.setCodeBanque("10107");
		idlocal.setIdLocal("SI024055352");
		idlocal.setCodeSegment("1100");
		idlocal.setDateDebut(LocalDate.now().minusMonths(5L));
		getEntityManager().persist(idlocal);

		status = new RestSynthTierLocalStatus();
		status.setRestRechTiersLocal(idlocal);
		status.setIdSyntheseTiers(3L);
		status.setDatePhoto(LocalDate.of(2019, 11, 10));
		status.setStatutEffectif("D");
		status.setDateMAJStatutEffectif(LocalDate.of(2019, 11, 10));
		status.setPalierEffectif("DX");
		getEntityManager().persist(status);

		status = new RestSynthTierLocalStatus();
		status.setRestRechTiersLocal(idlocal);
		status.setIdSyntheseTiers(4L);
		status.setDatePhoto(LocalDate.of(2020, 2, 8));
		status.setStatutEffectif("D");
		status.setDateMAJStatutEffectif(LocalDate.of(2020, 2, 8));
		status.setPalierEffectif("CX");
		getEntityManager().persist(status);

		// idrft : 0000002870 ; cdbq : 15007 ; idlocal : 24055352

		idlocal = new RestTiersLocal();
		idlocal.setRestAssoRftSiren(assoc);
		idlocal.setCodeBanque("15007");
		idlocal.setIdLocal("24055352");
		idlocal.setCodeSegment("1100");
		idlocal.setDateDebut(LocalDate.now().minusMonths(5L));
		getEntityManager().persist(idlocal);

		status = new RestSynthTierLocalStatus();
		status.setRestRechTiersLocal(idlocal);
		status.setIdSyntheseTiers(5L);
		status.setDatePhoto(LocalDate.of(2019, 11, 10));
		status.setStatutEffectif("D");
		status.setDateMAJStatutEffectif(LocalDate.of(2019, 11, 10));
		status.setPalierEffectif("DX");
		getEntityManager().persist(status);

		status = new RestSynthTierLocalStatus();
		status.setRestRechTiersLocal(idlocal);
		status.setIdSyntheseTiers(6L);
		status.setDatePhoto(LocalDate.of(2020, 2, 8));
		status.setStatutEffectif("D");
		status.setDateMAJStatutEffectif(LocalDate.of(2020, 2, 8));
		status.setPalierEffectif("CX");
		getEntityManager().persist(status);

		// idrft : 0000002748 ; cdbq : 42559; idlocal : 904208498
		idRft = new RestTiersIdRft();
		idRft.setIdRft("0000002748");
		idRft.setCodeBanqueReferente("42559");
		getEntityManager().persist(idRft);

		assoc = new RestAssociateRftSiren();
		assoc.setRestIdRFT(idRft);
		getEntityManager().persist(assoc);

		idlocal = new RestTiersLocal();
		idlocal.setRestAssoRftSiren(assoc);
		idlocal.setCodeBanque("42559");
		idlocal.setIdLocal("904208498");
		idlocal.setCodeSegment("3210");
		idlocal.setDateDebut(LocalDate.now().minusMonths(5L));
		getEntityManager().persist(idlocal);

		status = new RestSynthTierLocalStatus();
		status.setRestRechTiersLocal(idlocal);
		status.setIdSyntheseTiers(7L);
		status.setDatePhoto(LocalDate.of(2019, 11, 10));
		status.setStatutEffectif("ND");
		status.setDateMAJStatutEffectif(LocalDate.of(2019, 11, 10));
		getEntityManager().persist(status);

		status = new RestSynthTierLocalStatus();
		status.setRestRechTiersLocal(idlocal);
		status.setIdSyntheseTiers(8L);
		status.setDatePhoto(LocalDate.of(2020, 2, 8));
		status.setStatutEffectif("D");
		status.setDateMAJStatutEffectif(LocalDate.of(2020, 2, 8));
		status.setPalierEffectif("RX");
		getEntityManager().persist(status);

		// idrft : 0000002771 ; cdbq : 11315; idlocal : 75146771
		idRft = new RestTiersIdRft();
		idRft.setIdRft("0000002771");
		idRft.setCodeBanqueReferente("11315");
		getEntityManager().persist(idRft);

		assoc = new RestAssociateRftSiren();
		assoc.setRestIdRFT(idRft);
		getEntityManager().persist(assoc);

		idlocal = new RestTiersLocal();
		idlocal.setRestAssoRftSiren(assoc);
		idlocal.setCodeBanque("11315");
		idlocal.setIdLocal("75146771");
		idlocal.setCodeSegment("1100");
		idlocal.setDateDebut(LocalDate.now().minusMonths(5L));
		getEntityManager().persist(idlocal);

		status = new RestSynthTierLocalStatus();
		status.setRestRechTiersLocal(idlocal);
		status.setIdSyntheseTiers(9L);
		status.setDatePhoto(LocalDate.of(2019, 11, 10));
		status.setStatutEffectif("D");
		status.setDateMAJStatutEffectif(LocalDate.of(2019, 11, 10));
		status.setPalierEffectif("CX");
		getEntityManager().persist(status);

		status = new RestSynthTierLocalStatus();
		status.setRestRechTiersLocal(idlocal);
		status.setIdSyntheseTiers(10L);
		status.setDatePhoto(LocalDate.of(2020, 2, 8));
		status.setStatutEffectif("ND");
		status.setDateMAJStatutEffectif(LocalDate.of(2020, 2, 8));
		getEntityManager().persist(status);

		// retail 1 : avec assoc et dernier photo non defaut
		RestTiersSiren idSiren = new RestTiersSiren();
		idSiren.setSiren("11111");
		getEntityManager().persist(idSiren);

		assoc = new RestAssociateRftSiren();
		assoc.setRestIdSiren(idSiren);
		getEntityManager().persist(assoc);

		idlocal = new RestTiersLocal();
		idlocal.setRestAssoRftSiren(assoc);
		idlocal.setCodeBanque("15505");
		idlocal.setIdLocal("DONALD TRUMP");
		idlocal.setCodeSegment("3120");
		idlocal.setDateDebut(LocalDate.now().minusMonths(5L));
		getEntityManager().persist(idlocal);

		status = new RestSynthTierLocalStatus();
		status.setRestRechTiersLocal(idlocal);
		status.setIdSyntheseTiers(11L);
		status.setDatePhoto(LocalDate.of(2019, 11, 10));
		status.setStatutEffectif("D");
		status.setDateMAJStatutEffectif(LocalDate.of(2019, 11, 10));
		status.setPalierEffectif("CX");
		getEntityManager().persist(status);

		status = new RestSynthTierLocalStatus();
		status.setRestRechTiersLocal(idlocal);
		status.setIdSyntheseTiers(12L);
		status.setDatePhoto(LocalDate.of(2020, 2, 8));
		status.setStatutEffectif("ND");
		status.setDateMAJStatutEffectif(LocalDate.of(2020, 2, 8));
		getEntityManager().persist(status);

		// retail 2 : avec assoc
		idSiren = new RestTiersSiren();
		idSiren.setSiren("22222");
		getEntityManager().persist(idSiren);

		assoc = new RestAssociateRftSiren();
		assoc.setRestIdSiren(idSiren);
		getEntityManager().persist(assoc);

		idlocal = new RestTiersLocal();
		idlocal.setRestAssoRftSiren(assoc);
		idlocal.setCodeBanque("10107");
		idlocal.setIdLocal("MIKE TYSON");
		idlocal.setCodeSegment("3120");
		idlocal.setDateDebut(LocalDate.now().minusMonths(5L));
		getEntityManager().persist(idlocal);

		status = new RestSynthTierLocalStatus();
		status.setRestRechTiersLocal(idlocal);
		status.setIdSyntheseTiers(13L);
		status.setDatePhoto(LocalDate.of(2019, 11, 10));
		status.setStatutEffectif("ND");
		status.setDateMAJStatutEffectif(LocalDate.of(2019, 11, 10));
		getEntityManager().persist(status);

		status = new RestSynthTierLocalStatus();
		status.setRestRechTiersLocal(idlocal);
		status.setIdSyntheseTiers(14L);
		status.setDatePhoto(LocalDate.of(2020, 1, 9));
		status.setStatutEffectif("D");
		status.setDateMAJStatutEffectif(LocalDate.of(2020, 1, 9));
		status.setPalierEffectif("CX");
		getEntityManager().persist(status);

		// retail 3 : pas de assoc
		idlocal = new RestTiersLocal();
		idlocal.setCodeBanque("10107");
		idlocal.setIdLocal("NICOLAS CAGE");
		idlocal.setCodeSegment("3120");
		idlocal.setDateDebut(LocalDate.now().minusMonths(5L));
		getEntityManager().persist(idlocal);

		status = new RestSynthTierLocalStatus();
		status.setRestRechTiersLocal(idlocal);
		status.setIdSyntheseTiers(15L);
		status.setDatePhoto(LocalDate.of(2019, 11, 10));
		status.setStatutEffectif("ND");
		status.setDateMAJStatutEffectif(LocalDate.of(2019, 11, 10));
		getEntityManager().persist(status);

		status = new RestSynthTierLocalStatus();
		status.setRestRechTiersLocal(idlocal);
		status.setIdSyntheseTiers(16L);
		status.setDatePhoto(LocalDate.of(2020, 1, 20));
		status.setStatutEffectif("D");
		status.setDateMAJStatutEffectif(LocalDate.of(2020, 1, 20));
		status.setPalierEffectif("RX");
		getEntityManager().persist(status);

		// retail 4 : date fin not null
		idlocal = new RestTiersLocal();
		idlocal.setCodeBanque("10102");
		idlocal.setIdLocal("LARY KING");
		idlocal.setCodeSegment("3120");
		idlocal.setDateDebut(LocalDate.now().minusMonths(5L));
		idlocal.setDateFin(LocalDate.now().minusMonths(4L));
		getEntityManager().persist(idlocal);

		status = new RestSynthTierLocalStatus();
		status.setRestRechTiersLocal(idlocal);
		status.setIdSyntheseTiers(17L);
		status.setDatePhoto(LocalDate.of(2019, 11, 10));
		status.setStatutEffectif("ND");
		status.setDateMAJStatutEffectif(LocalDate.of(2019, 11, 10));
		getEntityManager().persist(status);

		status = new RestSynthTierLocalStatus();
		status.setRestRechTiersLocal(idlocal);
		status.setIdSyntheseTiers(18L);
		status.setDatePhoto(LocalDate.of(2020, 1, 20));
		status.setStatutEffectif("D");
		status.setDateMAJStatutEffectif(LocalDate.of(2020, 1, 20));
		status.setPalierEffectif("DX");
		getEntityManager().persist(status);

		// retail 5 : code segment null
		idlocal = new RestTiersLocal();
		idlocal.setCodeBanque("10102");
		idlocal.setIdLocal("MACRON");
		idlocal.setCodeSegment(null);
		idlocal.setDateDebut(LocalDate.now().minusMonths(5L));
		idlocal.setDateFin(LocalDate.now().minusMonths(4L));
		getEntityManager().persist(idlocal);

		status = new RestSynthTierLocalStatus();
		status.setRestRechTiersLocal(idlocal);
		status.setIdSyntheseTiers(18L);
		status.setDatePhoto(LocalDate.of(2019, 11, 10));
		status.setStatutEffectif("D");
		status.setDateMAJStatutEffectif(LocalDate.of(2019, 11, 10));
		status.setPalierEffectif("DX");
		getEntityManager().persist(status);

	}

	private static String getRootPath() {

		File test = new File("test");
		return test.getAbsolutePath().replace("/test", "");
	}

	@Test
	public void checkNirGeneration() throws Exception {

		Launcher.main(null);

		checkFileExist();
		checkFileContent();
	}

	public void checkFileExist() {

		Assert.assertTrue(new File(filePath).exists());
	}

	public void checkFileContent() throws IOException {

		File generatedFile = new File(filePath);
		BufferedReader bufferedReader = new BufferedReader(new FileReader(generatedFile));

		List<String> lines = new ArrayList<>();
		String line = null;
		while ((line = bufferedReader.readLine()) != null) {
			lines.add(line);
		}
		bufferedReader.close();

		Assert.assertTrue(lines.size() == 4);
		Assert.assertTrue(lines.get(0).equals("COD_BQ;ID_CLI;NOTE_DEFAUT;ID_SITUATION_TIERS"));
		Assert.assertTrue(lines.get(1).equals("42559;904208498;RX;8"));
		Assert.assertTrue(lines.get(2).equals("10107;MIKE TYSON;CX;14"));
		Assert.assertTrue(lines.get(3).equals("10107;NICOLAS CAGE;RX;16"));

	}

	@AfterClass
	public static void clearRepOut() {

		deleteDirectory(new File(getRootPath() + GeneralUtility.getRepOut()));
	}

	private static boolean deleteDirectory(File directoryToBeDeleted) {
		File[] allContents = directoryToBeDeleted.listFiles();
		if (allContents != null) {
			for (File file : allContents) {
				deleteDirectory(file);
			}
		}
		return directoryToBeDeleted.delete();
	}

}

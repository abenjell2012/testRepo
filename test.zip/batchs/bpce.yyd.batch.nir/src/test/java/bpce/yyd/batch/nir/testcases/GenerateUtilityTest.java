package bpce.yyd.batch.nir.testcases;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.net.URL;
import java.time.LocalDate;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import bpce.yyd.batch.nir.utils.GeneralUtility;
import fr.bpce.yyd.batch.commun.configuration.ConfigManager;
import fr.bpce.yyd.batch.commun.exception.InvalidInitialisationException;
import fr.bpce.yyd.batch.commun.exception.UnknownPropertyException;

public class GenerateUtilityTest {

	private static Properties properties;

	@BeforeClass
	public static void initProperties() throws Exception {
		// Chargement du fichier de propriétés des TI
		URL url = ClassLoader.getSystemClassLoader().getResource("config-ti.properties");
		String filename = url.getPath();
		properties = new Properties();
		InputStream input = new FileInputStream(filename);
		properties.load(input);
		input.close();

		// Utilisation de ces propriétés pour le ConfigManager
		Field propertiesField = ConfigManager.class.getDeclaredField("properties");
		propertiesField.setAccessible(true);
		propertiesField.set(null, properties);
	}

	@Test
	public void checkInitConstants() throws UnknownPropertyException, InvalidInitialisationException {

		GeneralUtility.initConstants();

		Assert.assertTrue("/src/test/resources/ti/out/".equals(GeneralUtility.getRepOut()));
		Assert.assertTrue("dev".equals(GeneralUtility.getEnv()));
	}

	@Test
	public void checkGenerateFileName() throws UnknownPropertyException, InvalidInitialisationException {

		GeneralUtility.initConstants();
		Pattern p = Pattern.compile(("(MDC)[a-zA-Z]*[\\.](SURCHARGE)[\\.](NIR)[\\.][0-9]{14}[\\.](csv)"));

		Matcher m = p.matcher(GeneralUtility.generateFileName(LocalDate.now()));
		Assert.assertTrue(m.matches());

		GeneralUtility.setEnv("PRD");
		m = p.matcher(GeneralUtility.generateFileName(LocalDate.now()));
		Assert.assertTrue(m.matches());

		GeneralUtility.setEnv("PROD");
		m = p.matcher(GeneralUtility.generateFileName(LocalDate.now()));
		Assert.assertTrue(m.matches());
	}

	@Test
	public void checkGenerateFilePath() throws UnknownPropertyException, InvalidInitialisationException {

		GeneralUtility.initConstants();
		String expectedPath = GeneralUtility.getRepOut() + LocalDate.now().format(GeneralUtility.DATE_FORMATTER)
				+ File.separator;
		Assert.assertTrue(expectedPath.equals(GeneralUtility.generateFilePath(LocalDate.now())));
	}

}
